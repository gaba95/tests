﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("compensaciones", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Compensations
    {
        public int tipoCompensacion { get; set; }

        [JsonProperty("descripcion")]
        public string valorDescripcion { get; set; } = "";

        public decimal valor { get; set; }
    }
}

﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public static class SafeProcedures
    {
        public static Dictionary<string, string> WhiteList { get; } = new Dictionary<string, string>
        {
            { "sp_acumulados_recibo", "sp_acumulados_recibo" }
        };
    }
}

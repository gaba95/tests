using ADAM.Recibos.Principal.Clases;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;

namespace ADAM.Recibos.Principal.Tests.Classes.Helpers
{
    [TestClass]
    public class PayrollHelperTests
    {
        #region InsertaIncapacidadesRecibo

        [TestMethod]
        public void InsertaIncapacidadesRecibo_ValidXml_AddsIncapacidadNodes()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var incapacidades = new DataTable();
            incapacidades.Columns.Add("DiasIncapacidad", typeof(string));
            incapacidades.Columns.Add("TipoIncapacidad", typeof(string));
            incapacidades.Columns.Add("Descuento", typeof(string));
            incapacidades.Rows.Add("5", "01", "1000.00");
            incapacidades.Rows.Add("3", "02", "500.00");

            var result = PayrollHelper.InsertaIncapacidadesRecibo(recibo, incapacidades);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("Incapacidades"));
            Assert.IsTrue(result.Contains("Incapacidad"));
            Assert.IsTrue(result.Contains("DiasIncapacidad=\"5\""));
            Assert.IsTrue(result.Contains("TipoIncapacidad=\"01\""));
            Assert.IsTrue(result.Contains("Descuento=\"1000.00\""));
            Assert.IsTrue(result.Contains("DiasIncapacidad=\"3\""));
        }

        [TestMethod]
        public void InsertaIncapacidadesRecibo_InvalidXml_ReturnsOriginalRecibo()
        {
            string recibo = "invalid xml content";
            var incapacidades = new DataTable();

            var result = PayrollHelper.InsertaIncapacidadesRecibo(recibo, incapacidades);

            Assert.AreEqual(recibo, result);
        }

        [TestMethod]
        public void InsertaIncapacidadesRecibo_EmptyDataTable_ReturnsXmlWithEmptyIncapacidades()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var incapacidades = new DataTable();
            incapacidades.Columns.Add("DiasIncapacidad", typeof(string));
            incapacidades.Columns.Add("TipoIncapacidad", typeof(string));
            incapacidades.Columns.Add("Descuento", typeof(string));

            var result = PayrollHelper.InsertaIncapacidadesRecibo(recibo, incapacidades);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("Incapacidades"));
        }

        #endregion

        #region InsertaHorasExtraRecibo

        [TestMethod]
        public void InsertaHorasExtraRecibo_ValidXml_AddsHorasExtraNodes()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var horasExtra = new DataTable();
            horasExtra.Columns.Add("Dias", typeof(string));
            horasExtra.Columns.Add("TipoHoras", typeof(string));
            horasExtra.Columns.Add("HorasExtra", typeof(string));
            horasExtra.Columns.Add("ImportePagado", typeof(string));
            horasExtra.Rows.Add("2", "01", "4", "350.00");

            var result = PayrollHelper.InsertaHorasExtraRecibo(recibo, horasExtra);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("HorasExtras"));
            Assert.IsTrue(result.Contains("HorasExtra"));
            Assert.IsTrue(result.Contains("Dias=\"2\""));
            Assert.IsTrue(result.Contains("TipoHoras=\"01\""));
            Assert.IsTrue(result.Contains("ImportePagado=\"350.00\""));
        }

        [TestMethod]
        public void InsertaHorasExtraRecibo_InvalidXml_ReturnsOriginalRecibo()
        {
            string recibo = "not valid xml";
            var horasExtra = new DataTable();

            var result = PayrollHelper.InsertaHorasExtraRecibo(recibo, horasExtra);

            Assert.AreEqual(recibo, result);
        }

        #endregion

        #region InsertaAdicionales

        [TestMethod]
        public void InsertaAdicionales_Nomina12_AddsAdicionalesWithNomina12Namespace()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina12"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var adicionales = new DataTable();
            adicionales.Columns.Add("campo_01", typeof(string));
            adicionales.Columns.Add("campo_02", typeof(string));
            adicionales.Rows.Add("valor1", "valor2");

            var result = PayrollHelper.InsertaAdicionales(recibo, adicionales, "nomina12.xsd");

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("Adicional"));
        }

        [TestMethod]
        public void InsertaAdicionales_LegacyNomina_AddsAdicionalesWithLegacyNamespace()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var adicionales = new DataTable();
            adicionales.Columns.Add("campo_01", typeof(string));
            adicionales.Rows.Add("valor1");

            var result = PayrollHelper.InsertaAdicionales(recibo, adicionales, "nomina.xsd");

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("Adicional"));
        }

        [TestMethod]
        public void InsertaAdicionales_WithTipoRegistro_CreatesNamedElements()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina12"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var adicionales = new DataTable();
            adicionales.Columns.Add("tipo_registro", typeof(string));
            adicionales.Columns.Add("tipo_checada", typeof(string));
            adicionales.Columns.Add("campo_01", typeof(string));
            adicionales.Rows.Add("1", "1_entradas", "08:00");

            var result = PayrollHelper.InsertaAdicionales(recibo, adicionales, "nomina12.xsd");

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("Adicional02"));
        }

        [TestMethod]
        public void InsertaAdicionales_InvalidXml_ReturnsOriginalRecibo()
        {
            string recibo = "not valid xml";
            var adicionales = new DataTable();

            var result = PayrollHelper.InsertaAdicionales(recibo, adicionales, "nomina12.xsd");

            Assert.AreEqual(recibo, result);
        }

        [TestMethod]
        public void InsertaAdicionales_EmptyTipoChecada_ExcludesExtraColumns()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina12"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var adicionales = new DataTable();
            adicionales.Columns.Add("tipo_registro", typeof(string));
            adicionales.Columns.Add("tipo_checada", typeof(string));
            adicionales.Columns.Add("campo_01", typeof(string));
            adicionales.Columns.Add("campo_05", typeof(string));
            adicionales.Columns.Add("campo_06", typeof(string));
            adicionales.Columns.Add("campo_07", typeof(string));
            adicionales.Rows.Add("1", "", "val1", "val5", "val6", "val7");

            var result = PayrollHelper.InsertaAdicionales(recibo, adicionales, "nomina12.xsd");

            Assert.IsNotNull(result);
            // campo_05, campo_06, campo_07 should be excluded when tipo_checada is empty
            Assert.IsFalse(result.Contains("campo_05"));
        }

        #endregion

        #region InsertaNodoTimbradoRelacionado

        [TestMethod]
        public void InsertaNodoTimbradoRelacionado_ValidXml_AddsCfdiRelacionados()
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"">
  <cfdi:Complemento/>
</cfdi:Comprobante>";

            var result = PayrollHelper.InsertaNodoTimbradoRelacionado(recibo);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains("CfdiRelacionados"));
            Assert.IsTrue(result.Contains("CfdiRelacionado"));
            Assert.IsTrue(result.Contains("TipoRelacion=\"04\""));
            Assert.IsTrue(result.Contains("UUID=\"\""));
        }

        [TestMethod]
        public void InsertaNodoTimbradoRelacionado_InvalidXml_ReturnsOriginalRecibo()
        {
            string recibo = "invalid xml";

            var result = PayrollHelper.InsertaNodoTimbradoRelacionado(recibo);

            Assert.AreEqual(recibo, result);
        }

        #endregion

        #region TipoChecada Switch Coverage

        [TestMethod]
        [DataRow("2_salidas", "Adicional03")]
        [DataRow("3_horas", "Adicional04")]
        [DataRow("4_horas_extra", "Adicional05")]
        [DataRow("6_retardos", "Adicional06")]
        [DataRow("7_salidas_temprano", "Adicional07")]
        [DataRow("unknown", "Adicional01")]
        public void InsertaAdicionales_DifferentTipoChecada_CreatesCorrectElement(string tipoChecada, string expectedElement)
        {
            string recibo = @"<?xml version=""1.0"" encoding=""utf-8""?>
<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/3"" xmlns:nomina=""http://www.sat.gob.mx/nomina12"">
  <cfdi:Complemento>
    <nomina:Nomina/>
  </cfdi:Complemento>
</cfdi:Comprobante>";

            var adicionales = new DataTable();
            adicionales.Columns.Add("tipo_registro", typeof(string));
            adicionales.Columns.Add("tipo_checada", typeof(string));
            adicionales.Columns.Add("campo_01", typeof(string));
            adicionales.Rows.Add("1", tipoChecada, "value");

            var result = PayrollHelper.InsertaAdicionales(recibo, adicionales, "nomina12.xsd");

            Assert.IsTrue(result.Contains(expectedElement));
        }

        #endregion
    }
}

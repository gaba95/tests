#nullable enable
namespace ADAM.MIIA.Configurador.UI;

partial class frmModificaProcedure
{
    private System.ComponentModel.IContainer? components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmModificaProcedure));
        cmdAceptar = new Button();
        cmdCancelar = new Button();
        txtProcedure2 = new TextBox();
        lblServicio = new Label();
        pnlBotones = new Panel();
        txtProcedure = new TextBox();
        pnlSuperior = new Panel();
        lblTitulo = new Label();
        lblDescripcion = new Label();
        txtTabla = new TextBox();
        lblTabla = new Label();
        pnlBotones.SuspendLayout();
        pnlSuperior.SuspendLayout();
        SuspendLayout();
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdAceptar.DialogResult = DialogResult.Cancel;
        cmdAceptar.FlatStyle = FlatStyle.Popup;
        cmdAceptar.Location = new Point(230, 2);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 0;
        cmdAceptar.Text = "Guardar";
        cmdAceptar.UseVisualStyleBackColor = true;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.FlatStyle = FlatStyle.Popup;
        cmdCancelar.Location = new Point(360, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cerrar";
        cmdCancelar.UseVisualStyleBackColor = true;
        // 
        // txtProcedure2
        // 
        txtProcedure2.BorderStyle = BorderStyle.FixedSingle;
        txtProcedure2.Location = new Point(160, 110);
        txtProcedure2.MaxLength = 200;
        txtProcedure2.Name = "txtProcedure2";
        txtProcedure2.Size = new Size(250, 28);
        txtProcedure2.TabIndex = 16;
        // 
        // lblServicio
        // 
        lblServicio.AutoSize = true;
        lblServicio.Location = new Point(10, 110);
        lblServicio.Name = "lblServicio";
        lblServicio.Size = new Size(147, 23);
        lblServicio.TabIndex = 15;
        lblServicio.Text = "Procedimiento 2:";
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Controls.Add(cmdAceptar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 228);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(494, 40);
        pnlBotones.TabIndex = 17;
        // 
        // txtProcedure
        // 
        txtProcedure.BorderStyle = BorderStyle.FixedSingle;
        txtProcedure.Location = new Point(160, 80);
        txtProcedure.MaxLength = 100;
        txtProcedure.Name = "txtProcedure";
        txtProcedure.Size = new Size(250, 28);
        txtProcedure.TabIndex = 14;
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(92, 145, 163);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(494, 30);
        pnlSuperior.TabIndex = 10;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 10.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(10, 5);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(333, 27);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Configuración por Procedimiento";
        // 
        // lblDescripcion
        // 
        lblDescripcion.AutoSize = true;
        lblDescripcion.Location = new Point(10, 80);
        lblDescripcion.Name = "lblDescripcion";
        lblDescripcion.Size = new Size(133, 23);
        lblDescripcion.TabIndex = 13;
        lblDescripcion.Text = "Procedimiento:";
        // 
        // txtTabla
        // 
        txtTabla.BorderStyle = BorderStyle.FixedSingle;
        txtTabla.Location = new Point(160, 50);
        txtTabla.MaxLength = 50;
        txtTabla.Name = "txtTabla";
        txtTabla.Size = new Size(250, 28);
        txtTabla.TabIndex = 12;
        txtTabla.Leave += txtTabla_Leave;
        // 
        // lblTabla
        // 
        lblTabla.AutoSize = true;
        lblTabla.Location = new Point(10, 50);
        lblTabla.Name = "lblTabla";
        lblTabla.Size = new Size(58, 23);
        lblTabla.TabIndex = 11;
        lblTabla.Text = "Tabla:";
        // 
        // frmModificaProcedure
        // 
        AcceptButton = cmdAceptar;
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        CancelButton = cmdCancelar;
        ClientSize = new Size(494, 268);
        Controls.Add(txtProcedure2);
        Controls.Add(lblServicio);
        Controls.Add(pnlBotones);
        Controls.Add(txtProcedure);
        Controls.Add(pnlSuperior);
        Controls.Add(lblDescripcion);
        Controls.Add(txtTabla);
        Controls.Add(lblTabla);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        Icon = (Icon)resources.GetObject("$this.Icon");
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "frmModificaProcedure";
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Modifica Procedure";
        Load += frmModificaProcedure_Load;
        pnlBotones.ResumeLayout(false);
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    private Button cmdAceptar;
    private Button cmdCancelar;
    private TextBox txtProcedure2;
    private Label lblServicio;
    private Panel pnlBotones;
    private TextBox txtProcedure;
    private Panel pnlSuperior;
    private Label lblTitulo;
    private Label lblDescripcion;
    private TextBox txtTabla;
    private Label lblTabla;
}

using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class DianModelTests
    {
        #region Employer

        [TestMethod]
        public void Employer_Properties_SetAndGet()
        {
            var employer = new Employer
            {
                razonSocial = "Empresa SA",
                primerApellido = "García",
                segundoApellido = "López",
                primerNombre = "Carlos",
                otrosNombres = "",
                nit = "900123456",
                dv = 7,
                pais = "CO",
                departamentoEstado = "Bogotá",
                municipioCiudad = "Bogotá",
                direccion = "Calle 100 #10-20",
                email = "empresa@test.com",
                telefono = "3001234567",
                codigoPostal = "110111",
                codigoSucursal = "001",
                nombreSucursal = "Principal",
                tipoIdentificacion = "NIT"
            };

            Assert.AreEqual("Empresa SA", employer.razonSocial);
            Assert.AreEqual(7, employer.dv);
            Assert.AreEqual("CO", employer.pais);
            Assert.AreEqual("NIT", employer.tipoIdentificacion);
        }

        [TestMethod]
        public void Employer_Serialization_RoundTrip()
        {
            var employer = new Employer { razonSocial = "Test SA", nit = "123", dv = 5 };
            var json = JsonConvert.SerializeObject(employer);
            var deserialized = JsonConvert.DeserializeObject<Employer>(json);

            Assert.AreEqual("Test SA", deserialized!.razonSocial);
            Assert.AreEqual("123", deserialized.nit);
            Assert.AreEqual(5, deserialized.dv);
        }

        #endregion

        #region Period

        [TestMethod]
        public void Period_Properties_SetAndGet()
        {
            var period = new Period
            {
                FechaPagoInicio = "2026-01-01",
                FechaPagoFin = "2026-01-31",
                FechaGen = "2026-02-01"
            };

            Assert.AreEqual("2026-01-01", period.FechaPagoInicio);
            Assert.AreEqual("2026-01-31", period.FechaPagoFin);
            Assert.AreEqual("2026-02-01", period.FechaGen);
        }

        [TestMethod]
        public void Period_JsonPropertyNames_AreCorrect()
        {
            var period = new Period { FechaPagoInicio = "2026-01-01", FechaPagoFin = "2026-01-31", FechaGen = "2026-02-01" };
            var json = JsonConvert.SerializeObject(period);

            Assert.IsTrue(json.Contains("\"fechaLiquidacionInicio\""));
            Assert.IsTrue(json.Contains("\"fechaLiquidacionFinal\""));
            Assert.IsTrue(json.Contains("\"fechaGeneracion\""));
        }

        #endregion

        #region Payment

        [TestMethod]
        public void Payment_Properties_SetAndGet()
        {
            var payment = new Payment
            {
                forma = 1,
                metodo = "10",
                banco = "Bancolombia",
                tipoCuenta = "Ahorros",
                numeroCuenta = "12345678"
            };

            Assert.AreEqual(1, payment.forma);
            Assert.AreEqual("10", payment.metodo);
            Assert.AreEqual("Bancolombia", payment.banco);
        }

        #endregion

        #region PaymentDates

        [TestMethod]
        public void PaymentDates_Properties_SetAndGet()
        {
            var pd = new PaymentDates { fechaPago = "2026-01-15" };
            Assert.AreEqual("2026-01-15", pd.fechaPago);
        }

        #endregion

        #region GeneralInformation

        [TestMethod]
        public void GeneralInformation_Properties_SetAndGet()
        {
            var info = new GeneralInformation
            {
                nominaAjuste = true,
                periodoNomina = "5"
            };

            Assert.IsTrue(info.nominaAjuste);
            Assert.AreEqual("5", info.periodoNomina);
        }

        #endregion

        #region PlaceGenerationXML

        [TestMethod]
        public void PlaceGenerationXML_Properties_SetAndGet()
        {
            var place = new PlaceGenerationXML
            {
                Pais = "CO",
                DepartamentoEstado = "11",
                MunicipioCiudad = "11001",
                Idioma = "es"
            };

            Assert.AreEqual("CO", place.Pais);
            Assert.AreEqual("11", place.DepartamentoEstado);
            Assert.AreEqual("11001", place.MunicipioCiudad);
            Assert.AreEqual("es", place.Idioma);
        }

        #endregion

        #region XMLSequenceNumber

        [TestMethod]
        public void XMLSequenceNumber_Properties_SetAndGet()
        {
            var seq = new XMLSequenceNumber
            {
                CodigoTrabajador = "T001",
                Prefijo = "NE",
                Consecutivo = "0001",
                Numero = "NE0001"
            };

            Assert.AreEqual("T001", seq.CodigoTrabajador);
            Assert.AreEqual("NE", seq.Prefijo);
            Assert.AreEqual("0001", seq.Consecutivo);
            Assert.AreEqual("NE0001", seq.Numero);
        }

        [TestMethod]
        public void XMLSequenceNumber_JsonPropertyNames_AreCorrect()
        {
            var seq = new XMLSequenceNumber { CodigoTrabajador = "T1", Prefijo = "P", Consecutivo = "1", Numero = "P1" };
            var json = JsonConvert.SerializeObject(seq);

            Assert.IsTrue(json.Contains("\"codigoTrabajador\""));
            Assert.IsTrue(json.Contains("\"prefijo\""));
            Assert.IsTrue(json.Contains("\"consecutivo\""));
            Assert.IsTrue(json.Contains("\"numero\""));
        }

        #endregion

        #region PredecessorInformation

        [TestMethod]
        public void PredecessorInformation_Properties_SetAndGet()
        {
            var info = new PredecessorInformation
            {
                cunePred = "CUNE123",
                numeroPred = "NE001",
                fechaGenPred = "2026-01-01",
                tipoNota = 2
            };

            Assert.AreEqual("CUNE123", info.cunePred);
            Assert.AreEqual("NE001", info.numeroPred);
            Assert.AreEqual("2026-01-01", info.fechaGenPred);
            Assert.AreEqual(2, info.tipoNota);
        }

        #endregion

        #region Basic

        [TestMethod]
        public void Basic_DefaultValues()
        {
            var basic = new Basic();
            Assert.AreEqual(0, basic.SueldoTrabajadoCantidad);
            Assert.AreEqual(0.0M, basic.SueldoTrabajado);
        }

        [TestMethod]
        public void Basic_Properties_SetAndGet()
        {
            var basic = new Basic { SueldoTrabajadoCantidad = 30, SueldoTrabajado = 2500000m };
            Assert.AreEqual(30, basic.SueldoTrabajadoCantidad);
            Assert.AreEqual(2500000m, basic.SueldoTrabajado);
        }

        [TestMethod]
        public void Basic_JsonPropertyNames_AreCorrect()
        {
            var basic = new Basic { SueldoTrabajadoCantidad = 15, SueldoTrabajado = 1000m };
            var json = JsonConvert.SerializeObject(basic);

            Assert.IsTrue(json.Contains("\"diasTrabajados\""));
            Assert.IsTrue(json.Contains("\"sueldoTrabajado\""));
        }

        #endregion

        #region Transport

        [TestMethod]
        public void Transport_Properties_SetAndGet()
        {
            var transport = new Transport
            {
                AuxilioTransporte = 140606m,
                ViaticoManuAlojS = 50000m,
                ViaticoManuAlojNS = 30000m
            };

            Assert.AreEqual(140606m, transport.AuxilioTransporte);
            Assert.AreEqual(50000m, transport.ViaticoManuAlojS);
            Assert.AreEqual(30000m, transport.ViaticoManuAlojNS);
        }

        #endregion

        #region Health

        [TestMethod]
        public void Health_Properties_SetAndGet()
        {
            var health = new Health { DeduccionPorcentaje = 4.0m, Deduccion = 100000m };
            Assert.AreEqual(4.0m, health.DeduccionPorcentaje);
            Assert.AreEqual(100000m, health.Deduccion);
        }

        #endregion

        #region PensionFund

        [TestMethod]
        public void PensionFund_Properties_SetAndGet()
        {
            var pf = new PensionFund { DeduccionPorcentaje = 4.0m, Deduccion = 100000m };
            Assert.AreEqual(4.0m, pf.DeduccionPorcentaje);
            Assert.AreEqual(100000m, pf.Deduccion);
        }

        #endregion

        #region PensionfundSP

        [TestMethod]
        public void PensionfundSP_Properties_SetAndGet()
        {
            var pfsp = new PensionfundSP
            {
                DeduccionSPPorcentaje = 12.0m,
                DeduccionSP = 300000m,
                DeduccionSubPorcentaje = 0.5m,
                DeduccionSub = 12500m
            };

            Assert.AreEqual(12.0m, pfsp.DeduccionSPPorcentaje);
            Assert.AreEqual(300000m, pfsp.DeduccionSP);
            Assert.AreEqual(0.5m, pfsp.DeduccionSubPorcentaje);
            Assert.AreEqual(12500m, pfsp.DeduccionSub);
        }

        #endregion

        #region Compensations

        [TestMethod]
        public void Compensations_Properties_SetAndGet()
        {
            var comp = new Compensations
            {
                tipoCompensacion = 1,
                valorDescripcion = "Bono extraordinario",
                valor = 500000m
            };

            Assert.AreEqual(1, comp.tipoCompensacion);
            Assert.AreEqual("Bono extraordinario", comp.valorDescripcion);
            Assert.AreEqual(500000m, comp.valor);
        }

        [TestMethod]
        public void Compensations_DefaultDescripcion_IsEmpty()
        {
            var comp = new Compensations();
            Assert.AreEqual("", comp.valorDescripcion);
        }

        #endregion

        #region Holidays

        [TestMethod]
        public void Holidays_Properties_SetAndGet()
        {
            var holidays = new Holidays
            {
                vacacionesCompensadas = true,
                FechaInicio = "2026-07-01",
                FechaFin = "2026-07-15",
                PagoCantidad = 15,
                Pago = 1250000m
            };

            Assert.IsTrue(holidays.vacacionesCompensadas);
            Assert.AreEqual("2026-07-01", holidays.FechaInicio);
            Assert.AreEqual(15, holidays.PagoCantidad);
            Assert.AreEqual(1250000m, holidays.Pago);
        }

        #endregion

        #region Premiums

        [TestMethod]
        public void Premiums_Properties_SetAndGet()
        {
            var premiums = new Premiums
            {
                CantidadCantidad = 180,
                Pago = 1250000m,
                PagoNS = 50000m,
                Cantidad = 180.5m,
                PagoNSCantidad = 5
            };

            Assert.AreEqual(180, premiums.CantidadCantidad);
            Assert.AreEqual(1250000m, premiums.Pago);
            Assert.AreEqual(50000m, premiums.PagoNS);
        }

        #endregion

        #region Layoffs

        [TestMethod]
        public void Layoffs_Properties_SetAndGet()
        {
            var layoffs = new Layoffs
            {
                Pago = 2500000m,
                PagoInteresesPorcentaje = 12,
                PagoIntereses = 300000m
            };

            Assert.AreEqual(2500000m, layoffs.Pago);
            Assert.AreEqual(12, layoffs.PagoInteresesPorcentaje);
            Assert.AreEqual(300000m, layoffs.PagoIntereses);
        }

        #endregion

        #region LayoffsInt

        [TestMethod]
        public void LayoffsInt_Properties_SetAndGet()
        {
            var layoffs = new LayoffsInt
            {
                Pago = 3000000m,
                PagoInteresesPorcentaje = 12.5m,
                PagoIntereses = 375000m
            };

            Assert.AreEqual(3000000m, layoffs.Pago);
            Assert.AreEqual(12.5m, layoffs.PagoInteresesPorcentaje);
            Assert.AreEqual(375000m, layoffs.PagoIntereses);
        }

        #endregion

        #region Disabilities

        [TestMethod]
        public void Disabilities_Properties_SetAndGet()
        {
            var disability = new Disabilities
            {
                FechaInicio = "2026-03-01",
                FechaFin = "2026-03-10",
                PagoCantidad = 10,
                TipoIncapacidad = 1,
                Pago = 500000m
            };

            Assert.AreEqual("2026-03-01", disability.FechaInicio);
            Assert.AreEqual("2026-03-10", disability.FechaFin);
            Assert.AreEqual(10, disability.PagoCantidad);
            Assert.AreEqual(1, disability.TipoIncapacidad);
            Assert.AreEqual(500000m, disability.Pago);
        }

        #endregion

        #region Licenses

        [TestMethod]
        public void Licenses_Properties_SetAndGet()
        {
            var license = new Licenses
            {
                tipoLicencia = 1,
                Pago = 300000m,
                PagoCantidad = 5,
                FechaInicio = "2026-04-01",
                FechaFin = "2026-04-05"
            };

            Assert.AreEqual(1, license.tipoLicencia);
            Assert.AreEqual(300000m, license.Pago);
            Assert.AreEqual(5, license.PagoCantidad);
        }

        #endregion

        #region Bonus

        [TestMethod]
        public void Bonus_Properties_SetAndGet()
        {
            var bonus = new Bonus
            {
                valorDescripcion = "Productividad",
                valor = 200000m,
                esSalarial = true
            };

            Assert.AreEqual("Productividad", bonus.valorDescripcion);
            Assert.AreEqual(200000m, bonus.valor);
            Assert.IsTrue(bonus.esSalarial);
        }

        [TestMethod]
        public void Bonus_DefaultDescripcion_IsEmpty()
        {
            var bonus = new Bonus();
            Assert.AreEqual("", bonus.valorDescripcion);
        }

        #endregion

        #region Attendances

        [TestMethod]
        public void Attendances_Properties_SetAndGet()
        {
            var att = new Attendances
            {
                AuxilioSDescripcion = "Auxilio alimentación",
                AuxilioS = 100000m,
                esSalarial = false
            };

            Assert.AreEqual("Auxilio alimentación", att.AuxilioSDescripcion);
            Assert.AreEqual(100000m, att.AuxilioS);
            Assert.IsFalse(att.esSalarial);
        }

        [TestMethod]
        public void Attendances_DefaultDescripcion_IsEmpty()
        {
            var att = new Attendances();
            Assert.AreEqual("", att.AuxilioSDescripcion);
        }

        #endregion

        #region Strikes

        [TestMethod]
        public void Strikes_Properties_SetAndGet()
        {
            var strike = new Strikes
            {
                fechaInicio = "2026-05-01",
                fechaFin = "2026-05-03",
                cantidad = 3
            };

            Assert.AreEqual("2026-05-01", strike.fechaInicio);
            Assert.AreEqual("2026-05-03", strike.fechaFin);
            Assert.AreEqual(3, strike.cantidad);
        }

        #endregion

        #region OtherConcepts

        [TestMethod]
        public void OtherConcepts_Properties_SetAndGet()
        {
            var oc = new OtherConcepts
            {
                valorDescripcionConcepto = "Concepto especial",
                valor = 150000m,
                esParteSalario = true
            };

            Assert.AreEqual("Concepto especial", oc.valorDescripcionConcepto);
            Assert.AreEqual(150000m, oc.valor);
            Assert.IsTrue(oc.esParteSalario);
        }

        [TestMethod]
        public void OtherConcepts_DefaultDescripcion_IsEmpty()
        {
            var oc = new OtherConcepts();
            Assert.AreEqual("", oc.valorDescripcionConcepto);
        }

        #endregion

        #region EPCTVBonds

        [TestMethod]
        public void EPCTVBonds_Properties_SetAndGet()
        {
            var bond = new EPCTVBonds
            {
                valorDescripcion = "Bono EPCTV",
                valor = 100000m,
                esParteSalario = false,
                esPagoAlimentacion = true
            };

            Assert.AreEqual("Bono EPCTV", bond.valorDescripcion);
            Assert.AreEqual(100000m, bond.valor);
            Assert.IsFalse(bond.esParteSalario);
            Assert.IsTrue(bond.esPagoAlimentacion);
        }

        [TestMethod]
        public void EPCTVBonds_DefaultDescripcion_IsEmpty()
        {
            var bond = new EPCTVBonds();
            Assert.AreEqual("", bond.valorDescripcion);
        }

        #endregion

        #region Commissions

        [TestMethod]
        public void Commissions_Properties_SetAndGet()
        {
            var comm = new Commissions
            {
                ComisionDescripcion = "Venta directa",
                Comision = 350000m
            };

            Assert.AreEqual("Venta directa", comm.ComisionDescripcion);
            Assert.AreEqual(350000m, comm.Comision);
        }

        [TestMethod]
        public void Commissions_DefaultDescripcion_IsEmpty()
        {
            var comm = new Commissions();
            Assert.AreEqual("", comm.ComisionDescripcion);
        }

        #endregion

        #region Unions

        [TestMethod]
        public void Unions_Properties_SetAndGet()
        {
            var union = new Unions
            {
                DeduccionPorcentaje = 1.5m,
                Deduccion = 37500m
            };

            Assert.AreEqual(1.5m, union.DeduccionPorcentaje);
            Assert.AreEqual(37500m, union.Deduccion);
        }

        #endregion

        #region Sanctions

        [TestMethod]
        public void Sanctions_Properties_SetAndGet()
        {
            var sanction = new Sanctions
            {
                valorDeduccionDescripcion = "Sanción disciplinaria",
                valorDeduccion = 50000m,
                tipoSancion = true
            };

            Assert.AreEqual("Sanción disciplinaria", sanction.valorDeduccionDescripcion);
            Assert.AreEqual(50000m, sanction.valorDeduccion);
            Assert.IsTrue(sanction.tipoSancion);
        }

        [TestMethod]
        public void Sanctions_DefaultDescripcion_IsEmpty()
        {
            var s = new Sanctions();
            Assert.AreEqual("", s.valorDeduccionDescripcion);
        }

        #endregion

        #region Orders

        [TestMethod]
        public void Orders_Properties_SetAndGet()
        {
            var order = new Orders
            {
                DeduccionDescripcion = "Libranza vivienda",
                Deduccion = 500000m
            };

            Assert.AreEqual("Libranza vivienda", order.DeduccionDescripcion);
            Assert.AreEqual(500000m, order.Deduccion);
        }

        [TestMethod]
        public void Orders_DefaultDescripcion_IsEmpty()
        {
            var o = new Orders();
            Assert.AreEqual("", o.DeduccionDescripcion);
        }

        #endregion

        #region OtherDiscounts

        [TestMethod]
        public void OtherDiscounts_Properties_SetAndGet()
        {
            var od = new OtherDiscounts
            {
                OtraDeduccionDescripcion = "Descuento especial",
                OtraDeduccion = 75000m
            };

            Assert.AreEqual("Descuento especial", od.OtraDeduccionDescripcion);
            Assert.AreEqual(75000m, od.OtraDeduccion);
        }

        [TestMethod]
        public void OtherDiscounts_DefaultDescripcion_IsEmpty()
        {
            var od = new OtherDiscounts();
            Assert.AreEqual("", od.OtraDeduccionDescripcion);
        }

        #endregion

        #region ThirdPartyPayments

        [TestMethod]
        public void ThirdPartyPayments_Properties_SetAndGet()
        {
            var tpp = new ThirdPartyPayments
            {
                PagoTerceroDescripcion = "Pago EPS",
                PagoTercero = 200000m
            };

            Assert.AreEqual("Pago EPS", tpp.PagoTerceroDescripcion);
            Assert.AreEqual(200000m, tpp.PagoTercero);
        }

        [TestMethod]
        public void ThirdPartyPayments_DefaultDescripcion_IsEmpty()
        {
            var tpp = new ThirdPartyPayments();
            Assert.AreEqual("", tpp.PagoTerceroDescripcion);
        }

        #endregion

        #region Advances

        [TestMethod]
        public void Advances_Properties_SetAndGet()
        {
            var adv = new Advances
            {
                AnticipoDescripcion = "Anticipo quincena",
                Anticipo = 1000000m
            };

            Assert.AreEqual("Anticipo quincena", adv.AnticipoDescripcion);
            Assert.AreEqual(1000000m, adv.Anticipo);
        }

        [TestMethod]
        public void Advances_DefaultDescripcion_IsEmpty()
        {
            var adv = new Advances();
            Assert.AreEqual("", adv.AnticipoDescripcion);
        }

        #endregion
    }
}

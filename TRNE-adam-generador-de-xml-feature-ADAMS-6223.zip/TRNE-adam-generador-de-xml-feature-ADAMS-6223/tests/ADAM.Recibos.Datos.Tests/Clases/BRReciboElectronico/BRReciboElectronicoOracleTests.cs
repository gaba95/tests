using Moq;
using System;
using System.Data;
using System.Reflection;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using Oracle.ManagedDataAccess.Client;

namespace ADAM.Recibos.DatosTests
{
    [TestClass]
    public class BRReciboElectronicoOracleTests
    {
        #region Helpers

        private static Mock<IDbConnectionFactory> CreateMockFactory(
            string? applicationUser = "TestUser",
            bool checkConnection = true)
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns(applicationUser);
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(checkConnection);
            return mockFactory;
        }

        private static Mock<IDbConnectionFactory> CreateMockFactoryWithOracleConnection(
            string applicationUser = "TestUser")
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns(applicationUser);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new OracleConnection("Data Source=localhost/FAKE;User Id=test;Password=test;Connection Timeout=1"));
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            return mockFactory;
        }

        private static Nomina CreateNomina(
            ManejoNomina manejoNomina = ManejoNomina.periodica,
            string conceptoFactura = "1000")
        {
            return new Nomina(
                compania: "0001",
                trabajador: "  90901010",
                tipoNomina: "01",
                claseNomina: "01",
                anio: 2026,
                periodo: 1,
                manejoNomina: manejoNomina,
                numeroLiquidacion: 0,
                conceptoFactura: conceptoFactura,
                formaPagoDefault: "EFEC"
            );
        }

        private static object InvokePrivateMethod(
            BRReciboElectronicoOracle instance,
            string methodName,
            params object[] parameters)
        {
            var method = typeof(BRReciboElectronicoOracle)
                .GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
            return method!.Invoke(instance, parameters);
        }

        #endregion

        #region Constructor Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();

            // Act
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Assert
            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        [TestMethod]
        public void Constructor_WithNullFactory_ShouldThrowNullReferenceException()
        {
            Assert.Throws<NullReferenceException>(() =>
            {
                new BRReciboElectronicoOracle(null);
            });
        }

        #endregion

        #region ApplicationUser Tests

        [TestMethod]
        public void ApplicationUser_ShouldReturnValueFromConnectionFactory()
        {
            // Arrange
            var mockFactory = CreateMockFactory(applicationUser: "AdminUser");
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act
            var result = service.ApplicationUser;

            // Assert
            Assert.AreEqual("AdminUser", result);
        }

        [TestMethod]
        public void ApplicationUser_ShouldReturnEmpty_WhenFactoryReturnsEmpty()
        {
            // Arrange
            var mockFactory = CreateMockFactory(applicationUser: string.Empty);
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act
            var result = service.ApplicationUser;

            // Assert
            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void ApplicationUser_ShouldReturnNull_WhenFactoryReturnsNull()
        {
            // Arrange
            var mockFactory = CreateMockFactory(applicationUser: null);
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act
            var result = service.ApplicationUser;

            // Assert
            Assert.IsNull(result);
        }

        #endregion

        #region CheckDbConnection Tests

        [TestMethod]
        public void CheckDbConnection_ShouldReturnTrue_WhenFactoryReturnsTrue()
        {
            // Arrange
            var mockFactory = CreateMockFactory(checkConnection: true);
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act
            var result = service.CheckDbConnection();

            // Assert
            Assert.IsTrue(result);
            mockFactory.Verify(f => f.CheckConnection(), Times.Once());
        }

        [TestMethod]
        public void CheckDbConnection_ShouldReturnFalse_WhenFactoryReturnsFalse()
        {
            // Arrange
            var mockFactory = CreateMockFactory(checkConnection: false);
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act
            var result = service.CheckDbConnection();

            // Assert
            Assert.IsFalse(result);
        }

        #endregion

        #region ObtenDatasetReciboFull Tests

        [TestMethod]
        public void ObtenDatasetReciboFull_Periodica_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");
            });
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.interactiva, 1, "1", "EFEC");
            });
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<InvalidCastException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");
            });
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange � factory returns a real OracleConnection (no connection string ? Open() fails)
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert � OracleConnection.Open() throws because there is no real database
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");
            });
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.interactiva, 1, "1", "EFEC");
            });
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_ConceptoFacturaNumerico_RealOracleConnection_ShouldThrow()
        {
            // Arrange � ConceptoFactura = "0" to cover int.TryParse branch with zero value
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.interactiva, 1, "0", "EFEC");
            });
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_ConceptoFacturaNoNumerico_RealOracleConnection_ShouldThrow()
        {
            // Arrange � ConceptoFactura = "ABC" to cover int.TryParse failure branch
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetReciboFull(
                    "0001", "  90901010", "01", "01",
                    2026, 1, ManejoNomina.interactiva, 1, "ABC", "EFEC");
            });
        }

        #endregion

        #region ObtenDatasetRecibo Tests

        [TestMethod]
        public void ObtenDatasetRecibo_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetRecibo(nomina);
            });
        }

        [TestMethod]
        public void ObtenDatasetRecibo_NullNomina_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetRecibo(null);
            });
        }

        [TestMethod]
        public void ObtenDatasetRecibo_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() =>
            {
                service.ObtenDatasetRecibo(nomina);
            });
        }

        [TestMethod]
        public void ObtenDatasetRecibo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetRecibo(nomina);
            });
        }

        [TestMethod]
        public void ObtenDatasetRecibo_Interactiva_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetRecibo(nomina);
            });
        }

        [TestMethod]
        public void ObtenDatasetRecibo_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetRecibo(nomina);
            });
        }

        #endregion

        #region ObtenDatasetAdicionales Tests

        [TestMethod]
        public void ObtenDatasetAdicionales_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NullNomina_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(null, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NullProcedimiento_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, null);
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_EmptyProcedimiento_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, string.Empty);
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NullProcedimiento_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, null);
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_EmptyProcedimiento_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, string.Empty);
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_Interactiva_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NullNominaAndNullProcedimiento_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(null, null);
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaNullCompania_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaNullTrabajador_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaNullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaNullTrabajador_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaZeroAnioAndPeriodo_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_WhitespaceProcedimiento_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "   ");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_WhitespaceProcedimiento_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "   ");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_DifferentProcedimiento_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange — method hardcodes "sp_horas_extra_sat" regardless of procedimiento parameter
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_incapacidades_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_DifferentProcedimiento_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange — method hardcodes "sp_horas_extra_sat" regardless of procedimiento parameter
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_incapacidades_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_Interactiva_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaNullClaseNomina_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", null, 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NominaNullTipoNomina_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", null, "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NegativeNumeroLiquidacion_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            Assert.Throws<OracleException>(() =>
            {
                service.ObtenDatasetAdicionales(nomina, "sp_horas_extra_sat");
            });
        }

        #endregion

        #region Private Methods via Reflection Tests

        [TestMethod]
        public void ObtenDatasetPrincipal_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaNoNumerico_ShouldThrowOracleException()
        {
            // Arrange — ConceptoFactura = "ABC" covers int.TryParse failure (pagoSeparacion defaults to 0)
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "ABC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaCero_ShouldThrowOracleException()
        {
            // Arrange — ConceptoFactura = "0" covers int.TryParse success with zero value
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "0");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullTrabajador_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullTipoNomina_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", null, "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullClaseNomina_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", null, 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullFormaPagoDefault_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", null);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NullFormaPagoDefault_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", null);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange — boundary values: year=0, period=0
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange — boundary values: year=0, period=0
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Periodica_ShouldCallCreateConnection()
        {
            // Arrange — periodica branch sets i_pago_separacion = 0
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.periodica, "1000");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ShouldCallCreateConnection()
        {
            // Arrange — interactiva branch parses ConceptoFactura via int.TryParse
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaEmpty_NullConnection_ShouldThrow()
        {
            // Arrange — empty ConceptoFactura: int.TryParse returns false, pagoSeparacion = 0
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, string.Empty);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaEmpty_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange — empty ConceptoFactura: int.TryParse returns false, pagoSeparacion = 0
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, string.Empty);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaNegative_NullConnection_ShouldThrow()
        {
            // Arrange — negative ConceptoFactura: int.TryParse succeeds with -1
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "-1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaNegative_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange — negative ConceptoFactura: int.TryParse succeeds with -1
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "-1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaNoNumerico_NullConnection_ShouldThrow()
        {
            // Arrange — non-numeric ConceptoFactura with null connection
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "ABC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaCero_NullConnection_ShouldThrow()
        {
            // Arrange — ConceptoFactura "0" with null connection
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "0");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_ConceptoFacturaLargeNumber_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange — large numeric ConceptoFactura to cover int.TryParse with large value
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "999999");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullTrabajador_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullTipoNomina_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", null, "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_NullClaseNomina_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", null, 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NullTipoNomina_NullConnection_ShouldThrow()
        {
            // Arrange — sp_incapacidades_sat does not use i_clase_nomina
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", null, "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NonOracleConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(InvalidCastException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullNomina_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_Interactiva_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_Interactiva_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", (Nomina)null));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullCompania_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullCompania_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina(null, "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullTrabajador_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NullTrabajador_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", null, "01", "01", 2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_ZeroAnioAndPeriodo_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_ZeroAnioAndPeriodo_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 0, 0, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NegativeNumeroLiquidacion_NullConnection_ShouldThrow()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_NegativeNumeroLiquidacion_RealOracleConnection_ShouldThrowOracleException()
        {
            // Arrange
            var mockFactory = CreateMockFactoryWithOracleConnection();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = new Nomina("0001", "  90901010", "01", "01", 2026, 1, ManejoNomina.periodica, -1, "1000", "EFEC");

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(OracleException));
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = CreateMockFactory();
            var service = new BRReciboElectronicoOracle(mockFactory.Object);
            var nomina = CreateNomina();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina));
            Assert.IsInstanceOfType(ex.InnerException, typeof(NullReferenceException));

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        #endregion

        #region Structural / Reflection Tests

        [TestMethod]
        public void ClassShouldImplementInterface_IBRReciboElectronico()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var implementsInterface = typeof(IBRReciboElectronico).IsAssignableFrom(type);
            Assert.IsTrue(implementsInterface, "Debe implementar IBRReciboElectronico");
        }

        [TestMethod]
        public void ShouldContainMethod_ObtenDatasetRecibo()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var metodo = type.GetMethod("ObtenDatasetRecibo");
            Assert.IsNotNull(metodo, "Debe existir el m�todo ObtenDatasetRecibo");
            Assert.AreEqual(typeof(DataSet), metodo.ReturnType, "Debe retornar DataSet");
        }

        [TestMethod]
        public void ShouldContainMethod_ObtenDatasetReciboFull()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var metodo = type.GetMethod("ObtenDatasetReciboFull");
            Assert.IsNotNull(metodo, "Debe existir el m�todo ObtenDatasetReciboFull");
            Assert.AreEqual(typeof(DataSet), metodo.ReturnType, "Debe retornar DataSet");
        }

        [TestMethod]
        public void ShouldContainMethod_ObtenDatasetAdicionales()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var metodo = type.GetMethod("ObtenDatasetAdicionales");
            Assert.IsNotNull(metodo, "Debe existir el m�todo ObtenDatasetAdicionales");
            Assert.AreEqual(typeof(DataSet), metodo.ReturnType, "Debe retornar DataSet");
            var parametros = metodo.GetParameters();
            Assert.AreEqual(2, parametros.Length, "Debe tener 2 par�metros");
        }

        [TestMethod]
        public void ShouldContainMethod_CheckDbConnection()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var metodo = type.GetMethod("CheckDbConnection");
            Assert.IsNotNull(metodo, "Debe existir el m�todo CheckDbConnection");
            Assert.AreEqual(typeof(bool), metodo.ReturnType, "Debe retornar bool");
        }

        [TestMethod]
        public void ShouldContainProperty_ApplicationUser()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var prop = type.GetProperty("ApplicationUser");
            Assert.IsNotNull(prop, "Debe existir la propiedad ApplicationUser");
            Assert.AreEqual(typeof(string), prop.PropertyType);
            Assert.IsTrue(prop.CanRead, "Debe poder leerse");
        }

        [TestMethod]
        public void ShouldContainPrivateField_connectionFactory()
        {
            var type = typeof(BRReciboElectronicoOracle);
            var field = type.GetField("_connectionFactory", BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(field, "Debe existir el campo privado _connectionFactory");
            Assert.AreEqual(typeof(IDbConnectionFactory), field.FieldType);
        }

        [TestMethod]
        public void ShouldContainAllSevenPrivateMethods()
        {
            var type = typeof(BRReciboElectronicoOracle);
            string[] expectedMethods =
            [
                "ObtenDatasetPrincipal",
                "ObtenDatasetHorasExtra",
                "ObtenDatasetIncapacidades",
                "ObtenDatasetOtrosPagos",
                "ObtenDatasetAccionesTitulos",
                "ObtenDatasetJubilacionPensionRetiro",
                "ObtenDatasetSeparacionIndemnizacion"
            ];

            foreach (var methodName in expectedMethods)
            {
                var method = type.GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
                Assert.IsNotNull(method, $"Debe existir el m�todo privado {methodName}");
                Assert.AreEqual(typeof(DataSet), method.ReturnType, $"{methodName} debe retornar DataSet");
            }
        }

        #endregion
    }
}

using System;
using ADAM.GeneracionRecibosElectronicos.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmConfiguracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmConfiguracion));
            this.tabPrincipal = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pnlDatosADAM = new System.Windows.Forms.Panel();
            this.cboPaisDefault = new System.Windows.Forms.ComboBox();
            this.lblPaisDefault = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.cboVersion = new System.Windows.Forms.ComboBox();
            this.lblUsuarioAplicacion = new System.Windows.Forms.Label();
            this.txtUsuarioAplicacion = new System.Windows.Forms.TextBox();
            this.pnlSqlOracle = new System.Windows.Forms.Panel();
            this.txtPuerto = new System.Windows.Forms.TextBox();
            this.lblPuerto = new System.Windows.Forms.Label();
            this.cboTipoServicio = new System.Windows.Forms.ComboBox();
            this.lblTipoServicio = new System.Windows.Forms.Label();
            this.cmdValidarConexion = new System.Windows.Forms.Button();
            this.lblServidor = new System.Windows.Forms.Label();
            this.lblBaseDatos = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.cmdBuscar = new System.Windows.Forms.Button();
            this.lblContrasenia = new System.Windows.Forms.Label();
            this.txtServidor = new System.Windows.Forms.TextBox();
            this.cboBaseDatos = new System.Windows.Forms.ComboBox();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtContrasenia = new System.Windows.Forms.TextBox();
            this.pnlODBC = new System.Windows.Forms.Panel();
            this.cmdConsultasODBC = new System.Windows.Forms.Button();
            this.cmdValidarODBC = new System.Windows.Forms.Button();
            this.lblParametros = new System.Windows.Forms.Label();
            this.txtParametrosODBC = new System.Windows.Forms.TextBox();
            this.lblControlador = new System.Windows.Forms.Label();
            this.lblDbODBC = new System.Windows.Forms.Label();
            this.lblUsuarioODBC = new System.Windows.Forms.Label();
            this.lblPasswordODBC = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cboDSN = new System.Windows.Forms.ComboBox();
            this.txtUsuarioODBC = new System.Windows.Forms.TextBox();
            this.txtPasswordODBC = new System.Windows.Forms.TextBox();
            this.pnlInferior = new System.Windows.Forms.Panel();
            this.pnlPlataforma = new System.Windows.Forms.Panel();
            this.cboPlataforma = new System.Windows.Forms.ComboBox();
            this.lblPlataforma = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnlParametrosAdicionales = new System.Windows.Forms.Panel();
            this.txtWSUsrPwd = new System.Windows.Forms.TextBox();
            this.lblWSUsrPwd = new System.Windows.Forms.Label();
            this.txtWSUsrID = new System.Windows.Forms.TextBox();
            this.lblWSUsrID = new System.Windows.Forms.Label();
            this.cboXSD = new System.Windows.Forms.ComboBox();
            this.lblXSD = new System.Windows.Forms.Label();
            this.cboXslt = new System.Windows.Forms.ComboBox();
            this.txtProcAdicionales = new System.Windows.Forms.TextBox();
            this.cboDatosAdicionales = new System.Windows.Forms.ComboBox();
            this.lblProcAdicionales = new System.Windows.Forms.Label();
            this.lblDatosAdicionales = new System.Windows.Forms.Label();
            this.lblServicio = new System.Windows.Forms.Label();
            this.txtServicio = new System.Windows.Forms.TextBox();
            this.lblSitio = new System.Windows.Forms.Label();
            this.txtSitio = new System.Windows.Forms.TextBox();
            this.cboMultiples = new System.Windows.Forms.ComboBox();
            this.lblCompania = new System.Windows.Forms.Label();
            this.cboCompania = new System.Windows.Forms.ComboBox();
            this.lblRuta = new System.Windows.Forms.Label();
            this.lblXslt = new System.Windows.Forms.Label();
            this.lblMultiples = new System.Windows.Forms.Label();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.lblTimeout = new System.Windows.Forms.Label();
            this.txtTimeout = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pnlCertKey = new System.Windows.Forms.Panel();
            this.pnlCertKeyBar = new System.Windows.Forms.Panel();
            this.cboCompaniaCertKey = new System.Windows.Forms.ComboBox();
            this.btnLoadCert = new System.Windows.Forms.Button();
            this.txtCertPath = new System.Windows.Forms.TextBox();
            this.btnLoadKey = new System.Windows.Forms.Button();
            this.txtKeyPath = new System.Windows.Forms.TextBox();
            this.txtCertKeyPassword = new System.Windows.Forms.TextBox();
            this.btnAddCertKey = new System.Windows.Forms.Button();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lvCFDI = new System.Windows.Forms.ListView();
            this.lblMensajeBorrado = new System.Windows.Forms.Label();
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.cmdAceptar = new System.Windows.Forms.Button();
            this.lblIndicaciones = new System.Windows.Forms.Label();
            this.epErroresConfiguracion = new System.Windows.Forms.ErrorProvider(this.components);
            this.pnlBotones = new System.Windows.Forms.Panel();
            this.fdCertFile = new System.Windows.Forms.OpenFileDialog();
            this.fdKeyFile = new System.Windows.Forms.OpenFileDialog();
            this.tabPrincipal.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnlDatosADAM.SuspendLayout();
            this.pnlSqlOracle.SuspendLayout();
            this.pnlODBC.SuspendLayout();
            this.pnlPlataforma.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlParametrosAdicionales.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.pnlCertKey.SuspendLayout();
            this.pnlCertKeyBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epErroresConfiguracion)).BeginInit();
            this.pnlBotones.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPrincipal
            // 
            this.tabPrincipal.Controls.Add(this.tabPage1);
            this.tabPrincipal.Controls.Add(this.tabPage2);
            this.tabPrincipal.Controls.Add(this.tabPage3);
            this.tabPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tabPrincipal.Name = "tabPrincipal";
            this.tabPrincipal.SelectedIndex = 0;
            this.tabPrincipal.Size = new System.Drawing.Size(684, 380);
            this.tabPrincipal.TabIndex = 0;
            this.tabPrincipal.SelectedIndexChanged += new System.EventHandler(this.tabPrincipal_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pnlDatosADAM);
            this.tabPage1.Controls.Add(this.pnlSqlOracle);
            this.tabPage1.Controls.Add(this.pnlODBC);
            this.tabPage1.Controls.Add(this.pnlInferior);
            this.tabPage1.Controls.Add(this.pnlPlataforma);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(676, 344);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Conexión";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pnlDatosADAM
            // 
            this.pnlDatosADAM.Controls.Add(this.cboPaisDefault);
            this.pnlDatosADAM.Controls.Add(this.lblPaisDefault);
            this.pnlDatosADAM.Controls.Add(this.lblVersion);
            this.pnlDatosADAM.Controls.Add(this.cboVersion);
            this.pnlDatosADAM.Controls.Add(this.lblUsuarioAplicacion);
            this.pnlDatosADAM.Controls.Add(this.txtUsuarioAplicacion);
            this.pnlDatosADAM.Location = new System.Drawing.Point(3, 223);
            this.pnlDatosADAM.Name = "pnlDatosADAM";
            this.pnlDatosADAM.Size = new System.Drawing.Size(670, 150);
            this.pnlDatosADAM.TabIndex = 0;
            // 
            // cboPaisDefault
            // 
            this.cboPaisDefault.FormattingEnabled = true;
            this.cboPaisDefault.Location = new System.Drawing.Point(180, 60);
            this.cboPaisDefault.Name = "cboPaisDefault";
            this.cboPaisDefault.Size = new System.Drawing.Size(163, 31);
            this.cboPaisDefault.TabIndex = 5;
            this.cboPaisDefault.SelectedIndexChanged += new System.EventHandler(this.cboPaisDefault_SelectedIndexChanged);
            // 
            // lblPaisDefault
            // 
            this.lblPaisDefault.AutoSize = true;
            this.lblPaisDefault.Location = new System.Drawing.Point(10, 64);
            this.lblPaisDefault.Name = "lblPaisDefault";
            this.lblPaisDefault.Size = new System.Drawing.Size(158, 23);
            this.lblPaisDefault.TabIndex = 4;
            this.lblPaisDefault.Text = "País Seleccionado:";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(10, 0);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(131, 23);
            this.lblVersion.TabIndex = 0;
            this.lblVersion.Text = "Versión ADAM :";
            // 
            // cboVersion
            // 
            this.cboVersion.FormattingEnabled = true;
            this.cboVersion.Items.AddRange(new object[] {
            "3",
            "5"});
            this.cboVersion.Location = new System.Drawing.Point(180, 0);
            this.cboVersion.Name = "cboVersion";
            this.cboVersion.Size = new System.Drawing.Size(100, 31);
            this.cboVersion.TabIndex = 1;
            this.cboVersion.Validating += new System.ComponentModel.CancelEventHandler(this.cboVersion_Validating);
            // 
            // lblUsuarioAplicacion
            // 
            this.lblUsuarioAplicacion.AutoSize = true;
            this.lblUsuarioAplicacion.Location = new System.Drawing.Point(10, 32);
            this.lblUsuarioAplicacion.Name = "lblUsuarioAplicacion";
            this.lblUsuarioAplicacion.Size = new System.Drawing.Size(164, 23);
            this.lblUsuarioAplicacion.TabIndex = 2;
            this.lblUsuarioAplicacion.Text = "Usuario Aplicación:";
            // 
            // txtUsuarioAplicacion
            // 
            this.txtUsuarioAplicacion.Location = new System.Drawing.Point(180, 32);
            this.txtUsuarioAplicacion.Name = "txtUsuarioAplicacion";
            this.txtUsuarioAplicacion.Size = new System.Drawing.Size(163, 28);
            this.txtUsuarioAplicacion.TabIndex = 3;
            this.txtUsuarioAplicacion.Validating += new System.ComponentModel.CancelEventHandler(this.txtUsuarioAplicacion_Validating);
            // 
            // pnlSqlOracle
            // 
            this.pnlSqlOracle.Controls.Add(this.txtPuerto);
            this.pnlSqlOracle.Controls.Add(this.lblPuerto);
            this.pnlSqlOracle.Controls.Add(this.cboTipoServicio);
            this.pnlSqlOracle.Controls.Add(this.lblTipoServicio);
            this.pnlSqlOracle.Controls.Add(this.cmdValidarConexion);
            this.pnlSqlOracle.Controls.Add(this.lblServidor);
            this.pnlSqlOracle.Controls.Add(this.lblBaseDatos);
            this.pnlSqlOracle.Controls.Add(this.lblUsuario);
            this.pnlSqlOracle.Controls.Add(this.cmdBuscar);
            this.pnlSqlOracle.Controls.Add(this.lblContrasenia);
            this.pnlSqlOracle.Controls.Add(this.txtServidor);
            this.pnlSqlOracle.Controls.Add(this.cboBaseDatos);
            this.pnlSqlOracle.Controls.Add(this.txtUsuario);
            this.pnlSqlOracle.Controls.Add(this.txtContrasenia);
            this.pnlSqlOracle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSqlOracle.Location = new System.Drawing.Point(3, 53);
            this.pnlSqlOracle.Name = "pnlSqlOracle";
            this.pnlSqlOracle.Size = new System.Drawing.Size(670, 170);
            this.pnlSqlOracle.TabIndex = 5;
            this.pnlSqlOracle.Visible = false;
            // 
            // txtPuerto
            // 
            this.txtPuerto.Location = new System.Drawing.Point(380, 100);
            this.txtPuerto.Name = "txtPuerto";
            this.txtPuerto.Size = new System.Drawing.Size(100, 28);
            this.txtPuerto.TabIndex = 13;
            // 
            // lblPuerto
            // 
            this.lblPuerto.AutoSize = true;
            this.lblPuerto.Location = new System.Drawing.Point(300, 100);
            this.lblPuerto.Name = "lblPuerto";
            this.lblPuerto.Size = new System.Drawing.Size(71, 23);
            this.lblPuerto.TabIndex = 12;
            this.lblPuerto.Text = "Puerto:";
            // 
            // cboTipoServicio
            // 
            this.cboTipoServicio.FormattingEnabled = true;
            this.cboTipoServicio.Items.AddRange(new object[] {
            "SERVICE_NAME",
            "SID"});
            this.cboTipoServicio.Location = new System.Drawing.Point(180, 100);
            this.cboTipoServicio.Name = "cboTipoServicio";
            this.cboTipoServicio.Size = new System.Drawing.Size(110, 31);
            this.cboTipoServicio.TabIndex = 11;
            // 
            // lblTipoServicio
            // 
            this.lblTipoServicio.AutoSize = true;
            this.lblTipoServicio.Location = new System.Drawing.Point(10, 100);
            this.lblTipoServicio.Name = "lblTipoServicio";
            this.lblTipoServicio.Size = new System.Drawing.Size(51, 23);
            this.lblTipoServicio.TabIndex = 10;
            this.lblTipoServicio.Text = "Tipo:";
            // 
            // cmdValidarConexion
            // 
            this.cmdValidarConexion.Location = new System.Drawing.Point(490, 62);
            this.cmdValidarConexion.Name = "cmdValidarConexion";
            this.cmdValidarConexion.Size = new System.Drawing.Size(110, 30);
            this.cmdValidarConexion.TabIndex = 6;
            this.cmdValidarConexion.Text = "&Validar";
            this.cmdValidarConexion.UseVisualStyleBackColor = true;
            this.cmdValidarConexion.Click += new System.EventHandler(this.cmdValidarConexion_Click);
            // 
            // lblServidor
            // 
            this.lblServidor.AutoSize = true;
            this.lblServidor.Location = new System.Drawing.Point(10, 10);
            this.lblServidor.Name = "lblServidor";
            this.lblServidor.Size = new System.Drawing.Size(84, 23);
            this.lblServidor.TabIndex = 0;
            this.lblServidor.Text = "Servidor:";
            // 
            // lblBaseDatos
            // 
            this.lblBaseDatos.AutoSize = true;
            this.lblBaseDatos.Location = new System.Drawing.Point(10, 133);
            this.lblBaseDatos.Name = "lblBaseDatos";
            this.lblBaseDatos.Size = new System.Drawing.Size(127, 23);
            this.lblBaseDatos.TabIndex = 7;
            this.lblBaseDatos.Text = "Base de Datos:";
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(10, 40);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(77, 23);
            this.lblUsuario.TabIndex = 2;
            this.lblUsuario.Text = "Usuario:";
            // 
            // cmdBuscar
            // 
            this.cmdBuscar.Enabled = false;
            this.cmdBuscar.Location = new System.Drawing.Point(490, 98);
            this.cmdBuscar.Name = "cmdBuscar";
            this.cmdBuscar.Size = new System.Drawing.Size(110, 30);
            this.cmdBuscar.TabIndex = 9;
            this.cmdBuscar.Text = "&Buscar";
            this.cmdBuscar.UseVisualStyleBackColor = true;
            this.cmdBuscar.Click += new System.EventHandler(this.cmdBuscar_Click);
            // 
            // lblContrasenia
            // 
            this.lblContrasenia.AutoSize = true;
            this.lblContrasenia.Location = new System.Drawing.Point(10, 70);
            this.lblContrasenia.Name = "lblContrasenia";
            this.lblContrasenia.Size = new System.Drawing.Size(107, 23);
            this.lblContrasenia.TabIndex = 4;
            this.lblContrasenia.Text = "Contraseña:";
            // 
            // txtServidor
            // 
            this.txtServidor.Location = new System.Drawing.Point(180, 10);
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.Size = new System.Drawing.Size(300, 28);
            this.txtServidor.TabIndex = 1;
            this.txtServidor.Validating += new System.ComponentModel.CancelEventHandler(this.txtServidor_Validating);
            // 
            // cboBaseDatos
            // 
            this.cboBaseDatos.FormattingEnabled = true;
            this.cboBaseDatos.Location = new System.Drawing.Point(180, 133);
            this.cboBaseDatos.Name = "cboBaseDatos";
            this.cboBaseDatos.Size = new System.Drawing.Size(300, 31);
            this.cboBaseDatos.TabIndex = 8;
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(180, 40);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(300, 28);
            this.txtUsuario.TabIndex = 3;
            this.txtUsuario.Validating += new System.ComponentModel.CancelEventHandler(this.txtUsuario_Validating);
            // 
            // txtContrasenia
            // 
            this.txtContrasenia.Location = new System.Drawing.Point(180, 70);
            this.txtContrasenia.Name = "txtContrasenia";
            this.txtContrasenia.PasswordChar = '*';
            this.txtContrasenia.Size = new System.Drawing.Size(300, 28);
            this.txtContrasenia.TabIndex = 5;
            this.txtContrasenia.Validating += new System.ComponentModel.CancelEventHandler(this.txtContrasenia_Validating);
            // 
            // pnlODBC
            // 
            this.pnlODBC.Controls.Add(this.cmdConsultasODBC);
            this.pnlODBC.Controls.Add(this.cmdValidarODBC);
            this.pnlODBC.Controls.Add(this.lblParametros);
            this.pnlODBC.Controls.Add(this.txtParametrosODBC);
            this.pnlODBC.Controls.Add(this.lblControlador);
            this.pnlODBC.Controls.Add(this.lblDbODBC);
            this.pnlODBC.Controls.Add(this.lblUsuarioODBC);
            this.pnlODBC.Controls.Add(this.lblPasswordODBC);
            this.pnlODBC.Controls.Add(this.textBox1);
            this.pnlODBC.Controls.Add(this.cboDSN);
            this.pnlODBC.Controls.Add(this.txtUsuarioODBC);
            this.pnlODBC.Controls.Add(this.txtPasswordODBC);
            this.pnlODBC.Location = new System.Drawing.Point(21, 250);
            this.pnlODBC.Name = "pnlODBC";
            this.pnlODBC.Size = new System.Drawing.Size(548, 160);
            this.pnlODBC.TabIndex = 6;
            this.pnlODBC.Visible = false;
            // 
            // cmdConsultasODBC
            // 
            this.cmdConsultasODBC.Location = new System.Drawing.Point(490, 126);
            this.cmdConsultasODBC.Name = "cmdConsultasODBC";
            this.cmdConsultasODBC.Size = new System.Drawing.Size(110, 30);
            this.cmdConsultasODBC.TabIndex = 11;
            this.cmdConsultasODBC.Text = "Consultas";
            this.cmdConsultasODBC.UseVisualStyleBackColor = true;
            this.cmdConsultasODBC.Click += new System.EventHandler(this.cmdConsultasODBC_Click);
            // 
            // cmdValidarODBC
            // 
            this.cmdValidarODBC.Location = new System.Drawing.Point(490, 67);
            this.cmdValidarODBC.Name = "cmdValidarODBC";
            this.cmdValidarODBC.Size = new System.Drawing.Size(110, 30);
            this.cmdValidarODBC.TabIndex = 6;
            this.cmdValidarODBC.Text = "&Validar";
            this.cmdValidarODBC.UseVisualStyleBackColor = true;
            this.cmdValidarODBC.Click += new System.EventHandler(this.cmdValidarODBC_Click);
            // 
            // lblParametros
            // 
            this.lblParametros.AutoSize = true;
            this.lblParametros.Location = new System.Drawing.Point(10, 130);
            this.lblParametros.Name = "lblParametros";
            this.lblParametros.Size = new System.Drawing.Size(154, 23);
            this.lblParametros.TabIndex = 9;
            this.lblParametros.Text = "Otros Parametros:";
            // 
            // txtParametrosODBC
            // 
            this.txtParametrosODBC.Location = new System.Drawing.Point(180, 130);
            this.txtParametrosODBC.Name = "txtParametrosODBC";
            this.txtParametrosODBC.Size = new System.Drawing.Size(300, 28);
            this.txtParametrosODBC.TabIndex = 10;
            // 
            // lblControlador
            // 
            this.lblControlador.AutoSize = true;
            this.lblControlador.Location = new System.Drawing.Point(10, 10);
            this.lblControlador.Name = "lblControlador";
            this.lblControlador.Size = new System.Drawing.Size(122, 23);
            this.lblControlador.TabIndex = 0;
            this.lblControlador.Text = "Fuente ODBC:";
            // 
            // lblDbODBC
            // 
            this.lblDbODBC.AutoSize = true;
            this.lblDbODBC.Location = new System.Drawing.Point(10, 100);
            this.lblDbODBC.Name = "lblDbODBC";
            this.lblDbODBC.Size = new System.Drawing.Size(181, 23);
            this.lblDbODBC.TabIndex = 7;
            this.lblDbODBC.Text = "Base de Datos / Ruta:";
            // 
            // lblUsuarioODBC
            // 
            this.lblUsuarioODBC.AutoSize = true;
            this.lblUsuarioODBC.Location = new System.Drawing.Point(10, 40);
            this.lblUsuarioODBC.Name = "lblUsuarioODBC";
            this.lblUsuarioODBC.Size = new System.Drawing.Size(77, 23);
            this.lblUsuarioODBC.TabIndex = 2;
            this.lblUsuarioODBC.Text = "Usuario:";
            // 
            // lblPasswordODBC
            // 
            this.lblPasswordODBC.AutoSize = true;
            this.lblPasswordODBC.Location = new System.Drawing.Point(10, 70);
            this.lblPasswordODBC.Name = "lblPasswordODBC";
            this.lblPasswordODBC.Size = new System.Drawing.Size(107, 23);
            this.lblPasswordODBC.TabIndex = 4;
            this.lblPasswordODBC.Text = "Contraseña:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(180, 100);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(300, 28);
            this.textBox1.TabIndex = 8;
            // 
            // cboDSN
            // 
            this.cboDSN.FormattingEnabled = true;
            this.cboDSN.Location = new System.Drawing.Point(180, 7);
            this.cboDSN.Name = "cboDSN";
            this.cboDSN.Size = new System.Drawing.Size(300, 31);
            this.cboDSN.TabIndex = 1;
            this.cboDSN.Validating += new System.ComponentModel.CancelEventHandler(this.cboDSN_Validating);
            // 
            // txtUsuarioODBC
            // 
            this.txtUsuarioODBC.Location = new System.Drawing.Point(180, 40);
            this.txtUsuarioODBC.Name = "txtUsuarioODBC";
            this.txtUsuarioODBC.Size = new System.Drawing.Size(300, 28);
            this.txtUsuarioODBC.TabIndex = 3;
            // 
            // txtPasswordODBC
            // 
            this.txtPasswordODBC.Location = new System.Drawing.Point(180, 70);
            this.txtPasswordODBC.Name = "txtPasswordODBC";
            this.txtPasswordODBC.PasswordChar = '*';
            this.txtPasswordODBC.Size = new System.Drawing.Size(300, 28);
            this.txtPasswordODBC.TabIndex = 5;
            // 
            // pnlInferior
            // 
            this.pnlInferior.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlInferior.Location = new System.Drawing.Point(3, 241);
            this.pnlInferior.Name = "pnlInferior";
            this.pnlInferior.Size = new System.Drawing.Size(670, 100);
            this.pnlInferior.TabIndex = 7;
            // 
            // pnlPlataforma
            // 
            this.pnlPlataforma.Controls.Add(this.cboPlataforma);
            this.pnlPlataforma.Controls.Add(this.lblPlataforma);
            this.pnlPlataforma.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlPlataforma.Location = new System.Drawing.Point(3, 3);
            this.pnlPlataforma.Name = "pnlPlataforma";
            this.pnlPlataforma.Size = new System.Drawing.Size(670, 50);
            this.pnlPlataforma.TabIndex = 4;
            // 
            // cboPlataforma
            // 
            this.cboPlataforma.FormattingEnabled = true;
            this.cboPlataforma.Items.AddRange(new object[] {
            "SQL",
            "ORACLE",
            "ODBC"});
            this.cboPlataforma.Location = new System.Drawing.Point(180, 20);
            this.cboPlataforma.Name = "cboPlataforma";
            this.cboPlataforma.Size = new System.Drawing.Size(100, 31);
            this.cboPlataforma.TabIndex = 1;
            this.cboPlataforma.SelectedIndexChanged += new System.EventHandler(this.cboPlataforma_SelectedIndexChanged);
            // 
            // lblPlataforma
            // 
            this.lblPlataforma.AutoSize = true;
            this.lblPlataforma.Location = new System.Drawing.Point(10, 20);
            this.lblPlataforma.Name = "lblPlataforma";
            this.lblPlataforma.Size = new System.Drawing.Size(104, 23);
            this.lblPlataforma.TabIndex = 0;
            this.lblPlataforma.Text = "Plataforma:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pnlParametrosAdicionales);
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(676, 344);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Parámetros Adicionales";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlParametrosAdicionales
            // 
            this.pnlParametrosAdicionales.Controls.Add(this.txtWSUsrPwd);
            this.pnlParametrosAdicionales.Controls.Add(this.lblWSUsrPwd);
            this.pnlParametrosAdicionales.Controls.Add(this.txtWSUsrID);
            this.pnlParametrosAdicionales.Controls.Add(this.lblWSUsrID);
            this.pnlParametrosAdicionales.Controls.Add(this.cboXSD);
            this.pnlParametrosAdicionales.Controls.Add(this.lblXSD);
            this.pnlParametrosAdicionales.Controls.Add(this.cboXslt);
            this.pnlParametrosAdicionales.Controls.Add(this.txtProcAdicionales);
            this.pnlParametrosAdicionales.Controls.Add(this.cboDatosAdicionales);
            this.pnlParametrosAdicionales.Controls.Add(this.lblProcAdicionales);
            this.pnlParametrosAdicionales.Controls.Add(this.lblDatosAdicionales);
            this.pnlParametrosAdicionales.Controls.Add(this.lblServicio);
            this.pnlParametrosAdicionales.Controls.Add(this.txtServicio);
            this.pnlParametrosAdicionales.Controls.Add(this.lblSitio);
            this.pnlParametrosAdicionales.Controls.Add(this.txtSitio);
            this.pnlParametrosAdicionales.Controls.Add(this.cboMultiples);
            this.pnlParametrosAdicionales.Controls.Add(this.lblCompania);
            this.pnlParametrosAdicionales.Controls.Add(this.cboCompania);
            this.pnlParametrosAdicionales.Controls.Add(this.lblRuta);
            this.pnlParametrosAdicionales.Controls.Add(this.lblXslt);
            this.pnlParametrosAdicionales.Controls.Add(this.lblMultiples);
            this.pnlParametrosAdicionales.Controls.Add(this.txtRuta);
            this.pnlParametrosAdicionales.Controls.Add(this.lblTimeout);
            this.pnlParametrosAdicionales.Controls.Add(this.txtTimeout);
            this.pnlParametrosAdicionales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlParametrosAdicionales.Location = new System.Drawing.Point(3, 3);
            this.pnlParametrosAdicionales.Name = "pnlParametrosAdicionales";
            this.pnlParametrosAdicionales.Size = new System.Drawing.Size(670, 338);
            this.pnlParametrosAdicionales.TabIndex = 0;
            // 
            // txtWSUsrPwd
            // 
            this.txtWSUsrPwd.Enabled = false;
            this.txtWSUsrPwd.Location = new System.Drawing.Point(190, 360);
            this.txtWSUsrPwd.Name = "txtWSUsrPwd";
            this.txtWSUsrPwd.PasswordChar = '*';
            this.txtWSUsrPwd.ReadOnly = true;
            this.txtWSUsrPwd.Size = new System.Drawing.Size(126, 28);
            this.txtWSUsrPwd.TabIndex = 29;
            // 
            // lblWSUsrPwd
            // 
            this.lblWSUsrPwd.Location = new System.Drawing.Point(17, 360);
            this.lblWSUsrPwd.Name = "lblWSUsrPwd";
            this.lblWSUsrPwd.Size = new System.Drawing.Size(170, 23);
            this.lblWSUsrPwd.TabIndex = 28;
            this.lblWSUsrPwd.Text = "Contraseña Servicio CENET:";
            this.lblWSUsrPwd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtWSUsrID
            // 
            this.txtWSUsrID.Enabled = false;
            this.txtWSUsrID.Location = new System.Drawing.Point(190, 330);
            this.txtWSUsrID.Name = "txtWSUsrID";
            this.txtWSUsrID.ReadOnly = true;
            this.txtWSUsrID.Size = new System.Drawing.Size(126, 28);
            this.txtWSUsrID.TabIndex = 27;
            // 
            // lblWSUsrID
            // 
            this.lblWSUsrID.Location = new System.Drawing.Point(17, 330);
            this.lblWSUsrID.Name = "lblWSUsrID";
            this.lblWSUsrID.Size = new System.Drawing.Size(170, 23);
            this.lblWSUsrID.TabIndex = 26;
            this.lblWSUsrID.Text = "Usuario Servicio CENET:";
            this.lblWSUsrID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboXSD
            // 
            this.cboXSD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboXSD.Enabled = false;
            this.cboXSD.FormattingEnabled = true;
            this.cboXSD.Location = new System.Drawing.Point(190, 103);
            this.cboXSD.Name = "cboXSD";
            this.cboXSD.Size = new System.Drawing.Size(300, 31);
            this.cboXSD.TabIndex = 24;
            // 
            // lblXSD
            // 
            this.lblXSD.Location = new System.Drawing.Point(17, 103);
            this.lblXSD.Name = "lblXSD";
            this.lblXSD.Size = new System.Drawing.Size(170, 23);
            this.lblXSD.TabIndex = 25;
            this.lblXSD.Text = "Archivo Validación XSD:";
            this.lblXSD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboXslt
            // 
            this.cboXslt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboXslt.Enabled = false;
            this.cboXslt.FormattingEnabled = true;
            this.cboXslt.Location = new System.Drawing.Point(190, 73);
            this.cboXslt.Name = "cboXslt";
            this.cboXslt.Size = new System.Drawing.Size(300, 31);
            this.cboXslt.TabIndex = 10;
            // 
            // txtProcAdicionales
            // 
            this.txtProcAdicionales.Enabled = false;
            this.txtProcAdicionales.Location = new System.Drawing.Point(190, 253);
            this.txtProcAdicionales.Name = "txtProcAdicionales";
            this.txtProcAdicionales.ReadOnly = true;
            this.txtProcAdicionales.Size = new System.Drawing.Size(300, 28);
            this.txtProcAdicionales.TabIndex = 23;
            // 
            // cboDatosAdicionales
            // 
            this.cboDatosAdicionales.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDatosAdicionales.Enabled = false;
            this.cboDatosAdicionales.FormattingEnabled = true;
            this.cboDatosAdicionales.Items.AddRange(new object[] {
            "True",
            "False"});
            this.cboDatosAdicionales.Location = new System.Drawing.Point(190, 283);
            this.cboDatosAdicionales.Name = "cboDatosAdicionales";
            this.cboDatosAdicionales.Size = new System.Drawing.Size(300, 31);
            this.cboDatosAdicionales.TabIndex = 22;
            // 
            // lblProcAdicionales
            // 
            this.lblProcAdicionales.Location = new System.Drawing.Point(17, 253);
            this.lblProcAdicionales.Name = "lblProcAdicionales";
            this.lblProcAdicionales.Size = new System.Drawing.Size(170, 23);
            this.lblProcAdicionales.TabIndex = 21;
            this.lblProcAdicionales.Text = "Procedimiento Adicionales:";
            this.lblProcAdicionales.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDatosAdicionales
            // 
            this.lblDatosAdicionales.Location = new System.Drawing.Point(17, 283);
            this.lblDatosAdicionales.Name = "lblDatosAdicionales";
            this.lblDatosAdicionales.Size = new System.Drawing.Size(170, 23);
            this.lblDatosAdicionales.TabIndex = 20;
            this.lblDatosAdicionales.Text = "Generar Datos Adicionales:";
            this.lblDatosAdicionales.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblServicio
            // 
            this.lblServicio.Location = new System.Drawing.Point(17, 193);
            this.lblServicio.Name = "lblServicio";
            this.lblServicio.Size = new System.Drawing.Size(170, 23);
            this.lblServicio.TabIndex = 19;
            this.lblServicio.Text = "Servicio Timbrado ADAM:";
            this.lblServicio.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtServicio
            // 
            this.txtServicio.Enabled = false;
            this.txtServicio.Location = new System.Drawing.Point(190, 193);
            this.txtServicio.Name = "txtServicio";
            this.txtServicio.ReadOnly = true;
            this.txtServicio.Size = new System.Drawing.Size(450, 28);
            this.txtServicio.TabIndex = 18;
            // 
            // lblSitio
            // 
            this.lblSitio.Location = new System.Drawing.Point(14, 43);
            this.lblSitio.Name = "lblSitio";
            this.lblSitio.Size = new System.Drawing.Size(170, 23);
            this.lblSitio.TabIndex = 9;
            this.lblSitio.Text = "Sitio Timbrado ADAM:";
            this.lblSitio.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSitio
            // 
            this.txtSitio.Enabled = false;
            this.txtSitio.Location = new System.Drawing.Point(190, 44);
            this.txtSitio.Name = "txtSitio";
            this.txtSitio.ReadOnly = true;
            this.txtSitio.Size = new System.Drawing.Size(450, 28);
            this.txtSitio.TabIndex = 12;
            // 
            // cboMultiples
            // 
            this.cboMultiples.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMultiples.Enabled = false;
            this.cboMultiples.FormattingEnabled = true;
            this.cboMultiples.Location = new System.Drawing.Point(190, 133);
            this.cboMultiples.Name = "cboMultiples";
            this.cboMultiples.Size = new System.Drawing.Size(383, 31);
            this.cboMultiples.TabIndex = 17;
            // 
            // lblCompania
            // 
            this.lblCompania.Location = new System.Drawing.Point(14, 13);
            this.lblCompania.Name = "lblCompania";
            this.lblCompania.Size = new System.Drawing.Size(170, 23);
            this.lblCompania.TabIndex = 15;
            this.lblCompania.Text = "Compañía:";
            this.lblCompania.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboCompania
            // 
            this.cboCompania.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompania.FormattingEnabled = true;
            this.cboCompania.Location = new System.Drawing.Point(190, 12);
            this.cboCompania.Name = "cboCompania";
            this.cboCompania.Size = new System.Drawing.Size(450, 31);
            this.cboCompania.TabIndex = 30;
            this.cboCompania.SelectedIndexChanged += new System.EventHandler(this.cboCompania_SelectedIndexChanged);
            // 
            // lblRuta
            // 
            this.lblRuta.Location = new System.Drawing.Point(17, 163);
            this.lblRuta.Name = "lblRuta";
            this.lblRuta.Size = new System.Drawing.Size(170, 23);
            this.lblRuta.TabIndex = 15;
            this.lblRuta.Text = "Ruta Multiples Archivos:";
            this.lblRuta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblXslt
            // 
            this.lblXslt.Location = new System.Drawing.Point(17, 73);
            this.lblXslt.Name = "lblXslt";
            this.lblXslt.Size = new System.Drawing.Size(170, 23);
            this.lblXslt.TabIndex = 11;
            this.lblXslt.Text = "Archivo Transformación XSLT:";
            this.lblXslt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMultiples
            // 
            this.lblMultiples.Location = new System.Drawing.Point(17, 133);
            this.lblMultiples.Name = "lblMultiples";
            this.lblMultiples.Size = new System.Drawing.Size(170, 23);
            this.lblMultiples.TabIndex = 13;
            this.lblMultiples.Text = "Generación Recibo:";
            this.lblMultiples.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtRuta
            // 
            this.txtRuta.Enabled = false;
            this.txtRuta.Location = new System.Drawing.Point(190, 163);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.ReadOnly = true;
            this.txtRuta.Size = new System.Drawing.Size(450, 28);
            this.txtRuta.TabIndex = 14;
            // 
            // lblTimeout
            // 
            this.lblTimeout.Location = new System.Drawing.Point(17, 223);
            this.lblTimeout.Name = "lblTimeout";
            this.lblTimeout.Size = new System.Drawing.Size(170, 23);
            this.lblTimeout.TabIndex = 21;
            this.lblTimeout.Text = "Tiempo de Espera:";
            this.lblTimeout.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtTimeout
            // 
            this.txtTimeout.Enabled = false;
            this.txtTimeout.Location = new System.Drawing.Point(190, 223);
            this.txtTimeout.Name = "txtTimeout";
            this.txtTimeout.ReadOnly = true;
            this.txtTimeout.Size = new System.Drawing.Size(50, 28);
            this.txtTimeout.TabIndex = 24;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pnlCertKey);
            this.tabPage3.Location = new System.Drawing.Point(4, 32);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(676, 344);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Certificados y Llaves";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pnlCertKey
            // 
            this.pnlCertKey.Controls.Add(this.pnlCertKeyBar);
            this.pnlCertKey.Controls.Add(this.lvCFDI);
            this.pnlCertKey.Controls.Add(this.lblMensajeBorrado);
            this.pnlCertKey.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCertKey.Location = new System.Drawing.Point(3, 3);
            this.pnlCertKey.Name = "pnlCertKey";
            this.pnlCertKey.Size = new System.Drawing.Size(670, 338);
            this.pnlCertKey.TabIndex = 0;
            // 
            // pnlCertKeyBar
            // 
            this.pnlCertKeyBar.Controls.Add(this.cboCompaniaCertKey);
            this.pnlCertKeyBar.Controls.Add(this.btnLoadCert);
            this.pnlCertKeyBar.Controls.Add(this.txtCertPath);
            this.pnlCertKeyBar.Controls.Add(this.btnLoadKey);
            this.pnlCertKeyBar.Controls.Add(this.txtKeyPath);
            this.pnlCertKeyBar.Controls.Add(this.txtCertKeyPassword);
            this.pnlCertKeyBar.Controls.Add(this.btnAddCertKey);
            this.pnlCertKeyBar.Controls.Add(this.lblPassword);
            this.pnlCertKeyBar.Location = new System.Drawing.Point(346, 35);
            this.pnlCertKeyBar.Name = "pnlCertKeyBar";
            this.pnlCertKeyBar.Size = new System.Drawing.Size(320, 260);
            this.pnlCertKeyBar.TabIndex = 0;
            // 
            // cboCompaniaCertKey
            // 
            this.cboCompaniaCertKey.FormattingEnabled = true;
            this.cboCompaniaCertKey.Location = new System.Drawing.Point(3, 3);
            this.cboCompaniaCertKey.Name = "cboCompaniaCertKey";
            this.cboCompaniaCertKey.Size = new System.Drawing.Size(300, 31);
            this.cboCompaniaCertKey.TabIndex = 0;
            // 
            // btnLoadCert
            // 
            this.btnLoadCert.Location = new System.Drawing.Point(3, 40);
            this.btnLoadCert.Name = "btnLoadCert";
            this.btnLoadCert.Size = new System.Drawing.Size(120, 30);
            this.btnLoadCert.TabIndex = 1;
            this.btnLoadCert.Text = "Cargar certificado";
            this.btnLoadCert.UseVisualStyleBackColor = true;
            this.btnLoadCert.Click += new System.EventHandler(this.btnLoadCert_Click);
            // 
            // txtCertPath
            // 
            this.txtCertPath.Location = new System.Drawing.Point(125, 41);
            this.txtCertPath.Name = "txtCertPath";
            this.txtCertPath.ReadOnly = true;
            this.txtCertPath.Size = new System.Drawing.Size(180, 28);
            this.txtCertPath.TabIndex = 2;
            // 
            // btnLoadKey
            // 
            this.btnLoadKey.Location = new System.Drawing.Point(3, 90);
            this.btnLoadKey.Name = "btnLoadKey";
            this.btnLoadKey.Size = new System.Drawing.Size(110, 30);
            this.btnLoadKey.TabIndex = 3;
            this.btnLoadKey.Text = "Cargar llave";
            this.btnLoadKey.UseVisualStyleBackColor = true;
            this.btnLoadKey.Click += new System.EventHandler(this.btnLoadKey_Click);
            // 
            // txtKeyPath
            // 
            this.txtKeyPath.Location = new System.Drawing.Point(115, 91);
            this.txtKeyPath.Name = "txtKeyPath";
            this.txtKeyPath.ReadOnly = true;
            this.txtKeyPath.Size = new System.Drawing.Size(180, 28);
            this.txtKeyPath.TabIndex = 4;
            // 
            // txtCertKeyPassword
            // 
            this.txtCertKeyPassword.Location = new System.Drawing.Point(65, 140);
            this.txtCertKeyPassword.Name = "txtCertKeyPassword";
            this.txtCertKeyPassword.PasswordChar = '*';
            this.txtCertKeyPassword.Size = new System.Drawing.Size(126, 28);
            this.txtCertKeyPassword.TabIndex = 5;
            // 
            // btnAddCertKey
            // 
            this.btnAddCertKey.Location = new System.Drawing.Point(3, 190);
            this.btnAddCertKey.Name = "btnAddCertKey";
            this.btnAddCertKey.Size = new System.Drawing.Size(110, 30);
            this.btnAddCertKey.TabIndex = 6;
            this.btnAddCertKey.Text = "Guardar CSD";
            this.btnAddCertKey.UseVisualStyleBackColor = true;
            this.btnAddCertKey.Click += new System.EventHandler(this.btnAddCertKey_Click);
            // 
            // lblPassword
            // 
            this.lblPassword.Location = new System.Drawing.Point(3, 140);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(100, 23);
            this.lblPassword.TabIndex = 7;
            this.lblPassword.Text = "Password: ";
            // 
            // lvCFDI
            // 
            this.lvCFDI.HideSelection = false;
            this.lvCFDI.Location = new System.Drawing.Point(0, 25);
            this.lvCFDI.MultiSelect = false;
            this.lvCFDI.Name = "lvCFDI";
            this.lvCFDI.Size = new System.Drawing.Size(345, 275);
            this.lvCFDI.TabIndex = 1;
            this.lvCFDI.UseCompatibleStateImageBehavior = false;
            this.lvCFDI.View = System.Windows.Forms.View.Details;
            this.lvCFDI.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lvCFDI_ItemActivate);
            // 
            // lblMensajeBorrado
            // 
            this.lblMensajeBorrado.Location = new System.Drawing.Point(0, 0);
            this.lblMensajeBorrado.Name = "lblMensajeBorrado";
            this.lblMensajeBorrado.Size = new System.Drawing.Size(400, 23);
            this.lblMensajeBorrado.TabIndex = 2;
            this.lblMensajeBorrado.Text = "Listado de CSD, (click sobre columna cliente para eliminar): ";
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancelar.Location = new System.Drawing.Point(380, 28);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(125, 50);
            this.cmdCancelar.TabIndex = 3;
            this.cmdCancelar.Text = "&Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            // 
            // cmdAceptar
            // 
            this.cmdAceptar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAceptar.Enabled = false;
            this.cmdAceptar.Location = new System.Drawing.Point(180, 28);
            this.cmdAceptar.Name = "cmdAceptar";
            this.cmdAceptar.Size = new System.Drawing.Size(125, 50);
            this.cmdAceptar.TabIndex = 2;
            this.cmdAceptar.Text = "&Guardar Configuración";
            this.cmdAceptar.UseVisualStyleBackColor = true;
            this.cmdAceptar.Click += new System.EventHandler(this.cmdAceptar_Click);
            // 
            // lblIndicaciones
            // 
            this.lblIndicaciones.AutoSize = true;
            this.lblIndicaciones.Location = new System.Drawing.Point(21, 6);
            this.lblIndicaciones.Name = "lblIndicaciones";
            this.lblIndicaciones.Size = new System.Drawing.Size(892, 23);
            this.lblIndicaciones.TabIndex = 1;
            this.lblIndicaciones.Text = "Al terminar la configuración de conexión, reinicie la aplicación para que se  con" +
    "sideren los cambios realizados";
            // 
            // epErroresConfiguracion
            // 
            this.epErroresConfiguracion.ContainerControl = this;
            // 
            // pnlBotones
            // 
            this.pnlBotones.Controls.Add(this.cmdAceptar);
            this.pnlBotones.Controls.Add(this.cmdCancelar);
            this.pnlBotones.Controls.Add(this.lblIndicaciones);
            this.pnlBotones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBotones.Location = new System.Drawing.Point(0, 379);
            this.pnlBotones.Name = "pnlBotones";
            this.pnlBotones.Size = new System.Drawing.Size(684, 90);
            this.pnlBotones.TabIndex = 1;
            // 
            // FrmConfiguracion
            // 
            this.AcceptButton = this.cmdAceptar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCancelar;
            this.ClientSize = new System.Drawing.Size(684, 469);
            this.Controls.Add(this.tabPrincipal);
            this.Controls.Add(this.pnlBotones);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmConfiguracion";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuracion";
            this.Load += new System.EventHandler(this.FrmConfiguracion_Load);
            this.tabPrincipal.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.pnlDatosADAM.ResumeLayout(false);
            this.pnlDatosADAM.PerformLayout();
            this.pnlSqlOracle.ResumeLayout(false);
            this.pnlSqlOracle.PerformLayout();
            this.pnlODBC.ResumeLayout(false);
            this.pnlODBC.PerformLayout();
            this.pnlPlataforma.ResumeLayout(false);
            this.pnlPlataforma.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.pnlParametrosAdicionales.ResumeLayout(false);
            this.pnlParametrosAdicionales.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.pnlCertKey.ResumeLayout(false);
            this.pnlCertKeyBar.ResumeLayout(false);
            this.pnlCertKeyBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epErroresConfiguracion)).EndInit();
            this.pnlBotones.ResumeLayout(false);
            this.pnlBotones.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        #region tabPage1
        private System.Windows.Forms.TabControl tabPrincipal;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel pnlSqlOracle;
        private System.Windows.Forms.Button cmdValidarConexion;
        private System.Windows.Forms.Label lblServidor;
        private System.Windows.Forms.Label lblBaseDatos;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Button cmdBuscar;
        private System.Windows.Forms.Label lblContrasenia;
        private System.Windows.Forms.TextBox txtServidor;
        private System.Windows.Forms.ComboBox cboBaseDatos;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtContrasenia;
        private System.Windows.Forms.Panel pnlODBC;
        private System.Windows.Forms.Button cmdValidarODBC;
        private System.Windows.Forms.Label lblParametros;
        private System.Windows.Forms.TextBox txtParametrosODBC;
        private System.Windows.Forms.Label lblControlador;
        private System.Windows.Forms.Label lblDbODBC;
        private System.Windows.Forms.Label lblUsuarioODBC;
        private System.Windows.Forms.Label lblPasswordODBC;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox cboDSN;
        private System.Windows.Forms.TextBox txtUsuarioODBC;
        private System.Windows.Forms.TextBox txtPasswordODBC;
        private System.Windows.Forms.Panel pnlInferior;
        private System.Windows.Forms.Panel pnlDatosADAM;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.ComboBox cboVersion;
        private System.Windows.Forms.Label lblUsuarioAplicacion;
        private System.Windows.Forms.TextBox txtUsuarioAplicacion;
        private System.Windows.Forms.Button cmdCancelar;
        private System.Windows.Forms.Button cmdAceptar;
        private System.Windows.Forms.Label lblIndicaciones;
        private System.Windows.Forms.Panel pnlPlataforma;
        private System.Windows.Forms.ComboBox cboPlataforma;
        private System.Windows.Forms.Label lblPlataforma;
        #endregion tabPage1

        #region tabPage2
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ErrorProvider epErroresConfiguracion;
        private System.Windows.Forms.Panel pnlBotones;
        private System.Windows.Forms.Panel pnlParametrosAdicionales;
        private System.Windows.Forms.Label lblSitio;
        private System.Windows.Forms.Label lblCompania;
        private System.Windows.Forms.ComboBox cboCompania;
        private System.Windows.Forms.Label lblRuta;
        private System.Windows.Forms.Label lblXslt;
        private System.Windows.Forms.Label lblMultiples;
        private System.Windows.Forms.ComboBox cboXslt;
        private System.Windows.Forms.TextBox txtSitio;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.ComboBox cboMultiples;
        private System.Windows.Forms.Label lblServicio;
        private System.Windows.Forms.TextBox txtServicio;
        private System.Windows.Forms.TextBox txtProcAdicionales;
        private System.Windows.Forms.ComboBox cboDatosAdicionales;
        private System.Windows.Forms.Label lblProcAdicionales;
        private System.Windows.Forms.Label lblDatosAdicionales;
        private System.Windows.Forms.ComboBox cboTipoServicio;
        private System.Windows.Forms.Label lblTipoServicio;
        private System.Windows.Forms.TextBox txtPuerto;
        private System.Windows.Forms.Label lblPuerto;
        private System.Windows.Forms.Button cmdConsultasODBC;
        private System.Windows.Forms.ComboBox cboXSD;
        private System.Windows.Forms.Label lblXSD;
        private System.Windows.Forms.TextBox txtWSUsrPwd;
        private System.Windows.Forms.Label lblWSUsrPwd;
        private System.Windows.Forms.TextBox txtWSUsrID;
        private System.Windows.Forms.Label lblWSUsrID;
        private System.Windows.Forms.ComboBox cboPaisDefault;
        private System.Windows.Forms.Label lblPaisDefault;
        private System.Windows.Forms.Label lblTimeout;
        private System.Windows.Forms.TextBox txtTimeout;
        #endregion tabPage2

        #region tabPage3
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel pnlCertKey;
        private System.Windows.Forms.Panel pnlCertKeyBar;
        private System.Windows.Forms.ComboBox cboCompaniaCertKey;
        private System.Windows.Forms.TextBox txtCertKeyPassword;
        private System.Windows.Forms.Button btnAddCertKey;
        private System.Windows.Forms.Button btnLoadCert;
        private System.Windows.Forms.Button btnLoadKey;
        private System.Windows.Forms.TextBox txtCertPath;
        private System.Windows.Forms.TextBox txtKeyPath;
        private System.Windows.Forms.ListView lvCFDI;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblMensajeBorrado;
        #endregion tabPage3

        private System.Windows.Forms.OpenFileDialog fdCertFile;
        private System.Windows.Forms.OpenFileDialog fdKeyFile;
    }
}
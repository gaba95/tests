﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("fondoPension", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PensionFund
    {
        [JsonProperty("porcentaje")]
        public decimal DeduccionPorcentaje { get; set; }

        [JsonProperty("deduccion")]
        public decimal Deduccion { get; set; }
    }
}

using ADAM.Recibos.Utilerias.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Utilerias.Tests.Clases
{
    [TestClass]
    public class FileExtensionTests
    {
        [TestMethod]
        public void FileExtension_Txt_HasValue0()
        {
            Assert.AreEqual(0, (int)FileExtension.txt);
        }

        [TestMethod]
        public void FileExtension_Csv_HasValue1()
        {
            Assert.AreEqual(1, (int)FileExtension.csv);
        }

        [TestMethod]
        public void FileExtension_ContainsTwoValues()
        {
            var values = Enum.GetValues(typeof(FileExtension));
            Assert.AreEqual(2, values.Length);
        }

        [TestMethod]
        [DataRow(FileExtension.txt)]
        [DataRow(FileExtension.csv)]
        public void FileExtension_AllValues_AreDefined(FileExtension ext)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(FileExtension), ext));
        }

        [TestMethod]
        public void FileExtension_ToString_ReturnsExpectedName()
        {
            Assert.AreEqual("txt", FileExtension.txt.ToString());
            Assert.AreEqual("csv", FileExtension.csv.ToString());
        }
    }
}

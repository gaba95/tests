﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("deducciones", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Deductions
    {
        public Health salud { get; set; }
        public PensionFund fondoPension { get; set; }
        public PensionfundSP fondoPensionSP { get; set; }
        public List<Unions> sindicatos { get; set; }
        public List<Sanctions> sanciones { get; set; }
        public List<Orders> libranzas { get; set; }
        public List<ThirdPartyPayments> pagosTerceros { get; set; }
        public List<Advances> anticipos { get; set; }
        public List<OtherDiscounts> otrosDescuentos { get; set; }

        [JsonProperty("pensionVoluntaria")]
        public decimal PensionVoluntaria { get; set; }

        [JsonProperty("retencionFuente")]
        public decimal RetencionFuente { get; set; }

        [JsonProperty("afc")]
        public decimal AFC { get; set; }

        [JsonProperty("cooperativa")]
        public decimal Cooperativa { get; set; }

        [JsonProperty("embargofiscal")]
        public decimal EmbargoFiscal { get; set; }

        [JsonProperty("planComplementarios")]
        public decimal PlanComplementarios { get; set; }

        [JsonProperty("educacion")]
        public decimal Educacion { get; set; }

        [JsonProperty("reintegro")]
        public decimal Reintegro { get; set; }
        
        [JsonProperty("deuda")]
        public decimal Deuda { get; set; }
    }
}

using Moq;
using System;
using System.Data;
using System.Reflection;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Datos.Clases.Common;
using Oracle.ManagedDataAccess.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoSAT
{
    [TestClass]
    public class CatalogoSatOracleTests
    {
        #region Constructor & Basic Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoSatOracle(mockFactory.Object);

            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        #endregion

        #region Structure / Reflection Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoSat()
        {
            Assert.IsTrue(typeof(ICatalogoSat).IsAssignableFrom(typeof(CatalogoSatOracle)));
        }

        [DataTestMethod]
        [DataRow("dsListaCatalogosSAT")]
        [DataRow("obtenDatasetCatalogosSAT")]
        [DataRow("obtenDatasetCatalogos")]
        [DataRow("obtenCatalogoADAM")]
        [DataRow("obtenDatasetRelacionCatalogosSATADAM")]
        [DataRow("AltaRelacionDatoCatalogoADAM")]
        [DataRow("BajaRelacionDatoCatalogoADAM")]
        public void ShouldContainMethod(string methodName)
        {
            var method = typeof(CatalogoSatOracle).GetMethod(methodName,
                BindingFlags.Public | BindingFlags.Instance);
            Assert.IsNotNull(method, $"Method {methodName} should exist");
        }

        #endregion

        #region InvalidCastException Tests (mock IDbConnection, not OracleConnection)

        [TestMethod]
        public void DsListaCatalogosSAT_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.dsListaCatalogosSAT());
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetCatalogosSAT("1"));
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetCatalogos("table1"));
        }

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenCatalogoADAM("1", "COMP"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP"));
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.AltaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01"));
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.BajaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01"));
        }

        #endregion

        #region RealOracleConnection Tests

        [TestMethod]
        public void DsListaCatalogosSAT_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.dsListaCatalogosSAT());
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetCatalogosSAT("1"));
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetCatalogos("table1"));
        }

        [TestMethod]
        public void ObtenCatalogoADAM_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenCatalogoADAM("1", "COMP"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP"));
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.AltaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01"));
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.BajaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01"));
        }

        #endregion

        #region Helpers

        private CatalogoSatOracle CreateServiceWithRealOracleConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new OracleConnection("Data Source=localhost/FAKE;User Id=test;Password=test;Connection Timeout=1"));

            return new CatalogoSatOracle(mockFactory.Object);
        }

        private CatalogoSatOracle CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            return new CatalogoSatOracle(mockFactory.Object);
        }

        #endregion
    }
}

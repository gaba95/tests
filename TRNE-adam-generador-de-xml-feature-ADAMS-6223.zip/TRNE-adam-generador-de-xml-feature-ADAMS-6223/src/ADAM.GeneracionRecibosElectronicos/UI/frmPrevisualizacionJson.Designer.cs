namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmPrevisualizacionJson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrevisualizacionJson));
            this.lblRegimen = new System.Windows.Forms.Label();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            this.cmdVerTodos = new System.Windows.Forms.Button();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdGuardar = new System.Windows.Forms.Button();
            this.pnlInferior = new System.Windows.Forms.Panel();
            this.gridDatosTrabajadores = new System.Windows.Forms.DataGridView();
            this.pnlResultados = new System.Windows.Forms.Panel();
            this.gridTotales = new System.Windows.Forms.DataGridView();
            this.pnlPreview = new System.Windows.Forms.Panel();
            this.pnlTreeview = new System.Windows.Forms.Panel();
            this.trvJson = new System.Windows.Forms.TreeView();
            this.pnlEstatus = new System.Windows.Forms.Panel();
            this.lbStatus = new System.Windows.Forms.ListBox();
            this.savedialog = new System.Windows.Forms.SaveFileDialog();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.pnlHerramientas.SuspendLayout();
            this.pnlInferior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosTrabajadores)).BeginInit();
            this.pnlResultados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridTotales)).BeginInit();
            this.pnlPreview.SuspendLayout();
            this.pnlTreeview.SuspendLayout();
            this.pnlEstatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRegimen
            // 
            this.lblRegimen.AutoSize = true;
            this.lblRegimen.Location = new System.Drawing.Point(0, -40);
            this.lblRegimen.Name = "lblRegimen";
            this.lblRegimen.Size = new System.Drawing.Size(143, 18);
            this.lblRegimen.TabIndex = 0;
            this.lblRegimen.Text = "Regimen de Contatación";
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(947, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(387, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Visualización del Json ADAM - DIAN";
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.cmdVerTodos);
            this.pnlHerramientas.Controls.Add(this.cmdCerrar);
            this.pnlHerramientas.Controls.Add(this.cmdGuardar);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlHerramientas.Location = new System.Drawing.Point(814, 50);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Padding = new System.Windows.Forms.Padding(5);
            this.pnlHerramientas.Size = new System.Drawing.Size(133, 472);
            this.pnlHerramientas.TabIndex = 16;
            // 
            // cmdVerTodos
            // 
            this.cmdVerTodos.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdVerTodos.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdVerTodos.Location = new System.Drawing.Point(5, 5);
            this.cmdVerTodos.Name = "cmdVerTodos";
            this.cmdVerTodos.Size = new System.Drawing.Size(123, 40);
            this.cmdVerTodos.TabIndex = 24;
            this.cmdVerTodos.Text = "&Ver Todos";
            this.cmdVerTodos.UseVisualStyleBackColor = true;
            this.cmdVerTodos.Click += new System.EventHandler(this.cmdVerTodos_Click);
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCerrar.Location = new System.Drawing.Point(5, 83);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(123, 40);
            this.cmdCerrar.TabIndex = 26;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            this.cmdCerrar.Click += new System.EventHandler(this.cmdSalir_Click);
            // 
            // cmdGuardar
            // 
            this.cmdGuardar.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdGuardar.Location = new System.Drawing.Point(5, 44);
            this.cmdGuardar.Name = "cmdGuardar";
            this.cmdGuardar.Size = new System.Drawing.Size(123, 40);
            this.cmdGuardar.TabIndex = 25;
            this.cmdGuardar.Text = "&Abrir Json";
            this.cmdGuardar.UseVisualStyleBackColor = true;
            this.cmdGuardar.Click += new System.EventHandler(this.cmdGuardar_Click);
            // 
            // pnlInferior
            // 
            this.pnlInferior.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInferior.Controls.Add(this.gridDatosTrabajadores);
            this.pnlInferior.Controls.Add(this.pnlResultados);
            this.pnlInferior.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlInferior.Location = new System.Drawing.Point(0, 50);
            this.pnlInferior.Name = "pnlInferior";
            this.pnlInferior.Size = new System.Drawing.Size(602, 472);
            this.pnlInferior.TabIndex = 17;
            // 
            // gridDatosTrabajadores
            // 
            this.gridDatosTrabajadores.AllowUserToAddRows = false;
            this.gridDatosTrabajadores.AllowUserToDeleteRows = false;
            this.gridDatosTrabajadores.AllowUserToResizeColumns = false;
            this.gridDatosTrabajadores.AllowUserToResizeRows = false;
            this.gridDatosTrabajadores.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosTrabajadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosTrabajadores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDatosTrabajadores.Location = new System.Drawing.Point(0, 0);
            this.gridDatosTrabajadores.MultiSelect = false;
            this.gridDatosTrabajadores.Name = "gridDatosTrabajadores";
            this.gridDatosTrabajadores.ReadOnly = true;
            this.gridDatosTrabajadores.RowHeadersVisible = false;
            this.gridDatosTrabajadores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosTrabajadores.Size = new System.Drawing.Size(602, 412);
            this.gridDatosTrabajadores.TabIndex = 0;
            this.gridDatosTrabajadores.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridDatosTrabajadores_CellClick);
            this.gridDatosTrabajadores.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gridDatosTrabajadores_CellPainting);
            this.gridDatosTrabajadores.ColumnAdded += new System.Windows.Forms.DataGridViewColumnEventHandler(this.gridDatosTrabajadores_ColumnAdded);
            this.gridDatosTrabajadores.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridDatosTrabajadores_ColumnHeaderMouseClick);
            // 
            // pnlResultados
            // 
            this.pnlResultados.Controls.Add(this.gridTotales);
            this.pnlResultados.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlResultados.Location = new System.Drawing.Point(0, 412);
            this.pnlResultados.Name = "pnlResultados";
            this.pnlResultados.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.pnlResultados.Size = new System.Drawing.Size(602, 60);
            this.pnlResultados.TabIndex = 3;
            // 
            // gridTotales
            // 
            this.gridTotales.AllowUserToDeleteRows = false;
            this.gridTotales.AllowUserToResizeRows = false;
            this.gridTotales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridTotales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridTotales.Location = new System.Drawing.Point(0, 10);
            this.gridTotales.MultiSelect = false;
            this.gridTotales.Name = "gridTotales";
            this.gridTotales.ReadOnly = true;
            this.gridTotales.RowHeadersVisible = false;
            this.gridTotales.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gridTotales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridTotales.Size = new System.Drawing.Size(602, 50);
            this.gridTotales.TabIndex = 5;
            // 
            // pnlPreview
            // 
            this.pnlPreview.Controls.Add(this.pnlTreeview);
            this.pnlPreview.Controls.Add(this.pnlEstatus);
            this.pnlPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPreview.Location = new System.Drawing.Point(602, 50);
            this.pnlPreview.Name = "pnlPreview";
            this.pnlPreview.Padding = new System.Windows.Forms.Padding(5);
            this.pnlPreview.Size = new System.Drawing.Size(212, 472);
            this.pnlPreview.TabIndex = 18;
            // 
            // pnlTreeview
            // 
            this.pnlTreeview.Controls.Add(this.trvJson);
            this.pnlTreeview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTreeview.Location = new System.Drawing.Point(5, 5);
            this.pnlTreeview.Name = "pnlTreeview";
            this.pnlTreeview.Size = new System.Drawing.Size(202, 417);
            this.pnlTreeview.TabIndex = 2;
            // 
            // trvJson
            // 
            this.trvJson.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trvJson.Location = new System.Drawing.Point(0, 0);
            this.trvJson.Name = "trvJson";
            this.trvJson.Size = new System.Drawing.Size(202, 417);
            this.trvJson.TabIndex = 1;
            // 
            // pnlEstatus
            // 
            this.pnlEstatus.Controls.Add(this.lbStatus);
            this.pnlEstatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlEstatus.Location = new System.Drawing.Point(5, 422);
            this.pnlEstatus.Name = "pnlEstatus";
            this.pnlEstatus.Size = new System.Drawing.Size(202, 45);
            this.pnlEstatus.TabIndex = 1;
            // 
            // lbStatus
            // 
            this.lbStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbStatus.FormattingEnabled = true;
            this.lbStatus.ItemHeight = 18;
            this.lbStatus.Location = new System.Drawing.Point(0, 0);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(202, 45);
            this.lbStatus.TabIndex = 0;
            // 
            // savedialog
            // 
            this.savedialog.DefaultExt = "xlsx";
            // 
            // FrmPrevisualizacionJson
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(947, 522);
            this.Controls.Add(this.pnlPreview);
            this.Controls.Add(this.pnlInferior);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.lblRegimen);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FrmPrevisualizacionJson";
            this.ShowInTaskbar = false;
            this.Text = "Visualización Json ADAM - DIAN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmPrevisualizacionJson_Load);
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.pnlHerramientas.ResumeLayout(false);
            this.pnlInferior.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosTrabajadores)).EndInit();
            this.pnlResultados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridTotales)).EndInit();
            this.pnlPreview.ResumeLayout(false);
            this.pnlTreeview.ResumeLayout(false);
            this.pnlEstatus.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblRegimen;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Button cmdGuardar;
        private System.Windows.Forms.Panel pnlInferior;
        private System.Windows.Forms.DataGridView gridDatosTrabajadores;
        private System.Windows.Forms.Panel pnlResultados;
        private System.Windows.Forms.Panel pnlPreview;
        private System.Windows.Forms.Button cmdVerTodos;
        private System.Windows.Forms.DataGridView gridTotales;
        private System.Windows.Forms.SaveFileDialog savedialog;
        private System.Windows.Forms.Panel pnlTreeview;
        private System.Windows.Forms.TreeView trvJson;
        private System.Windows.Forms.Panel pnlEstatus;
        private System.Windows.Forms.ListBox lbStatus;
    }
}
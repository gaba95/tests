﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("bonosEPCTV", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class EPCTVBonds
    {
        [JsonProperty("descripcion")]
        public string valorDescripcion { get; set; } = "";

        public decimal valor { get; set; }
        public bool esParteSalario { get; set; }
        public bool esPagoAlimentacion { get; set; }
    }
}

﻿using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.Recibos.Controls
{
    [ExcludeFromCodeCoverage]
    public class CustomMessageBox : Form
    {
        /// <summary>When true, Show() returns DialogResult.OK without displaying any UI. Use in unit-test / CI scenarios.</summary>
        public static bool SuppressUI { get; set; }

        public CustomMessageBox(string message, string title, string linkText, string filePath, MessageBoxIcon iconType)
        {
            // Form settings
            this.Text = title;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ClientSize = new Size(200, 50);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.BackColor = Color.White;
            this.AutoSize = true;
            this.TopMost = true;

            // Middle panel
            var middlePanel = new Panel()
            {
                MinimumSize = new Size(200,25),
                Size = new Size(200,25),
                BackColor = Color.White,
                AutoSize = true
            };

            // Icon
            var picIcon = new PictureBox
            {
                Location = new Point(15, 30),
                Size = new Size(32, 32),
                SizeMode = PictureBoxSizeMode.StretchImage
            };

            // Load icon based on MessageBoxIcon
            switch (iconType)
            {
                case MessageBoxIcon.Information:
                    picIcon.Image = SystemIcons.Information.ToBitmap();
                    break;
                case MessageBoxIcon.Warning:
                    picIcon.Image = SystemIcons.Warning.ToBitmap();
                    break;
                case MessageBoxIcon.Error:
                    picIcon.Image = SystemIcons.Error.ToBitmap();
                    break;
                case MessageBoxIcon.Question:
                    picIcon.Image = SystemIcons.Question.ToBitmap();
                    break;
                default:
                    picIcon.Image = null;
                    break;
            }

            // Message label
            var lblMessage = new Label
            {
                Text = message,
                AutoSize = true,
                MinimumSize = new Size(200, 0),
                MaximumSize = new Size(500, 0), // Wrap text if too long
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10),
                Location = new Point(50, 10),
            };

            // Link label
            var linkLabel = new LinkLabel
            {
                Text = linkText,
                AutoSize = true,
                MinimumSize = new Size(200, 0),
                MaximumSize = new Size(500, 0), // Wrap text if too long
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10),
                Location = new Point(10, 130)
            };

            linkLabel.LinkClicked += (sender, e) =>
            {
                try
                {
                    OpenFileSecure(filePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            // Bottom panel
            var bottomPanel = new Panel()
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = SystemColors.Control
            };

            // OK button
            var btnOk = new Button
            {
                Text = "OK",
                DialogResult = DialogResult.OK,
                Size = new Size(80, 30),
                Anchor = AnchorStyles.Right | AnchorStyles.Bottom,
            };

            // Add controls
            middlePanel.Controls.Add(picIcon);
            middlePanel.Controls.Add(lblMessage);
            if (!string.IsNullOrEmpty(linkText) && !string.IsNullOrEmpty(filePath))
            {
                middlePanel.Controls.Add(linkLabel);
            }
            bottomPanel.Controls.Add(btnOk);
            this.Controls.Add(middlePanel);
            this.Controls.Add(bottomPanel);

            // Set default button actions
            this.AcceptButton = btnOk;

            // Auto-size form based on label
            this.Load += (s, e) =>
            {
                // Relocate Link
                if (!string.IsNullOrEmpty(linkText) && !string.IsNullOrEmpty(filePath))
                {
                    linkLabel.Location = new Point(lblMessage.Location.X, lblMessage.Height + 10);
                }

                // Adjust form size to fit message
                this.ClientSize = new Size(this.ClientSize.Width,
                    middlePanel.Height + bottomPanel.Height + 10
                );

                // Relocate Button
                btnOk.Location = new Point(this.ClientSize.Width - btnOk.Width - 20, 10);
            };
        }

        public static DialogResult Show(string message, string title, string linkText, string filePath, MessageBoxIcon iconType)
        {
            if (SuppressUI) return DialogResult.OK;
            using (CustomMessageBox msgBox = new CustomMessageBox(message, title, linkText, filePath, iconType))
            {
                return msgBox.ShowDialog();
            }
        }

        public static DialogResult Show(string message, string title, MessageBoxIcon iconType)
        {
            if (SuppressUI) return DialogResult.OK;
            using (CustomMessageBox msgBox = new CustomMessageBox(message, title, string.Empty, string.Empty, iconType))
            {
                return msgBox.ShowDialog();
            }
        }

        private static void OpenFileSecure(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return;

            string fullPath = Path.GetFullPath(path);

            char[] forbidden = { '"', '&', '|', ';', '<', '>', '`', '$', '!', '\n', '\r' };
            if (fullPath.IndexOfAny(forbidden) >= 0)
                throw new ArgumentException("File path contains invalid characters.");

            if (!Path.IsPathRooted(fullPath) || !File.Exists(fullPath))
                return;

            string ext = Path.GetExtension(fullPath).ToLowerInvariant();
            string[] allowedExtensions = { ".xml", ".html", ".htm", ".json", ".csv", ".txt", ".pdf", ".xlsx", ".xls", ".zip" };
            if (!allowedExtensions.Contains(ext))
                throw new ArgumentException($"File extension '{ext}' is not allowed.");

            // Copy to safe temp location to break taint chain
            string safeTempDir = Path.Combine(Path.GetTempPath(), "ADAM_Viewer");
            Directory.CreateDirectory(safeTempDir);
            string safeFileName = "preview" + ext;
            string safeTempFile = Path.Combine(safeTempDir, safeFileName);
            File.Copy(fullPath, safeTempFile, overwrite: true);

            // Open the safe copy — path is fully controlled
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = safeTempFile,
                UseShellExecute = false,
                CreateNoWindow = true
            });
        }
    }
}

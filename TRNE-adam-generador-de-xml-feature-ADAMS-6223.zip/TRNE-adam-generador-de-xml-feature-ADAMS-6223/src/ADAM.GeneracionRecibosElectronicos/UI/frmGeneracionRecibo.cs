﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADAM.GeneracionRecibosElectronicos.Clases;
using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using ADAM.GeneracionRecibosElectronicos.Clases.Filter;
using ADAM.GeneracionRecibosElectronicos.Enums;
using ADAM.GeneracionRecibosElectronicos.UI;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Hangfire;
using ADAM.Recibos.Hangfire.Models;
using ADAM.Recibos.Principal;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmGeneracionRecibo : Form
    {
        private ToolStripButton tcmdConfiguracion;
        private ToolStripButton tcmdTipos;
        private ToolStripButton tcmdRegimen;
        private ToolStripButton tcmdBancos;
        private ToolStripButton tcmdIncapacidades;
        private ToolStripButton tcmdMapeoSAT;
        private ToolStripButton tcmdMapeoDIAN;
        private ToolStripButton tcmdConceptosDIAN;
        private ToolStripButton tcmdDocumentState;
        private ToolStripButton tcmdSitio;
        private ToolStripButton tcmdCatalogosDIAN;

        #region Variables

        private IBRReciboElectronico br;
        private ICatalogoDian _catalogosDIAN;
        private ICatalogoAdicional _catalogoAdicional;

        CallBackThread objThreadEjecucion;
        private string compania = "";
        private string gAnio = "";
        private string gMes = "";
        private bool bTransmitJsonToWS = false;
        private string metodoPago = "";   // AZ-1071: Not used for multiple payrolls

        private bool generarArchivos = false;
        private string trabajadorProcesado = "";
        private string archivoProcesado = "";

        // Stamping Variables
        private string rutaCertificado = "";
        private string passwordLlave = "";
        private string rutaLlave = "";
        private const string DateTimeFormat = "yyyyMMddHHmmss";
        private const string ColIdPadre = "id_padre";
        private const string ColIdParametro = "id_parametro";
        private const string ColAlfanumerico = "alfanumerico";
        private const string listaCamposImporte = "TotalGravado,TotalExento,TotalPercepciones,TotalGravadoDed,TotalExentoDed,TotalDeducciones,TotalImpuestosRet,NetoPagar,SalarioMensual";
        uint fPreviousExecutionState;       // Variable para guardar la configuracion actual
        uint nullVar = 0;                   // Para desactivar el protector de pantalla
        uint protectorPantallaActivo = 0;   // Guardar el estado actual de protector de pantalla

        // AZ-1061: Add variables to set the filtering of the grid
        private List<String> stringStateFilters = new List<String>();
        private string sFilterTrabajadores = String.Empty;
        private string selRowName = "Selected";
        private string statusRowName = "Estado";
        private string statusIdRowName = "IdEstado";
        private string dsFormFilter = String.Empty;

        StampingStatusDataHolder statusDataTempHolder = new StampingStatusDataHolder();

        ApplicationEnvironmentSettings appSettings;

        string adamEnvironmentParameter;

        private string szAccessToken;

        private string szResponseMsg;

        private DateTime dateTimeTokenIsValid;

        private DgQuery queryTrabajadores = null;

        private bool unSelectAll = true;

        #endregion

        #region Properties

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Pais { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Server { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Database { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string User { get; set; }
        
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SecureString Pwd { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AdamExecution { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Institucion
        {
            get
            {
                string szInst;
                switch (Pais)
                {
                    case "México":
                        szInst = "SAT";
                        break;
                    case "Colombia":
                        szInst = "DIAN";
                        break;
                    default:
                        szInst = "SAT";
                        break;
                }
                return szInst;
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Idioma
        {
            get
            {
                string szLanguage;
                switch (Pais)
                {
                    case "México":
                        szLanguage = LanguageCodes.Mexico;
                        break;
                    case "Colombia":
                        szLanguage = LanguageCodes.Colombia;
                        break;
                    default:
                        szLanguage = LanguageCodes.Mexico;
                        break;
                }
                return szLanguage;
            }
        }

        #endregion

        #region Events

        private void FrmGeneracionRecibo_Load(object sender, EventArgs e)
        {
            Inicializaclase();
        }
        
        private void CommandActionItem_Click(object sender, EventArgs e)
        {
            ToolStripButton button = (ToolStripButton)sender;
            CommandActions action = (CommandActions)button.Tag;
            switch (action)
            {
                case CommandActions.CONFIGURACION_ACCESO:
                    cmdConfiguracion_Click(sender, e);
                    break;
                case CommandActions.DEFINIR_TIPOS_CONCEPTOS:
                    cmdTipos_Click(sender, e);
                    break;
                case CommandActions.DEFINIR_REGIMEN_CONTRATACION:
                    cmdRegimen_Click(sender, e);
                    break;
                case CommandActions.CONFIGURACION_BANCOS:
                    cmdBancos_Click(sender, e);
                    break;
                case CommandActions.CONFIGURACION_INCAPACIDADES:
                    cmdIncapacidades_Click(sender, e);
                    break;
                case CommandActions.MAPEO_CATALOGOS_ADAM_SAT:
                    cmdMapeoSAT_Click(sender, e);
                    break;
                case CommandActions.MAPEO_CATALOGOS_ADAM_DIAN:
                    cmdMapeoDIAN_Click(sender, e);
                    break;
                case CommandActions.MAPEO_CONCEPTOS_ADAM_DIAN:
                    cmdConceptosDIAN_Click(sender, e);
                    break;
                case CommandActions.SITIO_TIMBRADO:
                    cmdSitio_Click(sender, e);
                    break;
                case CommandActions.CONSULTA_CATALOGOS_ADAM_DIAN:
                    cmdCatalogosDIAN_Click(sender, e);
                    break;
                case CommandActions.CONSULTA_ESTADO_DOCUMENTO:
                    cmdDocumentState_Click(sender, e);
                    break;
                default:
                    break;
            }
        }
        
        private void ToolStripButton_Paint(object sender, PaintEventArgs e)
        {
            ToolStripButton btn = (ToolStripButton)sender;
            ControlPaint.DrawBorder3D(e.Graphics, new Rectangle(0, 0, btn.Width, btn.Height));
            btn.BackColor = System.Drawing.Color.Gainsboro;
        }
        
        private void cboCompania_SelectedIndexChanged(object sender, EventArgs e)
        {
            // PTF-4277
            // Don't trigger if the dropdown is currently filled
            if (this.cboCompania.Tag != null) return;

            compania = cboCompania.SelectedValue.ToString();

            chlTipoNomina.DataSource = _catalogoAdicional.obtenDatasetTiposNomina(compania).Tables[0];
            chlTipoNomina.DisplayMember = "descripcion";
            chlTipoNomina.ValueMember = "tipo_nomina";
            chlClaseNomina.DataSource = _catalogoAdicional.obtenDatasetClasesNomina(compania).Tables[0];
            chlClaseNomina.DisplayMember = "descripcion";
            chlClaseNomina.ValueMember = "clase_nomina";

            gridTrabajadores.Columns.Clear();
            lbGenerados.Items.Clear();

            Properties.AppSettings.Default.selectedCompany = cboCompania.SelectedValue.ToString();
            ToggleOptionsLegacyNewStampingMode();
        }

        public void ToggleOptionsLegacyNewStampingMode()
        {
            try
            {
                if (Enum.Parse<Countries>(this.Pais) == Countries.México)
                {
                    if (this.IsNewStampingMode())
                    {
                        cmdGeneraArchivo.Visible = false;
                        cmdGenera.Text = "Timbrar y generar recibos";
                    }
                    else
                    {
                        cmdGeneraArchivo.Visible = true;
                        cmdGenera.Text = "Enviar Datos" + System.Environment.NewLine + "Sitio Timbrado";
                    }
                }
            }
            catch
            {
                // Intentionally ignored: UI toggle is non-critical
            }

        }

        private void cboClaseNomina_SelectedIndexChanged(object sender, EventArgs e)
        {
            gridTrabajadores.Columns.Clear();
            lbGenerados.Items.Clear();
        }
        
        private void txtAnio_ValueChanged(object sender, EventArgs e)
        {
            gridTrabajadores.Columns.Clear();
            lbGenerados.Items.Clear();
        }
        
        private void txtAnioAcumular_ValueChanged(object sender, EventArgs e)
        {
            gridTrabajadores.Columns.Clear();
            lbGenerados.Items.Clear();
        }
        
        private void setRowSelectionByType(int option, DataGridViewRow selectedRow, bool select)
        {
            DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)selectedRow.Cells["Sel"];

            switch (option)
            {
                case 1:
                    if (gridTrabajadores.Columns.Contains("TotalDeducciones") && gridTrabajadores.Columns.Contains("TotalPercepciones") && Convert.ToDecimal(selectedRow.Cells["TotalDeducciones"].Value) == 0 && Convert.ToDecimal(selectedRow.Cells["TotalPercepciones"].Value) == 0)
                    {
                        selectedColumn.Value = select;
                    }
                    break;
                default:
                    selectedColumn.Value = select;
                    break;
            }
        }
        
        private void updateSelectedRows(bool changeAllSelection, bool select)
        {
            this.Cursor = Cursors.WaitCursor;

            this.gridTrabajadores.CellValueChanged -= new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);

            int contador = 0;

            foreach (DataGridViewRow renglon in gridTrabajadores.Rows)
            {
                // AZ-1061: Change to use checkbox cell instead of parsed value
                DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)renglon.Cells["Sel"];

                // AZ-1061: Don't change the value if the checkbox is readonly
                if (!selectedColumn.ReadOnly)
                {
                    if (changeAllSelection)
                    {
                        setRowSelectionByType(cboTipoSeleccion.SelectedIndex, renglon, select);
                    }

                    if (selectedColumn.Value != null && bool.Parse(selectedColumn.Value.ToString()))
                        contador++;
                }
            }

            lblContador.Text = contador.ToString();

            CalculaTotales();

            // Ligar el evento para el valueChanged del Grid
            this.gridTrabajadores.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);
            this.Cursor = Cursors.Default;
        }
        
        private void cmdTrabajadores_Click(object sender, EventArgs e)
        {
            cmdGeneraArchivo.Enabled = true;
            cmdGenera.Enabled = true;
            pbResultados.Value = 0;

            // Get Employees List
            obtenListaTrabajadores();

            // Add Totals
            if (gridTrabajadores.Rows.Count > 0)
            {
                ConfiguraColumnasTotal();
                CalculaTotales();
                configuraCeldasImporte(gridTrabajadores);
                configuraCeldasImporte(gridTotales);
            }
        }
        
        private void cmdGeneraArchivo_Click(object sender, EventArgs e)
        {
            // PTF-3884
            if (Enum.Parse<Countries>(this.Pais) == Countries.Colombia)
            {
                // AZ-1061: If none selected, return
                int selectedCount = int.Parse(lblContador.Text);
                if (selectedCount <= 0)
                {
                    MessageBox.Show("No se encontró ningún trabajador seleccionado", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Process Employees
                if (gridTrabajadores.Rows.Count > 0)
                { ProcessDIANRecords(); }
            }
            else if (Enum.Parse<Countries>(this.Pais) == Countries.México)
            {
                // AZ-1061: If none selected, return
                int selectedCount = int.Parse(lblContador.Text);
                if (selectedCount <= 0)
                {
                    MessageBox.Show("No se encontró ningún trabajador seleccionado", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                lbGenerados.Items.Clear();
                generarArchivos = true;

                this.Cursor = Cursors.WaitCursor;
                cmdGeneraArchivo.Enabled = false;
                cmdGenera.Enabled = false;

                ProcesarTimbradoXMLs();
            }
        }
        
        private void cmdGenera_Click(object sender, EventArgs e)
        {
            // AZ-1061: If none selected, return
            int selectedCount = int.Parse(lblContador.Text);
            if (selectedCount <= 0)
            {
                MessageBox.Show("No se encontró ningún trabajador seleccionado", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidaEnvio())
            {
                return;
            }

            lbGenerados.Items.Clear();
            generarArchivos = false;

            this.Cursor = Cursors.WaitCursor;
            cmdGeneraArchivo.Enabled = true;
            cmdGenera.Enabled = true;

            if (Enum.Parse<Countries>(this.Pais) == Countries.México)
            {
                // Timbrado México Process
                ProcesarTimbradoXMLs();
            }
            else
            {
                // Set Var
                bTransmitJsonToWS = true;

                // CENET Colombia Json Process
                ProcessDIANRecords();
            }
        }
        
        private void cmdConfiguracion_Click(object sender, EventArgs e)
        {
            FrmConfiguracion configurationForm = new FrmConfiguracion();
            configurationForm.formaPadre = this;
            configurationForm.Server = this.Server;
            configurationForm.Database = this.Database;
            configurationForm.User = this.User;
            configurationForm.Pwd = this.Pwd;
            configurationForm.AdamExecution = this.AdamExecution;
            configurationForm.AppSettings = this.appSettings;
            configurationForm.Pais = this.Pais;
            configurationForm.ShowDialog();

            // Save country
            Properties.AppSettings.Default.defaultCountry = configurationForm.Pais;
            Properties.AppSettings.Default.Save();
        }
        
        private void cmdTipos_Click(object sender, EventArgs e)
        {
            FrmTiposPercepcionDeduccionSAT tipos = new FrmTiposPercepcionDeduccionSAT(Properties.AppSettings.Default);
            tipos.tipoPlataforma = this.tipoPlataforma;
            tipos.ShowDialog();
        }
        
        private void cmdRegimen_Click(object sender, EventArgs e)
        {
            FrmRegimenContratacion regimen = new FrmRegimenContratacion();
            regimen.compania = cboCompania.SelectedValue.ToString();
            regimen.tipoPlataforma = this.tipoPlataforma;
            regimen.ShowDialog();
        }
        
        private void gridTrabajadores_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            CalculaTotales();
        }

        private void gridTrabajadores_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.ScrollOrientation == ScrollOrientation.HorizontalScroll)
            {
                gridTotales.FirstDisplayedScrollingColumnIndex = gridTrabajadores.FirstDisplayedScrollingColumnIndex;
            }
        }
        
        private void gridTotales_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            return;
        }
        
        private void gridTrabajadores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                gridTrabajadores.Select();
                //unselect change to false, in order to not unselect all checkboxes in rows
                unSelectAll = false;
                //everytime a checkbox is clicked means that select all checkbox has to be unchecked
                chkSelectAll.Checked = false;

                //with this routine gets if the select checkbox is true or false, util to change lblcontador
                if (gridTrabajadores.CurrentRow != null)
                {
                    //EndEdit is needed to obtain the value of the cell correctly
                    gridTrabajadores.EndEdit();
                    DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)gridTrabajadores.CurrentRow.Cells["Sel"];

                    if (bool.Parse(selectedColumn.Value.ToString()))
                    {
                        lblContador.Text = (int.Parse(lblContador.Text) + 1).ToString();
                    }
                    else
                    {
                        lblContador.Text = (int.Parse(lblContador.Text) - 1).ToString();
                    }
                }

                CalculaTotales();

                if (AdamExecution == "1")
                {
                    gridTotales.Refresh();
                    gridTrabajadores.Refresh();
                }

            }
        }
        
        private void cmdCopiar_Click(object sender, EventArgs e)
        {
            CopiarListaAlclipBoard();
        }
        
        private void cmdSitio_Click(object sender, EventArgs e)
        {
            string companiaSeleccionada = cboCompania.SelectedIndex >= 0 ? cboCompania.SelectedValue.ToString() : string.Empty;
            DataSet dConfig = _catalogoAdicional.obtenConfiguracionCompania(companiaSeleccionada);
            Func<string, string> getParameterStringValue = GlobalHelper.CreateFuncGetParam(dConfig, ColIdParametro, ColAlfanumerico);
            bool flag_datosdConfig = dConfig != null && dConfig.Tables.Count > 0 && dConfig.Tables[0].Rows.Count > 0;

            string direccion = flag_datosdConfig
                               ? getParameterStringValue(ConfigurationTypes.stamping_site.ToString())
                               : Properties.AppSettings.Default.sitio;

            if (!string.IsNullOrEmpty(direccion))
            {
                if (!Uri.TryCreate(direccion, UriKind.Absolute, out Uri uriDireccion) ||
                     (uriDireccion.Scheme != Uri.UriSchemeHttp && uriDireccion.Scheme != Uri.UriSchemeHttps))
                {
                    MessageBox.Show("La dirección debe ser una URL válida y comenzar con 'http://' o 'https://'.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    GlobalHelper.OpenUrlSecure(uriDireccion.AbsoluteUri);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo abrir la dirección: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("La dirección no es válida.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void cmdBancos_Click(object sender, EventArgs e)
        {
        }
        
        private void cmdExporta_Click(object sender, EventArgs e)
        {
            ExportaCSV();
        }
        
        private void cmdIncapacidades_Click(object sender, EventArgs e)
        {
        }
        
        private void FrmGeneracionRecibo_FormClosing(object sender, FormClosingEventArgs e)
        {
            GuardaMetodoPagoDefault();
        }
        
        private void cmdMapeoSAT_Click(object sender, EventArgs e)
        {
            FrmMapeoCatalogosSAT mapeo = new FrmMapeoCatalogosSAT();
            mapeo.tipoPlataforma = this.tipoPlataforma;
            mapeo.compania = cboCompania.SelectedValue.ToString();

            // PTF-4277            
            mapeo.Text = String.Format("Mapeo Catálogos ADAM - {0}", this.Institucion);
            mapeo.Institucion = this.Institucion;
            mapeo.ShowDialog();
        }
        
        private void cmdCatalogosDIAN_Click(object sender, EventArgs e)
        {
            FrmConsultaCatalogosDIAN FrmCatalogDIAN = new FrmConsultaCatalogosDIAN();
            FrmCatalogDIAN.tipoPlataforma = this.tipoPlataforma;
            FrmCatalogDIAN.Text = String.Format("Consulta Catálogos ADAM - {0}", this.Institucion);
            FrmCatalogDIAN.Institucion = this.Institucion;
            FrmCatalogDIAN.ShowDialog();
        }
        
        private void cmdConceptosDIAN_Click(object sender, EventArgs e)
        {
            FrmTiposPercepcionDeduccionDIAN FrmConceptsDIAN = new FrmTiposPercepcionDeduccionDIAN();
            FrmConceptsDIAN.tipoPlataforma = this.tipoPlataforma;
            FrmConceptsDIAN.Text = String.Format("Consulta Catálogos ADAM - {0}", this.Institucion);
            FrmConceptsDIAN.Institucion = this.Institucion;
            FrmConceptsDIAN.ShowDialog();
        }
        
        private void cmdMapeoDIAN_Click(object sender, EventArgs e)
        {
            FrmMapeoCatalogosDIAN mapeo = new FrmMapeoCatalogosDIAN();
            mapeo.tipoPlataforma = this.tipoPlataforma;
            mapeo.compania = cboCompania.SelectedValue.ToString();

            // PTF-4277            
            mapeo.Text = String.Format("Mapeo Catálogos ADAM - {0}", this.Institucion);
            mapeo.Institucion = this.Institucion;
            mapeo.ShowDialog();
        }
        
        private void optMensual_CheckedChanged(object sender, EventArgs e)
        {
            updatePeriodicaVisibilityPanels();
        }
        
        private void ChkStateSinTimbrar_CheckedChanged(object sender, EventArgs e)
        {
            checkOtherStates();
        }
        
        private void ChkStateEnProceso_CheckedChanged(object sender, EventArgs e)
        {
            checkOtherStates();
        }
        
        private void ChkStateEliminado_CheckedChanged(object sender, EventArgs e)
        {
            checkOtherStates();
        }
        
        private void ChkStateCancelado_CheckedChanged(object sender, EventArgs e)
        {
            checkOtherStates();
        }
        
        private void ChkStateConError_CheckedChanged(object sender, EventArgs e)
        {
            checkOtherStates();
        }
        
        private void ChkStateFinalizado_CheckedChanged(object sender, EventArgs e)
        {
            checkOtherStates();
        }
        
        private void ChkStateTodos_CheckedChanged(object sender, EventArgs e)
        {
            deactivateCheckedEvents();
            chkStateCancelado.Checked = false;
            chkStateSinTimbrar.Checked = false;
            chkStateEnProceso.Checked = false;
            chkStateEliminado.Checked = false;
            chkStateConError.Checked = false;
            chkStateFinalizado.Checked = false;

            if (!chkStateTodos.Checked)
            {
                chkStateTodos.Checked = true;
            }

            filterDataSourceByState();

            activateCheckedEvents();
        }
        
        private void BtnStateRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtTrabajadores = (DataTable)gridTrabajadores.DataSource;

                if (dtTrabajadores != null)
                    updateRowsStampingStatus(dtTrabajadores, false);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al refrescar los estados: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void TxtControlValidationLeave(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox textBox = ((System.Windows.Forms.TextBox)sender);
            if (!isValidSplitInput(textBox.Text))
            {
                showNotValidSplitValueMessage(textBox);
            }
        }
        
        private void OptPeriodicaEspecifico_CheckedChanged(object sender, EventArgs e)
        {
            updatePeriodicaVisibilityPanels();
        }
        
        private void ChlTipoNomina_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            bool foundInteractiva = false;
            bool foundPeriodica = false;

            // Add checked items
            List<object> checkedItems = new List<object>();
            foreach (var item in chlTipoNomina.CheckedItems)
                checkedItems.Add(item);

            // If item was checked, but its new state is unchecked, remove from list
            if (e.NewValue == CheckState.Checked)
                checkedItems.Add(chlTipoNomina.Items[e.Index]);
            else
                checkedItems.Remove(chlTipoNomina.Items[e.Index]);

            // Find manejoNomina, to activate panels
            for (int i = 0; i < checkedItems.Count; i++)
            {
                ManejoNomina manejoNomina = GetManejoNomina(int.Parse(((System.Data.DataRowView)checkedItems[i])["manejo"].ToString()));
                if (manejoNomina == ManejoNomina.interactiva) foundInteractiva = true;
                if (manejoNomina == ManejoNomina.periodica) foundPeriodica = true;
            }

            // Enable controls based on manejoNomina found
            grpInteractiva.Enabled = foundInteractiva;
            grpPeriodica.Enabled = foundPeriodica;
            chlClaseNomina.Enabled = foundPeriodica;
        }
        
        private void OptInteractivaEspecifico_CheckedChanged(object sender, EventArgs e)
        {
            pnlCtrsEspecificosInteractiva.Visible = optInteractivaEspecifico.Checked;
            pnlCrtsRangoInteractiva.Visible = !optInteractivaEspecifico.Checked;
        }
        
        private void gridTrabajadores_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (gridTrabajadores.Columns.Contains("TotalDeducciones") && gridTrabajadores.Columns.Contains("TotalPercepciones") && Convert.ToDecimal(gridTrabajadores.Rows[e.RowIndex].Cells["TotalDeducciones"].Value) == 0 && Convert.ToDecimal(gridTrabajadores.Rows[e.RowIndex].Cells["TotalPercepciones"].Value) == 0)
            {
                gridTrabajadores.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Beige;
                gridTrabajadores.Rows[e.RowIndex].Cells["TotalDeducciones"].Style.ForeColor = Color.Red;
                gridTrabajadores.Rows[e.RowIndex].Cells["TotalPercepciones"].Style.ForeColor = Color.Red;
            }
        }
        
        private void chlClaseNomina_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Enum.Parse<Countries>(this.Pais) == Countries.Colombia)
            {
                grpPeriodica.Enabled = true;
            }
        }
        
        private void cmdSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea Salir de la aplicación ?", "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                Application.Exit();
        }
        
        private void cmdConfigurations_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Button button = (System.Windows.Forms.Button)sender;
            Point ptTopLeft = new Point(-143, 0);
            ptTopLeft = button.PointToScreen(ptTopLeft);
            Rectangle borderRectangle = MnuConfigurations.ClientRectangle;
            MnuConfigurations.Paint += (object _sender, PaintEventArgs _e) =>
            {
                //shows 3d Rectangle in Menu Border
                Rectangle bRectangle = MnuConfigurations.ClientRectangle;
                ControlPaint.DrawBorder3D(_e.Graphics, bRectangle, Border3DStyle.Raised);
            };
            MnuConfigurations.BackColor = pnlSuperior.BackColor;
            //Set Position for Context Menu
            MnuConfigurations.SetBounds(ptTopLeft.X, ptTopLeft.Y, borderRectangle.Width, borderRectangle.Height);
            //Animate Transition Right to Left
            AnimateUtilities.Animate(MnuConfigurations, AnimateUtilities.Effect.Slide, 200, 200);
            MnuConfigurations.Show(ptTopLeft);
        }
        
        private void cmdQueries_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Button button = (System.Windows.Forms.Button)sender;
            Point ptTopLeft = new Point(-143, 0);
            ptTopLeft = button.PointToScreen(ptTopLeft);
            Rectangle borderRectangle = MnuQueries.ClientRectangle;
            MnuQueries.Paint += (object _sender, PaintEventArgs _e) =>
            {
                //shows 3d Rectangle in Menu Border
                Rectangle bRectangle = MnuQueries.ClientRectangle;
                ControlPaint.DrawBorder3D(_e.Graphics, bRectangle, Border3DStyle.Raised);
            };
            MnuQueries.BackColor = pnlSuperior.BackColor;

            //Set Position for Context Menu
            MnuQueries.SetBounds(ptTopLeft.X, ptTopLeft.Y, borderRectangle.Width, borderRectangle.Height);

            //Set Animate Transition Right to Left
            AnimateUtilities.Animate(MnuQueries, AnimateUtilities.Effect.Slide, 200, 200);
            MnuQueries.Show(ptTopLeft);
        }
        
        private void gridTrabajadores_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            // Disabled Default Sort Function of the Grid, in Order to be manage from fromfiltersort
            e.Column.SortMode = DataGridViewColumnSortMode.Programmatic;

            // Convert first character to upper and replace _ with space
            string principalHeaderText = (e.Column.HeaderText[0].ToString().ToUpper() + e.Column.HeaderText.Substring(1)).Replace("_", " ");

            // Set a space after an every upper character
            principalHeaderText = String.Concat(principalHeaderText.Select(x => Char.IsUpper(x) ? " " + x : x.ToString())).TrimStart(' ');
            string newHeaderText = "";

            for (int i = 0; i <= principalHeaderText.Length - 1; i++)
            {
                if (Char.IsUpper(principalHeaderText[i]))
                {
                    if (i > 1 && Char.IsUpper(principalHeaderText[i - 2]))
                    {
                        // If the column header text is an acronym don't need a space after every upper character
                        newHeaderText = newHeaderText.TrimEnd() + principalHeaderText[i];
                    }
                    else
                    {
                        // If after a space exist a lower character convert to upper
                        if (i > 0 && principalHeaderText[i - 1] == ' ')
                        {
                            newHeaderText += principalHeaderText[i].ToString().ToUpper();
                        }
                        else
                        {
                            newHeaderText += principalHeaderText[i];
                        }
                    }
                }
                else
                {
                    // If after a space exist a lower character convert to upper
                    if (i > 0 && principalHeaderText[i - 1] == ' ')
                    {
                        newHeaderText += principalHeaderText[i].ToString().ToUpper();
                    }
                    else
                    {
                        newHeaderText += principalHeaderText[i];
                    }
                }
            }

            e.Column.HeaderText = newHeaderText;
        }
        
        private void gridTrabajadores_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex > 0)
            {
                if (gridTrabajadores.RowCount > 0)
                {
                    // Get the unique values of the column
                    // The column index has to be -1 because the index on e.columnIndex is refered to datagridview
                    // It has one more column than the original datasource (Sel column) and in this instruction the original datasource is being used
                    var uniqueValues = (from DataRow r in ((DataTable)gridTrabajadores.DataSource).Rows
                                        select r[e.ColumnIndex - 1]).Distinct();

                    // Get the column that triggered the event
                    var pColumn = gridTrabajadores.Columns[e.ColumnIndex];

                    FrmFilterSortDialog filtersort = new FrmFilterSortDialog(queryTrabajadores, pColumn, pColumn.ValueType, uniqueValues);

                    // Get the rectangle in screen for the cell that fires the event
                    var colCoordinates = gridTrabajadores.GetCellDisplayRectangle(pColumn.Index, 0, true);

                    // Set location of the frmfiltersordialog based on the cell that fires the event
                    if (pColumn.Width > filtersort.Width)
                    {
                        filtersort.Width = pColumn.Width;
                        filtersort.Location = new Point(colCoordinates.X + pColumn.Width - filtersort.Width, pnlInferior.Location.Y + pnlTrabajadores.Location.Y + gridTrabajadores.Location.Y + gridTrabajadores.ColumnHeadersHeight + colCoordinates.Height);
                    }
                    else
                    {
                        filtersort.Location = new Point(colCoordinates.X, pnlInferior.Location.Y + pnlTrabajadores.Location.Y + gridTrabajadores.Location.Y + gridTrabajadores.ColumnHeadersHeight + colCoordinates.Height);
                    }

                    // Show filter dialog
                    filtersort.ShowDialog();

                    // Apply Filters
                    applyfilter(pColumn, filtersort.Query, filtersort.isSorted, filtersort.Sort);
                }
            }
        }
        
        private void applyfilter(DataGridViewColumn pColumn, DgQuery pQuery, bool pIsSorted = false, System.ComponentModel.ListSortDirection plistSortDirection = System.ComponentModel.ListSortDirection.Descending)
        {
            queryTrabajadores = pQuery;

            // Check if sorted is needed
            if (plistSortDirection == System.ComponentModel.ListSortDirection.Ascending && pIsSorted)
            {
                gridTrabajadores.Sort(gridTrabajadores.Columns[pColumn.Index], System.ComponentModel.ListSortDirection.Ascending);
            }

            if (plistSortDirection == System.ComponentModel.ListSortDirection.Descending && pIsSorted)
            {
                gridTrabajadores.Sort(gridTrabajadores.Columns[pColumn.Index], System.ComponentModel.ListSortDirection.Descending);
            }

            // If a query is set for the column the column change forecolor to red if not default black
            if (queryTrabajadores.FilterEnumerable.Any(t => t.ColumnIndex == pColumn.Index))
            {
                gridTrabajadores.EnableHeadersVisualStyles = false;
                gridTrabajadores.Columns[pColumn.Index].HeaderCell.Style.ForeColor = Color.Blue;
            }
            else
            {
                gridTrabajadores.EnableHeadersVisualStyles = false;
                gridTrabajadores.Columns[pColumn.Index].HeaderCell.Style.ForeColor = Color.Black;
            }

            // Get the query result to apply on the grid
            var myquery = queryTrabajadores.GetQuery();

            // Apply filter
            ((DataTable)gridTrabajadores.DataSource).DefaultView.RowFilter = myquery;

            // Set Results
            if (queryTrabajadores.FilterEnumerable.Count > 0)
            {
                chkSelectAll.Checked = false;
            }
            else
            {
                chkSelectAll.Checked = true;
            }
        }
        
        private void gridTrabajadores_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //if cell painting is header (rowindex -1) put the icon at the end of the cell
            if (e.RowIndex == -1)
            {
                Rectangle r = new Rectangle(e.CellBounds.X + e.CellBounds.Width - 15, e.CellBounds.Y + (e.CellBounds.Height / 2) - 5, 10, 10);
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                e.Graphics.DrawImage(Properties.Resources.down_arrow, r);
                e.Handled = true;
            }
        }
        
        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSelectAll.Checked)
            {
                updateSelectedRows(true, true);
            }
            else
            {
                //unSelectAll is true by default
                if (unSelectAll)
                {
                    updateSelectedRows(true, false);
                }
            }
            if (AdamExecution == "1")
            {
                gridTotales.Refresh();
                gridTrabajadores.Refresh();
            }

            unSelectAll = true;
        }

        private void cmdCambioPais_Click(object sender, EventArgs e)
        {
            // Confirm the Action
            DialogResult result = MessageBox.Show("Está seguro de cambiar el país por defecto?", "Nómina Electrónica", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Save Settings
                Properties.AppSettings.Default.defaultCountry = String.Empty;
                Properties.AppSettings.Default.Save();

                // Show Message
                MessageBox.Show("La aplicación solicitará el país por defecto en la siguiente ejecución",
                                "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Exit Application
                Application.Exit();
            }
        }
        
        private void cmdDocumentState_Click(object sender, EventArgs e)
        {
            if (gridTrabajadores.Rows.Count > 0)
            {
                //get selected rows
                var rows = (from DataGridViewRow r in gridTrabajadores.Rows
                            where bool.Parse(r.Cells["Sel"].Value.ToString())
                            select ((DataRowView)r.DataBoundItem).Row);

                //transform rows to DataTale
                DataTable selectedRows = rows.CopyToDataTable();

                FrmEstadoDocumentoDIAN documentStateForm = new FrmEstadoDocumentoDIAN(selectedRows);
                documentStateForm.tipoPlataforma = this.tipoPlataforma;
                documentStateForm.szCompany = this.compania;
                documentStateForm.Show();
            }
        }

        #endregion

        #region Methods

        public FrmGeneracionRecibo(string[] parametros)
        {
            InitializeComponent();
            InitializeCommands();
            loadParameters(parametros);
        }

        private void loadParameters(string[] parameters)
        {
            for (int i = 0; i < parameters.Length; i++)
            {
                if (parameters[i].Contains("Environment="))
                {
                    this.adamEnvironmentParameter = parameters[i].Split('=')[1];
                }
                if (parameters[i].Contains("Server="))
                {
                    this.Server = parameters[i].Split('=')[1];
                }
                if (parameters[i].Contains("Database="))
                {
                    this.Database = parameters[i].Split('=')[1];
                }
                if (parameters[i].Contains("UserId="))
                {
                    this.User = parameters[i].Split('=')[1];
                }
                if (parameters[i].Contains("Password="))
                {
                    this.Pwd = new NetworkCredential(string.Empty, parameters[i].Split('=')[1]).SecurePassword;
                }
                if (parameters[i].Contains("AdamExecution="))
                {
                    this.AdamExecution = parameters[i].Split('=')[1];
                }
                if (parameters[i].Contains("Pais="))
                {
                    this.Pais = parameters[i].Split('=')[1];
                }
            }
        }
        
        private void InitializeCommands()
        {
            // Configuracion
            tcmdConfiguracion = GeneraToolStripButton("Configuración de " + Environment.NewLine + "&Acceso", CommandActions.CONFIGURACION_ACCESO);
            tcmdTipos = GeneraToolStripButton("Definir &Tipos de " + Environment.NewLine + "Conceptos", CommandActions.DEFINIR_TIPOS_CONCEPTOS);
            tcmdRegimen = GeneraToolStripButton("Definir &Regimen de " + Environment.NewLine + "Contratación", CommandActions.DEFINIR_REGIMEN_CONTRATACION);
            tcmdBancos = GeneraToolStripButton("Configuración de " + Environment.NewLine + "&Bancos", CommandActions.CONFIGURACION_BANCOS);
            tcmdIncapacidades = GeneraToolStripButton("Configuración de " + Environment.NewLine + "&Incapacidades", CommandActions.CONFIGURACION_INCAPACIDADES);
            tcmdMapeoSAT = GeneraToolStripButton("&Mapeo Catálogos " + Environment.NewLine + "ADAM - SAT", CommandActions.MAPEO_CATALOGOS_ADAM_SAT);
            tcmdMapeoDIAN = GeneraToolStripButton("&Mapeo Catálogos " + Environment.NewLine + "ADAM - DIAN", CommandActions.MAPEO_CATALOGOS_ADAM_DIAN);
            tcmdConceptosDIAN = GeneraToolStripButton("&Mapeo Conceptos " + Environment.NewLine + "ADAM - DIAN", CommandActions.MAPEO_CONCEPTOS_ADAM_DIAN);
            tcmdSitio = GeneraToolStripButton("Sitio &Timbrado", CommandActions.SITIO_TIMBRADO);
            tcmdBancos.Visible = false;
            tcmdIncapacidades.Visible = false;
            MnuConfigurations.Items.Add(tcmdConfiguracion);
            MnuConfigurations.Items.Add(tcmdTipos);
            MnuConfigurations.Items.Add(tcmdRegimen);
            MnuConfigurations.Items.Add(tcmdBancos);
            MnuConfigurations.Items.Add(tcmdIncapacidades);
            MnuConfigurations.Items.Add(tcmdMapeoSAT);
            MnuConfigurations.Items.Add(tcmdMapeoDIAN);
            MnuConfigurations.Items.Add(tcmdConceptosDIAN);
            MnuConfigurations.Items.Add(tcmdSitio);

            // Consultas y Reportes
            tcmdCatalogosDIAN = GeneraToolStripButton("&Consulta Catálogos " + Environment.NewLine + "ADAM - DIAN", CommandActions.CONSULTA_CATALOGOS_ADAM_DIAN);
            tcmdDocumentState = GeneraToolStripButton("&Consulta Estado " + Environment.NewLine + "Del Documento", CommandActions.CONSULTA_ESTADO_DOCUMENTO);
            MnuQueries.Items.Add(tcmdCatalogosDIAN);
            MnuQueries.Items.Add(tcmdDocumentState);
        }
        
        private ToolStripButton GeneraToolStripButton(string Text, CommandActions Tag, int Height = 40)
        {
            ToolStripButton item = new ToolStripButton();
            item.AutoSize = false;
            item.Height = Height;
            item.Width = 130;
            item.Font = new Font("Trebuchet MS", 8.5F, FontStyle.Regular, GraphicsUnit.Point);
            item.Text = Text;
            item.Paint += ToolStripButton_Paint;
            item.Click += CommandActionItem_Click;
            item.Tag = Tag;
            return item;
        }

        private void Inicializaclase()
        {
            // Get Version
            ObtenVersion();

            try
            {
                #region Configuration Form
                // Set Configuration Form
                FrmConfiguracion configurationForm = new FrmConfiguracion();
                configurationForm.formaPadre = this;
                configurationForm.Server = this.Server;
                configurationForm.Database = this.Database;
                configurationForm.User = this.User;
                configurationForm.Pwd = this.Pwd;
                configurationForm.AdamExecution = this.AdamExecution;
                configurationForm.AppSettings.ADAMEnvironment = this.adamEnvironmentParameter;
                configurationForm.Pais = this.Pais;
                #endregion 

                #region Disable & Hide Buttons
                // Disable Buttons
                cmdTrabajadores.Enabled = false;
                cmdGeneraArchivo.Enabled = false;
                cmdGenera.Enabled = false;
                chkValidaXSD.Enabled = false;
                cmdCopiar.Enabled = false;
                tcmdTipos.Enabled = false;
                tcmdRegimen.Enabled = false;
                tcmdSitio.Enabled = false;
                tcmdCatalogosDIAN.Enabled = false;
                tcmdMapeoDIAN.Enabled = false;
                tcmdMapeoSAT.Enabled = false;
                tcmdConceptosDIAN.Enabled = false;
                tcmdDocumentState.Enabled = false;

                // Hide Buttons
                cmdTrabajadores.Visible = false;
                cmdGeneraArchivo.Visible = false;
                cmdGenera.Visible = false;
                chkValidaXSD.Visible = false;
                cmdCopiar.Visible = false;
                cmdCambioPais.Visible = false;
                tcmdTipos.Visible = false;
                tcmdRegimen.Visible = false;
                tcmdSitio.Visible = false;
                tcmdCatalogosDIAN.Visible = false;
                tcmdMapeoDIAN.Visible = false;
                tcmdMapeoSAT.Visible = false;
                tcmdConceptosDIAN.Visible = false;
                tcmdDocumentState.Visible = false;
                lblInstitucion.Visible = false;
                #endregion 

                // Check Configuration
                if (!configurationForm.RecuperaConfiguracionActualConexion())
                {
                    configurationForm.ShowDialog();
                    return;
                }

                // PTF-4928: Load additional configuration and save loaded settings
                configurationForm.LoadConfiguration(false, true, false);
                this.appSettings = configurationForm.AppSettings;
                UtileriasConfig.AppSettings = this.appSettings;

                br = BRReciboElectronicoHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
                _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
                _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);

                #region Default Country
                // Get Languages
                string szLanguages = _catalogoAdicional.obtenCompaniasIdiomas();
                if (string.IsNullOrEmpty(szLanguages))
                {
                    // ADAM v5.4 & v5.3
                    // Try to get the configuration from the settings
                    if (!string.IsNullOrEmpty(this.appSettings.DefaultCountry))
                    {
                        this.Pais = this.appSettings.DefaultCountry;
                    }
                    else
                    {
                        // Choose Country
                        FrmAccessWizard initForm = new FrmAccessWizard();
                        DialogResult dialogResult = initForm.ShowDialog();
                        if (dialogResult == DialogResult.OK && initForm.Pais != "")
                        {
                            // Set Country
                            this.Pais = initForm.Pais;

                            // Save Settings
                            Properties.AppSettings.Default.defaultCountry = this.Pais;
                            Properties.AppSettings.Default.Save();
                        }
                        else if (dialogResult == DialogResult.Cancel)
                        {
                            // Close Form
                            this.Close();
                        }
                    }
                }
                else
                {
                    // Get Languages Supported
                    var lstIdiomas = szLanguages.Split(',').ToList();

                    // Set Language
                    if (lstIdiomas.Count == 1)
                    {
                        this.Pais = (lstIdiomas[0].Equals(LanguageCodes.Mexico) ? "México" : "Colombia");
                    }
                    else
                    {
                        // Get Default Country
                        if (!string.IsNullOrEmpty(this.appSettings.DefaultCountry))
                        {
                            this.Pais = this.appSettings.DefaultCountry;
                        }
                        else
                        {
                            // Choose Country
                            FrmAccessWizard initForm = new FrmAccessWizard();
                            DialogResult dialogResult = initForm.ShowDialog();
                            if (dialogResult == DialogResult.OK && initForm.Pais != "")
                            {
                                // Set Country
                                this.Pais = initForm.Pais;

                                // Save Settings
                                Properties.AppSettings.Default.defaultCountry = this.Pais;
                                Properties.AppSettings.Default.Save();
                            }
                            else if (dialogResult == DialogResult.Cancel)
                            {
                                // Close Form
                                this.Close();
                            }
                        }

                        // Enable Button
                        cmdCambioPais.Visible = true;
                    }
                }
                #endregion

                #region Set Additional Config & Reload
                // Set Additional Config & Reload
                configurationForm.Pais = this.Pais;
                configurationForm.LoadConfiguration(false, true, true);
                #endregion 

                #region Enable & Unhide Global Buttons
                // Enable Global Buttons
                cmdTrabajadores.Enabled = true;
                cmdTrabajadores.Visible = true;
                cmdGeneraArchivo.Enabled = true;
                cmdGeneraArchivo.Visible = true;
                chkValidaXSD.Enabled = true;
                chkValidaXSD.Visible = true;
                cmdGenera.Enabled = true;
                cmdGenera.Visible = true;
                cmdCopiar.Enabled = true;
                cmdCopiar.Visible = true;
                tcmdTipos.Enabled = true;
                tcmdRegimen.Enabled = true;
                tcmdSitio.Enabled = true;
                tcmdMapeoSAT.Enabled = true;
                tcmdCatalogosDIAN.Enabled = true;
                tcmdMapeoDIAN.Enabled = true;
                tcmdConceptosDIAN.Enabled = true;
                tcmdDocumentState.Enabled = true;
                #endregion

                #region Disable Buttons - Based on Country
                // PTF-4277
                // Disable Buttons - Based on Country
                switch (Enum.Parse<Countries>(this.Pais))
                {
                    case Countries.México:
                        cmdSalir.Visible = true;
                        cmdQueries.Visible = false;
                        cmdGeneraArchivo.Text = "Genera Archivo Previo Xml";
                        cmdGenera.Text = "Timbrar y generar recibos";
                        tcmdRegimen.Visible = true;
                        tcmdSitio.Visible = true;
                        tcmdTipos.Visible = true;
                        tcmdMapeoSAT.Visible = true;
                        tcmdSitio.Visible = true;
                        tcmdCatalogosDIAN.Visible = false;
                        tcmdMapeoDIAN.Visible = false;
                        tcmdConceptosDIAN.Visible = false;
                        tcmdDocumentState.Visible = false;
                        break;
                    case Countries.Colombia:
                        cmdSalir.Visible = true;
                        lblTipoNomina.Visible = false;
                        chlTipoNomina.Visible = false;
                        lblConcepto.Visible = false;
                        txtConceptoFactura.Visible = false;
                        lblMetodoPago.Visible = false;
                        cboFormaPago.Visible = false;
                        grpInteractiva.Visible = false;
                        optPeriodo.Visible = false;
                        optPeriodicaEspecifico.Visible = false;
                        optMensual.Visible = false;
                        cboMesPeriodicaHasta.Visible = false;
                        lblGuionMeses.Visible = false;
                        optPeriodicaRango.Visible = false;
                        nupAnioPeriodicaHasta.Visible = false;
                        lblAPeriodicaRangoAnio.Visible = false;
                        chkValidaXSD.Visible = false;
                        optPeriodo.Checked = false;
                        optMensual.Checked = true;
                        chlClaseNomina.Enabled = false;
                        chlClaseNomina.Visible = false;
                        lblClaseNomina.Visible = false;
                        optMensual.Location = new Point(353, 11);
                        grpPeriodica.Location = new Point(50, 35);
                        grpPeriodica.Size = new Size(385, 84);
                        grpPeriodica.Text = "Año/Mes:";
                        pnlSuperior.Size = new System.Drawing.Size(875, 130);
                        cmdGeneraArchivo.Text = "Genera Archivo Previo Json";
                        cmdGenera.Text = "Enviar Datos" + System.Environment.NewLine + "API DIAN";
                        tcmdRegimen.Visible = false;
                        tcmdTipos.Visible = false;
                        tcmdMapeoSAT.Visible = false;
                        tcmdSitio.Visible = false;
                        tcmdCatalogosDIAN.Visible = true;
                        tcmdMapeoDIAN.Visible = true;
                        tcmdConceptosDIAN.Visible = true;
                        tcmdDocumentState.Visible = true;
                        break;
                }
                #endregion

                #region Get Companies
                // Set Institucion
                this.lblInstitucion.Visible = true;
                this.lblInstitucion.Text = (string.IsNullOrEmpty(this.Institucion) || string.IsNullOrEmpty(this.Pais) ? "" : $"{this.Institucion} {this.Pais}");

                // Compañias con Permisos
                var dsPermissions = _catalogoAdicional.obtenDatasetCompanias(this.Idioma);
                if (dsPermissions != null && dsPermissions.Tables.Count > 0)
                {
                    cboCompania.Tag = true;
                    cboCompania.DataSource = dsPermissions.Tables[0];
                    cboCompania.DisplayMember = "nombre_cia";
                    cboCompania.ValueMember = "compania";
                    cboCompania.Tag = null;
                }

                // PTF-4277
                string company = (cboCompania.SelectedIndex >= 0
                                  ? cboCompania.SelectedValue.ToString()
                                  : "");
                #endregion 

                #region Initialize Controls
                // Initialize Controls
                switch (Enum.Parse<Countries>(this.Pais))
                {
                    case Countries.México:
                        // Tipos de Nomina
                        chlTipoNomina.DataSource = _catalogoAdicional.obtenDatasetTiposNomina(company).Tables[0];
                        chlTipoNomina.DisplayMember = "descripcion";
                        chlTipoNomina.ValueMember = "tipo_nomina";

                        // Clases de Nomina con permisos
                        chlClaseNomina.DataSource = _catalogoAdicional.obtenDatasetClasesNomina(company).Tables[0];
                        chlClaseNomina.DisplayMember = "descripcion";
                        chlClaseNomina.ValueMember = "clase_nomina";

                        configuraAnioPeriodo();

                        // 201606
                        cboFormaPago.DataSource = _catalogoAdicional.obtenDatasetFormaPago().Tables[0];
                        cboFormaPago.DisplayMember = "descripcion";
                        cboFormaPago.ValueMember = "metodo_pago_sat";

                        // Cambio para checar si mejora el performance en la seleccion de registros
                        gridTrabajadores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;

                        // JGE 201701 mantener el metodo de pago por omision
                        CargaMetodoPagoDefault();

                        // JGE 201812 Para procesar nominas periodicas por mes
                        cboMesPeriodicaDesde.DataSource = GlobalHelper.Meses();
                        cboMesPeriodicaDesde.DisplayMember = "descripcion";
                        cboMesPeriodicaDesde.ValueMember = "mes";

                        // AZ-1071: Add months to added combos
                        cboMesPeriodicaHasta.DataSource = GlobalHelper.Meses();
                        cboMesPeriodicaHasta.DisplayMember = "descripcion";
                        cboMesPeriodicaHasta.ValueMember = "mes";

                        cboMesInteractivaDesde.DataSource = GlobalHelper.Meses();
                        cboMesInteractivaDesde.DisplayMember = "descripcion";
                        cboMesInteractivaDesde.ValueMember = "mes";

                        cboMesInteractivaHasta.DataSource = GlobalHelper.Meses();
                        cboMesInteractivaHasta.DisplayMember = "descripcion";
                        cboMesInteractivaHasta.ValueMember = "mes";
                        break;
                    case Countries.Colombia:
                        configuraAnioPeriodo();

                        // Grid Selection Performance
                        gridTrabajadores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;

                        // Fill Months Dropdown
                        cboMesPeriodicaDesde.DataSource = GlobalHelper.Meses();
                        cboMesPeriodicaDesde.DisplayMember = "descripcion";
                        cboMesPeriodicaDesde.ValueMember = "mes";

                        // Enable Group
                        grpPeriodica.Enabled = true;
                        break;
                }
                #endregion 

                // STAMP-220
                // REC-30: Hide if not adam stamping client
                if (!isADAMStampingClient())
                {
                    lblEstado.Visible = false;
                    btnStateRefresh.Visible = false;
                    pnlEstadosTimbrado.Visible = false;
                    pnlFiltros.Height = pnlFiltros.Size.Height - pnlEstadosTimbrado.Height;
                    pnlTools.Height = pnlTools.Size.Height - pnlEstadosTimbrado.Height;
                }

                // PTF-1996: Added selection type, by default index 0 will be selected
                cboTipoSeleccion.SelectedIndex = 0;

                // PTF-4277 
                tcmdMapeoSAT.Text = $"&Mapeo Catálogos {Environment.NewLine}ADAM - {this.Institucion}";
                this.Text = String.Format("Generación de Recibos de Nómina Electrónicos - {0} {1}", this.Institucion, this.Pais);
                this.lblTitulo.Text = this.Text;

                ToggleOptionsLegacyNewStampingMode();
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos de configuración, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
        
        private void configuraAnioPeriodo()
        {
            nupAnioPeriodicaDesde.Minimum = DateTime.Now.Year - 10;
            nupAnioPeriodicaDesde.Maximum = DateTime.Now.Year + 1;
            nupAnioPeriodicaDesde.Value = DateTime.Now.Year;

            //AZ-1071: Add settings for added nups
            nupAnioPeriodicaHasta.Minimum = DateTime.Now.Year - 10;
            nupAnioPeriodicaHasta.Maximum = DateTime.Now.Year + 1;
            nupAnioPeriodicaHasta.Value = DateTime.Now.Year;

            nupAnioInteractivaDesde.Minimum = DateTime.Now.Year - 10;
            nupAnioInteractivaDesde.Maximum = DateTime.Now.Year + 1;
            nupAnioInteractivaDesde.Value = DateTime.Now.Year;

            nupAnioInteractivaHasta.Minimum = DateTime.Now.Year - 10;
            nupAnioInteractivaHasta.Maximum = DateTime.Now.Year + 1;
            nupAnioInteractivaHasta.Value = DateTime.Now.Year;
        }
        
        private bool areValidInputs(out string msg)
        {
            msg = "Debe seleccionar parámetros validos";

            if ((grpInteractiva.Enabled && optInteractivaEspecifico.Checked && (String.IsNullOrWhiteSpace(txtAniosInteractiva.Text) || String.IsNullOrWhiteSpace(txtMesesInteractiva.Text)))
                || (grpPeriodica.Enabled && optPeriodicaEspecifico.Checked && (String.IsNullOrWhiteSpace(txtAniosPeriodica.Text) || (optMensual.Checked && String.IsNullOrWhiteSpace(txtMesesPeriodica.Text)) || (optPeriodo.Checked && String.IsNullOrWhiteSpace(txtPeriodosPeriodica.Text)))))
            {
                msg = "Favor ingresar parámetros requeridos";
                return false;
            }

            if ((grpPeriodica.Enabled && optPeriodicaRango.Checked && (nupAnioPeriodicaDesde.Value > nupAnioPeriodicaHasta.Value))
                || (grpInteractiva.Enabled && optInteractivaRango.Checked && (nupAnioInteractivaDesde.Value > nupAnioInteractivaHasta.Value)))
            {
                msg = "Favor ingresar rango de años válido (menor a mayor)";
                return false;
            }

            if (grpPeriodica.Enabled && optPeriodicaRango.Checked && optPeriodo.Checked && (nupPeriodoDesde.Value > nupPeriodoHasta.Value))
            {
                msg = "Favor ingresar rango de periodos válido (menor a mayor)";
                return false;
            }

            if ((grpPeriodica.Enabled && optPeriodicaRango.Checked && optMensual.Checked && (int.Parse(cboMesPeriodicaDesde.SelectedValue.ToString()) > int.Parse(cboMesPeriodicaHasta.SelectedValue.ToString())))
            || (grpInteractiva.Enabled && optInteractivaRango.Checked && (int.Parse(cboMesInteractivaDesde.SelectedValue.ToString()) > int.Parse(cboMesInteractivaHasta.SelectedValue.ToString()))))
            {
                msg = "Favor ingresar rango de meses válido (menor a mayor)";
                return false;
            }

            return true;
        }
        
        private void updateGridFilter()
        {
            string filter = String.Empty;
            string stateFilter = String.Empty;

            // Construct state filtering
            foreach (string filterValue in stringStateFilters)
            {
                if (!string.IsNullOrEmpty(stateFilter))
                {
                    stateFilter += " OR ";
                }

                stateFilter += String.Format("Estado = '{0}'", filterValue);
            }

            // If not empty, add parenthesis for future AND clauses
            if (!string.IsNullOrEmpty(stateFilter))
            {
                stateFilter = "(" + stateFilter + ")";
            }

            filter += stateFilter;

            // Set trabajadores filter after setting the previous state conditions
            if (string.IsNullOrEmpty(filter))
            {
                filter = sFilterTrabajadores;
            }
            else
            {
                if (!string.IsNullOrEmpty(sFilterTrabajadores))
                    filter += " AND " + sFilterTrabajadores;
            }

            // Set FrmFiltroAvanzado filter, this is update from FrmFiltroAvanzado2 call
            if (string.IsNullOrEmpty(filter))
            {
                filter = dsFormFilter;
            }
            else
            {
                if (!string.IsNullOrEmpty(dsFormFilter))
                    filter += " AND " + dsFormFilter;
            }

            // Update the row filtering after we have the final filter
            ((DataTable)gridTrabajadores.DataSource).DefaultView.RowFilter = filter;

            // Update readonly selection checkbox and counter
            StampingStatusConstants statusConstants = new StampingStatusConstants();
            int selectedCount = 0;
            foreach (DataGridViewRow row in gridTrabajadores.Rows)
            {
                DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)row.Cells["Sel"];
                string statusId = row.Cells["IdEstado"].Value.ToString();

                bool canStamp = statusConstants.canProcessStamp(Convert.ToInt32(statusId));
                checkBoxCell.ReadOnly = !canStamp;
                if (bool.Parse(checkBoxCell.Value.ToString()))
                {
                    selectedCount++;
                }
            }

            // Update counter and totals based on selected rows
            lblContador.Text = selectedCount.ToString();
            CalculaTotales();
        }
        
        private static ManejoNomina GetManejoNomina(int value)
        {
            return value == 1 ? ManejoNomina.periodica : ManejoNomina.interactiva;
        }

        private ManejoNomina GetManejoNominaByPayrollType(string payrollType)
        {
            var matchRow = chlTipoNomina.Items
                                .Cast<DataRowView>()
                                .Select((item, index) => new { Item = item, Index = index })
                                .FirstOrDefault(x =>
                                    x.Item != null &&
                                    x.Item["tipo_nomina"].ToString().Equals(payrollType, StringComparison.OrdinalIgnoreCase));

            if (matchRow != null)
            {
                return GetManejoNomina(int.Parse(matchRow.Item["manejo"].ToString()));
            }
            else
            {
                // Not found, throw exception as the payrollType doesn't exist
                throw new InvalidOperationException("Manejo Nomina no encontrado para Tipo Nomina: " + payrollType);
            }
        }
        
        static bool IsDataSetEmpty(DataSet ds)
        {
            if (ds.Tables.Count == 0 || !(ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0))
            {
                return true;
            }

            return false;
        }
        
        private void setupDataSetAndMergeInDataTable(ref DataTable baseTable, DataSet dataToMerge)
        {
            if (!IsDataSetEmpty(dataToMerge))
            {
                if (isADAMStampingClient())
                {
                    // AZ-1061: Add selected and status column to the grid, selected is necessary for keeping selected items when filtering
                    dataToMerge.Tables[0].Columns.Add(selRowName).SetOrdinal(0);
                    dataToMerge.Tables[0].Columns.Add(statusRowName).SetOrdinal(1);
                    dataToMerge.Tables[0].Columns.Add(statusIdRowName).SetOrdinal(2);
                }

                // AZ-1061: Update states in datasource previous to assign itif
                if (baseTable == null)
                {
                    baseTable = dataToMerge.Tables[0];
                }
                else
                {
                    baseTable.Merge(dataToMerge.Tables[0]);
                }
            }
        }
        
        private bool isADAMStampingClient()
        {
            // AZ-1061
            // Will use Stamping Status Service if the option is selected in the configuraiton
            bool isADAMStampingClient = Properties.AppSettings.Default.multiplesArchivos == 2;
            return isADAMStampingClient;
        }
        
        public static string getPeriodsFromMonth(DataSet dsPeriodosList, ManejoNomina manejoNomina, int monthOrPeriod)
        {
            // Get periods depending if a month is selected or a unique value
            string periodoDBText = String.Empty;
            if (manejoNomina == ManejoNomina.periodica)
            {
                if (dsPeriodosList != null)
                {
                    foreach (DataRow periodoRow in dsPeriodosList.Tables[0].Rows)
                    {
                        // Only add , if it's the second value onwards
                        if (!string.IsNullOrEmpty(periodoDBText))
                        {
                            periodoDBText += ",";
                        }

                        periodoDBText += periodoRow[0].ToString();
                    }
                }
                else
                {
                    periodoDBText = monthOrPeriod.ToString();
                }
            }
            else
            {
                // AZ-1071: Use month from combo
                periodoDBText = monthOrPeriod.ToString();
            }

            // Default
            return periodoDBText;
        }
        
        private List<int> getListFromRange(int from, int to)
        {
            List<int> intList = new List<int>();
            for (int i = from; i <= to; i++)
            {
                intList.Add(i);
            }
            return intList;
        }
        
        private List<int> getListFromString(string stringToSplit)
        {
            List<int> intList = new List<int>();
            String[] stringList = stringToSplit.Split(',');
            foreach (string value in stringList)
            {
                intList.Add(int.Parse(value));
            }
            return intList;
        }
        
        private void obtenListaTrabajadores()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                // AZ-1071: Change to get the error message depending on the erroneous inputs
                string errorMessage;

                // PTF-3884: Validate type of payroll only for Mexico
                if (Enum.Parse<Countries>(this.Pais) == Countries.México)
                {
                    if (!areValidInputs(out errorMessage) || cboCompania.SelectedValue == null || chlTipoNomina.CheckedItems.Count == 0 || (chlClaseNomina.Enabled && chlClaseNomina.CheckedItems.Count == 0))
                    {
                        MessageBox.Show(errorMessage, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Cursor = Cursors.Default;
                        return;
                    }
                }
                else if (Enum.Parse<Countries>(this.Pais) == Countries.Colombia && cboCompania.SelectedValue == null)
                {
                    MessageBox.Show("Debe seleccionar parámetros validos", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Cursor = Cursors.Default;
                    return;
                }

                // Reiniciar el grid
                gridTrabajadores.DataSource = null;
                gridTrabajadores.Rows.Clear();
                gridTrabajadores.Columns.Clear();
                gridTrabajadores.Enabled = true;
                gridTrabajadores.Update();
                lblContador.Text = "0";
                lbGenerados.Items.Clear();
                chkSelectAll.Checked = false;
                Application.DoEvents();

                // Obtiene los datos del SP
                DataSet datosTrabajadores = null;
                DataTable dtTrabajadores = null;

                // AZ-1071: Save status request temporal info, if it applies
                if (isADAMStampingClient())
                {
                    DataRowView vrow = (DataRowView)cboCompania.SelectedItem;
                    DataRow companyRow = vrow.Row;
                    string companyRFC = companyRow["registro_fiscal"] == null ? "" : companyRow["registro_fiscal"].ToString();

                    statusDataTempHolder.reset();
                    statusDataTempHolder.setCompany(companyRFC);
                    statusDataTempHolder.setReceiptVersion("3.3");
                }

                // Get Employees
                switch (Enum.Parse<Countries>(this.Pais))
                {
                    case Countries.México:
                        // Get data from each payroll type selected
                        for (int i = 0; i < chlTipoNomina.CheckedItems.Count; i++)
                        {
                            ManejoNomina _manejoNomina = GetManejoNomina(int.Parse(((DataRowView)chlTipoNomina.CheckedItems[i])["manejo"].ToString()));
                            DataRowView payrollTypeItem = (DataRowView)chlTipoNomina.CheckedItems[i];
                            string payrollTypeValue = payrollTypeItem["tipo_nomina"].ToString();

                            if (_manejoNomina == ManejoNomina.periodica)
                            {
                                // Get data from each payroll class selected
                                for (int j = 0; j < chlClaseNomina.CheckedItems.Count; j++)
                                {
                                    // AZ-1071: Get data for every payrollType and payrollClass selected
                                    DataRowView payrollClassItem = (DataRowView)chlClaseNomina.CheckedItems[j];
                                    string payrollClassValue = payrollClassItem["clase_nomina"].ToString();

                                    // Get year list, depending on option selected
                                    List<int> yearList = optPeriodicaRango.Checked ?
                                        getListFromRange(int.Parse(nupAnioPeriodicaDesde.Value.ToString()), int.Parse(nupAnioPeriodicaHasta.Value.ToString())) :
                                        getListFromString(txtAniosPeriodica.Text);

                                    string periodsFromMonth = String.Empty;

                                    // Get for each year in list
                                    foreach (int periodicaYear in yearList)
                                    {
                                        if (optPeriodo.Checked)
                                        {
                                            List<int> periodList = optPeriodicaRango.Checked ?
                                                getListFromRange(int.Parse(nupPeriodoDesde.Value.ToString()), int.Parse(nupPeriodoHasta.Value.ToString())) :
                                                getListFromString(txtPeriodosPeriodica.Text);

                                            // Get for each period in list
                                            foreach (int periodicaPeriodo in periodList)
                                            {
                                                datosTrabajadores = _catalogoAdicional.obtenDatasetTrabajadoresRecibo(cboCompania.SelectedValue.ToString(), payrollTypeValue, payrollClassValue, periodicaYear, periodicaPeriodo, _manejoNomina);
                                                periodsFromMonth = getPeriodsFromMonth(null, _manejoNomina, periodicaPeriodo);

                                                setupDataSetAndMergeInDataTable(ref dtTrabajadores, datosTrabajadores);

                                                if (isADAMStampingClient())
                                                {
                                                    statusDataTempHolder.addPayrollType(_manejoNomina, payrollTypeValue);
                                                    statusDataTempHolder.addPayrollClass(_manejoNomina, payrollClassValue);
                                                    statusDataTempHolder.addPeriods(_manejoNomina, periodsFromMonth);
                                                    statusDataTempHolder.addYear(_manejoNomina, periodicaYear.ToString());
                                                }
                                            }
                                        }
                                        else
                                        {
                                            List<int> monthList = optPeriodicaRango.Checked ?
                                                getListFromRange(int.Parse(cboMesPeriodicaDesde.SelectedValue.ToString()), int.Parse(cboMesPeriodicaHasta.SelectedValue.ToString())) :
                                                getListFromString(txtMesesPeriodica.Text);

                                            // Get for each month in range
                                            foreach (int periodicaMonth in monthList)
                                            {
                                                datosTrabajadores = DatosTrabajadoresMensual(cboCompania.SelectedValue.ToString(), payrollTypeValue, payrollClassValue, periodicaYear, periodicaMonth, _manejoNomina, ref periodsFromMonth);

                                                setupDataSetAndMergeInDataTable(ref dtTrabajadores, datosTrabajadores);

                                                if (isADAMStampingClient())
                                                {
                                                    statusDataTempHolder.addPayrollType(_manejoNomina, payrollTypeValue);
                                                    statusDataTempHolder.addPayrollClass(_manejoNomina, payrollClassValue);
                                                    statusDataTempHolder.addPeriods(_manejoNomina, periodsFromMonth);
                                                    statusDataTempHolder.addYear(_manejoNomina, periodicaYear.ToString());
                                                }
                                            }
                                        }
                                    }

                                }
                            }
                            else
                            {
                                // Get year list, depending on option selected
                                List<int> yearList = optInteractivaRango.Checked ?
                                    getListFromRange(int.Parse(nupAnioInteractivaDesde.Value.ToString()), int.Parse(nupAnioInteractivaHasta.Value.ToString())) :
                                    getListFromString(txtAniosInteractiva.Text);

                                // Get for each year in range
                                foreach (int interactivaYear in yearList)
                                {
                                    List<int> monthList = optInteractivaRango.Checked ?
                                                getListFromRange(int.Parse(cboMesInteractivaDesde.SelectedValue.ToString()), int.Parse(cboMesInteractivaHasta.SelectedValue.ToString())) :
                                                getListFromString(txtMesesInteractiva.Text);

                                    // Get for each month in range
                                    foreach (int interactivaMonth in monthList)
                                    {
                                        datosTrabajadores = _catalogoAdicional.obtenDatasetTrabajadoresRecibo(cboCompania.SelectedValue.ToString(), payrollTypeValue, "", interactivaYear, interactivaMonth, _manejoNomina);

                                        string periodsFromMonth = getPeriodsFromMonth(null, _manejoNomina, interactivaMonth);

                                        setupDataSetAndMergeInDataTable(ref dtTrabajadores, datosTrabajadores);

                                        if (isADAMStampingClient())
                                        {
                                            statusDataTempHolder.addPayrollType(_manejoNomina, payrollTypeValue);
                                            statusDataTempHolder.addPeriods(_manejoNomina, periodsFromMonth);
                                            statusDataTempHolder.addYear(_manejoNomina, interactivaYear.ToString());
                                        }
                                    }
                                }
                            }
                        }
                        break;
                    case Countries.Colombia:
                        // Get Employees Data
                        datosTrabajadores = _catalogosDIAN.getDatasetEmployeesReceiptDian(cboCompania.SelectedValue.ToString(), nupAnioPeriodicaDesde.Value.ToString(), cboMesPeriodicaDesde.SelectedValue.ToString());
                        dtTrabajadores = (datosTrabajadores != null ? datosTrabajadores.Tables[0] : null);
                        break;
                }

                // Reset filter from FiltroAvanzado
                dsFormFilter = String.Empty;
                lblSeleccionados.Text = "Seleccionados:";
                lblSeleccionados.ForeColor = SystemColors.ControlText;

                // AZ-1071: Check if there is data, to give a reference to the user
                if (dtTrabajadores == null || dtTrabajadores.Rows.Count == 0)
                {
                    MessageBox.Show("No existe información con los parametros seleccionados ", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Cursor = Cursors.Default;
                    return;
                }

                // AZ-1071: Update stamping status, if it applies
                if (isADAMStampingClient())
                {
                    // Set status for all rows, will update after webservice call
                    updateRowsStampingStatus(dtTrabajadores, true);
                }
                else
                {
                    gridTrabajadores.DataSource = dtTrabajadores;
                    ConfiguraColumnaSeleccion();
                }

                // All columns readonly, except for selection column
                foreach (DataGridViewColumn columna in gridTrabajadores.Columns)
                {
                    if (columna.Name != "Sel")
                        columna.ReadOnly = true;
                }

                // Select all rows
                chkSelectAll.Checked = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }
        
        private void updatePeriodicaVisibilityPanels()
        {
            lblMesPeriodica.Visible = optMensual.Checked;
            lblPeriodo.Visible = !optMensual.Checked;

            //AZ-1071: Added month combos and periodos visibility setting, for panels
            pnlPeriodosPeriodicaRango.Visible = !optMensual.Checked && optPeriodicaRango.Checked;
            pnlMesPeriodicaRango.Visible = optMensual.Checked && optPeriodicaRango.Checked;
            pnlCtrsPeriodicaEspecificos.Visible = !optPeriodicaRango.Checked;
            txtMesesPeriodica.Visible = optMensual.Checked && !optPeriodicaRango.Checked;
            txtPeriodosPeriodica.Visible = !optMensual.Checked && !optPeriodicaRango.Checked;
        }
        
        private void updateRowsStampingStatus(DataTable dsTable, Boolean setInitDatasource)
        {
            /* 
            TO DO 
            Change to use Restful API 

            StampingStatusConstants statusConstants = new StampingStatusConstants();

            // Remove event, this improves performance
            this.gridTrabajadores.CellValueChanged -= new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);

            // Set status for all rows, will update after webservice call
            foreach (DataRow row in dsTable.Rows)
            {
                row[statusIdRowName] = 0;
                row[statusRowName] = statusConstants.getStatusText(0);
                if (string.IsNullOrEmpty(row[selRowName].ToString()))
                    row[selRowName] = true;
            }

            this.gridTrabajadores.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);

            StampingStatusTempInfo tempInfo;

            // If periodica payroll was selected
            if (statusDataTempHolder.processedPeriodica())
            {
                tempInfo = statusDataTempHolder.getInfo(Utilerias.ManejoNomina.periodica);
                DataRow[] testRows = dsTable.Select(String.Format("tipo_nomina IN ({0})", tempInfo.PayrollType));
                updateRowsStampingStatusHelper(ref testRows, Utilerias.ManejoNomina.periodica, tempInfo, setInitDatasource);
            }

            // If interactiva payroll was selected
            if (statusDataTempHolder.processedInteractiva())
            {
                tempInfo = statusDataTempHolder.getInfo(Utilerias.ManejoNomina.interactiva);
                DataRow[] testRows = dsTable.Select(String.Format("tipo_nomina IN ({0})", tempInfo.PayrollType));
                updateRowsStampingStatusHelper(ref testRows, Utilerias.ManejoNomina.interactiva, tempInfo, setInitDatasource);
            }

            if (setInitDatasource)
            {
                // Add Checbox column
                gridTrabajadores.DataSource = dsTable;

                DataGridViewCheckBoxColumn columnaCheck = new DataGridViewCheckBoxColumn();

                columnaCheck.Name = "Sel";
                columnaCheck.HeaderText = "Sel";
                columnaCheck.ReadOnly = false;
                columnaCheck.FalseValue = false;
                columnaCheck.TrueValue = true;
                columnaCheck.DataPropertyName = selRowName;
                gridTrabajadores.ReadOnly = false;
                gridTrabajadores.Columns.Insert(0, columnaCheck);

                gridTrabajadores.Columns[selRowName].Visible = false;
                gridTrabajadores.Columns[statusIdRowName].Visible = false;

                // Remove event, this improves performance
                this.gridTrabajadores.CellValueChanged -= new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);

                // Update readonly and status the first time in grid
                foreach (DataGridViewRow row in gridTrabajadores.Rows)
                {
                    DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)row.Cells["Sel"];
                    bool selected = bool.Parse(row.Cells[selRowName].Value.ToString());

                    checkBoxCell.ReadOnly = !selected;
                    checkBoxCell.Value = selected;
                }

                this.gridTrabajadores.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);
            }

            // AZ-1061: Filter by state given selected checkboxes
            filterDataSourceByState();
            */
        }
        
        private void filterDataSourceByState()
        {
            if (gridTrabajadores.DataSource == null)
            {
                return;
            }

            StampingStatusConstants statusConstants = new StampingStatusConstants();
            bool stateTodos = chkStateTodos.Checked;
            stringStateFilters.Clear();

            if (!stateTodos)
            {
                if (chkStateSinTimbrar.Checked)
                    stringStateFilters.Add(statusConstants.getStatusText(StampingStatusConstants.SIN_TIMBRAR));

                if (chkStateEnProceso.Checked)
                    stringStateFilters.Add(statusConstants.getStatusText(StampingStatusConstants.EN_PROCESO_VALUE));

                if (chkStateCancelado.Checked)
                    stringStateFilters.Add(statusConstants.getStatusText(StampingStatusConstants.CANCELADO_VALUE));

                if (chkStateEliminado.Checked)
                    stringStateFilters.Add(statusConstants.getStatusText(StampingStatusConstants.ELIMINADO_VALUE));

                if (chkStateConError.Checked)
                    stringStateFilters.Add(statusConstants.getStatusText(StampingStatusConstants.ERROR_VALUE));

                if (chkStateFinalizado.Checked)
                    stringStateFilters.Add(statusConstants.getStatusText(StampingStatusConstants.FINALIZADO_VALUE));
            }

            // States changed, call grid update
            updateGridFilter();
        }
        
        private void ProcesarTimbradoXMLs()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                // AZ-1061: Users can deselect rows when executing, prevent this
                gridTrabajadores.Enabled = false;

                // 201701 JGE
                // Modificacion para evitar que la pantalla se bloque o el equipo entre en suspension
                fPreviousExecutionState = NativeMethods.SetThreadExecutionState(NativeMethods.ES_CONTINUOUS | NativeMethods.ES_SYSTEM_REQUIRED);

                // Para desactivar el protector de pantalla
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_GETSCREENSAVERACTIVE, 0, ref protectorPantallaActivo, 0);
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENSAVEACTIVE, 0, ref nullVar, NativeMethods.SPIF_SENDWININICHANGE);

                // Parametros para el SP
                compania = cboCompania.SelectedValue.ToString();
                if (cboFormaPago.SelectedValue != null)
                    metodoPago = cboFormaPago.SelectedValue.ToString();
                else
                    metodoPago = "03";

                // Inicializa la barra de progreso
                pbResultados.Maximum = int.Parse(lblContador.Text);
                pbResultados.Value = 0;

                // Inicia la ejecucion en un thread independiente
                objThreadEjecucion = new CallBackThread(this, Process_SAT_Thread, Progress_SAT_CallBack);
                objThreadEjecucion.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task Process_SAT_Thread()
        {
            try
            {
                DataSet dParametrosCompania = _catalogoAdicional.obtenParametrosCompania(compania);
                Func<string, string> getParametroCompania = GlobalHelper.CreateFuncGetParam(dParametrosCompania, "parametro", "valor");
                var stamping_mode = getParametroCompania("stamping_mode");

                var listaTrabajadores = new Trabajadores();

                // AZ-1071: Check if the column exist in the datasource
                var existPagoSeparacion = gridTrabajadores.Columns.Contains("pago_separacion");

                #region Employees Iteration

                // Employees Iteration
                foreach (DataGridViewRow renglon in gridTrabajadores.Rows)
                {
                    // Change to use checkbox cell instead of parsed value
                    DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)renglon.Cells["Sel"];

                    bool selectedRow = (selectedColumn.Value != null
                                        ? bool.Parse(selectedColumn.Value.ToString())
                                        : false);

                    if (selectedRow)
                    {
                        string tipoNomina = renglon.Cells["tipo_nomina"].Value.ToString();
                        ManejoNomina _manejoNomina = GetManejoNominaByPayrollType(tipoNomina);

                        int pagoSeparacionValue;
                        if (_manejoNomina == ManejoNomina.interactiva)
                            pagoSeparacionValue = existPagoSeparacion ? int.Parse(renglon.Cells["pago_separacion"].Value.ToString()) : 1;
                        else
                            pagoSeparacionValue = 0;

                        listaTrabajadores.Add(new Trabajador()
                        {
                            numTrabajador = renglon.Cells["trabajador"].Value.ToString(),
                            tipoNomina = tipoNomina,
                            claseNomina = renglon.Cells["clase_nomina"].Value.ToString(),
                            anio = int.Parse(renglon.Cells["anio"].Value.ToString()),
                            manejoNomina = _manejoNomina,
                            numeroLiquidacion = int.Parse(renglon.Cells["numero_liquidacion"].Value.ToString()),
                            periodo = int.Parse(renglon.Cells["periodo"].Value.ToString()),
                            pagoSeparacion = pagoSeparacionValue, //PTF-2091: When manejoNomina is interactiva, send 1 to perform separation of Nodes in one file
                            esTimbradoRelacionado = gridTrabajadores.Columns.Contains("IdEstado") ? int.Parse(renglon.Cells["IdEstado"].Value.ToString()) == StampingStatusConstants.CANCELADO_VALUE : false, //REC-30: Added checkbox for related stamping, so it can be added by checking it
                        }); ;
                    }
                }
                
                #endregion

                if (_catalogoAdicional.existeTablaConfiguracion() && stamping_mode == "new_mode") // This is the new stamping mode
                {
                    if (listaTrabajadores.Count > 0)
                    {
                        var instance = this.appSettings.Database;
                        var url = getParametroCompania("hangfire_stamping_server");

                        var dataset_csd = _catalogoAdicional.ReadCSD();
                        var CFDI_disponibles_contiene_instancia = dataset_csd.Tables[0].AsEnumerable().Select(e => e.Field<string>("client")).Contains(this.compania);

                        if (CFDI_disponibles_contiene_instancia)
                        {
                            var company_info = dataset_csd.Tables[0].AsEnumerable().FirstOrDefault(e => e.Field<string>("client") == this.compania);
                            var cert = FrmConfiguracion.StringToByteArray(company_info.Field<string>("cert_data"));
                            var key = FrmConfiguracion.StringToByteArray(company_info.Field<string>("key_data"));

                            // CWE-316 storing secure strings
                            var password = new NetworkCredential("", company_info.Field<string>("password_data")).SecurePassword;

                            FrmConfiguracion.VerificarCSD(cert, key,
                                                          new NetworkCredential("", password).Password,
                                out bool key_password_is_valid, out bool csd_is_still_valid, out string subject, out DateTime not_after, out double available_cert_days);

                            if (!key_password_is_valid)
                            {
                                MessageBox.Show("Contraseña no corresponde con llave, favor de verificar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            if (!csd_is_still_valid)
                            {
                                MessageBox.Show($"Ha terminado la vigencia del CSD, el día {not_after:yyyy-MM-dd}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            if (key_password_is_valid && csd_is_still_valid)
                            {
                                StringBuilder sb = new StringBuilder();
                                sb.AppendLine($"La vigencia del CSD terminara el día {not_after:yyyy-MM-dd},");
                                sb.AppendLine($"le restan {available_cert_days} días de uso.");

                                MessageBoxIcon message_box_icon = MessageBoxIcon.Information;
                                if (available_cert_days > 65) { message_box_icon = MessageBoxIcon.Warning; }

                                MessageBox.Show(sb.ToString(), "Recordatorio de vigencia de CSD", MessageBoxButtons.OK, message_box_icon);

                                var endpoint = getParametroCompania("stamping_endpoint");
                                var employee_groups = listaTrabajadores.GroupBy(n => new { n.tipoNomina, n.claseNomina });
                                Parallel.ForEach(employee_groups, async item => { await SendMessageToEndPoint(item.ToList(), url, instance, endpoint); });
                            }
                        }
                        else
                        {
                            MessageBox.Show($"No existe certificado y llave para esta compañia en sistema", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else //This is the legacy stamping mode
                {
                    DataSet dConfig = _catalogoAdicional.obtenConfiguracionCompania(compania);
                    Func<string, string> getParameterStringValue = GlobalHelper.CreateFuncGetParam(dConfig, ColIdParametro, ColAlfanumerico);

                    var flag_datosdConfig = dConfig != null && dConfig.Tables[0].Rows.Count > 0;

                    #region Get Current Configuration

                    var archivoXSLT = flag_datosdConfig ?
                        getParameterStringValue(ConfigurationTypes.xslt_file.ToString()) :
                        appSettings.Xslt.ToString();

                    var archivoXSD = flag_datosdConfig ?
                                     getParameterStringValue(ConfigurationTypes.xsd_file.ToString()) :
                                     appSettings.Xsd.ToString();

                    var generaMultiplesArchivos = flag_datosdConfig
                                                      ? (!string.IsNullOrEmpty(getParameterStringValue(ConfigurationTypes.generation_type.ToString())) &&
                                                          (getParameterStringValue(ConfigurationTypes.generation_type.ToString()).ToLower().Equals("true") ||
                                                           getParameterStringValue(ConfigurationTypes.generation_type.ToString()).ToLower().Equals("1")
                                                          )
                                                        )
                                                      : (!string.IsNullOrEmpty(appSettings.MultipleFile) &&
                                                          (appSettings.MultipleFile.ToLower().Equals("true") ||
                                                            appSettings.MultipleFile.ToLower().Equals("1")
                                                          )
                                                        );

                    var rutaGenerador = Properties.AppSettings.Default[ConfigParameters.applicationPath.ToString()].ToString();

                    var rutaArchivosSalida = Path.Combine(rutaGenerador, "output", $"{Environment.UserName}_{DateTime.Now.ToString("ddMMyyyy_hhmmss")}");
                    
                    if (!Directory.Exists(rutaArchivosSalida))
                    {
                        Directory.CreateDirectory(rutaArchivosSalida);
                    }

                    var generaDatosAdicionales = flag_datosdConfig ?
                                                (!string.IsNullOrEmpty(getParameterStringValue(ConfigurationTypes.additional_generation.ToString())) &&
                                                 getParameterStringValue(ConfigurationTypes.additional_generation.ToString()).ToLower().Equals("true")) :
                                                (!string.IsNullOrEmpty(appSettings.AdditionalData) &&
                                                 appSettings.AdditionalData.ToLower().Equals("true"));

                    var procDatosAdicionales = flag_datosdConfig ?
                                              getParameterStringValue(ConfigurationTypes.additional_proc.ToString()) :
                                              appSettings.AdditionalProcedure.ToString();

                    int.TryParse(flag_datosdConfig ?
                                 getParameterStringValue(ConfigurationTypes.timeout.ToString()) :
                                 appSettings.Timeout.ToString(), out int timeout);

                    #endregion

                    #region Generate Xmls

                    // Add the header if multipleArchivos paramater is not set
                    if (!generaMultiplesArchivos)
                    {
                        EscribeEncabezadoArchivoPrevio(rutaArchivosSalida);
                    }
                    
                    // Generate Xmls
                    var generateXML = new GenerateXml(tipoPlataforma, Properties.AppSettings.Default,
                                                      listaTrabajadores, compania, 
                                                      txtConceptoFactura.Text, metodoPago,
                                                      rutaCertificado, rutaLlave, passwordLlave);

                    await generateXML.Run(objThreadEjecucion,
                                          generarArchivos,
                                          archivoXSLT,
                                          archivoXSD,
                                          chkValidaXSD.Checked,
                                          rutaGenerador,
                                          rutaArchivosSalida,
                                          generaMultiplesArchivos,
                                          generaDatosAdicionales,
                                          procDatosAdicionales,
                                          this.fPreviousExecutionState,
                                          this.protectorPantallaActivo,
                                          this.nullVar,
                                          UtileriasConfig.GetEndpointAddress(),
                                          timeout);

                    #endregion
                }

            }
            catch (InvalidOperationException opEx)
            {
                MessageBox.Show("Se cancelo el proceso, error: " + Environment.NewLine + opEx.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            catch (Exception ex)
            {
                // Get Inner exception message, in case the exception occurs inside the Thread
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace + (ex.InnerException != null ? (Environment.NewLine + ex.InnerException.Message) : ""), "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        public bool IsNewStampingMode()
        {
            try
            {
                string tmpCia;
                if (!string.IsNullOrEmpty(compania))
                    tmpCia = compania;
                else if (cboCompania.SelectedIndex >= 0)
                    tmpCia = cboCompania.SelectedValue.ToString();
                else
                    tmpCia = "";

                _catalogoAdicional.CheckDbConnection();
                DataSet dParametrosCompania = _catalogoAdicional.obtenParametrosCompania(tmpCia);
                Func<string, string> getParametroCompania = GlobalHelper.CreateFuncGetParam(dParametrosCompania, "parametro", "valor");
                var stamping_mode = getParametroCompania("stamping_mode");
                return (_catalogoAdicional.existeTablaConfiguracion() && stamping_mode == "new_mode");
            }
            catch
            {
                return false;
            }
        }

        public void InicializarBarraProgreso()
        {
            // Inicializa la barra de progreso
            pbResultados.Maximum = int.Parse(lblContador.Text);
            pbResultados.Value = 0;
        }

        public async Task SendMessageToEndPoint(List<Trabajador> listaTrabajadores, string url, string instance, string endpoint)
        {
            try
            {
                // Eliminar datos de recibos de pago
                DeletePayslipsData(listaTrabajadores);

                // Poblar la cola de empleados
                var employeesQueue = PopulateEmployeeQueue(listaTrabajadores);

                // Crear la solicitud de empleados
                var request = CreateEmployeeRequest(listaTrabajadores);

                // Enviar mensajes al endpoint
                await SendMessagesAsync(employeesQueue, request, url, instance, endpoint);

                MessageBox.Show($"Se ha enviado el timbrado, puede monitorear el progreso desde WorkSpace", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                objThreadEjecucion.UpdateUI($"Trabajador: \t se produjo un error en el envio {e.Message} a {url + "/" + endpoint}");
            }
        }

        private void DeletePayslipsData(List<Trabajador> listaTrabajadores)
        {
            string employeesList = string.Join(",", listaTrabajadores.Select(t => t.numTrabajador).ToArray());

            _catalogoAdicional.DeletePayslipsData(this.compania, listaTrabajadores[0].tipoNomina, listaTrabajadores[0].claseNomina,
                                                  listaTrabajadores[0].anio, listaTrabajadores[0].periodo, employeesList);
        }

        private Queue<EmployeeInfo> PopulateEmployeeQueue(List<Trabajador> listaTrabajadores)
        {
            var employees = new Queue<EmployeeInfo>();

            foreach (var item in listaTrabajadores)
            {
                employees.Enqueue(new EmployeeInfo
                {
                    Compania = this.compania,
                    TipoNomina = item.tipoNomina,
                    ClaseNomina = item.claseNomina,
                    Anio = item.anio.ToString(),
                    Periodo = item.periodo.ToString(),
                    Trabajador = item.numTrabajador,
                    NumeroLiquidacion = item.numeroLiquidacion.ToString(),
                    ManejoNomina = ((int)item.manejoNomina).ToString()
                });
            }

            return employees;
        }

        private EmployeeRequest CreateEmployeeRequest(List<Trabajador> listaTrabajadores) => new EmployeeRequest
        {
            Culture = this.Idioma,
            Country = this.Pais,
            ProcessId = Guid.NewGuid().ToString(),
            TotalEmployees = listaTrabajadores.Count.ToString()
        };

        private async Task SendMessagesAsync(Queue<EmployeeInfo> employees, EmployeeRequest request, string url, string instance, string endpoint)
        {
            int numberOfItemsPerMessage = 500;
            bool createJsonFromMessage = false;

            while (employees.Count > 0)
            {
                var employeesTempList = new List<EmployeeInfo>();

                for (int i = 0; i < numberOfItemsPerMessage; i++)
                {
                    if (employees.Count == 0) break;

                    var tempEmployee = employees.Dequeue();
                    employeesTempList.Add(tempEmployee);
                }

                if (employeesTempList.Count > 0)
                {
                    request.Employees = employeesTempList;
                    if (createJsonFromMessage) { RequestToJsonFile(request); }

                    var response = await HangfireHelper.CreateEmployeeRequestAsync(url, $"{instance}/{endpoint}", request);

                    if (response != null)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync();

                        if (response.StatusCode != HttpStatusCode.InternalServerError)
                        {
                            if (response.IsSuccessStatusCode)
                            {
                                var responseContentDeserialize = JsonConvert.DeserializeObject<Hashtable>(responseContent);

                                var error = bool.Parse(responseContentDeserialize["error"]?.ToString());
                                var message = responseContentDeserialize["message"]?.ToString();
                                var requestData = responseContentDeserialize["requestData"]?.ToString();

                                if (!error)
                                {
                                    foreach (var employee in employeesTempList)
                                    {
                                        objThreadEjecucion.UpdateUI($"Trabajador: {employee.Trabajador}\t enviado de manera exitosa a {url + instance + "/" + endpoint}");
                                    }
                                }
                                else
                                {
                                    foreach (var employee in employeesTempList)
                                    {
                                        objThreadEjecucion.UpdateUI($"Trabajador: {employee.Trabajador}\t error en envío: {message} |||||||||| request: {requestData}");
                                    }
                                }
                            }
                            else
                            {
                                foreach (var employee in employeesTempList)
                                {
                                    objThreadEjecucion.UpdateUI($"Trabajador: {employee.Trabajador}\t error en envío: {responseContent}");
                                }
                            }
                        }
                        else
                        {
                            objThreadEjecucion.UpdateUI($"Trabajador: \t error en envío: Internal Server Error");
                        }
                    }
                    else
                    {
                        foreach (var employee in employeesTempList)
                        {
                            objThreadEjecucion.UpdateUI($"Trabajador: {employee.Trabajador}\t no se recibió respuesta del servidor.");
                        }
                    }
                }
            }
        }

        public static void RequestToJsonFile(EmployeeRequest request)
        {
            string result_path = $@"C:\Temp\{DateTime.Now:yyyyMMddHHmmssffff}.json";
            string json = JsonConvert.SerializeObject(request, Formatting.Indented);
            File.WriteAllText(result_path, json);
        }

        public void Progress_SAT_CallBack(string status = "", bool reset = false)
        {
            if (reset)
                InicializarBarraProgreso();

            if (!string.IsNullOrEmpty(status))
            {
                string[] separadores = new string[] { "\t", "Trabajador: " };
                string trabajadorResultado = status.Split(separadores, StringSplitOptions.None)[1];
                string archivoResultado = status.Split(separadores, StringSplitOptions.None)[2];

                // Add Listbox Info
                if (status.IndexOf("Error")<0)
                {
                    lbGenerados.Items.Add(status);
                }
                else
                {
                    lbGenerados.Items.Add($"Trabajador: {trabajadorResultado}");
                    var displayResults = archivoResultado.Replace("validacion xsd:", string.Empty).Trim();
                    var results = displayResults.Split(new[] { "Error:" }, StringSplitOptions.RemoveEmptyEntries)
                                            .Select(value => $"Error: {value.Trim()}")
                                            .ToArray();
                    
                    foreach (var row in results)
                    {
                        lbGenerados.Items.Add(row);
                    }
                }

                lbGenerados.TopIndex = lbGenerados.Items.Count - 1;

                if (pbResultados.Value < pbResultados.Maximum &&
                    (trabajadorProcesado != trabajadorResultado || (trabajadorProcesado == trabajadorResultado && archivoProcesado != archivoResultado)))
                {
                    pbResultados.Value += 1;
                    trabajadorProcesado = trabajadorResultado;
                    archivoProcesado = archivoResultado;
                }

                if (pbResultados.Value >= pbResultados.Maximum)
                {
                    cmdGenera.Enabled = true;
                    cmdGeneraArchivo.Enabled = true;
                    this.Cursor = Cursors.Default;
                    gridTrabajadores.Enabled = true;
                    trabajadorProcesado = "";
                    archivoProcesado = "";

                    if (isADAMStampingClient())
                    {
                        DataTable dtTrabajadores = (DataTable)gridTrabajadores.DataSource;

                        if (dtTrabajadores != null)
                            updateRowsStampingStatus(dtTrabajadores, false);
                    }
                }
            }
        }
        
        private void CopiarListaAlclipBoard()
        {
            if (lbGenerados.SelectedItems.Count == 0)
                return;

            for (int i = 0; i < lbGenerados.Items.Count; i++)
            {
                lbGenerados.SetSelected(i, true);
            }
            string s = "";
            foreach (object o in lbGenerados.SelectedItems)
            {
                s += o.ToString() + Environment.NewLine;
            }
            Clipboard.SetText(s);
        }
        
        private void EscribeEncabezadoArchivoPrevio(string rutaArchivosSalida)
        {
            var xmlPreview = Path.Combine(rutaArchivosSalida, $"{br.ApplicationUser}_Previo.xml");

            if (File.Exists(xmlPreview))
            {
                File.Delete(xmlPreview);
            }

            StreamWriter writer;
            writer = File.AppendText(xmlPreview);
            writer.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            writer.WriteLine("<nominas>");
            writer.Flush();
            writer.Close();
        }
        
        private void ObtenVersion()
        {
            Assembly assemblyExec = Assembly.GetEntryAssembly();
            this.Text += $"          ({assemblyExec.GetName().Version})";
        }
        
        private void ConfiguraColumnasTotal()
        {
            gridTotales.Rows.Clear();
            gridTotales.Columns.Clear();
            gridTotales.ColumnHeadersVisible = true;

            foreach (DataGridViewColumn columna in gridTrabajadores.Columns)
            {
                DataGridViewColumn columnaTotal = new DataGridViewColumn(gridTrabajadores.Rows[0].Cells[columna.Name]);
                columnaTotal.Width = columna.Width;
                columnaTotal.Name = columna.Name;
                gridTotales.Columns.Add(columnaTotal);
            }

            if (AdamExecution == "1")
            {
                gridTotales.Refresh();
            }
        }
        
        private void CalculaTotales()
        {
            if (gridTotales.Rows.Count == 0)
                return;

            try
            {
                foreach (DataGridViewColumn columna in gridTrabajadores.Columns)
                {
                    if (listaCamposImporte.IndexOf(columna.Name) > -1)
                    {
                        gridTotales.Rows[0].Cells[columna.Name].Value = 0;

                        foreach (DataGridViewRow renglon in gridTrabajadores.Rows)
                        {
                            // AZ-1061: Change to use checkbox cell instead of parsed value
                            DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)renglon.Cells["Sel"];

                            bool selectedRow = (selectedColumn.Value != null
                                               ? bool.Parse(selectedColumn.Value.ToString())
                                               : false);

                            // PTF-1663: Can generate error if value is null
                            if (selectedRow)
                            {
                                Double acumulado = 0;
                                acumulado = double.Parse(gridTotales.Rows[0].Cells[columna.Name].Value.ToString());

                                Double actual = 0;

                                if (renglon.Cells[columna.Name].Value == null)
                                    actual = 0;
                                else
                                    actual = double.Parse(renglon.Cells[columna.Name].Value.ToString());

                                gridTotales.Rows[0].Cells[columna.Name].Value = acumulado + actual;
                            }
                        }
                    }
                    else
                    {
                        if (gridTotales.Columns.Contains(columna.Name))
                            gridTotales.Rows[0].Cells[columna.Name].Value = "---";
                    }
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al calcular los Totales, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void configuraCeldasImporte(DataGridView grid)
        {
            foreach (DataGridViewColumn columna in grid.Columns)
            {
                if (listaCamposImporte.IndexOf(columna.Name) > -1)
                {
                    columna.DefaultCellStyle.Format = "N2";
                    columna.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }
        }
        
        private Boolean ValidaEnvio()
        {
            try
            {
                // Set Message
                string mensaje = string.Format("Se enviaran los siguientes datos al proceso de {0} :",
                                 (this.Pais.Equals(Countries.Colombia.ToString()) ? "CENET" : "timbrado"))
                                 + Environment.NewLine + Environment.NewLine;

                mensaje += "Numero de empleados: " + lblContador.Text.PadLeft(30 - lblContador.Text.Length) + Environment.NewLine + Environment.NewLine;

                // Set Totals
                foreach (DataGridViewColumn columna in gridTotales.Columns)
                {
                    if (listaCamposImporte.IndexOf(columna.Name) > 0)
                    {
                        mensaje += columna.Name + ":\t\t" + ((Double)gridTotales.Rows[0].Cells[columna.Name].Value).ToString("C", System.Globalization.CultureInfo.CurrentCulture).PadLeft(30 - gridTotales.Rows[0].Cells[columna.Name].Value.ToString().Length) + Environment.NewLine;
                    }
                }

                // Show Message
                return (MessageBox.Show(mensaje, "ADAM", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes);
            }
            catch
            {
                return false;
            }
        }
        
        private void ExportaCSV()
        {
            if (gridTrabajadores.Rows.Count == 0)
                return;

            StringBuilder exportar = new StringBuilder();

            foreach (DataGridViewColumn columna in gridTotales.Columns)
                exportar.Append(columna.Name + ",");

            exportar.Length--; // Quita la última coma
            exportar.AppendLine();

            foreach (DataGridViewRow renglon in gridTrabajadores.Rows)
            {
                // AZ-1061: Change to use checkbox cell instead of parsed value
                DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)renglon.Cells["Sel"];

                bool selectedRow = (selectedColumn.Value != null && bool.Parse(selectedColumn.Value.ToString()));

                if (selectedRow)
                {
                    foreach (DataGridViewColumn columna in gridTotales.Columns)
                    {
                        object cellValue = renglon.Cells[columna.Name].Value;
                        exportar.Append(cellValue != null ? cellValue.ToString() + "," : ",");
                    }
                    exportar.Length--; // Quita la última coma
                    exportar.AppendLine();
                }
            }

            var outputCsv = Path.Combine(this.appSettings.ApplicationPath, "exporta.csv");

            try
            {
                using (StreamWriter writer = new StreamWriter(outputCsv))
                {
                    writer.Write(exportar.ToString());
                }

                if (File.Exists(outputCsv))
                {
                    GlobalHelper.OpenFileSecure(outputCsv);
                }
                else
                {
                    Console.WriteLine("El Archivo CSV no pudo ser creado.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocurrió un error al exportar el archivo CSV: " + ex.Message);
            }
        }

        private void CargaMetodoPagoDefault()
        {
            cboFormaPago.SelectedValue = Properties.AppSettings.Default.metodoPagoDefault.ToString();
        }
        
        private void GuardaMetodoPagoDefault()
        {
            if (cboFormaPago.SelectedValue != null)
            {
                Properties.AppSettings.Default.metodoPagoDefault = cboFormaPago.SelectedValue.ToString();
                Properties.AppSettings.Default.Save();
            }
        }
        
        private DataSet DatosTrabajadoresMensual(string compania, string tipoNomina, string claseNomina, int anio, int mesAcumular, ManejoNomina manejoNomina, ref string periodsFromMonth)
        {
            DataSet dsListaPeriodos;
            DataSet datosTrabajadoresTemp;
            DataSet datosTrabajadoresFinal = new DataSet();

            //1) Obtener la lista de periodos por mes acumular para la compañia, tipo de nomina, año y mes a acumular
            dsListaPeriodos = _catalogoAdicional.obtenListaPeriodosMes(compania, tipoNomina, anio, mesAcumular);

            int periodo = 0;
            foreach (DataRow renglon in dsListaPeriodos.Tables[0].Rows)
            {
                //2) Por cada registro ejecutar el proceso estandar y anexar los dataset para devolver un único datasets
                periodo = int.Parse(renglon[0].ToString());
                datosTrabajadoresTemp = _catalogoAdicional.obtenDatasetTrabajadoresRecibo(compania, tipoNomina, claseNomina, anio, periodo, manejoNomina);

                //Si es la primera vez agregar el datatable
                if (datosTrabajadoresFinal.Tables.Count == 0)
                {
                    datosTrabajadoresFinal.Tables.Add(datosTrabajadoresTemp.Tables[0].Copy());
                }
                //Sino, se hace el merge de los datos
                else
                {
                    datosTrabajadoresFinal.Tables[0].Merge(datosTrabajadoresTemp.Tables[0]);
                }
            }

            // AZ-1071: Added periodsFromMonth reference, to get advantage of existing call to database
            periodsFromMonth = getPeriodsFromMonth(dsListaPeriodos, manejoNomina, mesAcumular);

            // Al final se devuelve el dataset con los datos de todos los periodos del mes
            return datosTrabajadoresFinal;
        }

        private void deactivateCheckedEvents()
        {
            chkStateCancelado.CheckedChanged -= ChkStateCancelado_CheckedChanged;
            chkStateSinTimbrar.CheckedChanged -= ChkStateSinTimbrar_CheckedChanged;
            chkStateEnProceso.CheckedChanged -= ChkStateEnProceso_CheckedChanged;
            chkStateEliminado.CheckedChanged -= ChkStateEliminado_CheckedChanged;
            chkStateConError.CheckedChanged -= ChkStateConError_CheckedChanged;
            chkStateFinalizado.CheckedChanged -= ChkStateFinalizado_CheckedChanged;
        }
        
        private void activateCheckedEvents()
        {
            chkStateCancelado.CheckedChanged += ChkStateCancelado_CheckedChanged;
            chkStateSinTimbrar.CheckedChanged += ChkStateSinTimbrar_CheckedChanged;
            chkStateEnProceso.CheckedChanged += ChkStateEnProceso_CheckedChanged;
            chkStateEliminado.CheckedChanged += ChkStateEliminado_CheckedChanged;
            chkStateConError.CheckedChanged += ChkStateConError_CheckedChanged;
            chkStateFinalizado.CheckedChanged += ChkStateFinalizado_CheckedChanged;
        }
        
        private void checkOtherStates()
        {
            chkStateTodos.CheckedChanged -= ChkStateTodos_CheckedChanged;
            chkStateTodos.Checked = false;
            if (!chkStateCancelado.Checked && !chkStateSinTimbrar.Checked && !chkStateEnProceso.Checked
                && !chkStateEliminado.Checked && !chkStateConError.Checked && !chkStateFinalizado.Checked)
            {
                chkStateTodos.Checked = true;
            }
            filterDataSourceByState();
            chkStateTodos.CheckedChanged += ChkStateTodos_CheckedChanged;
        }
        
        private void ConfiguraColumnaSeleccion()
        {
            DataGridViewCheckBoxColumn columnaCheck = new DataGridViewCheckBoxColumn
            {
                Name = "Sel",
                HeaderText = "Sel",
                ReadOnly = false,
                FalseValue = false,
                TrueValue = true,
                DataPropertyName = selRowName
            };

            gridTrabajadores.ReadOnly = false;
            gridTrabajadores.Columns.Insert(0, columnaCheck);
        }
        
        private bool isValidSplitInput(string text)
        {
            bool isValid = true;
            if (!String.IsNullOrWhiteSpace(text))
            {
                String[] splitText = text.Split(',');
                for (int i = 0; i < splitText.Length; i++)
                {
                    int value = 0;
                    if (!int.TryParse(splitText[i].Trim(), out value))
                    {
                        isValid = false;
                        break;
                    }
                }
            }

            return isValid;
        }
        
        private void showNotValidSplitValueMessage(Control control)
        {
            MessageBox.Show("El valor o valores ingresados no son válidos (¿Están separados por comas y son enteros?)", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            control.Focus();
        }
        
        private void ProcessDIANRecords()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                // Users can deselect rows when executing, prevent this
                gridTrabajadores.Enabled = false;

                // Avoid screen blocking process
                fPreviousExecutionState = NativeMethods.SetThreadExecutionState(NativeMethods.ES_CONTINUOUS | NativeMethods.ES_SYSTEM_REQUIRED);

                // Disable Screen Saver
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_GETSCREENSAVERACTIVE, 0, ref protectorPantallaActivo, 0);
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENSAVEACTIVE, 0, ref nullVar, NativeMethods.SPIF_SENDWININICHANGE);

                // Initialice the Process
                pbResultados.Maximum = int.Parse(lblContador.Text);
                pbResultados.Value = 0;

                // Set Parameters
                compania = cboCompania.SelectedValue.ToString();
                gAnio = nupAnioPeriodicaDesde.Value.ToString();
                gMes = cboMesPeriodicaDesde.SelectedValue.ToString();

                // Initialize the Thread
                objThreadEjecucion = new CallBackThread(this, Process_DIAN_Thread, Progress_DIAN_CallBack);
                objThreadEjecucion.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private async Task Process_DIAN_Thread()
        {
            try
            {
                var rutaGenerador = Properties.AppSettings.Default[ConfigParameters.applicationPath.ToString()].ToString();

                var rutaArchivosSalida = Path.Combine(rutaGenerador, "output", $"{Environment.UserName}_{DateTime.Now.ToString("ddMMyyyy_hhmmss")}");

                if (!Directory.Exists(rutaArchivosSalida))
                {
                    Directory.CreateDirectory(rutaArchivosSalida);
                }

                // Build Json
                BuildJsonDian(objThreadEjecucion, rutaGenerador, rutaArchivosSalida, compania, gAnio, gMes, bTransmitJsonToWS);
            }
            catch (System.InvalidOperationException opEx)
            {
                MessageBox.Show("Se cancelo el proceso, error: " + Environment.NewLine + opEx.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            catch (Exception ex)
            {
                // REC-30: Get Inner exception message, in case the exception occurs inside the Thread
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace + (ex.InnerException != null ? (Environment.NewLine + ex.InnerException.Message) : ""), "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void Progress_DIAN_CallBack(string status = "", bool reset = false)
        {
            // Add Message to Status Bar
            lbGenerados.Items.Add(status);

            // Increase Counter
            pbResultados.Value += (pbResultados.Value < pbResultados.Maximum ? 1 : 0);
            if (pbResultados.Value >= pbResultados.Maximum)
            {
                this.Cursor = Cursors.Default;
                gridTrabajadores.Enabled = true;
            }
        }
        
        public void BuildJsonDian(CallBackThread objetoCallBack, string rutaGenerador, string rutaArchivosSalida, 
                                  string company, string year, string month, bool bTransmitJsonToWS)
        {
            // Local Variables
            DataSet ds = null;
            int emplCounter = 0;
            var jsonRequest = string.Empty;
            DateTime procStartTime = DateTime.Now;
            DataSet dsParentId;
            string employeeId = string.Empty;
            JsonDian jsonFile = new JsonDian();

            try
            {
                // Create Header Nodes
                jsonFile.periodo = new Period();
                dsParentId = _catalogosDIAN.getParentIdCatalog();
                if (dsParentId != null)
                {
                    #region Header Rows 
                    // Header Rows
                    DataRow[] headerRows = dsParentId.Tables[0].Select("id_padre IN ('periodo','informaciongeneral','empleador')");

                    // Add Status Message
                    objetoCallBack.UpdateUI("Procesando Encabezados Archivo DIAN" + "\t");

                    // Generate Header Info
                    foreach (DataRow dr in headerRows)
                    {

                        // Generate Header Data
                        ds = _catalogosDIAN.getDatasetInformationDian(company, year, month, "", dr[ColIdPadre].ToString(), dr["tipo"].ToString());
                        if (ds != null)
                        {
                            switch (dr[ColIdPadre].ToString().ToLower())
                            {
                                case "periodo":
                                    Period period = new Period();
                                    period = CreateSingleListFromTable<Period>(ds.Tables[0]);
                                    jsonFile.periodo = period;
                                    break;
                                case "informaciongeneral":
                                    GeneralInformation generalInformation = new GeneralInformation();
                                    generalInformation = CreateSingleListFromTable<GeneralInformation>(ds.Tables[0]);
                                    jsonFile.informacionGeneral = new GeneralInformation();
                                    jsonFile.informacionGeneral = generalInformation;
                                    break;
                                case "empleador":
                                    Employer employer = new Employer();
                                    employer = CreateSingleListFromTable<Employer>(ds.Tables[0]);
                                    jsonFile.empleador = new Employer();
                                    jsonFile.empleador = employer;
                                    break;
                            }
                        }
                    }
                    #endregion

                    #region Employee Rows
                    try
                    {
                        // Employees Iteration
                        foreach (DataGridViewRow renglon in gridTrabajadores.Rows)
                        {
                            // Check if the employee is selected
                            DataGridViewCheckBoxCell selectedColumn = (DataGridViewCheckBoxCell)renglon.Cells["Sel"];

                            bool selectedRow = (selectedColumn.Value != null
                                                   ? bool.Parse(selectedColumn.Value.ToString())
                                                   : false);

                            if (selectedRow)
                            {
                                // Get Employee Id
                                employeeId = renglon.Cells["trabajador"].Value.ToString();

                                // Add Status Message
                                objetoCallBack.UpdateUI("Procesando Trabajador: " + employeeId + "\t");

                                // Create Temporal Employee Node
                                var dianTrabajador = new Employee();

                                dianTrabajador.devengados = new Perceptions();
                                dianTrabajador.deducciones = new Deductions();

                                // Iterate DIAN Parent Rows
                                foreach (DataRow dr in dsParentId.Tables[0].Rows)
                                {
                                    // Special Case 
                                    // The type is retrieved with the Concept
                                    if (dr[ColIdPadre].ToString().ToLower().Equals("incapacidad") &&
                                        dr["tipo"].ToString().Equals("query"))
                                    { continue; }

                                    // Get Child Rows
                                    ds = _catalogosDIAN.getDatasetInformationDian(company, year, month, employeeId, dr[ColIdPadre].ToString(), dr["tipo"].ToString());
                                    if (ds != null)
                                    {
                                        if (ds.Tables[0].Rows.Count > 0)
                                        {
                                            // Add Records
                                            switch (dr[ColIdPadre].ToString().ToLower())
                                            {
                                                case "numerosecuenciaxml":
                                                    XMLSequenceNumber xMLSequenceNumber = new XMLSequenceNumber();
                                                    xMLSequenceNumber = CreateSingleListFromTable<XMLSequenceNumber>(ds.Tables[0]);
                                                    dianTrabajador.numeroSecuenciaXML = new XMLSequenceNumber();
                                                    dianTrabajador.numeroSecuenciaXML = xMLSequenceNumber;
                                                    break;
                                                case "trabajador":
                                                    dianTrabajador = CreateSingleListFromTable<Employee>(ds.Tables[0]);
                                                    dianTrabajador.devengados = new Perceptions();
                                                    dianTrabajador.deducciones = new Deductions();
                                                    break;
                                                case "pago":
                                                    Payment payment = new Payment();
                                                    payment = CreateSingleListFromTable<Payment>(ds.Tables[0]);
                                                    dianTrabajador.pago = new Payment();
                                                    dianTrabajador.pago = payment;
                                                    break;
                                                case "fechaspago":
                                                    List<PaymentDates> paymentDates = new List<PaymentDates>();
                                                    paymentDates = CreateListFromTable<PaymentDates>(ds.Tables[0]);
                                                    dianTrabajador.fechasPago = (dianTrabajador.fechasPago == null
                                                                                 ? new List<PaymentDates>()
                                                                                 : dianTrabajador.fechasPago);
                                                    dianTrabajador.fechasPago = paymentDates;
                                                    break;
                                                case "basico":
                                                    Basic basic = new Basic();
                                                    basic = CreateSingleListFromTable<Basic>(ds.Tables[0]);
                                                    dianTrabajador.devengados.basico = new Basic();
                                                    dianTrabajador.devengados.basico = basic;
                                                    break;
                                                case "transporte":
                                                    Transport transport = new Transport();
                                                    transport = CreateSingleListFromTable<Transport>(ds.Tables[0]);
                                                    dianTrabajador.devengados.transporte = new Transport();
                                                    dianTrabajador.devengados.transporte = transport;
                                                    break;
                                                case "hed":
                                                    List<HeDs> heDs = new List<HeDs>();
                                                    heDs = CreateListFromTable<HeDs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.heDs = (dianTrabajador.devengados.heDs == null
                                                                                      ? new List<HeDs>()
                                                                                      : dianTrabajador.devengados.heDs);
                                                    dianTrabajador.devengados.heDs = heDs;
                                                    break;
                                                case "hen":
                                                    List<HeNs> heNs = new List<HeNs>();
                                                    heNs = CreateListFromTable<HeNs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.heNs = (dianTrabajador.devengados.heNs == null
                                                                                      ? new List<HeNs>()
                                                                                      : dianTrabajador.devengados.heNs);
                                                    dianTrabajador.devengados.heNs = heNs;
                                                    break;
                                                case "hrn":
                                                    List<HrNs> hrNs = new List<HrNs>();
                                                    hrNs = CreateListFromTable<HrNs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.hrNs = (dianTrabajador.devengados.hrNs == null
                                                                                      ? new List<HrNs>()
                                                                                      : dianTrabajador.devengados.hrNs);
                                                    dianTrabajador.devengados.hrNs = hrNs;
                                                    break;
                                                case "hrddf":
                                                    List<HrddFs> hrddFs = new List<HrddFs>();
                                                    hrddFs = CreateListFromTable<HrddFs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.hrddFs = (dianTrabajador.devengados.hrddFs == null
                                                                                      ? new List<HrddFs>()
                                                                                      : dianTrabajador.devengados.hrddFs);
                                                    dianTrabajador.devengados.hrddFs = hrddFs;
                                                    break;
                                                case "hendf":
                                                    List<HendFs> hendFs = new List<HendFs>();
                                                    hendFs = CreateListFromTable<HendFs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.hendFs = (dianTrabajador.devengados.hendFs == null
                                                                                      ? new List<HendFs>()
                                                                                      : dianTrabajador.devengados.hendFs);
                                                    dianTrabajador.devengados.hendFs = hendFs;
                                                    break;
                                                case "hrndf":
                                                    List<HrndFs> hrndFs = new List<HrndFs>();
                                                    hrndFs = CreateListFromTable<HrndFs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.hrndFs = (dianTrabajador.devengados.hrndFs == null
                                                                                        ? new List<HrndFs>()
                                                                                        : dianTrabajador.devengados.hrndFs);
                                                    dianTrabajador.devengados.hrndFs = hrndFs;
                                                    break;
                                                case "heddf":
                                                    List<HeddFs> heddFs = new List<HeddFs>();
                                                    heddFs = CreateListFromTable<HeddFs>(ds.Tables[0]);
                                                    dianTrabajador.devengados.heddFs = (dianTrabajador.devengados.heddFs == null
                                                                                      ? new List<HeddFs>()
                                                                                      : dianTrabajador.devengados.heddFs);
                                                    dianTrabajador.devengados.heddFs = heddFs;
                                                    break;
                                                case "vacacionescomunes":
                                                case "vacacionescompensadas":
                                                    List<Holidays> holidays = new List<Holidays>();
                                                    holidays = CreateListFromTable<Holidays>(ds.Tables[0]);

                                                    foreach (var item in holidays)
                                                    {
                                                        item.vacacionesCompensadas = (dr[ColIdPadre].ToString().ToLower() == "vacacionescomunes"
                                                                                     ? false
                                                                                     : true);
                                                    }

                                                    dianTrabajador.devengados.vacaciones = (dianTrabajador.devengados.vacaciones == null
                                                                                            ? new List<Holidays>()
                                                                                            : dianTrabajador.devengados.vacaciones);
                                                    dianTrabajador.devengados.vacaciones = holidays;
                                                    break;
                                                case "primas":
                                                    Premiums premiums = new Premiums();
                                                    premiums = CreateSingleListFromTable<Premiums>(ds.Tables[0]);
                                                    premiums.Cantidad = (premiums.Cantidad == 0 && premiums.PagoNSCantidad > 0
                                                                            ? premiums.PagoNSCantidad
                                                                            : premiums.Cantidad);
                                                    premiums.CantidadCantidad = (premiums.CantidadCantidad == 0 && premiums.Cantidad > 0
                                                                                    ? Convert.ToInt32(premiums.Cantidad)
                                                                                    : premiums.CantidadCantidad);
                                                    dianTrabajador.devengados.primas = premiums;
                                                    break;
                                                case "cesantias":
                                                    LayoffsInt layoffsInt = new LayoffsInt();
                                                    layoffsInt = CreateSingleListFromTable<LayoffsInt>(ds.Tables[0]);
                                                    Layoffs layoffs = new Layoffs()
                                                    {
                                                        Pago = layoffsInt.Pago,
                                                        PagoInteresesPorcentaje = Decimal.ToInt32(layoffsInt.PagoInteresesPorcentaje),
                                                        PagoIntereses = layoffsInt.PagoIntereses
                                                    };
                                                    dianTrabajador.devengados.cesantias = new Layoffs();
                                                    dianTrabajador.devengados.cesantias = layoffs;
                                                    break;
                                                case "incapacidad":
                                                    List<Disabilities> disabilities = new List<Disabilities>();
                                                    disabilities = CreateListFromTable<Disabilities>(ds.Tables[0]);

                                                    foreach (var item in disabilities)
                                                    {
                                                        item.TipoIncapacidad = (item.TipoIncapacidad <= 0 ? 1 : item.TipoIncapacidad);
                                                    }

                                                    dianTrabajador.devengados.incapacidades = (dianTrabajador.devengados.incapacidades == null
                                                                                           ? new List<Disabilities>()
                                                                                           : dianTrabajador.devengados.incapacidades);
                                                    dianTrabajador.devengados.incapacidades = disabilities;
                                                    break;
                                                case "licenciamp":
                                                    List<Licenses> licenses1 = new List<Licenses>();
                                                    licenses1 = CreateListFromTable<Licenses>(ds.Tables[0]);

                                                    foreach (var item in licenses1)
                                                    {
                                                        item.tipoLicencia = 1; // 1 = Maternity or Paternity
                                                    }

                                                    dianTrabajador.devengados.licencias = (dianTrabajador.devengados.licencias == null
                                                                                           ? new List<Licenses>()
                                                                                           : dianTrabajador.devengados.licencias);
                                                    dianTrabajador.devengados.licencias = licenses1;
                                                    break;
                                                case "licenciar":
                                                    List<Licenses> licenses2 = new List<Licenses>();
                                                    licenses2 = CreateListFromTable<Licenses>(ds.Tables[0]);

                                                    foreach (var item in licenses2)
                                                    {
                                                        item.tipoLicencia = 2; // 2 = Paid
                                                    }

                                                    dianTrabajador.devengados.licencias = (dianTrabajador.devengados.licencias == null
                                                                                           ? new List<Licenses>()
                                                                                           : dianTrabajador.devengados.licencias);
                                                    dianTrabajador.devengados.licencias = licenses2;
                                                    break;
                                                case "licencianr":
                                                    Licenses licenses3 = new Licenses();
                                                    licenses3.tipoLicencia = 3; // 3 = Unpaid
                                                    licenses3.Pago = 0.00M;
                                                    licenses3.PagoCantidad = int.Parse(ds.Tables[0].Rows[0]["CantidadCantidad"].ToString());
                                                    dianTrabajador.devengados.licencias = (dianTrabajador.devengados.licencias == null
                                                                                           ? new List<Licenses>()
                                                                                           : dianTrabajador.devengados.licencias);
                                                    dianTrabajador.devengados.licencias.Add(licenses3);
                                                    break;
                                                case "bonificacion":
                                                    if (ds.Tables[0].Columns.Contains("BonificacionS"))
                                                    {
                                                        if (ds.Tables[0].Rows[0]["BonificacionS"].ToString().Length > 0)
                                                        {
                                                            Bonus bonus = new Bonus();
                                                            bonus.esSalarial = true;
                                                            bonus.valor = decimal.Parse(ds.Tables[0].Rows[0]["BonificacionS"].ToString());
                                                            bonus.valorDescripcion = ds.Tables[0].Rows[0]["BonificacionSDescripcion"].ToString();
                                                            dianTrabajador.devengados.bonificacion = (dianTrabajador.devengados.bonificacion == null
                                                                                                    ? new List<Bonus>()
                                                                                                    : dianTrabajador.devengados.bonificacion);
                                                            dianTrabajador.devengados.bonificacion.Add(bonus);
                                                        }
                                                    }

                                                    if (ds.Tables[0].Columns.Contains("BonificacionNS"))
                                                    {
                                                        if (ds.Tables[0].Rows[0]["BonificacionNS"].ToString().Length > 0)
                                                        {
                                                            Bonus bonus = new Bonus();
                                                            bonus.esSalarial = false;
                                                            bonus.valor = decimal.Parse(ds.Tables[0].Rows[0]["BonificacionNS"].ToString());
                                                            bonus.valorDescripcion = ds.Tables[0].Rows[0]["BonificacionNSDescripcion"].ToString();
                                                            dianTrabajador.devengados.bonificacion = (dianTrabajador.devengados.bonificacion == null
                                                                                                    ? new List<Bonus>()
                                                                                                    : dianTrabajador.devengados.bonificacion);
                                                            dianTrabajador.devengados.bonificacion.Add(bonus);
                                                        }
                                                    }
                                                    break;
                                                case "auxilio":
                                                    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                                                    {
                                                        foreach (DataRow drAuxilios in ds.Tables[0].Rows)
                                                        {
                                                            Attendances attendances = new Attendances();
                                                            dianTrabajador.devengados.auxilios = (dianTrabajador.devengados.auxilios == null
                                                                                           ? new List<Attendances>()
                                                                                           : dianTrabajador.devengados.auxilios);


                                                            if (ds.Tables[0].Columns.Contains("AuxilioS"))
                                                            {
                                                                if (drAuxilios["AuxilioS"].ToString().Length > 0)
                                                                {
                                                                    attendances = new Attendances();
                                                                    attendances.esSalarial = true;
                                                                    attendances.AuxilioS = decimal.Parse(drAuxilios["AuxilioS"].ToString());
                                                                    attendances.AuxilioSDescripcion = drAuxilios["AuxilioSDescripcion"].ToString();
                                                                    dianTrabajador.devengados.auxilios.Add(attendances);
                                                                }
                                                            }

                                                            if (ds.Tables[0].Columns.Contains("AuxilioNS"))
                                                            {
                                                                if (drAuxilios["AuxilioNS"].ToString().Length > 0)
                                                                {
                                                                    attendances = new Attendances();
                                                                    attendances.esSalarial = true;
                                                                    attendances.AuxilioS = decimal.Parse(drAuxilios["AuxilioNS"].ToString());
                                                                    attendances.AuxilioSDescripcion = drAuxilios["AuxilioNSDescripcion"].ToString();
                                                                    dianTrabajador.devengados.auxilios.Add(attendances);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case "huelgalegal":
                                                    List<Strikes> strikes = new List<Strikes>();
                                                    strikes = CreateListFromTable<Strikes>(ds.Tables[0]);
                                                    dianTrabajador.devengados.huelgas = (dianTrabajador.devengados.huelgas == null
                                                                                         ? new List<Strikes>()
                                                                                         : dianTrabajador.devengados.huelgas);
                                                    dianTrabajador.devengados.huelgas = strikes;
                                                    break;
                                                case "otroconcepto":
                                                    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                                                    {
                                                        foreach (DataRow drotherConcepts in ds.Tables[0].Rows)
                                                        {
                                                            if (ds.Tables[0].Rows[0][1].ToString().Trim().Length > 0)
                                                            {
                                                                OtherConcepts otherConcepts = new OtherConcepts();

                                                                if (ds.Tables[0].Columns.Contains("ConceptoS"))
                                                                {
                                                                    otherConcepts.esParteSalario = true;
                                                                    otherConcepts.valor = decimal.Parse(drotherConcepts["ConceptoS"].ToString());
                                                                    otherConcepts.valorDescripcionConcepto = drotherConcepts["ConceptoSDescripcion"].ToString();
                                                                }

                                                                if (ds.Tables[0].Columns.Contains("ConceptoNS"))
                                                                {
                                                                    otherConcepts.esParteSalario = false;
                                                                    otherConcepts.valor = decimal.Parse(drotherConcepts["ConceptoNS"].ToString());
                                                                    otherConcepts.valorDescripcionConcepto = drotherConcepts["ConceptoNSDescripcion"].ToString();
                                                                }

                                                                if (otherConcepts.valorDescripcionConcepto.Length > 0)
                                                                {
                                                                    dianTrabajador.devengados.otrosConceptos = (dianTrabajador.devengados.otrosConceptos == null
                                                                                                           ? new List<OtherConcepts>()
                                                                                                           : dianTrabajador.devengados.otrosConceptos);
                                                                    dianTrabajador.devengados.otrosConceptos.Add(otherConcepts);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case "compensacion":
                                                    Compensations compensations = new Compensations();
                                                    compensations.tipoCompensacion = (ds.Tables[0].Columns.Contains("CompensacionO") ? 1 : 2);
                                                    compensations.valor = decimal.Parse(ds.Tables[0].Rows[0][1].ToString());
                                                    dianTrabajador.devengados.compensaciones = (dianTrabajador.devengados.compensaciones == null
                                                                                           ? new List<Compensations>()
                                                                                           : dianTrabajador.devengados.compensaciones);
                                                    dianTrabajador.devengados.compensaciones.Add(compensations);
                                                    break;
                                                case "bonoepctv":
                                                    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                                                    {
                                                        foreach (DataRow drEPCTVBonus in ds.Tables[0].Rows)
                                                        {
                                                            EPCTVBonds ePCTVBonds = new EPCTVBonds();
                                                            dianTrabajador.devengados.bonosEPCTV = (dianTrabajador.devengados.bonosEPCTV == null
                                                                                                    ? new List<EPCTVBonds>()
                                                                                                    : dianTrabajador.devengados.bonosEPCTV);


                                                            if (ds.Tables[0].Columns.Contains("PagoS"))
                                                            {
                                                                if (drEPCTVBonus["PagoS"].ToString().Length > 0)
                                                                {
                                                                    ePCTVBonds = new EPCTVBonds();
                                                                    ePCTVBonds.esParteSalario = true;
                                                                    ePCTVBonds.esPagoAlimentacion = false;
                                                                    ePCTVBonds.valor = decimal.Parse(drEPCTVBonus["PagoS"].ToString());
                                                                    ePCTVBonds.valorDescripcion = drEPCTVBonus["PagoSDescripcion"].ToString();
                                                                    dianTrabajador.devengados.bonosEPCTV.Add(ePCTVBonds);
                                                                }
                                                            }

                                                            if (ds.Tables[0].Columns.Contains("PagoNS"))
                                                            {
                                                                if (drEPCTVBonus["PagoNS"].ToString().Length > 0)
                                                                {
                                                                    ePCTVBonds = new EPCTVBonds();
                                                                    ePCTVBonds.esParteSalario = false;
                                                                    ePCTVBonds.esPagoAlimentacion = false;
                                                                    ePCTVBonds.valor = decimal.Parse(drEPCTVBonus["PagoNS"].ToString());
                                                                    ePCTVBonds.valorDescripcion = drEPCTVBonus["PagoNSDescripcion"].ToString();
                                                                    dianTrabajador.devengados.bonosEPCTV.Add(ePCTVBonds);
                                                                }
                                                            }

                                                            if (ds.Tables[0].Columns.Contains("PagoAlimentacionS"))
                                                            {
                                                                if (drEPCTVBonus["PagoAlimentacionS"].ToString().Length > 0)
                                                                {
                                                                    ePCTVBonds = new EPCTVBonds();
                                                                    ePCTVBonds.esPagoAlimentacion = true;
                                                                    ePCTVBonds.esParteSalario = false;
                                                                    ePCTVBonds.valor = decimal.Parse(drEPCTVBonus["PagoAlimentacionS"].ToString());
                                                                    ePCTVBonds.valorDescripcion = drEPCTVBonus["PagoAlimentacionSDescripcion"].ToString();
                                                                    dianTrabajador.devengados.bonosEPCTV.Add(ePCTVBonds);
                                                                }
                                                            }

                                                            if (ds.Tables[0].Columns.Contains("PagoAlimentacionNS"))
                                                            {
                                                                if (drEPCTVBonus["PagoAlimentacionNS"].ToString().Length > 0)
                                                                {
                                                                    ePCTVBonds = new EPCTVBonds();
                                                                    ePCTVBonds.esPagoAlimentacion = true;
                                                                    ePCTVBonds.esParteSalario = false;
                                                                    ePCTVBonds.valor = decimal.Parse(drEPCTVBonus["PagoAlimentacionNS"].ToString());
                                                                    ePCTVBonds.valorDescripcion = drEPCTVBonus["PagoAlimentacionNSDescripcion"].ToString();
                                                                    dianTrabajador.devengados.bonosEPCTV.Add(ePCTVBonds);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break;
                                                case "comisiones":
                                                    List<Commissions> commissions = new List<Commissions>();
                                                    commissions = CreateListFromTable<Commissions>(ds.Tables[0]);
                                                    dianTrabajador.devengados.comisiones = (dianTrabajador.devengados.comisiones == null
                                                                                            ? new List<Commissions>()
                                                                                            : dianTrabajador.devengados.comisiones);
                                                    dianTrabajador.devengados.comisiones = commissions;
                                                    break;
                                                case "pagosterceros":
                                                    List<ThirdPartyPayments> thirdPartyPayments = new List<ThirdPartyPayments>();
                                                    thirdPartyPayments = CreateListFromTable<ThirdPartyPayments>(ds.Tables[0]);

                                                    if (dr["tipo"].ToString() == "percepcion")
                                                    {
                                                        dianTrabajador.devengados.pagosTerceros = (dianTrabajador.devengados.pagosTerceros == null
                                                                                                   ? new List<ThirdPartyPayments>()
                                                                                                   : dianTrabajador.devengados.pagosTerceros);
                                                        dianTrabajador.devengados.pagosTerceros = thirdPartyPayments;
                                                    }
                                                    else
                                                    {
                                                        dianTrabajador.deducciones.pagosTerceros = (dianTrabajador.deducciones.pagosTerceros == null
                                                                                                    ? new List<ThirdPartyPayments>()
                                                                                                    : dianTrabajador.deducciones.pagosTerceros);
                                                        dianTrabajador.deducciones.pagosTerceros = thirdPartyPayments;
                                                    }
                                                    break;
                                                case "anticipos":
                                                    List<Advances> advances = new List<Advances>();
                                                    advances = CreateListFromTable<Advances>(ds.Tables[0]);
                                                    if (dr["tipo"].ToString() == "percepcion")
                                                    {
                                                        dianTrabajador.devengados.anticipos = (dianTrabajador.devengados.anticipos == null
                                                                                               ? new List<Advances>()
                                                                                               : dianTrabajador.devengados.anticipos);
                                                        dianTrabajador.devengados.anticipos = advances;
                                                    }
                                                    else
                                                    {
                                                        dianTrabajador.deducciones.anticipos = (dianTrabajador.deducciones.anticipos == null
                                                                                                ? new List<Advances>()
                                                                                                : dianTrabajador.deducciones.anticipos);
                                                        dianTrabajador.deducciones.anticipos = advances;
                                                    }
                                                    break;
                                                case "devengados":
                                                    Perceptions accrued = new Perceptions();
                                                    accrued = CreateSingleListFromTable<Perceptions>(ds.Tables[0]);
                                                    dianTrabajador.devengados = accrued;
                                                    break;
                                                case "salud":
                                                    Health health = new Health();
                                                    health = CreateSingleListFromTable<Health>(ds.Tables[0]);
                                                    dianTrabajador.deducciones.salud = health;
                                                    break;
                                                case "fondopension":
                                                    PensionFund pensionFund = new PensionFund();
                                                    pensionFund = CreateSingleListFromTable<PensionFund>(ds.Tables[0]);
                                                    dianTrabajador.deducciones.fondoPension = pensionFund;
                                                    break;
                                                case "fondosp":
                                                    PensionfundSP pensionfundSP = new PensionfundSP();
                                                    pensionfundSP = CreateSingleListFromTable<PensionfundSP>(ds.Tables[0]);
                                                    dianTrabajador.deducciones.fondoPensionSP = pensionfundSP;
                                                    break;
                                                case "sindicato":
                                                    List<Unions> unions = new List<Unions>();
                                                    unions = CreateListFromTable<Unions>(ds.Tables[0]);
                                                    dianTrabajador.deducciones.sindicatos = (dianTrabajador.deducciones.sindicatos == null
                                                                                            ? new List<Unions>()
                                                                                            : dianTrabajador.deducciones.sindicatos);
                                                    dianTrabajador.deducciones.sindicatos = unions;
                                                    break;
                                                case "sancion":
                                                    Sanctions sanctions = new Sanctions();
                                                    sanctions.tipoSancion = (ds.Tables[0].Columns.Contains("SancionPriv") ? true : false);
                                                    sanctions.valorDeduccion = decimal.Parse(ds.Tables[0].Rows[0][1].ToString());
                                                    dianTrabajador.deducciones.sanciones = (dianTrabajador.deducciones.sanciones == null
                                                                                           ? new List<Sanctions>()
                                                                                           : dianTrabajador.deducciones.sanciones);
                                                    dianTrabajador.deducciones.sanciones.Add(sanctions);
                                                    break;
                                                case "libranza":
                                                    List<Orders> orders = new List<Orders>();
                                                    orders = CreateListFromTable<Orders>(ds.Tables[0]);
                                                    dianTrabajador.deducciones.libranzas = (dianTrabajador.deducciones.libranzas == null
                                                                                            ? new List<Orders>()
                                                                                            : dianTrabajador.deducciones.libranzas);
                                                    dianTrabajador.deducciones.libranzas = orders;
                                                    break;
                                                case "otrasdeducciones":
                                                    DataSet filteredDeductions = new DataSet();
                                                    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                                                    {
                                                        filteredDeductions.Merge(ds.Tables[0].Select("OtraDeduccion > 0", ""));
                                                        if (filteredDeductions != null && filteredDeductions.Tables != null && filteredDeductions.Tables.Count > 0)
                                                        {
                                                            List<OtherDiscounts> otherDiscounts = new List<OtherDiscounts>();
                                                            otherDiscounts = CreateListFromTable<OtherDiscounts>(filteredDeductions.Tables[0]);
                                                            dianTrabajador.deducciones.otrosDescuentos = (dianTrabajador.deducciones.otrosDescuentos == null
                                                                                                         ? new List<OtherDiscounts>()
                                                                                                         : dianTrabajador.deducciones.otrosDescuentos);
                                                            dianTrabajador.deducciones.otrosDescuentos = otherDiscounts;
                                                        }
                                                    }
                                                    break;
                                                case "deducciones":
                                                    Deductions deductions = new Deductions();
                                                    deductions = CreateSingleListFromTable<Deductions>(ds.Tables[0]);
                                                    dianTrabajador.deducciones = deductions;
                                                    break;
                                            }
                                        }
                                    }
                                }

                                dianTrabajador.employeeId = employeeId;

                                // Get DIAN Correlative
                                if (bTransmitJsonToWS)
                                {
                                    DataSet dsDianSequence = _catalogosDIAN.obtenCorrelativoDian(company, employeeId);
                                    if (dsDianSequence != null &&
                                        dsDianSequence.Tables != null &&
                                        dsDianSequence.Tables.Count > 0)
                                    {
                                        dianTrabajador.numeroSecuenciaXML.Prefijo = (dsDianSequence.Tables[0].Columns.Contains("dian_prefijo")
                                                                                     ? dsDianSequence.Tables[0].Rows[0]["dian_prefijo"].ToString()
                                                                                     : "");
                                        dianTrabajador.numeroSecuenciaXML.Consecutivo = (dsDianSequence.Tables[0].Columns.Contains("dian_consecutivo")
                                                                                         ? dsDianSequence.Tables[0].Rows[0]["dian_consecutivo"].ToString()
                                                                                         : "");
                                        dianTrabajador.numeroSecuenciaXML.Numero = (dsDianSequence.Tables[0].Columns.Contains("dian_numero")
                                                                                    ? dsDianSequence.Tables[0].Rows[0]["dian_numero"].ToString()
                                                                                    : "");
                                    }
                                }
                                else
                                {
                                    dianTrabajador.numeroSecuenciaXML.Consecutivo = (emplCounter + 1).ToString();
                                }

                                // Add Counter
                                emplCounter++;

                                // Create/Add Employee Node
                                jsonFile.trabajador = (jsonFile.trabajador == null
                                                         ? new List<IEmployee>()
                                                         : jsonFile.trabajador);

                                jsonFile.trabajador.Add(dianTrabajador);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    #endregion

                    // Write Data
                    if (!bTransmitJsonToWS)
                    {
                        DataSet configuration = _catalogoAdicional.obtenConfiguracionCompania(company);

                        //function to get value of parameters
                        Func<string, string> getParameterStringValue = (string id_parametro) =>
                        {
                            var parametro = configuration.Tables[0].AsEnumerable().Where(t => t.Field<string>(ColIdParametro) == id_parametro).ToArray();
                            if (parametro != null && parametro.Length > 0)
                            {
                                return parametro[0]?.Field<string>(ColAlfanumerico);
                            }
                            return string.Empty;
                        };

                        // Write Json File
                        jsonRequest = jsonFile.WriteJsonRequest(rutaArchivosSalida, company, year, month);
                        var jsonPath = jsonRequest.Replace(rutaGenerador, string.Empty);

                        // Set Message to Display
                        var message = $"Generación Concluida - Archivo DIAN {Environment.NewLine}" +
                                      $"Se procesaron {emplCounter.ToString()} empleados correctamente." + Environment.NewLine + Environment.NewLine +
                                      $"Tiempo del Proceso: {(DateTime.Now - procStartTime).ToString()}" + Environment.NewLine + Environment.NewLine +
                                      $"Ruta Archivo: {jsonPath}";

                        FrmPrevisualizacionJson FrmPrevisualizacionJson = new FrmPrevisualizacionJson(rutaGenerador, rutaArchivosSalida, jsonFile, jsonRequest, company, year, month, message);

                        if (this.InvokeRequired)
                        {
                            this.Invoke(new Action(delegate
                            {
                                FrmPrevisualizacionJson.ShowDialog(this);
                            }));
                        }
                    }
                    else
                    {
                        // Transmit File
                        TransmitJsonFileToWS(rutaGenerador, rutaArchivosSalida, company, year, month, jsonFile);
                    }
                }
                else
                {
                    MessageBox.Show("No se encontraron datos o configuración para generar el Archivo DIAN", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Se generó un error durante el proceso de Generación del Archivo DIAN" + Environment.NewLine + ex.Message, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Disable Parameter
            NativeMethods.SetThreadExecutionState(fPreviousExecutionState);

            // Enable the screen saver
            if (protectorPantallaActivo == 1)
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENSAVEACTIVE, 1, ref nullVar, NativeMethods.SPIF_SENDWININICHANGE);
        }
        
        public static string WriteJsonResponse(string rutaArchivosSalida, string company, string year, string month, AddPayrollResponse jsonFile)
        {
            try
            {
                // Set Path
                var jsonFilename = Path.Combine(rutaArchivosSalida, $"DIAN_COL_{company}_{year}-{month}_{DateTime.Now.ToString(DateTimeFormat)}_Response.json");
                var htmlFilename = Path.Combine(rutaArchivosSalida, "temp", $"DIAN_COL_{company}_{year}-{month}_{DateTime.Now.ToString(DateTimeFormat)}_Response.html");

                // Files Content
                string jsonOutput = JsonConvert.SerializeObject(jsonFile);
                string jsonIndent = JsonConvert.SerializeObject(JsonConvert.DeserializeObject<object>(jsonOutput), Formatting.Indented);
                string htmlOutput = String.Format("<html><body><pre><code>{0}</code></pre></body></html>", jsonIndent);

                // Write Files
                File.WriteAllText(jsonFilename, jsonIndent);
                File.WriteAllText(htmlFilename, htmlOutput);

                return htmlFilename;
            }
            catch
            {
                return string.Empty;
            }
        }
        
        public static string WriteJsonFull(string rutaArchivosSalida, string company, string year, string month, JsonDianFull jsonFile)
        {
            try
            {
                // Set Path
                var jsonFilename = Path.Combine(rutaArchivosSalida, $"DIAN_COL_{company}_{year}-{month}_{DateTime.Now.ToString(DateTimeFormat)}_Complete.json");
                var htmlFilename = Path.Combine(rutaArchivosSalida, $"DIAN_COL_{company}_{year}-{month}_{DateTime.Now.ToString(DateTimeFormat)}_Complete.html");

                // Files Content
                string jsonOutput = JsonConvert.SerializeObject(jsonFile);
                string jsonIndent = JsonConvert.SerializeObject(JsonConvert.DeserializeObject<object>(jsonOutput), Formatting.Indented);
                string htmlOutput = String.Format("<html><body><pre><code>{0}</code></pre></body></html>", jsonIndent);

                // Write Files
                File.WriteAllText(jsonFilename, jsonIndent);
                File.WriteAllText(htmlFilename.Replace(".json", ".html"), htmlOutput);

                return htmlFilename;
            }
            catch
            {
                return string.Empty;
            }
        }
        
        private static JsonDianFull BuildFullResponse(JsonDian jsonReqFile, AddPayrollResponse jsonRespFile)
        {
            try
            {
                // Build Master File
                JsonDianFull jsonDianFull = new JsonDianFull()
                {
                    respuestaDian = new AddGlobalPayrollResponse()
                    {
                        message = jsonRespFile.message,
                        errores = jsonRespFile.errores
                    },
                    periodo = jsonReqFile.periodo,
                    informacionGeneral = jsonReqFile.informacionGeneral,
                    empleador = jsonReqFile.empleador,
                    trabajador = new List<IEmployee>()
                };

                // Add Employees
                for (int nIndex = 0; nIndex < jsonReqFile.trabajador.Count; nIndex++)
                {
                    EmployeeFull emplFull = new EmployeeFull()
                    {
                        informacionPredecesor = jsonReqFile.trabajador[nIndex].informacionPredecesor,
                        tipoTrabajador = jsonReqFile.trabajador[nIndex].tipoTrabajador,
                        subtipoTrabajador = jsonReqFile.trabajador[nIndex].subtipoTrabajador,
                        altoRiesgoPension = jsonReqFile.trabajador[nIndex].altoRiesgoPension,
                        tipoDocumento = jsonReqFile.trabajador[nIndex].tipoDocumento,
                        numeroDocumento = jsonReqFile.trabajador[nIndex].numeroDocumento,
                        primerApellido = jsonReqFile.trabajador[nIndex].primerApellido,
                        segundoApellido = jsonReqFile.trabajador[nIndex].segundoApellido,
                        primerNombre = jsonReqFile.trabajador[nIndex].primerNombre,
                        otrosNombres = jsonReqFile.trabajador[nIndex].otrosNombres,
                        lugarTrabajoPais = jsonReqFile.trabajador[nIndex].lugarTrabajoPais,
                        lugarTrabajoDepartamentoEstado = jsonReqFile.trabajador[nIndex].lugarTrabajoDepartamentoEstado,
                        lugarTrabajoMunicipioCiudad = jsonReqFile.trabajador[nIndex].lugarTrabajoMunicipioCiudad,
                        lugarTrabajoDireccion = jsonReqFile.trabajador[nIndex].lugarTrabajoDireccion,
                        salarioIntegral = jsonReqFile.trabajador[nIndex].salarioIntegral,
                        tipoContrato = jsonReqFile.trabajador[nIndex].tipoContrato,
                        sueldo = jsonReqFile.trabajador[nIndex].sueldo,
                        fechaIngreso = jsonReqFile.trabajador[nIndex].fechaIngreso,
                        fechaRetiro = jsonReqFile.trabajador[nIndex].fechaRetiro,
                        tiempoLaborado = jsonReqFile.trabajador[nIndex].tiempoLaborado,
                        emailTrabajador = jsonReqFile.trabajador[nIndex].emailTrabajador,
                        comprobanteTotal = jsonReqFile.trabajador[nIndex].comprobanteTotal,
                        tipoMoneda = jsonReqFile.trabajador[nIndex].tipoMoneda,
                        trm = jsonReqFile.trabajador[nIndex].trm,
                        notas = jsonReqFile.trabajador[nIndex].notas,
                        numeroSecuenciaXML = jsonReqFile.trabajador[nIndex].numeroSecuenciaXML,
                        lugarGeneracionXML = jsonReqFile.trabajador[nIndex].lugarGeneracionXML,
                        pago = jsonReqFile.trabajador[nIndex].pago,
                        fechasPago = jsonReqFile.trabajador[nIndex].fechasPago,
                        devengados = jsonReqFile.trabajador[nIndex].devengados,
                        deducciones = jsonReqFile.trabajador[nIndex].deducciones,
                        redondeo = jsonReqFile.trabajador[nIndex].redondeo,
                        devengadosTotal = jsonReqFile.trabajador[nIndex].devengadosTotal,
                        deduccionesTotal = jsonReqFile.trabajador[nIndex].deduccionesTotal,
                        respuestaDian = jsonRespFile.notificaciones[nIndex],
                        employeeId = jsonReqFile.trabajador[nIndex].employeeId
                    };
                    jsonDianFull.trabajador.Add(emplFull);
                }

                // Default
                return jsonDianFull;
            }
            catch
            {
                return null;
            }
        }
        
        public void TransmitJsonFileToWS(string rutaGenerador, string rutaArchivosSalida, string szCompany, string szYear, string szMonth, JsonDian jsonFile)
        {
            // Local Vars
            bool auth = false;

            // Get Time for Authentication Token
            int minutes = DateTime.Compare(DateTime.UtcNow, dateTimeTokenIsValid);

            try
            {
                // Validate if Token is Alive
                if (minutes > 0)
                {
                    // Get Authentication Token From CENET API
                    auth = GetAuthenticationToken(szCompany);
                }
                else
                {
                    auth = true;
                }

                // Check Authentication
                if (auth)
                {
                    // Transmit File
                    AddPayrollResponse jsonRespFile;
                    bool transmit = TransmitJSON(szCompany, jsonFile, out jsonRespFile);

                    // Check Results
                    if (transmit)
                    {
                        // Build Master File including Response
                        JsonDianFull jsonDianMasterFile = BuildFullResponse(jsonFile, jsonRespFile);

                        // Write Full Response
                        var fullResponse = WriteJsonFull(rutaArchivosSalida, szCompany, szYear, szMonth, jsonDianMasterFile);

                        string message = "El mensaje fue transmitido a CENET" + Environment.NewLine + Environment.NewLine +
                                        "Ruta Archivo: " + fullResponse + Environment.NewLine + Environment.NewLine +
                                        "Presione OK para visualizar los archivos" + Environment.NewLine + Environment.NewLine;

                        FrmPrevisualizacionJson FrmPrevisualizacionJson = new FrmPrevisualizacionJson(rutaGenerador, rutaArchivosSalida, jsonDianMasterFile, fullResponse, szCompany, szYear, szMonth, message, FrmPrevisualizacionJson.VisualizationType.Response);

                        if (this.InvokeRequired)
                        {
                            this.Invoke(new Action(delegate
                            {
                                FrmPrevisualizacionJson.ShowDialog(this);
                            }));
                        }
                    }
                    else
                    {
                        // Display Message
                        MessageBox.Show("Error de transmisión - CENET" + Environment.NewLine +
                                        "Error CENET: " + szResponseMsg + Environment.NewLine + Environment.NewLine,
                                        "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show($"Error de autenticación - CENET {Environment.NewLine}{szResponseMsg}{Environment.NewLine}{Environment.NewLine}",
                                    "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error {Environment.NewLine}{ex.Message}{Environment.NewLine}{Environment.NewLine}",
                                "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Set Var
            bTransmitJsonToWS = false;
        }
        
        private bool GetAuthenticationToken(string szCompany)
        {
            try
            {
                // Create API Call
                RestApiClient rClient = new RestApiClient();
                LoginResponse loginResponse = new LoginResponse();

                if (szCompany == string.Empty)
                {
                    szAccessToken = "";
                    szResponseMsg = "URL, usuario y/o contraseña no validos.";
                    return false;
                }

                DataSet configuration = _catalogoAdicional.obtenConfiguracionCompania(szCompany);

                if (configuration is null || configuration.Tables.Count == 0 || configuration.Tables[0].Rows.Count == 0)
                {
                    szAccessToken = "";
                    szResponseMsg = "URL, usuario y/o contraseña no validos.";
                    return false;
                }

                // Function to get value of parameters
                Func<string, string> getParameterStringValue = (string id_parametro) =>
                {
                    var parametro = configuration.Tables[0].AsEnumerable().Where(t => t.Field<string>(ColIdParametro) == id_parametro).ToArray();
                    if (parametro != null && parametro.Length > 0)
                    {
                        return parametro[0]?.Field<string>(ColAlfanumerico);
                    }
                    return string.Empty;
                };

                // Set API Parameters
                rClient.endPoint = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                rClient.userName = getParameterStringValue(ConfigurationTypes.ws_user.ToString());
                rClient.userPwd = new NetworkCredential(string.Empty, getParameterStringValue(ConfigurationTypes.ws_password.ToString())).SecurePassword;

                loginResponse = rClient.LoginRequest();

                // Get Response
                if (loginResponse != null)
                {
                    if (loginResponse.type.Equals("OK"))
                    {
                        dateTimeTokenIsValid = DateTime.UtcNow.AddMinutes(55);
                        szAccessToken = loginResponse.content.jwt;
                        return true;
                    }
                    else
                    {
                        szAccessToken = "";
                        szResponseMsg = loginResponse.validationMessage;
                        return false;
                    }
                }
                else
                {
                    szAccessToken = "";
                    szResponseMsg = "URL, usuario y/o contraseña no validos.";
                    return false;
                }
            }
            catch (Exception ex)
            {
                szAccessToken = "";
                szResponseMsg = "Exception: " + ex.Message;
                return false;
            }
        }
        
        private bool TransmitJSON(string companyId, JsonDian jsonFile, out AddPayrollResponse addPayrollResponse)
        {
            // Create API Call
            RestApiClient rClient = new RestApiClient();
            addPayrollResponse = new AddPayrollResponse();

            // Get Config
            DataSet dConfig = _catalogoAdicional.obtenConfiguracionCompania(companyId);
            if (dConfig != null && dConfig.Tables[0].Rows.Count > 0)
            {
                Func<string, string> getParameterStringValue = (string id_parametro) =>
                {
                    var parametro = dConfig.Tables[0].AsEnumerable().Where(t => t.Field<string>(ColIdParametro) == id_parametro).ToArray();
                    if (parametro != null && parametro.Length > 0)
                    {
                        return parametro[0]?.Field<string>(ColAlfanumerico);
                    }
                    return string.Empty;
                };

                rClient.endPoint = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                rClient.userName = getParameterStringValue(ConfigurationTypes.ws_user.ToString());
                rClient.userPwd = new NetworkCredential(string.Empty, getParameterStringValue(ConfigurationTypes.ws_password.ToString())).SecurePassword;
            }
            else
            {
                rClient.endPoint = UtileriasConfig.GetEndpointAddress();
                rClient.userName = Properties.AppSettings.Default.WSUsrID;
                rClient.userPwd = new NetworkCredential(string.Empty, Properties.AppSettings.Default.WSUsrPwd).SecurePassword;
            }

            // Set API Body
            rClient.json = JsonConvert.SerializeObject(jsonFile);

            // Call CENET WS
            addPayrollResponse = rClient.AddPayrollRequest(rClient.userName, szAccessToken);

            // Get Response
            if (addPayrollResponse != null)
            {
                //Add payroll response and error messages if exist
                if (addPayrollResponse.notificaciones != null && addPayrollResponse.notificaciones.Count > 0)
                {
                    //loop every item on threads
                    Parallel.ForEach(addPayrollResponse.notificaciones, n =>
                    {
                        try
                        {
                            //run async the ActualizaBitacoraCorrelativosDian method and execute a callback inline function to insert Validation Results if is needed
                            Task.Factory.FromAsync(_catalogosDIAN.ActualizaBitacoraCorrelativosDian(compania, n.numeroDocumento, n.documentoID, n.estadoAccion), asyncResult =>
                            {
                                var r = (Task<bool>)asyncResult;
                                bool isUpdated = r.Result;

                                if (isUpdated && n.resultadoValidacion != null && n.resultadoValidacion.Count > 0)
                                {
                                    foreach (ResultadoValidacion rv in n.resultadoValidacion)
                                    {
                                        //insert Validation Result (Error)
                                        _catalogosDIAN.AltaResultadoValidacion(n.numeroDocumento, rv.errorCode, rv.errorMessage);
                                    }
                                }
                            });
                        }
                        catch
                        {
                            // Intentionally left empty: errors updating bitacora are non-critical
                        }
                    });
                }

                // Default
                return true;
            }
            else
            {
                szResponseMsg = "No se obtuvo respuesta de CENET";
                return false;
            }
        }

        public static T CreateSingleListFromTable<T>(DataTable dt) where T : new()
        {
            T lst = new T();

            foreach (DataRow r in dt.Rows)
            {
                lst = CreateItemFromRow<T>(r);
            }

            return lst;
        }

        public static List<T> CreateListFromTable<T>(DataTable dt) where T : new()
        {
            List<T> lst = new List<T>();

            foreach (DataRow r in dt.Rows)
            {
                lst.Add(CreateItemFromRow<T>(r));
            }

            return lst;
        }
        
        public static T CreateItemFromRow<T>(DataRow row) where T : new()
        {
            T item = new T();

            SetItemFromRow(item, row);

            return item;
        }
        
        public static void SetItemFromRow<T>(T item, DataRow row) where T : new()
        {
            foreach (DataColumn c in row.Table.Columns)
            {
                PropertyInfo p = item.GetType().GetProperty(c.ColumnName);

                if (p != null && row[c] != DBNull.Value)
                {
                    p.SetValue(item, row[c], null);
                }
            }
        }
        
        public DataSet AddColumns(ref DataSet ds, string category)
        {
            DataRow drReporte;
            DataTable dt = new DataTable();
            ds = new DataSet();

            Dictionary<string, string> lstPayrollInformation = new Dictionary<string, string>()
            {
                { "tipoNomina","" },
                { "fechaInicioLiquidación","" },
            };

            Dictionary<string, string> lstPayrollAdjustments = new Dictionary<string, string>()
            {
                { "numeroPredecesor","" },
                { "CUNEPredecesor","" },
                { "fechaGeneracionPredecesor","" },
            };

            if (category == "InformacionNomina")
            {
                foreach (KeyValuePair<string, string> entry in lstPayrollInformation)
                {
                    DataColumn dcColumnName = new DataColumn(entry.Key);
                    dt.Columns.Add(dcColumnName);
                }
                drReporte = dt.NewRow();
                foreach (DataColumn column in dt.Columns)
                {
                    drReporte[column.ColumnName] = "";

                }
                dt.Rows.Add(drReporte);

            }
            else if (category == "AjusteNomina")
            {
                foreach (KeyValuePair<string, string> entry in lstPayrollAdjustments)
                {
                    DataColumn dcColumnName = new DataColumn(entry.Key);
                    dt.Columns.Add(dcColumnName);
                }
                drReporte = dt.NewRow();
                foreach (DataColumn column in dt.Columns)
                {
                    drReporte[column.ColumnName] = "";
                }
                dt.Rows.Add(drReporte);
            }

            ds.Tables.Add(dt);

            return ds;
        }
        
        public string ValidateDataType(string dato, DataColumn dc)
        {
            string szResult;
            szResult = dato;

            if (!string.IsNullOrEmpty(dato))
            {
                if (dc.DataType == typeof(DateTime) || dc.ColumnName.Contains("fecha"))
                {
                    string[] format = { "yyyyMMdd" };
                    DateTime date;

                    if (DateTime.TryParseExact(dato,
                                               format,
                                               System.Globalization.CultureInfo.InvariantCulture,
                                               System.Globalization.DateTimeStyles.None,
                                               out date))
                        szResult = date.ToString("yyyy-MM-dd");
                }
                else if (dc.DataType == typeof(String))
                {
                    szResult = dato.Replace(",", "");
                }
            }

            return szResult;
        }

#endregion
    }
}
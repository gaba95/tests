﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("empleador", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Employer
    {
        public string razonSocial { get; set; }
        public string primerApellido { get; set; }
        public string segundoApellido { get; set; }
        public string primerNombre { get; set; }
        public string otrosNombres { get; set; }
        public string nit { get; set; }
        public int dv { get; set; }
        public string pais { get; set; }
        public string departamentoEstado { get; set; }
        public string municipioCiudad { get; set; }
        public string direccion { get; set; }
        public string email { get; set; }
        public string telefono { get; set; }
        public string codigoPostal { get; set; }
        public string codigoSucursal { get; set; }
        public string nombreSucursal { get; set; }
        public string tipoIdentificacion { get; set; }
    }
}

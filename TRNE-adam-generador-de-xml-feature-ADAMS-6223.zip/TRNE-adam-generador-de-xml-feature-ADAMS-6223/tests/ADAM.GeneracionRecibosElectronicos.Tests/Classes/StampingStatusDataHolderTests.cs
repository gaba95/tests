﻿using ADAM.Recibos.Utilerias.Enums;
using ADAM.GeneracionRecibosElectronicos.Clases;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes
{
    [TestClass]
    public class StampingStatusDataHolderTests
    {

        [TestMethod]
        public void Constructor_ShouldInitializeEntries_ForPeriodicaAndInteractiva()
        {
            var holder = new StampingStatusDataHolder();

            var periodic = holder.getInfo(ManejoNomina.periodica);
            var interactive = holder.getInfo(ManejoNomina.interactiva);

            Assert.IsNotNull(periodic, "Expected periodica entry to be initialized.");
            Assert.IsNotNull(interactive, "Expected interactiva entry to be initialized.");
        }

        [TestMethod]
        public void GetInfo_WhenKeyIsUnknown_ShouldThrowKeyNotFoundException()
        {
            var holder = new StampingStatusDataHolder();

            Assert.Throws<KeyNotFoundException>(() =>
            {
                holder.getInfo((ManejoNomina)999999);
            });
        }

        [TestMethod]
        public void ProcessedPeriodica_WhenPayrollTypeIsEmpty_ShouldReturnFalse()
        {
            var holder = new StampingStatusDataHolder();

            Assert.IsFalse(holder.processedPeriodica(), "Should be false when PayrollType is null/empty for periodica.");
        }

        [TestMethod]
        public void ProcessedInteractiva_WhenPayrollTypeIsEmpty_ShouldReturnFalse()
        {
            var holder = new StampingStatusDataHolder();

            Assert.IsFalse(holder.processedInteractiva(), "Should be false when PayrollType is null/empty for interactiva.");
        }

        [TestMethod]
        public void ProcessedPeriodica_WhenPayrollTypeIsAdded_ShouldReturnTrue()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollType(ManejoNomina.periodica, "P");

            Assert.IsTrue(holder.processedPeriodica(), "Should be true when PayrollType is set for periodica.");
        }

        [TestMethod]
        public void ProcessedInteractiva_WhenPayrollTypeIsAdded_ShouldReturnTrue()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollType(ManejoNomina.interactiva, "I");

            Assert.IsTrue(holder.processedInteractiva(), "Should be true when PayrollType is set for interactiva.");
        }

        [TestMethod]
        public void Reset_ShouldClearAllTrackedFields_ForBothNominas()
        {
            var holder = new StampingStatusDataHolder();

            holder.setCompany("RFC123");
            holder.setReceiptVersion("4.0");
            holder.addPayrollType(ManejoNomina.periodica, "P");
            holder.addPayrollClass(ManejoNomina.periodica, "C1");
            holder.addPeriods(ManejoNomina.periodica, "01");
            holder.addYear(ManejoNomina.periodica, "2026");

            holder.addPayrollType(ManejoNomina.interactiva, "I");
            holder.addPayrollClass(ManejoNomina.interactiva, "C2");
            holder.addPeriods(ManejoNomina.interactiva, "02");
            holder.addYear(ManejoNomina.interactiva, "2025");

            Assert.IsTrue(holder.processedPeriodica());
            Assert.IsTrue(holder.processedInteractiva());

            holder.reset();

            var periodic = holder.getInfo(ManejoNomina.periodica);
            var interactive = holder.getInfo(ManejoNomina.interactiva);

            Assert.AreEqual(string.Empty, periodic.PayrollType);
            Assert.AreEqual(string.Empty, periodic.PayrollClass);
            Assert.AreEqual(string.Empty, periodic.CompanyRFC);
            Assert.AreEqual(string.Empty, periodic.ReceiptVersion);
            Assert.AreEqual(string.Empty, periodic.Periods);
            Assert.AreEqual(string.Empty, periodic.Year);

            Assert.AreEqual(string.Empty, interactive.PayrollType);
            Assert.AreEqual(string.Empty, interactive.PayrollClass);
            Assert.AreEqual(string.Empty, interactive.CompanyRFC);
            Assert.AreEqual(string.Empty, interactive.ReceiptVersion);
            Assert.AreEqual(string.Empty, interactive.Periods);
            Assert.AreEqual(string.Empty, interactive.Year);
        }

        [TestMethod]
        public void SetCompany_ShouldSetCompanyRFC_ForBothNominas()
        {
            var holder = new StampingStatusDataHolder();

            holder.setCompany("RFC-XYZ");

            Assert.AreEqual("RFC-XYZ", holder.getInfo(ManejoNomina.periodica).CompanyRFC);
            Assert.AreEqual("RFC-XYZ", holder.getInfo(ManejoNomina.interactiva).CompanyRFC);
        }

        [TestMethod]
        public void SetReceiptVersion_ShouldSetReceiptVersion_ForBothNominas()
        {
            var holder = new StampingStatusDataHolder();

            holder.setReceiptVersion("v1");

            Assert.AreEqual("v1", holder.getInfo(ManejoNomina.periodica).ReceiptVersion);
            Assert.AreEqual("v1", holder.getInfo(ManejoNomina.interactiva).ReceiptVersion);
        }

        [TestMethod]
        public void AddPayrollType_ShouldWrapValueInQuotes_AndAppendWithComma_WhenAddingDifferentValues()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollType(ManejoNomina.periodica, "P");
            holder.addPayrollType(ManejoNomina.periodica, "Q");

            Assert.AreEqual("'P','Q'", holder.getInfo(ManejoNomina.periodica).PayrollType);
        }

        [TestMethod]
        public void AddPayrollType_WhenAddingSameValueTwice_ShouldNotDuplicate()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollType(ManejoNomina.periodica, "P");
            holder.addPayrollType(ManejoNomina.periodica, "P");

            Assert.AreEqual("'P'", holder.getInfo(ManejoNomina.periodica).PayrollType);
        }

        [TestMethod]
        public void AddPayrollClass_ShouldWrapValueInQuotes_AndPreventDuplicates()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollClass(ManejoNomina.interactiva, "C1");
            holder.addPayrollClass(ManejoNomina.interactiva, "C1");
            holder.addPayrollClass(ManejoNomina.interactiva, "C2");

            Assert.AreEqual("'C1','C2'", holder.getInfo(ManejoNomina.interactiva).PayrollClass);
        }

        [TestMethod]
        public void AddPeriods_ShouldAppendQuotedValues_AndPreventDuplicates()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPeriods(ManejoNomina.periodica, "01");
            holder.addPeriods(ManejoNomina.periodica, "02");
            holder.addPeriods(ManejoNomina.periodica, "02");

            Assert.AreEqual("'01','02'", holder.getInfo(ManejoNomina.periodica).Periods);
        }

        [TestMethod]
        public void AddYear_ShouldAppendQuotedValues_AndPreventDuplicates()
        {
            var holder = new StampingStatusDataHolder();

            holder.addYear(ManejoNomina.interactiva, "2024");
            holder.addYear(ManejoNomina.interactiva, "2025");
            holder.addYear(ManejoNomina.interactiva, "2024");

            Assert.AreEqual("'2024','2025'", holder.getInfo(ManejoNomina.interactiva).Year);
        }

        [TestMethod]
        public void AddFilters_AreIndependent_PerNomina()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollType(ManejoNomina.periodica, "P");
            holder.addPayrollType(ManejoNomina.interactiva, "I");

            Assert.AreEqual("'P'", holder.getInfo(ManejoNomina.periodica).PayrollType);
            Assert.AreEqual("'I'", holder.getInfo(ManejoNomina.interactiva).PayrollType);
        }

        [TestMethod]
        public void AddPayrollType_WhenValueIsSubstringOfExisting_ShouldStillNotDuplicate_ByCurrentContainsLogic()
        {
            var holder = new StampingStatusDataHolder();

            holder.addPayrollType(ManejoNomina.periodica, "AB");
            holder.addPayrollType(ManejoNomina.periodica, "A");

            Assert.AreEqual("'AB','A'", holder.getInfo(ManejoNomina.periodica).PayrollType);
        }
    }
}

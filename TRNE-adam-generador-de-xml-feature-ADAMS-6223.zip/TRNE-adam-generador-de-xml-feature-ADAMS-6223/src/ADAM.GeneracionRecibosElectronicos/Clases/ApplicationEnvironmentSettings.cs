﻿using System.Security;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.GeneracionRecibosElectronicos.Clases
{
    [ExcludeFromCodeCoverage]
    public class ApplicationEnvironmentSettings
    {
        #region Properties

        public string Platform { get; set; }
        public string DSN { get; set; }
        public string Server { get; set; } = "";
        public string Database { get; set; } = "";
        public string User { get; set; } = "";
        public SecureString Password { get; set; }
        public string OracleType { get; set; }
        public string OraclePort { get; set; }
        public string ApplicationUser { get; set; } = "";
        public string ApplicationPath { get; set; } = string.Empty;
        public string Version { get; set; }
        public string Site { get; set; }
        public string Xslt { get; set; }
        public string Xsd { get; set; }
        public string XmlFilePath { get; set; }
        public string MultipleFile { get; set; }
        public string AdditionalData { get; set; }
        public string AdditionalProcedure { get; set; }
        public string Timeout { get; set; }
        public string ADAMEnvironment { get; set; }
        public string WSUsrID { get; set; }
        public SecureString WSUsrPwd { get; set; }
        public string SelectedCompany { get; set; }
        public string DefaultCountry { get; set; }

        #endregion
    }
}

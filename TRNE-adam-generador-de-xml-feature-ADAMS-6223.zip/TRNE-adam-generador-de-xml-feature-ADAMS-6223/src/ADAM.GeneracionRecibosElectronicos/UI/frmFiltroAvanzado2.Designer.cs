namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmFiltroAvanzado2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFiltroAvanzado2));
            this.gridDisponibles = new System.Windows.Forms.DataGridView();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbTextoBusqueda = new System.Windows.Forms.ComboBox();
            this.btnAgregarIdALista = new System.Windows.Forms.Button();
            this.lblBuscarEmpleado = new System.Windows.Forms.Label();
            this.pnlIntermedio = new System.Windows.Forms.Panel();
            this.cmdInicializar = new System.Windows.Forms.Button();
            this.cmdAplicar = new System.Windows.Forms.Button();
            this.lblSeleccionados = new System.Windows.Forms.Label();
            this.pnlFiltro = new System.Windows.Forms.Panel();
            this.txtListaFiltro = new System.Windows.Forms.TextBox();
            this.lblFiltro = new System.Windows.Forms.Label();
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.cmdAceptar = new System.Windows.Forms.Button();
            this.gridSeleccionados = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gridDisponibles)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlIntermedio.SuspendLayout();
            this.pnlFiltro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSeleccionados)).BeginInit();
            this.SuspendLayout();
            // 
            // gridDisponibles
            // 
            this.gridDisponibles.AllowUserToAddRows = false;
            this.gridDisponibles.AllowUserToDeleteRows = false;
            this.gridDisponibles.AllowUserToResizeRows = false;
            this.gridDisponibles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDisponibles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDisponibles.Location = new System.Drawing.Point(80, 49);
            this.gridDisponibles.Name = "gridDisponibles";
            this.gridDisponibles.ReadOnly = true;
            this.gridDisponibles.RowHeadersVisible = false;
            this.gridDisponibles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDisponibles.Size = new System.Drawing.Size(80, 43);
            this.gridDisponibles.TabIndex = 3;
            this.gridDisponibles.Visible = false;
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.panel1);
            this.pnlPrincipal.Controls.Add(this.pnlIntermedio);
            this.pnlPrincipal.Controls.Add(this.pnlFiltro);
            this.pnlPrincipal.Controls.Add(this.lblFiltro);
            this.pnlPrincipal.Controls.Add(this.cmdCancelar);
            this.pnlPrincipal.Controls.Add(this.cmdAceptar);
            this.pnlPrincipal.Controls.Add(this.gridSeleccionados);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 0);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(0, 80, 0, 40);
            this.pnlPrincipal.Size = new System.Drawing.Size(884, 662);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.cmbTextoBusqueda);
            this.panel1.Controls.Add(this.btnAgregarIdALista);
            this.panel1.Controls.Add(this.lblBuscarEmpleado);
            this.panel1.Location = new System.Drawing.Point(6, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(866, 32);
            this.panel1.TabIndex = 9;
            // 
            // cmbTextoBusqueda
            // 
            this.cmbTextoBusqueda.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbTextoBusqueda.FormattingEnabled = true;
            this.cmbTextoBusqueda.Location = new System.Drawing.Point(112, 3);
            this.cmbTextoBusqueda.Name = "cmbTextoBusqueda";
            this.cmbTextoBusqueda.Size = new System.Drawing.Size(596, 26);
            this.cmbTextoBusqueda.TabIndex = 10;
            this.cmbTextoBusqueda.TextUpdate += new System.EventHandler(this.CmbTextoBusqueda_TextUpdate);
            // 
            // btnAgregarIdALista
            // 
            this.btnAgregarIdALista.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAgregarIdALista.Location = new System.Drawing.Point(714, 5);
            this.btnAgregarIdALista.Name = "btnAgregarIdALista";
            this.btnAgregarIdALista.Size = new System.Drawing.Size(149, 23);
            this.btnAgregarIdALista.TabIndex = 2;
            this.btnAgregarIdALista.Text = "Agregar Id a Listado";
            this.btnAgregarIdALista.UseVisualStyleBackColor = true;
            this.btnAgregarIdALista.Click += new System.EventHandler(this.BtnAgregarIdALista_Click);
            // 
            // lblBuscarEmpleado
            // 
            this.lblBuscarEmpleado.AutoSize = true;
            this.lblBuscarEmpleado.Location = new System.Drawing.Point(1, 7);
            this.lblBuscarEmpleado.Name = "lblBuscarEmpleado";
            this.lblBuscarEmpleado.Size = new System.Drawing.Size(105, 18);
            this.lblBuscarEmpleado.TabIndex = 0;
            this.lblBuscarEmpleado.Text = "Buscar Empleado:";
            // 
            // pnlIntermedio
            // 
            this.pnlIntermedio.Controls.Add(this.cmdInicializar);
            this.pnlIntermedio.Controls.Add(this.cmdAplicar);
            this.pnlIntermedio.Controls.Add(this.lblSeleccionados);
            this.pnlIntermedio.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlIntermedio.Location = new System.Drawing.Point(0, 200);
            this.pnlIntermedio.Name = "pnlIntermedio";
            this.pnlIntermedio.Size = new System.Drawing.Size(884, 60);
            this.pnlIntermedio.TabIndex = 4;
            // 
            // cmdInicializar
            // 
            this.cmdInicializar.Location = new System.Drawing.Point(265, 18);
            this.cmdInicializar.Name = "cmdInicializar";
            this.cmdInicializar.Size = new System.Drawing.Size(75, 23);
            this.cmdInicializar.TabIndex = 2;
            this.cmdInicializar.Text = "Inicializar";
            this.cmdInicializar.UseVisualStyleBackColor = true;
            this.cmdInicializar.Click += new System.EventHandler(this.cmdInicializar_Click);
            // 
            // cmdAplicar
            // 
            this.cmdAplicar.Location = new System.Drawing.Point(150, 18);
            this.cmdAplicar.Name = "cmdAplicar";
            this.cmdAplicar.Size = new System.Drawing.Size(109, 23);
            this.cmdAplicar.TabIndex = 1;
            this.cmdAplicar.Text = "Aplicar Filtro";
            this.cmdAplicar.UseVisualStyleBackColor = true;
            this.cmdAplicar.Click += new System.EventHandler(this.cmdAplicar_Click);
            // 
            // lblSeleccionados
            // 
            this.lblSeleccionados.AutoSize = true;
            this.lblSeleccionados.Location = new System.Drawing.Point(0, 20);
            this.lblSeleccionados.Name = "lblSeleccionados";
            this.lblSeleccionados.Size = new System.Drawing.Size(87, 18);
            this.lblSeleccionados.TabIndex = 0;
            this.lblSeleccionados.Text = "Seleccionados";
            // 
            // pnlFiltro
            // 
            this.pnlFiltro.Controls.Add(this.txtListaFiltro);
            this.pnlFiltro.Controls.Add(this.gridDisponibles);
            this.pnlFiltro.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFiltro.Location = new System.Drawing.Point(0, 80);
            this.pnlFiltro.Name = "pnlFiltro";
            this.pnlFiltro.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.pnlFiltro.Size = new System.Drawing.Size(884, 120);
            this.pnlFiltro.TabIndex = 8;
            // 
            // txtListaFiltro
            // 
            this.txtListaFiltro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtListaFiltro.Location = new System.Drawing.Point(0, 10);
            this.txtListaFiltro.Multiline = true;
            this.txtListaFiltro.Name = "txtListaFiltro";
            this.txtListaFiltro.Size = new System.Drawing.Size(884, 110);
            this.txtListaFiltro.TabIndex = 4;
            // 
            // lblFiltro
            // 
            this.lblFiltro.AutoSize = true;
            this.lblFiltro.Location = new System.Drawing.Point(7, 59);
            this.lblFiltro.Name = "lblFiltro";
            this.lblFiltro.Size = new System.Drawing.Size(318, 18);
            this.lblFiltro.TabIndex = 1;
            this.lblFiltro.Text = "Lista de Ids empleados para filtro (separados por coma):";
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancelar.Location = new System.Drawing.Point(797, 627);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(75, 23);
            this.cmdCancelar.TabIndex = 7;
            this.cmdCancelar.Text = "Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            this.cmdCancelar.Click += new System.EventHandler(this.cmdCancelar_Click);
            // 
            // cmdAceptar
            // 
            this.cmdAceptar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAceptar.Location = new System.Drawing.Point(704, 628);
            this.cmdAceptar.Name = "cmdAceptar";
            this.cmdAceptar.Size = new System.Drawing.Size(75, 23);
            this.cmdAceptar.TabIndex = 6;
            this.cmdAceptar.Text = "Aceptar";
            this.cmdAceptar.UseVisualStyleBackColor = true;
            this.cmdAceptar.Click += new System.EventHandler(this.cmdAceptar_Click);
            // 
            // gridSeleccionados
            // 
            this.gridSeleccionados.AllowUserToAddRows = false;
            this.gridSeleccionados.AllowUserToDeleteRows = false;
            this.gridSeleccionados.AllowUserToResizeRows = false;
            this.gridSeleccionados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridSeleccionados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridSeleccionados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridSeleccionados.Location = new System.Drawing.Point(0, 266);
            this.gridSeleccionados.Name = "gridSeleccionados";
            this.gridSeleccionados.ReadOnly = true;
            this.gridSeleccionados.RowHeadersVisible = false;
            this.gridSeleccionados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridSeleccionados.Size = new System.Drawing.Size(884, 356);
            this.gridSeleccionados.TabIndex = 5;
            // 
            // FrmFiltroAvanzado2
            // 
            this.AcceptButton = this.cmdAceptar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCancelar;
            this.ClientSize = new System.Drawing.Size(884, 662);
            this.Controls.Add(this.pnlPrincipal);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFiltroAvanzado2";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Filtro Avanzado";
            this.Load += new System.EventHandler(this.FrmFiltroAvanzado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridDisponibles)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlIntermedio.ResumeLayout(false);
            this.pnlIntermedio.PerformLayout();
            this.pnlFiltro.ResumeLayout(false);
            this.pnlFiltro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSeleccionados)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridDisponibles;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.DataGridView gridSeleccionados;
        private System.Windows.Forms.Panel pnlIntermedio;
        private System.Windows.Forms.Label lblSeleccionados;
        private System.Windows.Forms.Button cmdAplicar;
        private System.Windows.Forms.Button cmdInicializar;
        private System.Windows.Forms.Button cmdCancelar;
        private System.Windows.Forms.Button cmdAceptar;
        private System.Windows.Forms.Label lblFiltro;
        private System.Windows.Forms.Panel pnlFiltro;
        private System.Windows.Forms.TextBox txtListaFiltro;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblBuscarEmpleado;
        private System.Windows.Forms.Button btnAgregarIdALista;
        private System.Windows.Forms.ComboBox cmbTextoBusqueda;
    }
}
using ADAM.GeneracionRecibosElectronicos.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes
{
    [TestClass]
    public class EnumTests
    {
        #region CommandActions

        [TestMethod]
        public void CommandActions_ContainsExpectedCount()
        {
            Assert.AreEqual(11, Enum.GetValues(typeof(CommandActions)).Length);
        }

        [TestMethod]
        [DataRow(CommandActions.CONFIGURACION_ACCESO)]
        [DataRow(CommandActions.DEFINIR_TIPOS_CONCEPTOS)]
        [DataRow(CommandActions.DEFINIR_REGIMEN_CONTRATACION)]
        [DataRow(CommandActions.CONFIGURACION_BANCOS)]
        [DataRow(CommandActions.CONFIGURACION_INCAPACIDADES)]
        [DataRow(CommandActions.MAPEO_CATALOGOS_ADAM_SAT)]
        [DataRow(CommandActions.MAPEO_CATALOGOS_ADAM_DIAN)]
        [DataRow(CommandActions.MAPEO_CONCEPTOS_ADAM_DIAN)]
        [DataRow(CommandActions.SITIO_TIMBRADO)]
        [DataRow(CommandActions.CONSULTA_CATALOGOS_ADAM_DIAN)]
        [DataRow(CommandActions.CONSULTA_ESTADO_DOCUMENTO)]
        public void CommandActions_AllValues_AreDefined(CommandActions action)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(CommandActions), action));
        }

        #endregion

        #region ComparationOperator

        [TestMethod]
        public void ComparationOperator_ContainsExpectedCount()
        {
            Assert.AreEqual(10, Enum.GetValues(typeof(ComparationOperator)).Length);
        }

        [TestMethod]
        [DataRow(ComparationOperator.Equal, 1)]
        [DataRow(ComparationOperator.NotEqual, 2)]
        [DataRow(ComparationOperator.Contain, 3)]
        [DataRow(ComparationOperator.NoContain, 4)]
        [DataRow(ComparationOperator.Greater, 5)]
        [DataRow(ComparationOperator.GreaterOrEqual, 6)]
        [DataRow(ComparationOperator.Less, 7)]
        [DataRow(ComparationOperator.LessOrEqual, 8)]
        [DataRow(ComparationOperator.In, 9)]
        [DataRow(ComparationOperator.NotIn, 10)]
        public void ComparationOperator_HasExpectedValue(ComparationOperator op, int expected)
        {
            Assert.AreEqual(expected, (int)op);
        }

        #endregion

        #region ConditionalOperator

        [TestMethod]
        public void ConditionalOperator_ContainsTwoValues()
        {
            Assert.AreEqual(2, Enum.GetValues(typeof(ConditionalOperator)).Length);
        }

        [TestMethod]
        [DataRow(ConditionalOperator.And, 1)]
        [DataRow(ConditionalOperator.Or, 2)]
        public void ConditionalOperator_HasExpectedValue(ConditionalOperator op, int expected)
        {
            Assert.AreEqual(expected, (int)op);
        }

        #endregion

        #region Countries

        [TestMethod]
        public void Countries_ContainsTwoValues()
        {
            Assert.AreEqual(2, Enum.GetValues(typeof(Countries)).Length);
        }

        [TestMethod]
        [DataRow(Countries.México, 1)]
        [DataRow(Countries.Colombia, 2)]
        public void Countries_HasExpectedValue(Countries country, int expected)
        {
            Assert.AreEqual(expected, (int)country);
        }

        #endregion

        #region DianResponseStatus

        [TestMethod]
        public void DianResponseStatus_ContainsThreeValues()
        {
            Assert.AreEqual(3, Enum.GetValues(typeof(DianResponseStatus)).Length);
        }

        [TestMethod]
        [DataRow(DianResponseStatus.NotValid)]
        [DataRow(DianResponseStatus.Correcto)]
        [DataRow(DianResponseStatus.Incorrecto)]
        public void DianResponseStatus_AllValues_AreDefined(DianResponseStatus status)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(DianResponseStatus), status));
        }

        #endregion

        #region LanguageCodes

        [TestMethod]
        public void LanguageCodes_Mexico_HasExpectedValue()
        {
            Assert.AreEqual("es-MX", LanguageCodes.Mexico);
        }

        [TestMethod]
        public void LanguageCodes_Colombia_HasExpectedValue()
        {
            Assert.AreEqual("es-CO", LanguageCodes.Colombia);
        }

        #endregion

        #region PadType

        [TestMethod]
        public void PadType_ContainsTwoValues()
        {
            Assert.AreEqual(2, Enum.GetValues(typeof(PadType)).Length);
        }

        [TestMethod]
        [DataRow(PadType.Left)]
        [DataRow(PadType.Right)]
        public void PadType_AllValues_AreDefined(PadType padType)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(PadType), padType));
        }

        #endregion

        #region ColumnValueType

        [TestMethod]
        public void ColumnValueType_ContainsThreeValues()
        {
            Assert.AreEqual(3, Enum.GetValues(typeof(ColumnValueType)).Length);
        }

        [TestMethod]
        [DataRow(ColumnValueType.String, 1)]
        [DataRow(ColumnValueType.Num, 2)]
        [DataRow(ColumnValueType.Date, 3)]
        public void ColumnValueType_HasExpectedValue(ColumnValueType type, int expected)
        {
            Assert.AreEqual(expected, (int)type);
        }

        #endregion
    }
}

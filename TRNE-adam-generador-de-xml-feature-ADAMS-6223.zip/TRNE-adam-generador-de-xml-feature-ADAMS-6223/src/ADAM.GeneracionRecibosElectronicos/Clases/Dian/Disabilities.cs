﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("incapacidades", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Disabilities
    {
        [JsonProperty("fechaInicio")]
        public string FechaInicio;

        [JsonProperty("fechaFin")]
        public string FechaFin;

        [JsonProperty("cantidad")]
        public int PagoCantidad { get; set; }

        [JsonProperty("tipo")]
        public int TipoIncapacidad { get; set; }

        [JsonProperty("pago")]
        public decimal Pago { get; set; }
    }
}

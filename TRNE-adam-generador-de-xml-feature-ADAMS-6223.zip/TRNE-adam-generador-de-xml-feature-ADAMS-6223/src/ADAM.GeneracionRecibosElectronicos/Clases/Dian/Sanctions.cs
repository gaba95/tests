﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("sanciones", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Sanctions
    {
        [JsonProperty("descripcion")]
        public string valorDeduccionDescripcion { get; set; } = "";

        public decimal valorDeduccion { get; set; }
        public bool tipoSancion { get; set; }
    }
}

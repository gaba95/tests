﻿using System.Data;
using System.Globalization;
using System.Net;
using System.Xml.Linq;

namespace ADAM.Recibos.Utilerias.Tests.Helpers
{
    public static class GlobaHelperTest
    {
        public static string ToXml(this DataTable table, int metaIndex = 0)
        {

                XDocument xdoc = new XDocument(
                    new XElement(table.TableName,
                        from column in table.Columns.Cast<DataColumn>()
                        where column != table.Columns[metaIndex]
                        select new XElement(column.ColumnName,
                            from row in table.AsEnumerable()
                            select new XElement(row.Field<string>(metaIndex), row[column])
                            )
                        )
                    );

                return xdoc.ToString();
            
        }

        public static DataTable Meses()
        {
            DataTable meses = new DataTable();
            DataRow renglon;

            string nombreMes;
            meses.Columns.Add("mes");
            meses.Columns.Add("descripcion");

            for (int mes = 0; mes < 12; mes++)
            {
                nombreMes = CultureInfo.GetCultureInfo("es-MX").DateTimeFormat.MonthNames[mes];
                renglon = meses.NewRow();
                renglon["mes"] = mes + 1;
                renglon["descripcion"] = nombreMes.ToUpper();
                meses.Rows.Add(renglon);
            }

            return meses;
        }

        public static Func<string, string> CreateFuncGetParam(DataSet param, string columnParamName, string columnValueName)
        {
            Func<string, string> resultFunc = (string id_parametro) =>
            {
                var parametro = param.Tables[0].AsEnumerable().Where(t => t.Field<string>(columnParamName) == id_parametro).ToArray();
                if (parametro != null && parametro.Length > 0)
                    return parametro[0]?.Field<string>(columnValueName);
                return string.Empty;
            };
            return resultFunc;
        }

        public static void ValidateUrl(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                throw new ArgumentException("La URL no puede estar vacía.");
            }

            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri uri))
            {
                throw new ArgumentException("La URL no es válida.");
            }

            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
            {
                throw new ArgumentException("Solo se permiten esquemas HTTP y HTTPS.");
            }

            string host = uri.Host.ToLower();
            IPAddress[] addresses = Dns.GetHostAddresses(host);

            foreach (var ip in addresses)
            {
                if (IPAddress.IsLoopback(ip))
                    throw new ArgumentException("No se permite el acceso a direcciones locales o privadas.");
            }
        }

    }
}

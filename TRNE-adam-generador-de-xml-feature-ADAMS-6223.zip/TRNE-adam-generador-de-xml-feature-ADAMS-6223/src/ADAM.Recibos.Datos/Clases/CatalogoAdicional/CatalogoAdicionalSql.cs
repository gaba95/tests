﻿using System.Data;
using Microsoft.Data.SqlClient;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.Recibos.Datos.Clases.CatalogoAdicional
{
    public class CatalogoAdicionalSql : ICatalogoAdicional
    {
        private const string ParamCompania = "@compania";
        private const string ParamUser = "@user";
        private const string ParamCompany = "@company";
        private const string ParamTipoConcepto = "@tipoConcepto";
        private const string ParamClient = "@client";
        private const string SqlCheckCompaniaColumn = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'rel_tipo_clase_nomina' AND COLUMN_NAME = 'compania'";

        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoAdicionalSql(IDbConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
            _connectionFactory.CreateConnection();
        }

        public bool CheckDbConnection()
        {
            return _connectionFactory.CheckConnection();
        }

        public DataSet obtenDatasetTrabajadoresRecibo(string compania, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina)
        {
            int connectionRetries = 0;
            DataSet ds = new();

            // AZ-1071: Added connection tries, so if it fails at the fill or timeout, it doesn´t throw
            // the Exception at first error. This helps to maintain consistency when getting multiple
            // years, months, payrolls, etc
            while (connectionRetries < Database.MaxConnectionRetries)
            {
                try
                {
                    using var dbConnection = this._connectionFactory.CreateConnection();

                    if (dbConnection.State == ConnectionState.Closed)
                        dbConnection.Open();

                    ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_trabajadores_recibo_sat", "Table", cmd =>
                    {
                        SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                        SqlHelpers.AddCharParam(cmd, "@tipo_nomina", 2, tipoNomina);
                        SqlHelpers.AddCharParam(cmd, "@clase_nomina", 2, claseNomina);
                        SqlHelpers.AddIntParam(cmd, "@anio", anio);
                        SqlHelpers.AddIntParam(cmd, "@periodo", periodo);
                        SqlHelpers.AddIntParam(cmd, "@manejo_nomina", (int)manejoNomina);
                    }));

                    return ds;
                }
                catch
                {
                    connectionRetries++;

                    if (connectionRetries == Database.MaxConnectionRetries)
                        throw;
                }
            }
            return ds;
        }

        public string obtenCompaniasIdiomas()
        {
            string szIdiomas = "";
            bool bCountry = false;

            // Include only companies from Mexico & Colombia

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            // Check if exists the culture column
            SqlCommand comandobCountry = new("IF EXISTS(SELECT TOP 1 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'companias' AND COLUMN_NAME = 'cve_pais') SELECT 1 ELSE SELECT 0", sqlConnection);

            // Check Connection
            if (comandobCountry.Connection == null)
            {  return String.Empty; }

            bCountry = int.Parse(comandobCountry.ExecuteScalar().ToString()) == 1;

            // If the ADAM Version supports the column cve_pais
            if (bCountry)
            {
                // Select Languages Include Only México & Colombia
                var sqlStmt = new SqlCommand(@"SELECT STUFF((SELECT ',' + RTRIM(c.cve_pais)
                                                 FROM dbo.companias c
                                                WHERE c.compania NOT IN('0', 'A')
                                                  AND c.cve_pais IN('es-MX','es-CO')
                                                GROUP BY c.cve_pais
                                              FOR XML PATH(''), TYPE).value('text()[1]', 'NVARCHAR(max)'), 1, LEN(','), '')", sqlConnection);
                sqlStmt.Prepare();

                szIdiomas = sqlStmt.ExecuteScalar().ToString();
            }
            return szIdiomas;
        }

        public DataSet obtenDatasetCompanias(string szLangCode)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            // Check if exists the culture column
            const string sqlQuery01 = @"IF EXISTS(SELECT TOP 1 1 
                                                    FROM INFORMATION_SCHEMA.COLUMNS 
                                                   WHERE TABLE_NAME = 'companias' 
                                                     AND COLUMN_NAME = 'cve_pais') 
                                          SELECT 1 
                                        ELSE 
                                          SELECT 0";
            var sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);

            // Get Companies
            sqlStmt.Prepare();
            bool bCountry = SqlCommandExecutor.Request(sqlStmt, true);
            var excludedCompanies = "'0', 'A'";

            // Check legacy instances to not exclude company 'A'
            if (!existeTablaConfiguracion())
            {
                excludedCompanies = "'0'";
            }

            // Include only companies from Mexico & Colombia
            if (bCountry)
            {
                const string sqlQuery02 = @"SELECT c.compania, 
                                                   RTRIM(c.compania) + '-' + RTRIM(c.nombre_cia) AS nombre_cia, c.registro_fiscal
                                              FROM dbo.companias AS c
                                               INNER JOIN dbo.aut_companias AS at ON at.compania = c.compania
                                             WHERE at.usuario = @user
                                               AND c.compania NOT IN (@exclude)
                                               AND c.cve_pais IN (@languages)";
                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);

                sqlStmt.Parameters.Add(ParamUser, SqlDbType.VarChar, 10).Value = this._connectionFactory.ApplicationUser;
                sqlStmt.Parameters.Add("@exclude", SqlDbType.VarChar, 50).Value = excludedCompanies;
                sqlStmt.Parameters.Add("@languages", SqlDbType.VarChar, 50).Value = szLangCode.Trim();
                sqlStmt.Prepare();
            }
            else
            {
                const string sqlQuery03 = @"SELECT c.compania, 
                                                   RTRIM(c.compania) + '-' + RTRIM(c.nombre_cia) AS nombre_cia, c.registro_fiscal
                                              FROM dbo.companias AS c
                                               INNER JOIN dbo.aut_companias AS at ON at.compania = c.compania
                                             WHERE at.usuario = @user
                                               AND c.compania NOT IN (@exclude)";
                sqlStmt = new SqlCommand(sqlQuery03, sqlConnection);

                sqlStmt.Parameters.Add(ParamUser, SqlDbType.VarChar, 10).Value = this._connectionFactory.ApplicationUser;
                sqlStmt.Parameters.Add("@exclude", SqlDbType.VarChar, 50).Value = excludedCompanies;
                sqlStmt.Prepare();
            }

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        // Check if the environment includes the table to store the config
        public bool existeTablaConfiguracion()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            var sqlStmt = new SqlCommand(@"SELECT COUNT(*) 
                                             FROM INFORMATION_SCHEMA.COLUMNS 
                                            WHERE TABLE_NAME = 'tb_configuracion_adicional_compania'", sqlConnection);
            sqlStmt.Prepare();

            var existsConfTable = int.Parse(sqlStmt.ExecuteScalar().ToString());
            return existsConfTable > 0;
        }

        public bool DeletePayslipsData(string companyId, string payrollType, string payrollClass,
                                      int payrollYear, int payrollPeriod, string employee)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_borrar_recibos_pago";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char).Value = companyId;
            sqlStmt.Parameters.Add("@tipo_nomina", SqlDbType.Char).Value = payrollType;
            sqlStmt.Parameters.Add("@clase_nomina", SqlDbType.Char).Value = payrollClass;
            sqlStmt.Parameters.Add("@anio", SqlDbType.SmallInt).Value = payrollYear;
            sqlStmt.Parameters.Add("@periodo", SqlDbType.SmallInt).Value = payrollPeriod;
            sqlStmt.Parameters.Add("@lstTrabajadores", SqlDbType.VarChar).Value = employee;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public DataSet obtenConfiguracionCompania(string compania)
        {
            try
            {
                using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                if (sqlConnection.State == ConnectionState.Closed)
                    sqlConnection.Open();

                bool existsConfTable = false;
                const string sqlQuery01 = @"SELECT COUNT(*) 
                                              FROM INFORMATION_SCHEMA.COLUMNS 
                                             WHERE TABLE_NAME = @table_name";
                var sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
                sqlStmt.Parameters.Add("@table_name", SqlDbType.VarChar, 100).Value = "tb_configuracion_adicional_compania";
                sqlStmt.Prepare();

                existsConfTable = SqlCommandExecutor.Request(sqlStmt, true);

                if (existsConfTable)
                {
                    const string sqlQuery02 = @"SELECT cc.compania, cc.id_parametro, 
                                                       cc.descripcion, cc.alfanumerico, 
                                                       cc.numero_real, cc.numero_entero, 
                                                       cc.fecha
                                                  FROM tb_configuracion_adicional_compania cc
                                                    INNER JOIN aut_companias at ON at.compania = cc.compania
                                                 WHERE at.usuario = @user
                                                   AND cc.compania = @company";
                    sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);

                    sqlStmt.Parameters.Add(ParamUser, SqlDbType.VarChar, 30).Value = this._connectionFactory.ApplicationUser;
                    sqlStmt.Parameters.Add(ParamCompany, SqlDbType.Char, 4).Value = compania;
                    sqlStmt.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        public void GuardaConfiguracionCompania(string company, ConfigurationTypes parameterId, string description, string alphanumeric, decimal num_decimal = 0, int num_int = 0)
        {
            try
            {
                using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                if (sqlConnection.State == ConnectionState.Closed)
                    sqlConnection.Open();

                bool existsConfTable = false;
                const string sqlQuery01 = @"SELECT COUNT(*) 
                                              FROM INFORMATION_SCHEMA.COLUMNS 
                                             WHERE TABLE_NAME = 'tb_configuracion_adicional_compania'";
                var sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
                sqlStmt.Prepare();

                existsConfTable = SqlCommandExecutor.Request(sqlStmt, true);

                if (existsConfTable)
                {
                    const string sqlQuery02 = @"IF NOT EXISTS (SELECT cc.compania 
                                                                FROM tb_configuracion_adicional_compania cc 
                                                               WHERE cc.compania = @company 
                                                                 AND id_parametro = @parameterId
                                                             )
                                                 INSERT INTO tb_configuracion_adicional_compania (compania, id_parametro, descripcion, alfanumerico, numero_real, numero_entero, fecha)
                                                  VALUES (@company, @parameterId, @description, @alphanumeric, @num_decimal, @num_int, @date)
                                               ELSE
                                                 UPDATE tb_configuracion_adicional_compania 
                                                    SET alfanumerico = @alphanumeric,
                                                        numero_real = @num_decimal,
                                                        numero_entero = @num_int,
                                                        fecha = @date
                                                  WHERE compania = @company 
                                                    AND id_parametro = @parameterId";
                    sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);

                    sqlStmt.Parameters.Add(ParamCompany, SqlDbType.Char, 4).Value = company;
                    sqlStmt.Parameters.Add("@parameterId", SqlDbType.VarChar, 50).Value = parameterId;
                    sqlStmt.Parameters.Add("@description", SqlDbType.VarChar, 100).Value = description;
                    sqlStmt.Parameters.Add("@alphanumeric", SqlDbType.VarChar, 300).Value = alphanumeric;
                    var pDecimal = sqlStmt.Parameters.Add("@num_decimal", SqlDbType.Decimal);
                    pDecimal.Precision = 18;
                    pDecimal.Scale = 2;
                    pDecimal.Value = num_decimal;
                    sqlStmt.Parameters.Add("@num_int", SqlDbType.Int).Value = num_int;
                    sqlStmt.Parameters.Add("@date", SqlDbType.DateTime).Value = DateTime.Now;
                    sqlStmt.Prepare();

                    SqlCommandExecutor.Request(sqlStmt, false);
                }
            }
            catch 
            { 
                // Nothing
            }
        }

        public DataSet obtenDatasetClasesNomina(string compania)
        {
            int rowsRelTable = 0;
            int existsRelTable;
            int existCompanyColumn;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            try
            {
                const string sqlQuery01 = @"SELECT COUNT(*) 
                                              FROM INFORMATION_SCHEMA.COLUMNS 
                                             WHERE TABLE_NAME = 'rel_tipo_clase_nomina'";
                var sqlStmt01 = new SqlCommand(sqlQuery01, sqlConnection);
                sqlStmt01.Prepare();

                if (sqlStmt01.Connection.State == ConnectionState.Closed)
                    sqlStmt01.Connection.Open();

                existsRelTable = Convert.ToInt32(sqlStmt01.ExecuteScalar());

                sqlStmt01.Connection.Close();
            }
            catch 
            { 
                return null; 
            }

            try
            {
                var sqlStmt02 = new SqlCommand(SqlCheckCompaniaColumn, sqlConnection);

                if (sqlStmt02.Connection.State == ConnectionState.Closed)
                    sqlStmt02.Connection.Open();

                sqlStmt02.Prepare();

                existCompanyColumn = Convert.ToInt32(sqlStmt02.ExecuteScalar());

                sqlStmt02.Connection.Close();
            }
            catch 
            { 
                return null; 
            }

            // Special Cases - ADAM v5.4 & v5.3
            if (existsRelTable > 0)
            {
                var sqlStmt03 = new SqlCommand(SqlCheckCompaniaColumn, sqlConnection);

                if (sqlStmt03.Connection.State == ConnectionState.Closed)
                    sqlStmt03.Connection.Open();

                sqlStmt03.Prepare();

                existCompanyColumn = int.Parse(sqlStmt03.ExecuteScalar().ToString());

                const string sqlQuery04 = @"SELECT COUNT(*) 
                                              FROM dbo.rel_tipo_clase_nomina";
                sqlStmt03 = new SqlCommand(sqlQuery04, sqlConnection);
                sqlStmt03.Prepare();

                rowsRelTable = int.Parse(sqlStmt03.ExecuteScalar().ToString());

                sqlStmt03.Connection.Close();
            }

            // Get Payroll Classes
            if (existsRelTable > 0 && rowsRelTable > 0)
            {
                if (existCompanyColumn == 1)
                {
                    const string sqlQuery04 = @"SELECT DISTINCT cn.clase_nomina, 
                                                       RTRIM(cn.clase_nomina) + '-' + RTRIM(cn.descripcion) AS descripcion
                                                  FROM dbo.clases_nomina AS cn
                                                    INNER JOIN dbo.rel_usu_clase_nom AS rucn ON rucn.clase_nomina = cn.clase_nomina
                                                    INNER JOIN dbo.rel_tipo_clase_nomina rel ON rel.clase_nomina = cn.clase_nomina
                                                 WHERE rucn.usuario = @user 
                                                   AND rel.compania = @company";

                    var sqlStmt04 = new SqlCommand(sqlQuery04, sqlConnection);

                    if (sqlStmt04.Connection.State == ConnectionState.Closed)
                        sqlStmt04.Connection.Open();

                    sqlStmt04.Parameters.Add(ParamUser, SqlDbType.VarChar, 12).Value = this._connectionFactory.ApplicationUser;
                    sqlStmt04.Parameters.Add(ParamCompany, SqlDbType.VarChar, 10).Value = compania;
                    sqlStmt04.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt04));
                }
                else
                {
                    const string sqlQuery05 = @"SELECT DISTINCT cn.clase_nomina, 
                                                       RTRIM(cn.clase_nomina) + '-' + RTRIM(cn.descripcion) AS descripcion
                                                  FROM dbo.clases_nomina AS cn
                                                    INNER JOIN dbo.rel_usu_clase_nom AS rucn ON rucn.clase_nomina = cn.clase_nomina
                                                    INNER JOIN dbo.rel_tipo_clase_nomina rel ON rel.clase_nomina = cn.clase_nomina
                                                 WHERE rucn.usuario = @user";

                    var sqlStmt05 = new SqlCommand(sqlQuery05, sqlConnection);

                    if (sqlStmt05.Connection.State == ConnectionState.Closed)
                        sqlStmt05.Connection.Open();

                    sqlStmt05.Parameters.Add(ParamUser, SqlDbType.VarChar, 12).Value = this._connectionFactory.ApplicationUser;
                    sqlStmt05.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt05));
                }
            }
            else
            {
                const string sqlQuery06 = @"SELECT DISTINCT cn.clase_nomina, 
                                                   RTRIM(cn.clase_nomina) + '-' + RTRIM(cn.descripcion) AS descripcion
                                              FROM dbo.clases_nomina AS cn
                                                INNER JOIN dbo.rel_usu_clase_nom AS rucn ON rucn.clase_nomina = cn.clase_nomina
                                             WHERE rucn.usuario = @user";

                var sqlStmt06 = new SqlCommand(sqlQuery06, sqlConnection);

                if (sqlStmt06.Connection.State == ConnectionState.Closed)
                    sqlStmt06.Connection.Open();

                sqlStmt06.Parameters.Add(ParamUser, SqlDbType.VarChar, 12).Value = this._connectionFactory.ApplicationUser;
                sqlStmt06.Prepare();

                return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt06));
            }
        }

        public DataSet obtenDatasetTiposNomina(string compania)
        {
            int rowsRelTable = 0;
            int existsRelTable;
            int existCompanyColumn;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            try
            {
                const string sqlQuery01 = @"SELECT COUNT(*) 
                                              FROM INFORMATION_SCHEMA.COLUMNS 
                                             WHERE TABLE_NAME = 'rel_tipo_clase_nomina'";
                var sqlStmt01 = new SqlCommand(sqlQuery01, sqlConnection);
                sqlStmt01.Prepare();

                if (sqlStmt01.Connection.State == ConnectionState.Closed)
                    sqlStmt01.Connection.Open();

                existsRelTable = int.Parse(sqlStmt01.ExecuteScalar().ToString());

                sqlStmt01.Connection.Close();
            }
            catch 
            { 
                return null; 
            }
            
            try
            {
                var sqlStmt02 = new SqlCommand(SqlCheckCompaniaColumn, sqlConnection);
                sqlStmt02.Prepare();

                if (sqlStmt02.Connection.State == ConnectionState.Closed)
                    sqlStmt02.Connection.Open();

                existCompanyColumn = int.Parse(sqlStmt02.ExecuteScalar().ToString());

                sqlStmt02.Connection.Close();
            }
            catch 
            { 
                return null; 
            }

            // Special Cases - ADAM v5.4 & v5.3
            if (existsRelTable > 0)
            {
                var sqlStmt04 = new SqlCommand(SqlCheckCompaniaColumn, sqlConnection);
                sqlStmt04.Prepare();
                    
                if (sqlStmt04.Connection.State == ConnectionState.Closed)
                    sqlStmt04.Connection.Open();

                existCompanyColumn = int.Parse(sqlStmt04.ExecuteScalar().ToString());

                const string sqlQuery05 = @"SELECT COUNT(*) 
                                              FROM dbo.rel_tipo_clase_nomina";
                sqlStmt04 = new SqlCommand(sqlQuery05, sqlConnection);
                sqlStmt04.Prepare();

                rowsRelTable = int.Parse(sqlStmt04.ExecuteScalar().ToString());

                sqlStmt04.Connection.Close();
            }

            // Get Payroll Types
            if (existsRelTable > 0 && rowsRelTable > 0)
            {
                if (existCompanyColumn == 1)
                {
                    const string sqlQuery05 = @"SELECT DISTINCT(t.tipo_nomina), 
                                                       RTRIM(t.tipo_nomina) + '-' + RTRIM(t.descripcion) AS descripcion, 
                                                       t.manejo
                                                  FROM dbo.tipos_nomina t
                                                    INNER JOIN dbo.rel_tipo_clase_nomina rel ON rel.tipo_nomina = t.tipo_nomina
                                                 WHERE rel.compania = @company";

                    var sqlStmt05 = new SqlCommand(sqlQuery05, sqlConnection);

                    if (sqlStmt05.Connection.State == ConnectionState.Closed)
                        sqlStmt05.Connection.Open();

                    sqlStmt05.Parameters.Add(ParamCompany, SqlDbType.VarChar, 10).Value = compania;
                    sqlStmt05.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt05));
                }
                else
                {
                    const string sqlQuery06 = @"SELECT DISTINCT(t.tipo_nomina), 
                                                       RTRIM(t.tipo_nomina) + '-' + RTRIM(t.descripcion) AS descripcion, 
                                                       t.manejo
                                                  FROM dbo.tipos_nomina t 
                                                    INNER JOIN dbo.rel_tipo_clase_nomina rel ON rel.tipo_nomina = t.tipo_nomina";

                    var sqlStmt06 = new SqlCommand(sqlQuery06, sqlConnection);

                    if (sqlStmt06.Connection.State == ConnectionState.Closed)
                        sqlStmt06.Connection.Open();

                    sqlStmt06.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt06));
                }
            }
            else
            {
                const string sqlQuery07 = @"SELECT DISTINCT(t.tipo_nomina), 
                                                   RTRIM(t.tipo_nomina) + '-' + RTRIM(t.descripcion) AS descripcion, 
                                                   t.manejo
                                              FROM dbo.tipos_nomina t";

                var sqlStmt07 = new SqlCommand(sqlQuery07, sqlConnection);
                sqlStmt07.Prepare();

                return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt07));
            }
        }

        public DataSet obtenBasesDisponibles()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT name 
                                        FROM master.dbo.sysdatabases 
                                       WHERE UPPER(name) NOT IN ('FILESYSTEMSQL','MASTER', 'MODEL', 'MSDB', 'REPORTSERVER', 'REPORTSERVERTEMPDB', 'TEMPDB') 
                                       ORDER BY name";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenListaPeriodosMes(string compania, string tipoNomina, int anio, int mesAcumular)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT cp.periodo
                                        FROM calendario_procesos AS cp
                                          INNER JOIN cal_proc_cias AS cpc ON cpc.id_calendario = cp.id_calendario
                                       WHERE cp.tipo_nomina = @tipoNomina
                                         AND cp.anio = @anio
                                         AND cp.mes_acumular = @mesAcumular
                                         AND cpc.compania = @compania";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add("@tipoNomina", SqlDbType.Char, 2).Value = tipoNomina;
            sqlStmt.Parameters.Add("@anio", SqlDbType.Int).Value = anio;
            sqlStmt.Parameters.Add("@mesAcumular", SqlDbType.Int).Value = mesAcumular;
            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = compania;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetTiposPercepcionDeduccion(int tipo)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT clave, descripcion 
                                        FROM tipos_percepcion_deduccion
                                       WHERE tipo_concepto_sat = @tipo
                                       ORDER BY clave";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = tipo;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetDescripcionTipos()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT item, RTRIM(descripcion) AS descripcion
                                        FROM criterios_valores
                                       WHERE campo = @value";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add("@value", SqlDbType.Char, 20).Value = "tipo_concepto_sat";
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetRelacionConceptos(int tipoConcepto, string claveTipo)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT rct.tipo_concepto_sat, rct.clave, rct.concepto, RTRIM(c.descripcion) AS descripcion 
                                        FROM rel_conceptos_tipos_sat12 AS rct 
                                          INNER JOIN conceptos AS c ON c.concepto = rct.concepto 
                                       WHERE rct.tipo_concepto_sat = @tipoConcepto 
                                         AND rct.clave = @claveTipo 
                                       ORDER BY rct.concepto";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamTipoConcepto, SqlDbType.TinyInt).Value = tipoConcepto;
            sqlStmt.Parameters.Add("@claveTipo", SqlDbType.VarChar, 10).Value = claveTipo.Trim();
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetConceptosRelacionar(int tipoConcepto, string claveTipo)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            switch (tipoConcepto)
            {
                case 2: // Deducciones
                    const string sqlQuery01 = @"SELECT concepto, 
                                                       RTRIM(concepto) + '--' + RTRIM(descripcion) AS descripcion 
                                                  FROM dbo.conceptos 
                                                 WHERE concepto NOT IN (SELECT concepto
                                                                          FROM rel_conceptos_tipos_sat12
                                                                         WHERE tipo_concepto_sat = @tipoConcepto) 
                                                   AND tipo_transaccion IN (2,3,5)
                                                 ORDER BY concepto";

                    var sqlStmt01 = new SqlCommand(sqlQuery01, sqlConnection);
                    sqlStmt01.Parameters.Add(ParamTipoConcepto, SqlDbType.TinyInt).Value = tipoConcepto;
                    sqlStmt01.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt01));

                case 4: // Incapacidad
                    const string sqlQuery02 = @"SELECT concepto, 
                                                       RTRIM(concepto) + '--' + RTRIM(descripcion) AS descripcion 
                                                  FROM dbo.conceptos 
                                                 WHERE concepto NOT IN (SELECT concepto 
                                                                          FROM rel_conceptos_tipos_sat12 
                                                                         WHERE tipo_concepto_sat = @tipoConcepto) 
                                                   AND tipo_transaccion IN (1,2,3,5)
                                                 ORDER BY concepto";

                    var sqlStmt02 = new SqlCommand(sqlQuery02, sqlConnection);
                    sqlStmt02.Parameters.Add(ParamTipoConcepto, SqlDbType.TinyInt).Value = tipoConcepto;
                    sqlStmt02.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt02));

                default: // Percepciones/Otros Pagos
                    const string sqlQuery03 = @"SELECT concepto, 
                                                       RTRIM(concepto) + '--' + RTRIM(descripcion) AS descripcion 
                                                  FROM dbo.conceptos 
                                                 WHERE concepto NOT IN (SELECT concepto
                                                                          FROM rel_conceptos_tipos_sat12
                                                                         WHERE tipo_concepto_sat = @tipoConcepto) 
                                                   AND tipo_transaccion IN (1,3,4,5)
                                                 ORDER BY concepto";

                    var sqlStmt03 = new SqlCommand(sqlQuery03, sqlConnection);
                    sqlStmt03.Parameters.Add(ParamTipoConcepto, SqlDbType.TinyInt).Value = tipoConcepto;
                    sqlStmt03.Prepare();

                    return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt03));
            }
        }

        public bool AltaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_alta_rel_conceptos_tipos_sat12";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add("@tipo_concepto_sat", SqlDbType.TinyInt).Value = tipo;
            sqlStmt.Parameters.Add("@clave", SqlDbType.VarChar).Value = claveTipo;
            sqlStmt.Parameters.Add("@concepto", SqlDbType.SmallInt).Value = concepto;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public bool BajaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_baja_rel_conceptos_tipos_sat12";

            SqlCommand sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add("@tipo_concepto_sat", SqlDbType.TinyInt).Value = tipo;
            sqlStmt.Parameters.Add("@clave", SqlDbType.VarChar).Value = claveTipo;
            sqlStmt.Parameters.Add("@concepto", SqlDbType.SmallInt).Value = concepto;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public DataSet obtenDatasetTrabajadoresRegimen(string compania)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tg.compania, t.trabajador, REPLACE(t.nombre,'/', ' ') AS nombre, 
                                             ISNULL(rtr.clave_regimen,0) AS regimen, 
                                             ISNULL(cv.descripcion_sat,'---') AS descripcion 
                                        FROM trabajadores AS t 
                                          INNER JOIN trabajadores_grales AS tg ON tg.trabajador = t.trabajador 
                                          LEFT OUTER JOIN rel_trab_regimen AS rtr ON rtr.trabajador = tg.trabajador AND rtr.compania = tg.compania 
                                          LEFT OUTER JOIN catalogos_valores_sat_adam AS cv ON cv.clave_sat = rtr.clave_regimen AND cv.tipo = 3 
                                        WHERE tg.compania = @compania 
                                        ORDER BY tg.trabajador";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = compania.Trim();
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetRegimen()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT clave_sat AS clave,clave_sat + '--' + descripcion_sat AS descripcion 
                                        FROM catalogos_valores_sat_adam 
                                       WHERE tipo = 3 
                                       ORDER BY clave_sat";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public bool AltaRelacionRegimen(string compania, string trabajador, string regimen)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuerÿ = "sp_alta_rel_trab_regimen";

            SqlCommand sqlStmt = new SqlCommand(sqlQuerÿ, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char).Value = compania;
            sqlStmt.Parameters.Add("@trabajador", SqlDbType.Char).Value = trabajador;
            sqlStmt.Parameters.Add("@clave_regimen", SqlDbType.Char).Value = regimen;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public DataSet obtenDatasetFormaPago()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT clave_sat AS metodo_pago_sat, clave_sat + '--' + descripcion_sat AS descripcion
                                        FROM catalogos_valores_sat_adam
                                       WHERE tipo = 10
                                       ORDER BY clave_sat";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet ReadCSD()
        {
            int existCertTable;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            try
            {
                // Special Case  ADAM v5.4 & v5.3
                const string sqlQuery01 = @"SELECT COUNT(*) 
                                              FROM INFORMATION_SCHEMA.COLUMNS 
                                             WHERE TABLE_NAME = 'tb_keystore_global'";
                var sqlExistCertTable = new SqlCommand(sqlQuery01, sqlConnection);

                if (sqlExistCertTable.Connection == null)
                {
                    existCertTable = 0;
                }
                else
                {
                    if (sqlExistCertTable.Connection.State == ConnectionState.Closed)
                        sqlExistCertTable.Connection.Open();
                    existCertTable = int.Parse(sqlExistCertTable.ExecuteScalar().ToString());
                }
            }
            catch 
            { 
                return null; 
            }

            if (existCertTable > 0)
            {
                const string sqlQuery02 = @"SELECT tbkg1.client,
                                                   CASE 
                                                     WHEN tbkg1.key_data IS NOT NULL AND tbkg1.key_data != '' THEN 'ok'
                                                     ELSE 'error'
                                                   END as certificado,
                                                   CASE 
                                                     WHEN tbkg2.key_data IS NOT NULL AND tbkg2.key_data != '' THEN 'ok'
                                                     ELSE 'error'
                                                   END as llave,
                                                   CASE 
                                                     WHEN tbkg2.key_pass IS NOT NULL AND tbkg2.key_pass != '' THEN 'ok'
                                                     ELSE 'error'
                                                   END as [password],
	                                               tbkg1.key_data as cert_data,
	                                               tbkg2.key_data as key_data,
	                                               tbkg2.key_pass as password_data
                                              FROM tb_keystore_global tbkg1
                                               LEFT JOIN tb_keystore_global tbkg2 ON tbkg1.client = tbkg2.client
                                             WHERE tbkg1.int_type != tbkg2.int_type
                                               AND tbkg1.int_type LIKE '%cer%'";
                var sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);
                sqlStmt.Prepare();

                return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            }
            else
            {
                return null;
            }
        }

        public bool CreateReplaceCSD(byte[] certBytes, byte[] keyBytes, string client, string key_pass)
        {
            try
            {
                using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                if (sqlConnection.State == ConnectionState.Closed)
                    sqlConnection.Open();

                DeleteCSD(client);

                // Insert Certificate
                const string sqlQuery01 = @"INSERT INTO tb_keystore_global (client, int_type,key_type,key_pass,key_data ) 
                                           VALUES (@client, 'certificate','Privada','',@bitStringCert)";
                var sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
                
                sqlStmt.Parameters.Add(ParamClient, SqlDbType.VarChar, 15).Value = client;
                sqlStmt.Parameters.Add("@bitStringCert", SqlDbType.VarChar, 8000).Value = certBytes;
                sqlStmt.Prepare();

                SqlCommandExecutor.Request(sqlStmt, false);

                // Insert Key
                const string sqlQuery02 = @"INSERT INTO tb_keystore_global (client, int_type,key_type,key_pass,key_data ) 
                                            VALUES (@client,'key','Privada',@keyPass,@bitStringKey)";
                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);

                sqlStmt.Parameters.Add(ParamClient, SqlDbType.VarChar, 15).Value = client;
                sqlStmt.Parameters.Add("@keyPass", SqlDbType.VarChar, 50).Value = key_pass;
                sqlStmt.Parameters.Add("@bitStringKey", SqlDbType.VarChar, 8000).Value = keyBytes;
                sqlStmt.Prepare();

                SqlCommandExecutor.Request(sqlStmt, false);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteCSD(string client)
        {
            try
            {
                using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                if (sqlConnection.State == ConnectionState.Closed)
                    sqlConnection.Open();

                const string sqlQuery01 = @"DELETE FROM tb_keystore_global 
                                             WHERE client = @client 
                                               AND int_type = 'certificate'";
                var sqlStmt01 = new SqlCommand(sqlQuery01, sqlConnection);

                sqlStmt01.Parameters.Add(ParamClient, SqlDbType.VarChar, 15).Value = client;
                sqlStmt01.Prepare();

                SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt01));

                const string sqlQuery02 = @"DELETE FROM tb_keystore_global 
                                             WHERE client = @client
                                               AND int_type = 'key'";
                var sqlStmt02 = new SqlCommand(sqlQuery02, sqlConnection);

                sqlStmt02.Parameters.Add(ParamClient, SqlDbType.VarChar, 15).Value = client;
                sqlStmt02.Prepare();

                SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt02));

                return true;
            }
            catch 
            { 
                return false; 
            }
        }

        public DataSet obtenParametrosCompania(string compania)
        {
            try
            {
                using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                if (sqlConnection.State == ConnectionState.Closed)
                    sqlConnection.Open();

                const string sqlQuery = @"SELECT cc.pais, cc.parametro, 
                                                 cc.secuencia_parametro,
                                                 cc.compania, cc.fecha_vigencia, 
                                                 cc.tipo_nomina, cc.valor
                                            FROM parametros_compania cc 
                                              INNER JOIN aut_companias at ON at.compania = cc.compania 
                                           WHERE at.usuario = @user
                                             AND cc.compania = @company";
                var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

                sqlStmt.Parameters.Add(ParamUser, SqlDbType.VarChar, 10).Value = this._connectionFactory.ApplicationUser;
                sqlStmt.Parameters.Add(ParamCompany, SqlDbType.VarChar, 30).Value = compania;
                sqlStmt.Prepare();

                return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            }
            catch
            {
                return null;
            }
        }

    }
}

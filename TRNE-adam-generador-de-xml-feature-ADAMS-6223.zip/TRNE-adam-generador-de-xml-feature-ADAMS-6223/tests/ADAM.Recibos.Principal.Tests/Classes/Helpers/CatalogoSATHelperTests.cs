using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Principal.Test.Fakes;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Test.Classes.Helpers
{
    [TestClass]
    public class CatalogoSatHelperTests
    {
        #region Helpers

        private static FakeAppSettings CreateSqlSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "TestDB")
                .With(ConfigParameters.user.ToString(), "sa")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.version.ToString(), "5");
        }

        private static FakeAppSettings CreateOracleSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "ORCL")
                .With(ConfigParameters.user.ToString(), "system")
                .With(ConfigParameters.password.ToString(), "oracle")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.puertoOracle.ToString(), "1521")
                .With(ConfigParameters.tipoOracle.ToString(), "SERVICE_NAME");
        }

        private static FakeAppSettings CreateOdbcSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.dsn.ToString(), "TestDSN")
                .With(ConfigParameters.user.ToString(), "admin")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user");
        }

        #endregion

        #region CreateInstance - SQLServer

        [TestMethod]
        public void CreateInstance_SQLServer_ReturnsCatalogoSatSql()
        {
            var result = CatalogoSatHelper.CreateInstance(
                TipoPlataforma.SQLServer, CreateSqlSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoSatSql>(result);
        }

        #endregion

        #region CreateInstance - ORACLE

        [TestMethod]
        public void CreateInstance_Oracle_ReturnsCatalogoSatOracle()
        {
            var result = CatalogoSatHelper.CreateInstance(
                TipoPlataforma.ORACLE, CreateOracleSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoSatOracle>(result);
        }

        #endregion

        #region CreateInstance - ODBC

        [TestMethod]
        public void CreateInstance_ODBC_ReturnsCatalogoSatOdbc()
        {
            var result = CatalogoSatHelper.CreateInstance(
                TipoPlataforma.ODBC, CreateOdbcSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoSatOdbc>(result);
        }

        #endregion

        #region CreateInstance - Default

        [TestMethod]
        public void CreateInstance_InvalidPlatform_ReturnsCatalogoSatSql()
        {
            var result = CatalogoSatHelper.CreateInstance(
                (TipoPlataforma)999, CreateSqlSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoSatSql>(result);
        }

        #endregion

        #region CreateInstance - Interface

        [TestMethod]
        public void CreateInstance_AllPlatforms_ReturnICatalogoSat()
        {
            var sql = CatalogoSatHelper.CreateInstance(TipoPlataforma.SQLServer, CreateSqlSettings());
            var oracle = CatalogoSatHelper.CreateInstance(TipoPlataforma.ORACLE, CreateOracleSettings());
            var odbc = CatalogoSatHelper.CreateInstance(TipoPlataforma.ODBC, CreateOdbcSettings());

            Assert.IsInstanceOfType<ICatalogoSat>(sql);
            Assert.IsInstanceOfType<ICatalogoSat>(oracle);
            Assert.IsInstanceOfType<ICatalogoSat>(odbc);
        }

        #endregion
    }
}

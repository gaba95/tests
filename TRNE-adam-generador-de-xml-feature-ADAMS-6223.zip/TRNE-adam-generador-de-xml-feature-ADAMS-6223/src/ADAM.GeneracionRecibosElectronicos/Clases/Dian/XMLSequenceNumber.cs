﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("numeroSecuenciaXML", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class XMLSequenceNumber
    {
        [JsonProperty("codigoTrabajador")]
        public string CodigoTrabajador { get; set; }

        [JsonProperty("prefijo")]
        public string Prefijo { get; set; }

        [JsonProperty("consecutivo")]
        public string Consecutivo { get; set; }
        
        [JsonProperty("numero")]
        public string Numero { get; set; }
    }
}

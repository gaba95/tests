namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmCambiaMapeoSAT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCambiaMapeoSAT));
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdCambiar = new System.Windows.Forms.Button();
            this.cboDatoADAM = new System.Windows.Forms.ComboBox();
            this.lblDatoADAM = new System.Windows.Forms.Label();
            this.lblDescDatoSAT = new System.Windows.Forms.Label();
            this.lblDatoSAT = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(346, 200);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 13;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            this.cmdCerrar.Click += new System.EventHandler(this.cmdCerrar_Click);
            // 
            // cmdCambiar
            // 
            this.cmdCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCambiar.Location = new System.Drawing.Point(200, 200);
            this.cmdCambiar.Name = "cmdCambiar";
            this.cmdCambiar.Size = new System.Drawing.Size(110, 50);
            this.cmdCambiar.TabIndex = 12;
            this.cmdCambiar.Text = "&Asignar Dato";
            this.cmdCambiar.UseVisualStyleBackColor = true;
            this.cmdCambiar.Click += new System.EventHandler(this.cmdCambiar_Click);
            // 
            // cboDatoADAM
            // 
            this.cboDatoADAM.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboDatoADAM.DropDownWidth = 350;
            this.cboDatoADAM.FormattingEnabled = true;
            this.cboDatoADAM.Location = new System.Drawing.Point(206, 110);
            this.cboDatoADAM.Name = "cboDatoADAM";
            this.cboDatoADAM.Size = new System.Drawing.Size(250, 26);
            this.cboDatoADAM.TabIndex = 11;
            // 
            // lblDatoADAM
            // 
            this.lblDatoADAM.AutoSize = true;
            this.lblDatoADAM.Location = new System.Drawing.Point(200, 80);
            this.lblDatoADAM.Name = "lblDatoADAM";
            this.lblDatoADAM.Size = new System.Drawing.Size(68, 18);
            this.lblDatoADAM.TabIndex = 10;
            this.lblDatoADAM.Text = "Dato ADAM";
            // 
            // lblDescDatoSAT
            // 
            this.lblDescDatoSAT.Location = new System.Drawing.Point(10, 130);
            this.lblDescDatoSAT.Name = "lblDescDatoSAT";
            this.lblDescDatoSAT.Size = new System.Drawing.Size(180, 100);
            this.lblDescDatoSAT.TabIndex = 9;
            this.lblDescDatoSAT.Text = "----";
            // 
            // lblDatoSAT
            // 
            this.lblDatoSAT.Location = new System.Drawing.Point(10, 80);
            this.lblDatoSAT.Name = "lblDatoSAT";
            this.lblDatoSAT.Size = new System.Drawing.Size(180, 50);
            this.lblDatoSAT.TabIndex = 8;
            this.lblDatoSAT.Text = "Dato SAT:";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.Location = new System.Drawing.Point(10, 20);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(146, 60);
            this.lblDescripcion.TabIndex = 7;
            this.lblDescripcion.Text = "Relaciona el dato del SAT con los catálogos existentes de ADAM";
            // 
            // FrmCambiaMapeo
            // 
            this.AcceptButton = this.cmdCambiar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(484, 262);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdCambiar);
            this.Controls.Add(this.cboDatoADAM);
            this.Controls.Add(this.lblDatoADAM);
            this.Controls.Add(this.lblDescDatoSAT);
            this.Controls.Add(this.lblDatoSAT);
            this.Controls.Add(this.lblDescripcion);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCambiaMapeo";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asignar Valor Mapeo";
            this.Load += new System.EventHandler(this.FrmCambiaMapeo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Button cmdCambiar;
        private System.Windows.Forms.ComboBox cboDatoADAM;
        private System.Windows.Forms.Label lblDatoADAM;
        private System.Windows.Forms.Label lblDescDatoSAT;
        private System.Windows.Forms.Label lblDatoSAT;
        private System.Windows.Forms.Label lblDescripcion;
    }
}
﻿using ADAM.GeneracionRecibosElectronicos.Enums;
using ADAM.GeneracionRecibosElectronicos.Helpers;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Helpers
{
    [TestClass]
    public class ExtensionsTests
    {
        #region EmptyIfNull
        [TestMethod]
        public void EmptyIfNull_WhenNull_ReturnsEmptyString()
        {
            object? value = null;

            var result = value.EmptyIfNull();

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void EmptyIfNull_WhenNotNull_UsesToStringAndTrim()
        {
            object value = " TEST ";

            var result = value.EmptyIfNull();

            Assert.AreEqual("TEST", result);
        }

        [TestMethod]
        public void EmptyIfNull_WhenNotStringObject_UsesToStringAndTrim()
        {
            object value = 123456;

            var result = value.EmptyIfNull();

            Assert.AreEqual("123456", result);
        }
        #endregion

        #region FormatDate
        [TestMethod]
        public void FormatDate_WhenNull_ReturnsEmptyString()
        {
            object? value = null;

            var result = value.FormatDate("yyyyMMdd");

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void FormatDate_WhenValidDateString_ReturnsFormattedDate()
        {
            object value = "2026-02-09";

            var result = value.FormatDate("yyyyMMdd");

            Assert.AreEqual("20260209", result);
        }

        [TestMethod]
        public void FormatDate_WhenValidDateTime_ReturnsFormattedDate()
        {
            object value = new DateTime(2026, 02, 09, 0, 0, 0, DateTimeKind.Local);

            var result = value.FormatDate("dd/MM/yyyy");

            Assert.AreEqual("09/02/2026", result);
        }

        [TestMethod]
        public void FormatDate_WhenInvalidDate_ReturnsEmptyString()
        {
            object value = "not-a-valid-date";

            var result = value.FormatDate("yyyyMMdd");

            Assert.AreEqual(string.Empty, result);
        }

        #endregion

        #region FixedLenght

        [TestMethod]
        public void FixedLenght_WhenNull_PadsEmtptyToSize_RightByDefault()
        {
            object? value = null;
            var result = value.FixedLength(5);

            Assert.AreEqual("     ", result);
            Assert.AreEqual(5, result.Length);
        }

        [TestMethod]
        public void FixedLegth_WhenString_TrimThenPadsRight()
        {
            object value = "  abc  ";
            var result = value.FixedLength(7, PadType.Right, ('_'));

            Assert.AreEqual("abc____", result);
            Assert.AreEqual(7, result.Length);
        }

        [TestMethod]
        public void FixedLength_WhenString_TrimsThenPadsLeft()
        {
            object value = "  abc  ";
            var result = value.FixedLength(6, PadType.Left, '0');

            Assert.AreEqual("000abc", result);
            Assert.AreEqual(6, result.Length);
        }

        [TestMethod]
        public void FixedLength_WhenLongerThanSize_Truncates()
        {
            object value = "ABCDEFGHIJ";
            var result = value.FixedLength(4);

            Assert.AreEqual("ABCD", result);
            Assert.AreEqual(4, result.Length);
        }

        [TestMethod]
        public void FixedLength_WhenDecimal_FormatsWithFixedDecimals_ThenPadsOrTruncates()
        {
            object value = 12.3m;
            var result = value.FixedLength(size: 6, ePadType: PadType.Left, padChar: '0', decimals: 2);

            Assert.AreEqual("012.30", result);
            Assert.AreEqual(6, result.Length);
        }

        [TestMethod]
        public void FixedLength_WhenDecimal_AndSizeSmallerThanFormatted_Truncates()
        {
            object value = 123.456m;
            var result = value.FixedLength(size: 5, ePadType: PadType.Right, padChar: ' ', decimals: 2);

            Assert.AreEqual("123.4", result);
            Assert.AreEqual(5, result.Length);
        }

        #endregion

        #region FixedDecimals
        [TestMethod]
        public void FixedDecimals_WhenNull_ReturnsZeroString()
        {
            object? value = null;
            var result = value.FixedDecimals(2);

            Assert.AreEqual("0", result);
        }

        [TestMethod]
        public void FixedDecimals_WhenDecimal_ReturnsFormattedWithDecimals()
        {
            object value = 5m;
            var result = value.FixedDecimals(3);

            Assert.AreEqual("5.000", result);
        }

        [TestMethod]
        public void FixedDecimals_WhenString_ReturnsTrimmedString_NotFormatted()
        {
            object value = "  9.5  ";
            var result = value.FixedDecimals(2);

            Assert.AreEqual("9.5", result);
        }

        [TestMethod]
        public void FixedDecimals_WhenToStringThrows_ReturnsZero()
        {
            object value = new ThrowsOnToString();

            var result = value.FixedDecimals(2);

            Assert.AreEqual("0", result);
        }

        #endregion

        #region NoSpaceSequence
        [TestMethod]
        public void NoSpaceSequence_RemovesControlCharacters_AndTrims()
        {
            object value = " \tTest\r\n123\a\b ";
            var result = value.NoSpaceSequence();

            Assert.AreEqual("Test123",result);
        }

        [TestMethod]
        public void NoSpaceSequence_DoesNotRemoveInternalSpaces()
        {
            object value = "   123   ";
            var result = value.NoSpaceSequence();

            Assert.AreEqual("123", result);
        }

        #endregion

        [ExcludeFromCodeCoverage]
        private sealed class ThrowsOnToString
        {
            public override string ToString() => throw new InvalidOperationException("Error");
        }
    }
}

using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO.Compression;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ADAM.GeneracionRecibosElectronicos.Clases;
using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using ADAM.GeneracionRecibosElectronicos.Clases.Filter;
using ADAM.GeneracionRecibosElectronicos.UI;
using ADAM.Recibos.Controls;
using System.Windows.Forms;
using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmPrevisualizacionJson : Form
    {
        #region Enums
        public enum VisualizationType
        {
            Previsualization,
            Response
        }

        #endregion

        #region variables

        protected IJsonDIAN jsonDIAN;
        protected string filePath;
        protected string message;
        protected VisualizationType visualization;
        protected DgQuery queryTrabajadores;
        protected string rutaGenerador;
        protected string rutaArchivosSalida;

        #endregion

        #region Metodos

        private void FormatGridView()
        {

            gridDatosTrabajadores.AutoGenerateColumns = false;

            if (visualization == VisualizationType.Previsualization)
            {
                gridDatosTrabajadores.ColumnCount = 4;
            }
            if (visualization == VisualizationType.Response)
            {
                gridDatosTrabajadores.ColumnCount = 5;
            }

            gridDatosTrabajadores.Columns[0].Name = "employeeId";
            gridDatosTrabajadores.Columns[0].HeaderText = "Trabajador";
            gridDatosTrabajadores.Columns[0].DataPropertyName = "employeeId";

            gridDatosTrabajadores.Columns[1].Name = "nombreCompleto";
            gridDatosTrabajadores.Columns[1].HeaderText = "Nombre";
            gridDatosTrabajadores.Columns[1].DataPropertyName = "nombreCompleto";

            gridDatosTrabajadores.Columns[2].Name = "deduccionesTotal";
            gridDatosTrabajadores.Columns[2].HeaderText = "Deducciones";
            gridDatosTrabajadores.Columns[2].DataPropertyName = "deduccionesTotal";
            gridDatosTrabajadores.Columns[2].DefaultCellStyle.Format = "#,##0.00";

            gridDatosTrabajadores.Columns[3].Name = "devengadosTotal";
            gridDatosTrabajadores.Columns[3].HeaderText = "Devengados";
            gridDatosTrabajadores.Columns[3].DataPropertyName = "devengadosTotal";
            gridDatosTrabajadores.Columns[3].DefaultCellStyle.Format = "#,##0.00";

            if (visualization == VisualizationType.Response)
            {
                gridDatosTrabajadores.Columns[4].Name = "respuestaDianEstatus";
                gridDatosTrabajadores.Columns[4].HeaderText = "RespuestaDian";
                gridDatosTrabajadores.Columns[4].DataPropertyName = "respuestaDianEstatus";
            }

            gridTotales.AutoGenerateColumns = false;

            if (visualization == VisualizationType.Previsualization)
            {
                gridTotales.ColumnCount = 4;
            }
            if (visualization == VisualizationType.Response)
            {
                gridTotales.ColumnCount = 5;
            }

            gridTotales.Columns[0].Name = "employeeId";
            gridTotales.Columns[0].HeaderText = "Trabajador";
            gridTotales.Columns[0].DataPropertyName = "employeeId";

            gridTotales.Columns[1].Name = "nombreCompleto";
            gridTotales.Columns[1].HeaderText = "Nombre";
            gridTotales.Columns[1].DataPropertyName = "nombreCompleto";

            gridTotales.Columns[2].Name = "deduccionesTotal";
            gridTotales.Columns[2].HeaderText = "Deducciones";
            gridTotales.Columns[2].DataPropertyName = "deduccionesTotal";
            gridTotales.Columns[2].DefaultCellStyle.Format = "#,##0.00";

            gridTotales.Columns[3].Name = "devengadosTotal";
            gridTotales.Columns[3].HeaderText = "Devengados";
            gridTotales.Columns[3].DataPropertyName = "devengadosTotal";
            gridTotales.Columns[3].DefaultCellStyle.Format = "#,##0.00";

            if (visualization == VisualizationType.Response)
            {
                gridDatosTrabajadores.Columns[4].Name = "respuestaDianEstatus";
                gridDatosTrabajadores.Columns[4].HeaderText = "RespuestaDian";
                gridDatosTrabajadores.Columns[4].DataPropertyName = "respuestaDianEstatus";
            }
        }

        private void showJsonFileFull()
        {
            if (!string.IsNullOrEmpty(filePath) && 
                (filePath.EndsWith(".json", StringComparison.OrdinalIgnoreCase) ||
                 filePath.EndsWith(".html", StringComparison.OrdinalIgnoreCase)))
            {
                var safePath = Path.GetFullPath(Path.ChangeExtension(filePath, ".html"));
                ADAM.Recibos.Utilerias.Helpers.GlobalHelper.OpenFileSecure(safePath);
            }
        }

        private void DisplayTreeView(JToken root, string rootName)
        {
            trvJson.BeginUpdate();
            try
            {
                trvJson.Nodes.Clear();
                var tNode = trvJson.Nodes[trvJson.Nodes.Add(new TreeNode(rootName))];
                tNode.Tag = root;

                AddNode(root, tNode);

                trvJson.CollapseAll();

                //expand first node
                if (trvJson.Nodes.Count > 0)
                    trvJson.Nodes[0].Expand();
            }
            finally
            {
                trvJson.EndUpdate();
            }

            trvJson.Refresh();
        }

        private void AddNode(JToken token, TreeNode inTreeNode)
        {
            if (token == null)
                return;
            if (token is JValue)
            {
                var childNode = inTreeNode.Nodes[inTreeNode.Nodes.Add(new TreeNode(token.ToString()))];
                childNode.Tag = token;
            }
            else if (token is JObject)
            {
                var obj = (JObject)token;
                foreach (var property in obj.Properties())
                {
                    if (property.Name.Contains("respuestaDianMessage") | property.Name.Contains("codigoMensajeDian") | property.Name.Contains("respuestaDianEstatus"))
                    {
                        continue;
                    }

                    var childNode = inTreeNode.Nodes[inTreeNode.Nodes.Add(new TreeNode(property.Name))];
                    childNode.Tag = property;
                    AddNode(property.Value, childNode);
                }
            }
            else if (token is JArray)
            {
                var array = (JArray)token;
                for (int i = 0; i < array.Count; i++)
                {
                    var childNode = inTreeNode.Nodes[inTreeNode.Nodes.Add(new TreeNode(i.ToString()))];
                    childNode.Tag = array[i];
                    AddNode(array[i], childNode);
                }
            }

        }

        private void showJsonDIANOnTreeView(IJsonDIAN pJsonDIAN, string pTitle = "Json")
        {
            showObjectOnTreeView(pJsonDIAN, pTitle);
        }

        private void showObjectOnTreeView(Object pObject, string pTitle = "Json")
        {
            using (var reader = new StringReader(JsonConvert.SerializeObject(pObject, Formatting.Indented)))
            {
                using (var JsonReader = new JsonTextReader(reader))
                {
                    var root = JToken.Load(JsonReader);
                    DisplayTreeView(root, pTitle);
                }
            }
        }

        private void ExpandNodeTrabajador()
        {
            if (trvJson.Nodes.Count > 0 && trvJson.Nodes[0].Nodes.Count > 0)
            {
                foreach (TreeNode n in trvJson.Nodes[0].Nodes)
                {
                    if (n.Text == "trabajador")
                    {
                        trvJson.Nodes[0].Nodes[n.Index].Expand();
                    }
                }
            }
        }

        public DataTable GetDTfromDGV(DataGridView dgv)
        {
            DataTable dt = new DataTable();

            for (int ik = 0; ik < dgv.Columns.Count; ik++)
            {
                dt.Columns.Add(dgv.Columns[ik].HeaderText);
            }

            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                var dr = dt.NewRow();
                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    dr[j] = dgv.Rows[i].Cells[j].Value;
                }
                dt.Rows.Add(dr);
            }

            return dt;
        }

        #endregion

        #region Constructor

        public FrmPrevisualizacionJson(string pRutaGenerador, string pRutaArchivosSalida, IJsonDIAN pjsonDIAN, string filepath, string pCompany, string pYear, string pMonth, string pmessage, VisualizationType visualizationType = VisualizationType.Previsualization)
        {
            InitializeComponent();
            this.jsonDIAN = pjsonDIAN;
            this.filePath = filepath;
            this.message = pmessage;
            this.rutaGenerador = pRutaGenerador;
            this.rutaArchivosSalida = pRutaArchivosSalida;
            visualization = visualizationType;
        }

        #endregion

        #region Events

        private void gridDatosTrabajadores_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var grid = (DataGridView)sender;

            if (e.RowIndex < 0)
            {
                return;
            }

            DataRowView dr = (DataRowView)grid.Rows[e.RowIndex].DataBoundItem;
            string employeeid = dr["employeeId"].ToString();
            var employee = jsonDIAN.trabajador.FirstOrDefault(t => t.employeeId == employeeid);

            if (employee == null) return;

            showObjectOnTreeView(employee, employee.employeeId.Trim());
        }

        private void FrmPrevisualizacionJson_Load(object sender, EventArgs e)
        {
            FormatGridView();

            //create a new employee object to save totals for deducciones and devengados, in order to be added as datasources form gridTotales
            if (visualization == VisualizationType.Previsualization)
            {
                // Check if no employees are selected
                if (jsonDIAN.trabajador==null) { return;  }

                // Get Data
                gridDatosTrabajadores.DataSource = ListToDataTable.Convert<Employee>(jsonDIAN.trabajador);
                gridDatosTrabajadores.ClearSelection();

                Employee totales = new Employee();

                totales.employeeId = "---";
                totales.primerApellido = "---";
                totales.deduccionesTotal = jsonDIAN.trabajador.Sum(t => t.deduccionesTotal);
                totales.devengadosTotal = jsonDIAN.trabajador.Sum(t => t.devengadosTotal);


                List<Employee> totalesds = new List<Employee>();
                totalesds.Add(totales);

                gridTotales.DataSource = totalesds;

                lblTitulo.Text = "Visualización del Json ADAM - DIAN";
            }

            if (visualization == VisualizationType.Response)
            {
                // Check if no employees are selected
                if (jsonDIAN.trabajador == null) { return; }

                // Get Data
                gridDatosTrabajadores.DataSource = ListToDataTable.Convert<EmployeeFull>(jsonDIAN.trabajador);
                gridDatosTrabajadores.ClearSelection();

                EmployeeFull totales = new EmployeeFull();

                totales.employeeId = "---";
                totales.primerApellido = "---";
                totales.deduccionesTotal = jsonDIAN.trabajador.Sum(t => t.deduccionesTotal);
                totales.devengadosTotal = jsonDIAN.trabajador.Sum(t => t.devengadosTotal);
                totales.respuestaDian = new Notificaciones();


                List<EmployeeFull> totalesds = new List<EmployeeFull>();
                totalesds.Add(totales);

                gridTotales.DataSource = totalesds;
                lblTitulo.Text = "Visualización del Json Respuesta - DIAN";

                var correctValues = (from DataGridViewRow r in gridDatosTrabajadores.Rows
                                    where r.Cells["respuestaDianEstatus"].Value.ToString() == "Correcto"
                                    select r.Cells["respuestaDianEstatus"].Value
                                    ).Count();
               
                int incorrectValues = (from DataGridViewRow r in gridDatosTrabajadores.Rows
                                    where r.Cells["respuestaDianEstatus"].Value.ToString() == "Incorrecto"
                                    select r.Cells["respuestaDianEstatus"].Value
                                    ).Count();

                lbStatus.Items.Add("Correctos " + correctValues.ToString());
                lbStatus.Items.Add("Incorrectos " + incorrectValues.ToString());
            }

            showJsonDIANOnTreeView(jsonDIAN);

            ExpandNodeTrabajador();

            // Zip Output Folder
            var zipFile = $"{this.rutaArchivosSalida}.zip";
            ZipFile.CreateFromDirectory(rutaArchivosSalida, zipFile);

            // Shows confirmation message
            CustomMessageBox.Show(this.message, "ADAM",
                                  $"Descargar archivo: {Path.GetFileName(zipFile)}",
                                  zipFile,
                                  MessageBoxIcon.Information);
        }

        private void cmdSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdGuardar_Click(object sender, EventArgs e)
        {
            showJsonFileFull();
        }

        private void cmdVerTodos_Click(object sender, EventArgs e)
        {
            showJsonDIANOnTreeView(jsonDIAN);
            gridDatosTrabajadores.ClearSelection();
            ExpandNodeTrabajador();
        }

        private void gridDatosTrabajadores_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //if cell painting is header (rowindex -1) put the icon at the end of the cell
            if (e.RowIndex == -1)
            {
                Rectangle r = new Rectangle(e.CellBounds.X + e.CellBounds.Width - 15, e.CellBounds.Y + (e.CellBounds.Height / 2) - 5, 10, 10);
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                e.Graphics.DrawImage(Properties.Resources.down_arrow, r);
                e.Handled = true;
            }
        }

        private void gridDatosTrabajadores_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //get the column that fires the event
            var pColumn = gridDatosTrabajadores.Columns[e.ColumnIndex];

            //get the unique values of the column
            var uniqueValues = (from DataRow r in ((DataTable)gridDatosTrabajadores.DataSource).Rows
                                select r[pColumn.Name]).Distinct();


            FrmFilterSortDialog filtersort = new FrmFilterSortDialog(queryTrabajadores, pColumn, pColumn.ValueType, uniqueValues);

            //get the rectangle in screen for the cell that fires the event
            var colCoordinates = gridDatosTrabajadores.GetCellDisplayRectangle(pColumn.Index, 0, true);

            //set location of the frmfiltersordialog based on the cell that fires the event
            if (pColumn.Width > filtersort.Width)
            {
                filtersort.Width = pColumn.Width;
                filtersort.Location = new Point(colCoordinates.X + pColumn.Width - filtersort.Width, pnlInferior.Location.Y + gridDatosTrabajadores.Location.Y + gridDatosTrabajadores.ColumnHeadersHeight + colCoordinates.Height);
            }
            else
            {
                filtersort.Location = new Point(colCoordinates.X, pnlInferior.Location.Y + gridDatosTrabajadores.Location.Y + gridDatosTrabajadores.ColumnHeadersHeight + colCoordinates.Height);
            }

            filtersort.ShowDialog();

            applyfilter(pColumn, filtersort.Query, filtersort.isSorted, filtersort.Sort);
        }

        private void applyfilter(DataGridViewColumn pColumn, DgQuery pQuery, bool pIsSorted = false, System.ComponentModel.ListSortDirection plistSortDirection = System.ComponentModel.ListSortDirection.Descending)
        {
            //que the query object result
            queryTrabajadores = pQuery;

            //check if sorted is needed
            if (plistSortDirection == System.ComponentModel.ListSortDirection.Ascending && pIsSorted)
            {
                gridDatosTrabajadores.Sort(gridDatosTrabajadores.Columns[pColumn.Index], System.ComponentModel.ListSortDirection.Ascending);
            }

            if (plistSortDirection == System.ComponentModel.ListSortDirection.Descending && pIsSorted)
            {
                gridDatosTrabajadores.Sort(gridDatosTrabajadores.Columns[pColumn.Index], System.ComponentModel.ListSortDirection.Descending);
            }

            //if a query is set for the column the column change forecolor to red if not default black
            if (queryTrabajadores.FilterEnumerable.Any(t => t.ColumnIndex == pColumn.Index))
            {
                gridDatosTrabajadores.EnableHeadersVisualStyles = false;
                gridDatosTrabajadores.Columns[pColumn.Index].HeaderCell.Style.ForeColor = Color.Blue;
            }
            else
            {
                gridDatosTrabajadores.EnableHeadersVisualStyles = false;
                gridDatosTrabajadores.Columns[pColumn.Index].HeaderCell.Style.ForeColor = Color.Black;
            }

            //get the query result to apply on the grid
            var myquery = queryTrabajadores.GetQuery();

            ((DataTable)gridDatosTrabajadores.DataSource).DefaultView.RowFilter = myquery;
        }

        private void gridDatosTrabajadores_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            e.Column.SortMode = DataGridViewColumnSortMode.Programmatic;
        }

        #endregion
    }
}

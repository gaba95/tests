using System;
using System.Collections.Generic;
using System.Configuration;

namespace ADAM.Recibos.Datos.Tests.Fakes
{
    public sealed class FakeAppSettings : ApplicationSettingsBase
    {
        private readonly Dictionary<string, object> _values = new(StringComparer.OrdinalIgnoreCase);

        public FakeAppSettings With(string key, object value)
        {
            _values[key] = value;
            return this;
        }

        public override object this[string propertyName]
        {
            get
            {
                if (_values.TryGetValue(propertyName, out var v))
                    return v;
                return string.Empty;
            }
            set => _values[propertyName] = value;
        }
    }
}

using System;
using System.Data;
using System.Configuration;
using ADAM.Recibos.Datos.Utils;
using Oracle.ManagedDataAccess.Client;
using ADAM.Recibos.Datos.Clases.Common;

namespace ADAM.Recibos.Datos.Clases.CatalogoSAT
{
    public class CatalogoSatOracle : ICatalogoSat
    {
        private const string ParamTipo = "i_tipo";
        private const string ParamCompania = "i_compania";

        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoSatOracle(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public DataSet dsListaCatalogosSAT()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT item AS clave, descripcion
                                           FROM criterios_valores
                                          WHERE campo = 'tipo_catalogo_sat'";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetCatalogosSAT(string tipo)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT tipo,clave_sat,descripcion_sat
                                           FROM catalogos_valores_sat_adam
                                          WHERE tipo = @tipo";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@tipo", OracleDbType.Varchar2).Value = tipo;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetCatalogos(string tabla)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT * FROM @table";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@table", OracleDbType.Varchar2).Value = tabla;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenCatalogoADAM(string tipo, string compania)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_consulta_catalogos_adam";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamTipo, OracleDbType.Char).Value = tipo;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = compania;
            oracleStmt.Parameters.Add(new OracleParameter("i_return_value", OracleDbType.RefCursor, 0, ParameterDirection.Output, false, 0, 0, "", DataRowVersion.Current, null));
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetRelacionCatalogosSATADAM(string tipo, string claveSAT, string compania)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_consulta_rel_datos_sat_adam";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamTipo, OracleDbType.Char).Value = tipo;
            oracleStmt.Parameters.Add("i_clave_sat", OracleDbType.Char).Value = claveSAT;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = compania;
            oracleStmt.Parameters.Add(new OracleParameter("i_return_value", OracleDbType.RefCursor, 0, ParameterDirection.Output, false, 0, 0, "", DataRowVersion.Current, null));
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public bool AltaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_alta_dato_cat_sat_adam";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamTipo, OracleDbType.Int16).Value = tipo;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = compania;
            oracleStmt.Parameters.Add("i_clave_sat", OracleDbType.Char).Value = claveSAT.Trim();
            oracleStmt.Parameters.Add("i_clave_adam", OracleDbType.Char).Value = claveADAM.Trim();
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(oracleStmt, false);
        }

        public bool BajaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_baja_dato_cat_sat_adam";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamTipo, OracleDbType.Int16).Value = tipo;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = compania;
            oracleStmt.Parameters.Add("i_clave_sat", OracleDbType.Char).Value = claveSAT;
            oracleStmt.Parameters.Add("i_clave_adam", OracleDbType.Char).Value = claveADAM;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(oracleStmt, false);
        }
    }
}

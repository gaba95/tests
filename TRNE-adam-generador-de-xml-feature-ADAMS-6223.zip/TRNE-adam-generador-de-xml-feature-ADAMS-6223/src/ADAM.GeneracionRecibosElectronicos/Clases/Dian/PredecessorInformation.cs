﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("informacionPredecesor", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PredecessorInformation
    {
        public string cunePred { get; set; }
        public string numeroPred { get; set; }
        public string fechaGenPred { get; set; }
        public int tipoNota { get; set; }
    }
}

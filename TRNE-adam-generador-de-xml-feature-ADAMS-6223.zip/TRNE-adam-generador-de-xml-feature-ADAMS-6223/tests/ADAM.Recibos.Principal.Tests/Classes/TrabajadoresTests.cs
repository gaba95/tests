﻿using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Tests.Classes
{
    [TestClass]
    public class TrabajadoresTests
    {
        [TestMethod]
        public void Trabajador_Should_Assign_All_Properties_Correctly()
        {
            // Arrange
            var trabajador = new Trabajador
            {
                numTrabajador = "12345",
                claseNomina = "A",
                numeroLiquidacion = 10,
                periodo = 202401,
                esTimbradoRelacionado = true,
                pagoSeparacion = 2,
                tipoNomina = "ORD",
                anio = 2024,
                manejoNomina = ManejoNomina.interactiva
            };

            // Assert
            Assert.AreEqual("12345", trabajador.numTrabajador);
            Assert.AreEqual("A", trabajador.claseNomina);
            Assert.AreEqual(10, trabajador.numeroLiquidacion);
            Assert.AreEqual(202401, trabajador.periodo);
            Assert.IsTrue(trabajador.esTimbradoRelacionado);
            Assert.AreEqual(2, trabajador.pagoSeparacion);
            Assert.AreEqual("ORD", trabajador.tipoNomina);
            Assert.AreEqual(2024, trabajador.anio);
            Assert.AreEqual(ManejoNomina.interactiva, trabajador.manejoNomina);
        }
    
        [TestMethod]
        public void Trabajadores_Should_Behave_As_List()
        {
            // Arrange
            var trabajadores = new Trabajadores();
            var trabajador = new Trabajador { numTrabajador = "001" };

            // Act
            trabajadores.Add(trabajador);

            // Assert
            Assert.HasCount(1, trabajadores);
            Assert.AreEqual("001", trabajadores[0].numTrabajador);
        }

        [TestMethod]
        public void Trabajadores_Should_Allow_Initialization_With_Collection()
        {
            // Arrange
            var initialList = new List<Trabajador>
            {
                new() { numTrabajador = "A1" },
                new() { numTrabajador = "A2" }
            };

            var trabajadores = new Trabajadores();
            trabajadores.AddRange(initialList);

            // Assert
            Assert.HasCount(2, trabajadores);
            CollectionAssert.AreEqual(initialList, trabajadores);
        }
    }
}


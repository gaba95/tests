﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAM.Recibos.Principal.Test.Helpers
{
    internal sealed class TestTempDirectory : IDisposable
    {
        public string PathValue {get;}

        public TestTempDirectory(string prefix)
        {
            PathValue = System.IO.Path.Combine(System.IO.Path.GetTempPath(), prefix, Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(PathValue);  
        }

        public void Dispose()
        {
            try
            {
                if (Directory.Exists(PathValue))
                {
                    Directory.Delete(PathValue, recursive: true);
                }
            }
            catch
            {

            }
        }

    }
}

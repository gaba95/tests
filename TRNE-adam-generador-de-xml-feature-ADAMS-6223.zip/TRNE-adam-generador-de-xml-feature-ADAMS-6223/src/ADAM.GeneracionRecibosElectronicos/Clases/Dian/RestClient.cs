using ADAM.Recibos.Utilerias.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security;
using System.Text.Encodings.Web;
using System.Text.RegularExpressions;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    #region Login 
    
    public class Content
    {
        public string jwt { get; set; }
    }

    public class LoginRequest
    {
        public string login { get; set; }

        [JsonProperty("password")]
        public string value { get; set; }
    }

    public class LoginResponse
    {
        public string type { get; set; }
        public string validationMessage { get; set; }
        public Content content { get; set; }
    }

    #endregion

    #region Payroll
    
    public class AddPayrollRequest
    {
        public string json { get; set; }
    }

    public class AddPayrollResponse
    {
        public string message { get; set; }
        [JsonExtensionData]
        public Dictionary<string, object> errores { get; set; }
        public List<Notificaciones> notificaciones { get; set; }
    }

    public class AddGlobalPayrollResponse
    {
        public string message { get; set; }
        [JsonExtensionData]
        public Dictionary<string, object> errores { get; set; }
    }

    public class ResultadoValidacion
    {
        public string documentoID { get; set; }
        public string errorCode { get; set; }
        public string errorMessage { get; set; }
        public string fechaInicioPeriodo { get; set; }
        public string identificacion { get; set; }
        public string numeroDocumento { get; set; }
        public string propertyName { get; set; }
        public string tipoDocumento { get; set; }
        public string trabajador { get; set; }
    }

    public class Notificaciones
    {
        public string categoriaMensaje { get; set; }
        public string codigoMensaje { get; set; }
        public string mensaje { get; set; }
        public string documentoID { get; set; }
        public string estadoAccion { get; set; }
        public string tipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public List<ResultadoValidacion> resultadoValidacion { get; set; }
    }

    #endregion

    #region DocumentState
    
    public class DianErrors
    {
        public string code { get; set; }
        public string description { get; set; }
    }

    public class DocumentStateResponse
    {
        public string estadoDocumento { get; set; }
        public DateTime fechaGeneracion { get; set; }
        public string cune { get; set; }
        public string numeroDocumento { get; set; }
        public List<DianErrors> dianErrors { get; set; }
    }

    #endregion

    #region RestApiClient

    public class RestApiClient
    {
        #region Properties

        
        public string endPoint { get; set; }

        public string userName { get; set; }

        public SecureString userPwd { get; set; }

        public string json { get; set; }

        #endregion

        #region Methods
        
        public RestApiClient()
        {
            endPoint = string.Empty;
        }
        
        public LoginResponse LoginRequest()
        {
            LoginResponse loginResponse = new LoginResponse();

            try 
            {
                HttpClientHandler handler = new HttpClientHandler
                {
                    AllowAutoRedirect = true,
                    MaxAutomaticRedirections = 2
                };

                using (var client = new HttpClient(handler))
                {
                    // Http Client Properties
                    client.BaseAddress = new Uri(endPoint);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    // Set Security
                    System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)(0xc0 | 0x300 | 0xc00);  // .Net Framework 4.0 missing values

                    // Set Login Request
                    var loginRequest = new LoginRequest() 
                    { 
                        login = userName,
                        value = new NetworkCredential(string.Empty, userPwd).Password
                    };

                    // Send Post
                    HttpResponseMessage response = client.PostAsJsonAsync("api/security/login", loginRequest).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        loginResponse = response.Content.ReadFromJsonAsync<LoginResponse>().Result;
                    }
                    else
                    {
                        loginResponse.content = new Content();
                        loginResponse.type = response.StatusCode.ToString();
                        loginResponse.validationMessage = response.ReasonPhrase;
                    }
                }
            }
            catch(Exception ex)
            {
                loginResponse.type = "Error";
                loginResponse.validationMessage = ex.Message;
            }
 
            return loginResponse;
        }
        
        public AddPayrollResponse AddPayrollRequest(string szUserId, string szAccessToken)
        {
            AddPayrollResponse addPayrollResponse = new AddPayrollResponse
            {
                notificaciones = []
            };

            try
            {
                HttpClientHandler handler = new HttpClientHandler
                {
                    AllowAutoRedirect = true,
                    MaxAutomaticRedirections = 2
                };

                using (var client = new HttpClient(handler))
                {
                    // Clean UserID
                    Regex rxNonAlpha = new Regex("[^0-9]", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(500));
                    string WSUserID = rxNonAlpha.Replace(szUserId, "");

                    // Http Client Properties
                    client.BaseAddress = new Uri(endPoint);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    // Set Security
                    System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)(0xc0 | 0x300 | 0xc00);  // .Net Framework 4.0 missing values

                    // Add Bearer Token
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", szAccessToken);

                    // Add Querystring Parameters
                    var queryParams = new Dictionary<string, string>
                    {
                        { "TipoDocumentoEmpleador", "NI" },
                        { "NumeroDocumentoEmpleador", WSUserID }
                    };
                    var queryString = string.Join("&", queryParams.Select(p => $"{p.Key}={Uri.EscapeDataString(p.Value)}"));

                    // Timeout
                    client.Timeout = TimeSpan.FromMinutes(10);

                    // Send Post
                    var response = client.PostAsync($"api/Nomina/AgregarNomina?{queryString}", null).Result;

                    // Get Results
                    if (response.IsSuccessStatusCode)
                    {
                        addPayrollResponse = JsonConvert.DeserializeObject<AddPayrollResponse>(response.Content.ToString());
                    }
                    else
                    {
                        Notificaciones notificaciones = new Notificaciones();
                        notificaciones.mensaje = response.ReasonPhrase;
                        addPayrollResponse.notificaciones.Add(notificaciones);
                    }
                }
            }
            catch(Exception ex)
            {
                Notificaciones notificaciones = new Notificaciones();
                notificaciones.mensaje = ex.Message;
                addPayrollResponse.notificaciones.Add(notificaciones);
            }

            return addPayrollResponse;
        }

        public DocumentStateResponse getDocumentState(string szAccessToken, string szUserId, string documentoId, DateTime fechaDocumento)
        {
            DocumentStateResponse documenState = new DocumentStateResponse
            {
                dianErrors = []
            };

            try
            {
                HttpClientHandler handler = new HttpClientHandler
                {
                    AllowAutoRedirect = true,
                    MaxAutomaticRedirections = 2
                };

                using (var client = new HttpClient(handler))
                {
                    // Clean UserID
                    Regex rxNonAlpha = new Regex("[^0-9]", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(500));
                    string WSUserID = rxNonAlpha.Replace(szUserId, "");

                    // Http Client Properties
                    client.BaseAddress = new Uri(endPoint);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    // Set Security
                    System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)(0xc0 | 0x300 | 0xc00);  // .Net Framework 4.0 missing values

                    // Add Bearer Token
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", szAccessToken);

                    // Add Querystring Parameters
                    var queryParams = new Dictionary<string, string>
                    {
                        { "TipoDocumentoEmpleador", "NI" },
                        { "NumeroDocumentoEmpleador", WSUserID },
                        { "DocumentoID", documentoId },
                        { "FechaDocumento", fechaDocumento.ToString() }
                    };
                    var queryString = string.Join("&", queryParams.Select(p => $"{p.Key}={Uri.EscapeDataString(p.Value)}"));

                    string sanitizedUrl = client.BaseAddress.AbsoluteUri;
                    string sanitizedEndPoint = UrlEncoder.Default.Encode($"api/Nomina/EstadoDocumentoNomina?{queryString}");
                    GlobalHelper.ValidateUrl(sanitizedUrl);

                    var fullUrl = new Uri($"{sanitizedUrl}{sanitizedEndPoint}");

                    // Send Post
                    client.Timeout = TimeSpan.FromMinutes(10);
                    var response = client.PostAsync(fullUrl, null).Result;

                    // Get Results
                    if (response.IsSuccessStatusCode)
                    {
                        documenState = JsonConvert.DeserializeObject<DocumentStateResponse>(response.Content.ToString());
                    }
                    else
                    {
                        DianErrors errDian = new DianErrors();
                        errDian.description = response.ReasonPhrase;
                        documenState.dianErrors.Add(errDian);
                    }
                }
            }
            catch (Exception ex)
            {
                DianErrors errDian = new DianErrors();
                errDian.description = ex.Message;
                documenState.dianErrors.Add(errDian);
            }

            return documenState;
        }

		#endregion
	}
    #endregion
}
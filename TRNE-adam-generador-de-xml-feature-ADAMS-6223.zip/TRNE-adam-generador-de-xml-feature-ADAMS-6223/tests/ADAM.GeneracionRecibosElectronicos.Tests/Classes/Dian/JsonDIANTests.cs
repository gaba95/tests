using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using Newtonsoft.Json;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class JsonDIANTests
    {
        private static string CreateIsolatedTempDirectory()
        {
            string dir = Path.Combine(Path.GetTempPath(), "JsonDIANTests_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            return dir;
        }

        [TestMethod]
        public void WriteJsonRequest_CreateFiles_AndReturnsHtmlPath()
        {
            string tempDir = CreateIsolatedTempDirectory();

            try
            {
                var sut = new JsonDian
                {
                    trabajador = null
                };

                string company = "ACME";
                string year = "2026";
                string month = "02";

                string returnedHtmlPath = sut.WriteJsonRequest(tempDir, company, year, month);

                Assert.IsFalse(string.IsNullOrEmpty(returnedHtmlPath), "Method should return the HTML file path.");
                Assert.IsTrue(File.Exists(returnedHtmlPath), "Returned HTML file must exist.");
                Assert.AreEqual(".html", Path.GetExtension(returnedHtmlPath), "Returned File must have .html extensio.n");
                Assert.AreEqual(tempDir, Path.GetDirectoryName(returnedHtmlPath), "Returned path must be under the target directory.");

                string prefix = $"DIAN_COL_{company}_{year}-{month}_";
                var jsonFiles = Directory.GetFiles(tempDir, $"{prefix}*_Request.json");
                var htmlFIles = Directory.GetFiles(tempDir, $"{prefix}*_Request.html");

                Assert.AreEqual(1, jsonFiles.Length, "Exactly one JSON file should be created.");
                Assert.AreEqual(1, htmlFIles.Length, "Exactly one HTML file should be created.");
                Assert.AreEqual(Path.GetFullPath(htmlFIles[0]), Path.GetFullPath(returnedHtmlPath), "Returned path should match the created HTML file.");

                string jsonFromFile = File.ReadAllText(jsonFiles[0]);
                string expectedJson = JsonConvert.SerializeObject(sut, Formatting.Indented);
                Assert.AreEqual(expectedJson, jsonFromFile, "JSON content shlud match serialized object.");

                string htmlFromFile = File.ReadAllText(htmlFIles[0]);
                string expectedHtml = $"<html><body><pre><code>{expectedJson}</code></pre></body></html>";
                Assert.AreEqual(expectedHtml, htmlFromFile, "HTML file should wrap JSON inside <pre><code>...</code></pre>.");

            }
            finally
            {
                if (Directory.Exists(tempDir))
                {
                    try 
                    { 
                        Directory.Delete(tempDir, recursive: true); 
                    } 
                    catch 
                    { 
                        // Best-effort cleanup: ignore failures deleting temp directory
                    }
                }
            }
        }

        [TestMethod]
        public void WriteJsonRequest_ReturnsEmptyString_OnException()
        {
            var sut = new JsonDian();

            string returnedHtmlPath = sut.WriteJsonRequest(null, "ACME", "2026", "02");

            Assert.AreEqual(string.Empty, returnedHtmlPath, "Mehot should return empty string when an exception occurs.");
        }

        [TestMethod]
        public void JsonDianByEmployee_SetsSingleEmployee_AndReturnsSameInstance()
        {
            var sut = new JsonDian();
            var employeeMock = new Moq.Mock<Employee>();
            var employee = employeeMock.Object;

            IJsonDIAN result = sut.JsonDianByEmployee(employee);

            Assert.AreSame(sut, result, "JsonDianByEmployee should return the same instance (this).");
            Assert.IsNotNull(sut.trabajador, "trabajador list should be initialized.");
            Assert.AreEqual(1, sut.trabajador.Count, "trabajador list should contain exactly one employee.");
            Assert.AreSame(employee, sut.trabajador[0], "The provided employee should be the only item in the list.");
        }

        [TestMethod]
        public void JsonDianByEmployee_ReplacesExistingList_WithNewSingleEmployee()
        {
            var sut = new JsonDian();
            var employee1 = new Mock<IEmployee>().Object;
            var employee2 = new Mock<IEmployee>().Object;

            sut.JsonDianByEmployee(employee1);
            Assert.AreEqual(1, sut.trabajador.Count, "PreCondition: First call shlud set one employee.");
            Assert.AreSame(employee1, sut.trabajador[0], "PreCondition: employee1 should be present.");

            sut.JsonDianByEmployee(employee2);

            Assert.IsNotNull(sut.trabajador, "trabajador list should still be initialized.");
            Assert.AreEqual(1, sut.trabajador.Count, "List should be replaced with a single employee.");
            Assert.AreSame(employee2, sut.trabajador[0], "The new employee should replace the previous one.");

        }
    }
}

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows.Forms;
using ADAM.GeneracionRecibosElectronicos.Clases.Filter;

namespace ADAM.GeneracionRecibosElectronicos.UI
{
    [ExcludeFromCodeCoverage]
    public partial class FrmFilterSortDialog : Form
    {
        #region Properties

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DgQuery Query { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ListSortDirection Sort { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool isSorted { get; set; }

        #endregion

        #region Variables

        private DgFilter filter { get; set; }
        private DgFilter initFilter { get; set; }
        private DataGridViewColumn column { get; set; }

        private Type colValueType { get; set; }

        private IEnumerable<object> uniqueValues;

        private bool unSelectAll = true;

        #endregion

        #region constants

        const string SeleccionarTodos = "Seleccionar Todos";

        #endregion

        #region Constructors

        /// <summary>
        /// constructor for the class
        /// </summary>
        /// <param name="pQuery">Query Object</param>
        /// <param name="pColumn">Column to Work</param>
        /// <param name="pColValueType">Value Type for values of the Column on the grid</param>
        /// <param name="pUniqueValues">List of Unique Values to show in checkbox</param>
        public FrmFilterSortDialog(DgQuery pQuery, DataGridViewColumn pColumn, Type pColValueType, IEnumerable<object> pUniqueValues)
        {
            InitializeComponent();

            // Set Query Objects
            Query = (pQuery is null ? new DgQuery() : pQuery);
            column = pColumn;
            colValueType = pColValueType;

            // Get the filter applied to the column if exist
            filter = Query.FilterEnumerable.FirstOrDefault(t => t.ColumnIndex == pColumn.Index);
            if (filter != null)
                initFilter = (DgFilter)filter.Clone();

            uniqueValues = pUniqueValues;

            // Sorted is needed as false in order to not fires a reorder when the window is closed if is not neccesary
            isSorted = false;
        }

        #endregion

        #region Methods

        #region ChkUniqueValueToogleCheck
        /// <summary>
        /// check or uncheck all items
        /// </summary>
        /// <param name="check"></param>
        private void ChkUniqueValueToogleCheck(bool check)
        {
            for (int i = 1; i < chkUniqueValues.Items.Count; i++)
                chkUniqueValues.SetItemChecked(i, check);
        }
        #endregion

        #region SetNumInValues
        /// <summary>
        /// Creates a comma separated string with all checked values
        /// </summary>
        /// <returns></returns>
        private string SetNumInValues()
        {
            Array items = new object[chkUniqueValues.CheckedItems.Count];
            chkUniqueValues.CheckedItems.CopyTo(items, 0);

            string value = "";

            foreach (object i in items)
            {
                filter.RawValue.Add(i);
                value += i.ToString() + ",";
            }

            return value.Remove(value.Length - 1, 1);
        }
        #endregion

        #region SetStringInValues
        /// <summary>
        /// Creates a comma separated string with all checked values including '' characters
        /// </summary>
        /// <returns></returns>
        private string SetStringInValues()
        {
            Array items = new object[chkUniqueValues.CheckedItems.Count];
            chkUniqueValues.CheckedItems.CopyTo(items, 0);

            string value = "";

            foreach (object i in items)
            {
                filter.RawValue.Add(i);
                value += "'" + i.ToString() + "',";
            }

            return value.Remove(value.Length - 1, 1);
        }
        #endregion

        #region RemoveFilter
        /// <summary>
        /// Delete the filter applied to the column in Query.filterEnumerable List
        /// </summary>
        private void RemoveFilter()
        {
            var actualfilter = Query.FilterEnumerable.FirstOrDefault(t => t.ColumnIndex == column.Index);
            if (actualfilter != null)
            {
                Query.FilterEnumerable.Remove(actualfilter);
            }
        }
        #endregion

        #region AddtoFilter
        /// <summary>
        /// Take the actual filter and create new one to merge together
        /// </summary>
        private void AddtoFilter()
        {
            DgFilter actualfilter = null;

            if (chkUniqueValues.CheckedItems.Count > 0)
            {
                actualfilter = Query.FilterEnumerable.FirstOrDefault(t => t.ColumnIndex == column.Index);

                // If items checked, remove any actual filter, create a new one to be added to the list of the Query Object
                RemoveFilter();

                filter = new DgFilter(column.Index, column.Name, Enums.ColumnValueType.Num);
                filter.Comparation = Enums.ComparationOperator.In;
                filter.Condition = Enums.ConditionalOperator.And;

                short coltype = (short)Enums.ColumnValueType.Num;
                string value = SetNumInValues();

                if (colValueType == typeof(string))
                {
                    coltype = (short)Enums.ColumnValueType.String;
                    value = SetStringInValues();
                }

                if (colValueType == typeof(DateTime))
                {
                    coltype = (short)Enums.ColumnValueType.Date;
                    value = SetStringInValues();
                }

                filter.ColValueType = (Enums.ColumnValueType)coltype;
                filter.Value = value;

                //if actual filter is null dont need to merge just copy it
                if (actualfilter == null)
                {
                    actualfilter = filter;
                }
                else
                {
                    //if new filter contains values merge with actualfilter
                    if (filter.RawValue.Count > 0)
                    {
                        actualfilter.RawValue.AddRange(filter.RawValue);
                        actualfilter.Value += "," + filter.Value;
                    }
                }

                Query.FilterEnumerable.Add(actualfilter);

                //filter needs to be equal to the adding filter
                filter = actualfilter;
                txtFilter.Text = "";
                cmdAddToFilter.Enabled = false;
            }
        }
        #endregion

        #region CreateNewFilter
        /// <summary>
        /// Create new DgFilter
        /// </summary>
        private void CreateNewFilter()
        {
            // If items checked, remove any actual filter, create a new one to be added to the list of the Query Object
            RemoveFilter();
            filter = new DgFilter(column.Index, column.Name, Enums.ColumnValueType.Num);
            filter.Comparation = Enums.ComparationOperator.In;
            filter.Condition = Enums.ConditionalOperator.And;

            short coltype = (short)Enums.ColumnValueType.Num;
            string value = SetNumInValues();

            if (colValueType == typeof(string))
            {
                coltype = (short)Enums.ColumnValueType.String;
                value = SetStringInValues();
            }

            if (colValueType == typeof(DateTime))
            {
                coltype = (short)Enums.ColumnValueType.Date;
                value = SetStringInValues();
            }

            filter.ColValueType = (Enums.ColumnValueType)coltype;
            filter.Value = value;

            Query.FilterEnumerable.Add(filter);
        }
        #endregion 

        #endregion

        #region Events

        #region cmdClose_Click
        /// <summary>
        /// Close the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdClose_Click(object sender, EventArgs e)
        {
            if (initFilter != null && filter != null && initFilter.Value != filter.Value)
            {
                filter = initFilter;
            }

            Close();
        }
        #endregion

        #region FrmFilterSortDialog_Load
        /// <summary>
        /// Load the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmFilterSortDialog_Load(object sender, EventArgs e)
        {
            lblColumnName.Text = column.HeaderText;

            // Set source to autcomplete of filter textbox
            AutoCompleteStringCollection colSource = new AutoCompleteStringCollection();
            string[] resultArray = Array.ConvertAll(uniqueValues.ToArray(), v => v.ToString());
            colSource.AddRange(resultArray);
            txtFilter.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtFilter.AutoCompleteCustomSource = colSource;

            // Set to none the autocomplete in order to obtain a better use of the space in windows
            txtFilter.AutoCompleteMode = AutoCompleteMode.None;

            // Add uniquevalues to checkbox and Seleccionar Todos index 0
            chkUniqueValues.Items.Add(SeleccionarTodos);
            chkUniqueValues.Items.AddRange(uniqueValues.ToArray());

            // If a filter exist for the field check the items related
            if (filter != null)
            {
                lnkDeleteFilter.Enabled = true;

                foreach (object v in filter.RawValue)
                {
                    int index = uniqueValues.ToList().IndexOf(v);
                    chkUniqueValues.SetItemChecked(index + 1, true);
                }
            }
        }
        #endregion

        #region chkUniqueValues_ItemCheck
        /// <summary>
        /// Triggered when an item of the checklist is checked or unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkUniqueValues_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            object value =  chkUniqueValues.SelectedItem;

            if (value == (object)SeleccionarTodos)
            {
                // if SeleccionarTodos was selected clearselected to not loop the event and check or uncheck when necesary
                if (e.NewValue == CheckState.Checked)
                {
                    chkUniqueValues.ClearSelected();
                    ChkUniqueValueToogleCheck(true);
                }
                else
                {
                    chkUniqueValues.ClearSelected();
                    ChkUniqueValueToogleCheck(false);
                }
            }
            else {
                // UnSelectAll is true by default, and pass to be false in order to not loop the event when SetItemChecked fires event itemcheck again
                if (unSelectAll)
                {
                    unSelectAll = false;
                    chkUniqueValues.SetItemChecked(0, false);
                }

                // UnselectAll returns to it default value
                unSelectAll = true;
            }
        }
        #endregion

        #region txtFilter_TextChanged
        /// <summary>
        /// Triggered when text changed on txtfilter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            // Seek for the coincidence in checkvalues and populate the checkboxes with the results 
            if (txtFilter.Text.Length > 0)
            {
                if (chkUniqueValues.CheckedItems.Count > 0)
                    CreateNewFilter();

                cmdAddToFilter.Enabled = true;
                chkUniqueValues.Items.Clear();
                var newValues = uniqueValues.Where(t => t.ToString().ToUpper().Contains(txtFilter.Text.ToUpper()));
                chkUniqueValues.Items.Add(SeleccionarTodos);
                chkUniqueValues.Items.AddRange(newValues.ToArray());
            }
            else
            {
                // if textbox is empty populate the checkboxes with the original uniqueValues
                chkUniqueValues.Items.Clear();
                chkUniqueValues.Items.Add(SeleccionarTodos);
                chkUniqueValues.Items.AddRange(uniqueValues.ToArray());

                // if a filter exist for the field check the items related
                if (filter != null)
                {
                    lnkDeleteFilter.Enabled = true;

                    foreach (object v in filter.RawValue)
                    {
                        int index = uniqueValues.ToList().IndexOf(v);
                        chkUniqueValues.SetItemChecked(index + 1, true);
                    }
                }
            } 
        }
        #endregion

        #region cmdOk_Click
        /// <summary>
        /// Triggered when button Aceptar is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdOk_Click(object sender, EventArgs e)
        {
            if (chkUniqueValues.CheckedItems.Count > 0)
            {
                CreateNewFilter();
            }
            else {
                RemoveFilter();
            }

            Close();
        }
        #endregion

        #region lnkDeleteFilter_LinkClicked
        /// <summary>
        /// Triggered when link eliminar filtro is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lnkDeleteFilter_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //remove any actual filter on the column
            RemoveFilter();
            Close();
        }
        #endregion

        #region lnkMoreFilters_LinkClicked
        /// <summary>
        /// Triggered when link mas filtros is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lnkMoreFilters_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        { 
            FrmFilterAdvanced advanced = new FrmFilterAdvanced(Query, column, colValueType);
            advanced.ShowDialog();
            Query = advanced.Query;
            Close();
        }
        #endregion

        #region lnkDesc_LinkClicked
        /// <summary>
        /// Triggered when link Ordenar Descendente is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lnkDesc_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //set sorted as true to fire a reorder in column when windows is closed
            isSorted = true;
            Sort = ListSortDirection.Descending;
            Close();
        }
        #endregion

        #region lnkAsc_LinkClicked
        /// <summary>
        /// Triggered when link Ordenar Ascendente is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lnkAsc_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //set sorted as true to fire a reorder in column when windows is closed
            isSorted = true;
            Sort = ListSortDirection.Ascending;
            Close();
        }
        #endregion

        #region cmdAddToFilter_Click
        /// <summary>
        /// Triggered when Button Agregar al filtro is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdAddToFilter_Click(object sender, EventArgs e)
        {
            AddtoFilter();
        }
        #endregion 

        #endregion
    }
}

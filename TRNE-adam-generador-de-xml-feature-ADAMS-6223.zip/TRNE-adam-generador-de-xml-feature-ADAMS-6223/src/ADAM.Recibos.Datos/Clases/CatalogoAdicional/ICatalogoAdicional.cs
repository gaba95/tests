﻿using System.Data;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.Recibos.Datos.Clases.CatalogoAdicional
{
    public interface ICatalogoAdicional
    {
        bool CheckDbConnection();
        bool AltaRelacionConcepto(int tipo, string claveTipo, int concepto);
        bool AltaRelacionRegimen(string compania, string trabajador, string regimen);
        bool BajaRelacionConcepto(int tipo, string claveTipo, int concepto);
        bool existeTablaConfiguracion();

        bool DeletePayslipsData(string companyId, string payrollType, string payrollClass, int payrollYear, int payrollPeriod, string employee);
        string obtenCompaniasIdiomas();
        DataSet obtenDatasetClasesNomina(string compania); // PTF-4277
        DataSet obtenDatasetCompanias(string szLangCode);
        DataSet obtenConfiguracionCompania(string compania);
        void GuardaConfiguracionCompania(string company, ConfigurationTypes parameterId, string description, string alphanumeric, decimal num_decimal = 0, int num_int = 0);
        DataSet obtenDatasetConceptosRelacionar(int tipoConcepto, string claveTipo);
        DataSet obtenDatasetDescripcionTipos();

        DataSet obtenDatasetRegimen();
        DataSet obtenDatasetRelacionConceptos(int tipoConcepto, string claveTipo);
        DataSet obtenDatasetTiposNomina(string compania); // PTF-4277
        DataSet obtenDatasetTiposPercepcionDeduccion(int tipo);
        DataSet obtenDatasetTrabajadoresRecibo(string compania, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina);
        DataSet obtenDatasetTrabajadoresRegimen(string compania);
        DataSet obtenBasesDisponibles();

        DataSet ReadCSD();
        DataSet obtenDatasetFormaPago();
        DataSet obtenParametrosCompania(string compania);
        DataSet obtenListaPeriodosMes(string compania, string tipoNomina, int anio, int mesAcumular);

        bool DeleteCSD(string client);
        bool CreateReplaceCSD(byte[] certBytes, byte[] keyBytes, string client, string key_pass);
    }
}

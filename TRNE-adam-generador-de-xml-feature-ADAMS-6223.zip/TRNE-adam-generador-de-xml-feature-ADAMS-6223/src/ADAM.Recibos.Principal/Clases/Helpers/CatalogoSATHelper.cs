using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using System.Configuration;

namespace ADAM.Recibos.Principal.Clases.Helpers
{
    public static class CatalogoSatHelper
    {
        public static ICatalogoSat CreateInstance(TipoPlataforma tipoPlataforma,
                                                  ApplicationSettingsBase appSettings)
        {
            switch (tipoPlataforma)
            {
                case TipoPlataforma.SQLServer:
                    return new CatalogoSatSql(new SqlConnectionFactory(appSettings));

                case TipoPlataforma.ORACLE:
                    return new CatalogoSatOracle(new OracleConnectionFactory(appSettings));

                case TipoPlataforma.ODBC:
                    return new CatalogoSatOdbc(new OdbcConnectionFactory(appSettings));

                default:
                    return new CatalogoSatSql(new SqlConnectionFactory(appSettings));
            }
        }
    }
}

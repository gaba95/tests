namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmTiposPercepcionDeduccionSAT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTiposPercepcionDeduccionSAT));
            this.gridTiposPercepciones = new System.Windows.Forms.DataGridView();
            this.pnlIzquierdo = new System.Windows.Forms.Panel();
            this.cmdAgregar = new System.Windows.Forms.Button();
            this.cboTipo = new System.Windows.Forms.ComboBox();
            this.lblTipo = new System.Windows.Forms.Label();
            this.pnlDerecho = new System.Windows.Forms.Panel();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdQuitar = new System.Windows.Forms.Button();
            this.gridConceptos = new System.Windows.Forms.DataGridView();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridTiposPercepciones)).BeginInit();
            this.pnlIzquierdo.SuspendLayout();
            this.pnlDerecho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridConceptos)).BeginInit();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // gridTiposPercepciones
            // 
            this.gridTiposPercepciones.AllowUserToAddRows = false;
            this.gridTiposPercepciones.AllowUserToDeleteRows = false;
            this.gridTiposPercepciones.AllowUserToResizeRows = false;
            this.gridTiposPercepciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridTiposPercepciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridTiposPercepciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridTiposPercepciones.Location = new System.Drawing.Point(10, 80);
            this.gridTiposPercepciones.MultiSelect = false;
            this.gridTiposPercepciones.Name = "gridTiposPercepciones";
            this.gridTiposPercepciones.ReadOnly = true;
            this.gridTiposPercepciones.RowHeadersVisible = false;
            this.gridTiposPercepciones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridTiposPercepciones.Size = new System.Drawing.Size(430, 117);
            this.gridTiposPercepciones.TabIndex = 2;
            this.gridTiposPercepciones.SelectionChanged += new System.EventHandler(this.gridTiposPercepciones_SelectionChanged);
            // 
            // pnlIzquierdo
            // 
            this.pnlIzquierdo.Controls.Add(this.cmdAgregar);
            this.pnlIzquierdo.Controls.Add(this.cboTipo);
            this.pnlIzquierdo.Controls.Add(this.lblTipo);
            this.pnlIzquierdo.Controls.Add(this.gridTiposPercepciones);
            this.pnlIzquierdo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlIzquierdo.Location = new System.Drawing.Point(0, 50);
            this.pnlIzquierdo.Name = "pnlIzquierdo";
            this.pnlIzquierdo.Padding = new System.Windows.Forms.Padding(10, 80, 10, 60);
            this.pnlIzquierdo.Size = new System.Drawing.Size(450, 257);
            this.pnlIzquierdo.TabIndex = 0;
            // 
            // cmdAgregar
            // 
            this.cmdAgregar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdAgregar.Location = new System.Drawing.Point(10, 203);
            this.cmdAgregar.Name = "cmdAgregar";
            this.cmdAgregar.Size = new System.Drawing.Size(110, 50);
            this.cmdAgregar.TabIndex = 3;
            this.cmdAgregar.Text = "&Agregar Concepto";
            this.cmdAgregar.UseVisualStyleBackColor = true;
            this.cmdAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // cboTipo
            // 
            this.cboTipo.FormattingEnabled = true;
            this.cboTipo.Location = new System.Drawing.Point(70, 32);
            this.cboTipo.Name = "cboTipo";
            this.cboTipo.Size = new System.Drawing.Size(200, 26);
            this.cboTipo.TabIndex = 1;
            this.cboTipo.SelectedIndexChanged += new System.EventHandler(this.cboTipo_SelectedIndexChanged);
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(10, 40);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(36, 18);
            this.lblTipo.TabIndex = 0;
            this.lblTipo.Text = "Tipo:";
            // 
            // pnlDerecho
            // 
            this.pnlDerecho.Controls.Add(this.cmdCerrar);
            this.pnlDerecho.Controls.Add(this.cmdQuitar);
            this.pnlDerecho.Controls.Add(this.gridConceptos);
            this.pnlDerecho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDerecho.Location = new System.Drawing.Point(450, 50);
            this.pnlDerecho.Name = "pnlDerecho";
            this.pnlDerecho.Padding = new System.Windows.Forms.Padding(10, 80, 10, 60);
            this.pnlDerecho.Size = new System.Drawing.Size(258, 257);
            this.pnlDerecho.TabIndex = 1;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(148, 203);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 2;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // cmdQuitar
            // 
            this.cmdQuitar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdQuitar.Location = new System.Drawing.Point(10, 203);
            this.cmdQuitar.Name = "cmdQuitar";
            this.cmdQuitar.Size = new System.Drawing.Size(110, 50);
            this.cmdQuitar.TabIndex = 1;
            this.cmdQuitar.Text = "&Quitar Concepto";
            this.cmdQuitar.UseVisualStyleBackColor = true;
            this.cmdQuitar.Click += new System.EventHandler(this.cmdQuitar_Click);
            // 
            // gridConceptos
            // 
            this.gridConceptos.AllowUserToAddRows = false;
            this.gridConceptos.AllowUserToDeleteRows = false;
            this.gridConceptos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridConceptos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridConceptos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridConceptos.Location = new System.Drawing.Point(10, 80);
            this.gridConceptos.MultiSelect = false;
            this.gridConceptos.Name = "gridConceptos";
            this.gridConceptos.ReadOnly = true;
            this.gridConceptos.RowHeadersVisible = false;
            this.gridConceptos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridConceptos.Size = new System.Drawing.Size(238, 117);
            this.gridConceptos.TabIndex = 0;
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(708, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(366, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Configuracion Tipo de Conceptos";
            // 
            // FrmTiposPercepcionDeduccion
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(708, 307);
            this.Controls.Add(this.pnlDerecho);
            this.Controls.Add(this.pnlIzquierdo);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmTiposPercepcionDeduccion";
            this.ShowInTaskbar = false;
            this.Text = "FrmTiposPercepcion";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmTiposPercepcion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridTiposPercepciones)).EndInit();
            this.pnlIzquierdo.ResumeLayout(false);
            this.pnlIzquierdo.PerformLayout();
            this.pnlDerecho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridConceptos)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridTiposPercepciones;
        private System.Windows.Forms.Panel pnlIzquierdo;
        private System.Windows.Forms.Panel pnlDerecho;
        private System.Windows.Forms.DataGridView gridConceptos;
        private System.Windows.Forms.ComboBox cboTipo;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.Button cmdAgregar;
        private System.Windows.Forms.Button cmdQuitar;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
    }
}
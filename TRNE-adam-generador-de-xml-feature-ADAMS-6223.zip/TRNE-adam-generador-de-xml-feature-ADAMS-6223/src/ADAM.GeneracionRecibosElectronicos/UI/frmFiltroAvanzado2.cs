using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.GeneracionRecibosElectronicos.Clases;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmFiltroAvanzado2 : Form
    {

        #region variables de la clase

        private DataTable _dsComboItems = null; //AZ-1071: For combo search
        private string _textoFiltro = "";

        #endregion

        #region propiedades de la clase

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataTable dsOriginal { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataTable dsSeleccionados { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string textoFiltro
        {
            get
            {
                return _textoFiltro;
            }
            set
            {
                _textoFiltro = value;
                txtListaFiltro.Text = value;
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DSFilter
        {
            get;
            set;
        }

        #endregion

        #region eventos de la clase

        private void FrmFiltroAvanzado_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }

        private void cmdAplicar_Click(object sender, EventArgs e)
        {

            AplicarFiltro();

        }

        private void cmdInicializar_Click(object sender, EventArgs e)
        {

            //Limpiar el grid
            gridSeleccionados.DataSource = null;
            gridSeleccionados.Rows.Clear();

            //Limpiar el texto
            txtListaFiltro.Clear();

        }

        private void cmdAceptar_Click(object sender, EventArgs e)
        {
            ActualizaDsSeleccion();

            this.Close();
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// AZ-1071: Shows list of possible items, based on user's input. This will search based in "contains" search,
        /// rather than "startWith" that combobox has as default
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CmbTextoBusqueda_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(cmbTextoBusqueda.Text))
                {
                    cmbTextoBusqueda.Items.Clear();
                    cmbTextoBusqueda.Items.AddRange(getAutoCompleteSourceList(_dsComboItems.Select()));
                }
                else
                {
                    cmbTextoBusqueda.Items.Clear();
                    cmbTextoBusqueda.Items.AddRange(getAutoCompleteSourceList(_dsComboItems.Select("nombre LIKE '%" + cmbTextoBusqueda.Text + "%' OR trabajador LIKE '%" + cmbTextoBusqueda.Text + "%'")));
                }

                this.cmbTextoBusqueda.SelectionStart = this.cmbTextoBusqueda.Text.Length;
                Cursor = Cursors.Default;

                if (cmbTextoBusqueda.Items.Count > 0)
                {
                    this.cmbTextoBusqueda.DroppedDown = true;
                }
                else
                {
                    this.cmbTextoBusqueda.DroppedDown = false;

                }
            }
            catch
            {
                //Dropped down throws exception when assigning false and the item doesn´t exist in the list.
                //The exception has to be caught so it doesn´t raise the error in the UI
            }
        }

        /// <summary>
        /// AZ-1071: Appends the id to the list in the textbox filter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAgregarIdALista_Click(object sender, EventArgs e)
        {
            List<String> idsList = new List<String>();

            //Validate if string is empty, else add the values
            if (!String.IsNullOrWhiteSpace(txtListaFiltro.Text))
            {
                String[] splitList = txtListaFiltro.Text.Split(',');
                idsList.AddRange(splitList);
            }

            //Validate selected item and if the list already contains the id
            AutoCompleteEmployeeInfo info = (AutoCompleteEmployeeInfo)cmbTextoBusqueda.SelectedItem;

            if (info != null)
            {
                if (!idsList.Contains(info.Value))
                {
                    idsList.Add(info.Value);

                    String finalList = String.Empty;
                    foreach (String idText in idsList)
                    {
                        if (String.IsNullOrWhiteSpace(finalList))
                        {
                            finalList = idText;
                        }
                        else
                        {
                            finalList += "," + idText;
                        }
                    }

                    //set the new list of ids
                    txtListaFiltro.Text = finalList;
                }
            }

        }

        #endregion

        #region metodos de la clase

        /// <summary>
        /// Constructor.
        /// </summary>
        public FrmFiltroAvanzado2()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialize class.
        /// </summary>
        private void InicializaClase()
        {
            //AZ-1061: Use the datatable instead of dataset
            gridDisponibles.DataSource = dsOriginal;

            //Carga la estructura de la tabla en el grid NO ligado a datos
            foreach (DataGridViewColumn columna in gridDisponibles.Columns)
            {
                gridSeleccionados.Columns.Add((DataGridViewColumn)columna.Clone());
            }

            //AZ-1061: Hide Selected and IdEstado columns
            if (gridSeleccionados.Columns.Contains("IdEstado"))
            {
                gridSeleccionados.Columns["Selected"].Visible = false;
                gridSeleccionados.Columns["IdEstado"].Visible = false;
            }

            //Si hay datos seleccionados previamente, se cargan
            if (dsSeleccionados != null && dsSeleccionados.Rows.Count > 0)
                CargaSeleccionActual();

            setTextboxFilterSource();
        }

        /// <summary>
        /// Set textbox filter source, with RFC or no.
        /// </summary>
        private void setTextboxFilterSource()
        {
            DataView view = new DataView(dsOriginal);
            view.Sort = "trabajador asc";
            if (dsOriginal.Columns.Contains("RFC"))
            {
                this._dsComboItems = view.ToTable(true, "trabajador", "nombre", "RFC");
            }
            else
            {
                this._dsComboItems = view.ToTable(true, "trabajador", "nombre");
            }

            cmbTextoBusqueda.Items.Clear();
            cmbTextoBusqueda.Items.AddRange(getAutoCompleteSourceList(_dsComboItems.Select()));

        }

        /// <summary>
        /// Execute filter.
        /// </summary>
        private void AplicarFiltro()
        {
            //1) Get text and convert to list.
            List<String> ListaFinalEmpleados = new List<string>();

            String[] ListaEmpleados;
            ListaEmpleados = txtListaFiltro.Text.Split(',');

            //Format by employee.
            foreach (string empleado in ListaEmpleados)
            {
                ListaFinalEmpleados.Add(empleado.Trim().PadLeft(10));
            }


            //Create and apply filter.
            string filtro = "";

            foreach (string empleadoFormateado in ListaFinalEmpleados)
            {
                filtro += "'" + empleadoFormateado + "',";
            }

            //Delete final comma.
            filtro = filtro.Substring(0, filtro.Length - 1);

            ((DataTable)gridDisponibles.DataSource).DefaultView.RowFilter = " trabajador IN (" + filtro + ")";

            //AZ-1061: Set datasource filter variable, which will be use in FrmGeneracionRecibo
            DSFilter = ((DataTable)gridDisponibles.DataSource).DefaultView.RowFilter + "";

            //Apply filter to dataset and load in grid.
            gridSeleccionados.DataSource = gridDisponibles.DataSource;

        }

        /// <summary>
        /// Update DS selections.
        /// </summary>
        private void ActualizaDsSeleccion()
        {
            //Clone dsOriginal datatable
            dsSeleccionados = dsOriginal.Clone();

            //Leer el grid de datos seleccionados y agregar cada registro al dataset
            foreach (DataGridViewRow renglon in gridSeleccionados.Rows)
            {
                DataRow renglonTabla = dsSeleccionados.Rows.Add();
                foreach (DataColumn columna in dsSeleccionados.Columns)
                {
                    renglonTabla[columna.ColumnName] = renglon.Cells[columna.ColumnName].Value;
                }
            }

            _textoFiltro = txtListaFiltro.Text;
        }

        /// <summary>
        /// Load current selection.
        /// </summary>
        private void CargaSeleccionActual()
        {
            foreach (DataRow registro in dsSeleccionados.Rows)
            {
                //DataGridViewRow renglon; //= new DataGridViewRow();
                int index = gridSeleccionados.Rows.Add();
                foreach (DataColumn columna in dsSeleccionados.Columns)
                {
                    gridSeleccionados.Rows[index].Cells[columna.ColumnName].Value = registro[columna.ColumnName];
                }

                //Hide selection of grid availables.
                foreach (DataGridViewRow renglon in gridDisponibles.Rows)
                {

                    if (renglon.Cells["trabajador"].Value.ToString() == gridSeleccionados.Rows[index].Cells["trabajador"].Value.ToString())
                    {
                        //Stop link to let hide row.
                        CurrencyManager currencyManager1 = (CurrencyManager)BindingContext[gridDisponibles.DataSource];
                        currencyManager1.SuspendBinding();

                        renglon.Visible = false;

                        //When added to list selected, enabled data link.
                        currencyManager1.ResumeBinding();
                    }
                }

            }
        }

        /// <summary>
        /// AZ-1071: Returns a list of AutoCompleteEmployeeInfo, based on the rows passed as the parameter
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private AutoCompleteEmployeeInfo[] getAutoCompleteSourceList(DataRow[] rows)
        {
            List<AutoCompleteEmployeeInfo> autoSourceCollection = new List<AutoCompleteEmployeeInfo>();

            foreach (DataRow row in rows)
            {
                autoSourceCollection.Add(new AutoCompleteEmployeeInfo(row[0].ToString().Trim() + " - " + row[1].ToString(), row[0].ToString().Trim()));
            }

            return autoSourceCollection.ToArray();
        }

        #endregion


    }
}

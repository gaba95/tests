using Moq;
using System;
using System.Data;
using System.Reflection;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Datos.Clases.Common;
using Oracle.ManagedDataAccess.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoDIAN
{
    [TestClass]
    public class CatalogoDianOracleTests
    {
        #region Constructor & Basic Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoDianOracle(mockFactory.Object);

            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        #endregion

        #region Structure / Reflection Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoDian()
        {
            Assert.IsTrue(typeof(ICatalogoDian).IsAssignableFrom(typeof(CatalogoDianOracle)));
        }

        [DataTestMethod]
        [DataRow("dsListaSeccionesDIAN")]
        [DataRow("dsListaCamposDIAN")]
        [DataRow("getDatasetEmployeesReceiptDian")]
        [DataRow("getDatasetInformationDian")]
        [DataRow("getParentIdCatalog")]
        [DataRow("getTypeClassification")]
        [DataRow("obtenCorrelativoDian")]
        [DataRow("obtenDatasetTablaDIAN")]
        [DataRow("obtenCatalogoAdamDIAN")]
        [DataRow("altaRelacionDatoCatalogoDIAN")]
        [DataRow("existRelacionDatoConceptoDIAN")]
        [DataRow("bajaRelacionDatoCatalogoDIAN")]
        [DataRow("obtenDatasetRelacionCatalogosDIAN")]
        [DataRow("obtenDatasetConceptosRelacionarDIAN")]
        [DataRow("getDatasetConceptosADAM")]
        [DataRow("altaRelacionDatoConceptoDIAN")]
        [DataRow("obtenDatasetRelacionConceptosDIAN")]
        [DataRow("bajaRelacionDatoConceptoDIAN")]
        [DataRow("obtenConfiguracionActualAdicional")]
        [DataRow("guardaConfiguracionActualAdicional")]
        [DataRow("obtenDatasetTreeViewCatalogosDIAN")]
        [DataRow("obtenDatasetTreeViewCatalogosDIANByCompany")]
        [DataRow("obtenDatasetTreeViewConceptosDIAN")]
        [DataRow("obtenDatasetTreeViewConceptosDIANByCompany")]
        [DataRow("obtenDataSetConceptosAux")]
        [DataRow("obtenDataSetCatalogosAux")]
        [DataRow("ActualizaBitacoraCorrelativosDian")]
        [DataRow("AltaResultadoValidacion")]
        [DataRow("obtenDatasetBitacoraCorrelativosDianEmpleado")]
        [DataRow("obtenConfiguracionActualAdicionalMx")]
        [DataRow("guardaConfiguracionActualAdicionalMx")]
        public void ShouldContainMethod(string methodName)
        {
            var method = typeof(CatalogoDianOracle).GetMethod(methodName,
                BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static);
            Assert.IsNotNull(method, $"Method {methodName} should exist");
        }

        #endregion

        #region Stub Methods (return fixed values)

        [TestMethod]
        public void ObtenDatasetTablaDIAN_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenDatasetTablaDIAN("field1"));
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenCatalogoAdamDIAN("field1"));
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_WithParam_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenCatalogoAdamDIAN("field1", "param1"));
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoDIAN_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsFalse(service.altaRelacionDatoCatalogoDIAN("COMP", "campo", "dian", "adam"));
        }

        [TestMethod]
        public void ExistRelacionDatoConceptoDIAN_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsFalse(service.existRelacionDatoConceptoDIAN("COMP", "campo", "concepto"));
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoDIAN_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsFalse(service.bajaRelacionDatoCatalogoDIAN("COMP", "campo", "dian", "adam"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosDIAN_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenDatasetRelacionCatalogosDIAN("COMP", "campo", "dian"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionarDIAN_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenDatasetConceptosRelacionarDIAN("tipo"));
        }

        [TestMethod]
        public void GetDatasetConceptosADAM_ShouldReturnTrue()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsTrue(service.getDatasetConceptosADAM("tipo", "concepto"));
        }

        [TestMethod]
        public void AltaRelacionDatoConceptoDIAN_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsFalse(service.altaRelacionDatoConceptoDIAN("COMP", "campo", "concepto"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionConceptosDIAN_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenDatasetRelacionConceptosDIAN("COMP", "campo"));
        }

        [TestMethod]
        public void BajaRelacionDatoConceptoDIAN_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsFalse(service.bajaRelacionDatoConceptoDIAN("COMP", "campo", "concepto"));
        }

        [TestMethod]
        public void ActualizaBitacoraCorrelativosDian_ShouldReturnCompletedTaskWithFalse()
        {
            var service = CreateServiceWithMockDB();
            var result = service.ActualizaBitacoraCorrelativosDian("COMP", "001", "DOC1", "OK");
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCompleted);
            Assert.IsFalse(result.Result);
        }

        [TestMethod]
        public void AltaResultadoValidacion_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsFalse(service.AltaResultadoValidacion("001", "ERR01", "mensaje"));
        }

        [TestMethod]
        public void ObtenDatasetBitacoraCorrelativosDianEmpleado_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenDatasetBitacoraCorrelativosDianEmpleado("COMP", "TRAB001"));
        }

        [TestMethod]
        public void ObtenDatasetBitacoraCorrelativosDianEmpleado_WithCorrectosParam_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            Assert.IsNull(service.obtenDatasetBitacoraCorrelativosDianEmpleado("COMP", "TRAB001", false));
        }

        [TestMethod]
        public void ObtenConfiguracionActualAdicionalMx_ShouldReturnNull()
        {
            Assert.IsNull(CatalogoDianOracle.obtenConfiguracionActualAdicionalMx("COMP"));
        }

        #endregion

        #region NotImplementedException Methods

        [TestMethod]
        public void ObtenConfiguracionActualAdicional_ShouldThrowNotImplementedException()
        {
            Assert.Throws<NotImplementedException>(() => CatalogoDianOracle.obtenConfiguracionActualAdicional("val"));
        }

        [TestMethod]
        public void GuardaConfiguracionActualAdicional_ShouldThrowNotImplementedException()
        {
            Assert.Throws<NotImplementedException>(() =>
                CatalogoDianOracle.guardaConfiguracionActualAdicional("val", "/tmp", "http://api", "user", "pass"));
        }

        [TestMethod]
        public void ObtenDatasetTreeViewCatalogosDIAN_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenDatasetTreeViewCatalogosDIAN());
        }

        [TestMethod]
        public void ObtenDatasetTreeViewCatalogosDIANByCompany_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenDatasetTreeViewCatalogosDIANByCompany("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetTreeViewConceptosDIAN_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenDatasetTreeViewConceptosDIAN());
        }

        [TestMethod]
        public void ObtenDatasetTreeViewConceptosDIANByCompany_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenDatasetTreeViewConceptosDIANByCompany("COMP"));
        }

        [TestMethod]
        public void ObtenDataSetConceptosAux_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenDataSetConceptosAux());
        }

        [TestMethod]
        public void ObtenDataSetCatalogosAux_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenDataSetCatalogosAux());
        }

        [TestMethod]
        public void GuardaConfiguracionActualAdicionalMx_ShouldThrowNotImplementedException()
        {
            Assert.Throws<NotImplementedException>(() =>
                CatalogoDianOracle.guardaConfiguracionActualAdicionalMx("COMP", "sitio", "xslt", "xsd", 1, "/tmp", "http://api", true, "sp_adicional"));
        }

        #endregion

        #region InvalidCastException Tests (mock IDbConnection, not OracleConnection)

        [TestMethod]
        public void DsListaSeccionesDIAN_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.dsListaSeccionesDIAN("tipo"));
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithTipoConcepto_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.dsListaCamposDIAN("padre", "mapeo", "concepto"));
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithoutTipoConcepto_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.dsListaCamposDIAN("padre", "mapeo"));
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.getDatasetEmployeesReceiptDian("COMP", "2026", "01"));
        }

        [TestMethod]
        public void GetDatasetInformationDian_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "tipo"));
        }

        [TestMethod]
        public void GetParentIdCatalog_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.getParentIdCatalog());
        }

        [TestMethod]
        public void GetTypeClassification_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.getTypeClassification());
        }

        [TestMethod]
        public void ObtenCorrelativoDian_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenCorrelativoDian("COMP", "TRAB001"));
        }

        #endregion

        #region RealOracleConnection Tests

        [TestMethod]
        public void DsListaSeccionesDIAN_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.dsListaSeccionesDIAN("tipo"));
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithTipoConcepto_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.dsListaCamposDIAN("padre", "mapeo", "concepto"));
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithoutTipoConcepto_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.dsListaCamposDIAN("padre", "mapeo"));
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.getDatasetEmployeesReceiptDian("COMP", "2026", "01"));
        }

        [TestMethod]
        public void GetDatasetInformationDian_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "tipo"));
        }

        [TestMethod]
        public void GetParentIdCatalog_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.getParentIdCatalog());
        }

        [TestMethod]
        public void GetTypeClassification_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.getTypeClassification());
        }

        [TestMethod]
        public void ObtenCorrelativoDian_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenCorrelativoDian("COMP", "TRAB001"));
        }

        #endregion

        #region Helpers

        private CatalogoDianOracle CreateServiceWithRealOracleConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new OracleConnection("Data Source=localhost/FAKE;User Id=test;Password=test;Connection Timeout=1"));

            return new CatalogoDianOracle(mockFactory.Object);
        }

        private CatalogoDianOracle CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            return new CatalogoDianOracle(mockFactory.Object);
        }

        #endregion
    }
}

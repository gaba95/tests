﻿using ADAM.BackOffice.Mexico.SAT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using ADAM.Recibos.Mexico.Tests.Helper;


namespace ADAM.Recibos.Mexico.SAT.Tests
{
    [TestClass]
    public class OpenSslKeyV1Tests
    {
        [TestMethod]
        public void SignString_WhenKeyFileMissing_ProducesErrorMessage()
        {
            string fakePath = Path.Combine(Path.GetTempPath(), "no_existe_123.key");

            string result = OpenSslKeyV1.SignString(fakePath, "1234", "cadena");

            Assert.IsTrue(result.Contains(".key file does not exist"));
        }


        [TestMethod]
        public void SignString_WhenKeyFileCorrupted_ThrowsException()
        {
            string tempFile = Path.GetTempFileName();
            File.WriteAllText(tempFile, "contenido inválido");

            try
            {
                OpenSslKeyV1.SignString(tempFile, "1234", "cadena");
                Assert.Fail("Se esperaba una excepción pero no fue lanzada.");
            }
            catch (Exception ex)
            {
                Assert.IsInstanceOfType(ex, typeof(Exception));
            }
        }

        [TestMethod]
        public void SignString_WhenKeyBytesEmpty_ThrowsException()
        {
            byte[] emptyBytes = Array.Empty<byte>();

            try
            {
                OpenSslKeyV1.SignString(emptyBytes, "1234", "cadena");
                Assert.Fail("Se esperaba una excepción pero no fue lanzada.");
            }
            catch (Exception ex)
            {
                Assert.IsInstanceOfType(ex, typeof(Exception));

            }
        }
        [TestMethod]
        public void OpenKeyFile_FileNotExists_ReturnsNull()
        {
            var result = OpenSslKeyV1.OpenKeyFile("no_existe.key", "1234");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void OpenKeyFile_WhenFileContentInvalid_FailsToLoadKey()
        {
            string tempFile = Path.GetTempFileName();
            File.WriteAllText(tempFile, "contenido inválido");

            var result = OpenSslKeyV1.OpenKeyFile(tempFile, "1234");

            Assert.IsNull(result);
        }



        [TestMethod]
        public void OpenKeyFile_WhenKeyBytesNull_FailsToLoadKey()
        {
            var result = OpenSslKeyV1.OpenKeyFile((byte[])null, "1234");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void OpenKeyFile_WhenKeyBytesEmpty_FailsToLoadKey()
        {
            byte[] empty = new byte[0];

            var result = OpenSslKeyV1.OpenKeyFile(empty, "1234");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenDataNotAsn1_RejectsInput()
        {
            byte[] invalid = Encoding.UTF8.GetBytes("esto no es una llave");

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(invalid, "1234");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenOidNotRsa_RejectsKeyStructure()
        {
            // ASN.1 sintético:
            // SEQUENCE (0x30 0x0D)
            //   SEQUENCE (0x30 0x0B)
            //     OID incorrecto (11 bytes)
            byte[] fakeAsn1 = new byte[]
            {
             0x30, 0x0D,       // SEQUENCE
             0x30, 0x0B,       // inner SEQUENCE
             0x06, 0x09,       // OID tag + length
             0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x05 // OID incorrecto
            };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(fakeAsn1, "1234");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenSaltCorrupted_AbortsParsing()
        {
            byte[] fake = new byte[]
            {
             0x30, 0x1A,             // SEQUENCE
             0x30, 0x18,             // inner SEQUENCE
             // OID PBES2
             0x06, 0x09,
             0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x05, 0x0D,
             // SEQUENCE
             0x30, 0x0B,
             // SEQUENCE PBKDF2
             0x30, 0x09,
             0x06, 0x09,
             0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x05, 0x0C,
             // Salt tag but missing length → error
             0x04
            };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(fake, "1234");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenEncryptedBlockInvalid_FailsGracefully()
        {

            byte[] fake = new byte[]
            {
             0x30, 0x3A,             // SEQUENCE
             0x30, 0x38,             // inner SEQUENCE
             // OID PBES2
             0x06, 0x09,
             0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x05, 0x0D,
             // SEQUENCE
             0x30, 0x2B,
             // SEQUENCE PBKDF2
             0x30, 0x11,
             0x06, 0x09,
             0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x05, 0x0C,
             // Salt
             0x04, 0x04, 0xAA, 0xBB, 0xCC, 0xDD,
             // Iterations
             0x02, 0x01, 0x10,
             // SEQUENCE des-EDE3-CBC
             0x30, 0x14,
             0x06, 0x08,
             0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x03, 0x07,
             // IV
             0x04, 0x08, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
             // Encrypted data (fake)
             0x04, 0x04, 0x01, 0x02, 0x03, 0x04
            };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(fake, "1234");

            Assert.IsNull(result);
        }



        [TestMethod]
        public void Reverse_ReturnsReversedString()
        {
            string result = OpenSslKeyV1.Reverse("ABC123");
            Assert.AreEqual("321CBA", result);
        }

        [TestMethod]
        public void Reverse_EmptyString_ReturnsEmpty()
        {
            string result = OpenSslKeyV1.Reverse("");
            Assert.AreEqual("", result);
        }

        [TestMethod]
        public void CertificateData_WithValidCertificateBytes_ReturnsData()
        {

            var cert2 = TestCertificateHelper.CreatePublicOnlyCertificate();
            byte[] raw = cert2.Export(X509ContentType.Cert);


            OpenSslKeyV1.CertificateData(raw, out X509Certificate cert, out string certificate, out string number);


            Assert.IsNotNull(cert);
            Assert.IsFalse(string.IsNullOrEmpty(certificate));
            Assert.IsFalse(string.IsNullOrEmpty(number));
        }

        [TestMethod]
        public void CertificateData_WithValidCertificateFile_ReturnsData()
        {

            var cert2 = TestCertificateHelper.CreatePublicOnlyCertificate();
            byte[] raw = cert2.Export(X509ContentType.Cert);

            string temp = Path.GetTempFileName();
            File.WriteAllBytes(temp, raw);


            OpenSslKeyV1.CertificateData(temp, out string certificate, out string number);


            Assert.IsFalse(string.IsNullOrEmpty(certificate));
            Assert.IsFalse(string.IsNullOrEmpty(number));
        }

        [TestMethod]
        public void DecryptPBDK2_InvalidData_ReturnsNull()
        {
            byte[] edata = { 1, 2, 3, 4 };
            byte[] salt = { 5, 6, 7, 8 };
            byte[] iv = new byte[16]; // IV válido en tamaño
            SecureString pwd = new SecureString();
            pwd.AppendChar('a');

            var result = OpenSslKeyV1.DecryptPBDK2(edata, salt, iv, pwd, 1000);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecryptPBDK2_InvalidIV_ThrowsAndReturnsNull()
        {
            byte[] edata = { 1, 2, 3, 4 };
            byte[] salt = { 5, 6, 7, 8 };
            byte[] iv = { 1, 2 }; // IV inválido
            SecureString pwd = new SecureString();
            pwd.AppendChar('a');

            var result = OpenSslKeyV1.DecryptPBDK2(edata, salt, iv, pwd, 1000);

            Assert.IsNull(result);
        }


        [TestMethod]
        public void DecodePrivateKeyInfo_WhenHeaderMalformed_RejectsStructure()
        {
            byte[] pkcs8 = { 0x01, 0x02, 0x03 };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(pkcs8);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenVersionInvalid_RejectsKey()
        {
            // SEQUENCE + versión incorrecta
            byte[] pkcs8 = {
                0x30, 0x03, // SEQUENCE
                0x02, 0x01, 0x02 // INTEGER (versión != 1)
            };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(pkcs8);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenOidUnexpected_RejectsKey()
        {
            // SEQUENCE, versión 1, OID incorrecto
            byte[] pkcs8 = {
                0x30, 0x16,       // SEQUENCE
                0x02, 0x01, 0x01, // INTEGER 1
                // OID sequence (15 bytes) pero no rsaEncryption
                0x30, 0x0D, 0x06, 0x09,
                0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x05,
                0x05, 0x00
            };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(pkcs8);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodePrivateKeyInfo_WhenOctetStringMissing_RejectsKey()
        {
            // SEQUENCE, versión 1, OID correcto, pero sin octet string
            byte[] pkcs8 = {
                0x30, 0x16,       // SEQUENCE
                0x02, 0x01, 0x01, // INTEGER 1
                // OID rsaEncryption + NULL
                0x30, 0x0D, 0x06, 0x09,
                0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01,
                0x05, 0x00
            };

            var result = OpenSslKeyV1.DecodePrivateKeyInfo(pkcs8);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodeRSAPrivateKey_WhenHeaderMalformed_RejectsKey()
        {
            byte[] priv = { 0x01, 0x02, 0x03 };

            var result = OpenSslKeyV1.DecodeRSAPrivateKey(priv);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodeRSAPrivateKey_WhenVersionInvalid_RejectsKey()
        {

            byte[] priv = {
             0x30, 0x03,       // SEQUENCE
             0x01, 0x02,       // no 0x0102
             0x00
            };

            var result = OpenSslKeyV1.DecodeRSAPrivateKey(priv);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DecodeRSAPrivateKey_WhenComponentsIncomplete_RejectsKey()
        {
            byte[] priv = {
             0x30, 0x0A,       // SEQUENCE
             0x01, 0x02,       // 0x0102
             0x00,             // 0x00
             0x02, 0x01, 0x01  // primer INTEGER muy corto
            };

            var result = OpenSslKeyV1.DecodeRSAPrivateKey(priv);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void SignString_WhenKeyBytesNull_ReturnsErrorMessage()
        {
            string result = OpenSslKeyV1.SignString((byte[])null, "1234", "cadena");

            Assert.AreEqual(".key is null ", result);
        }

        [TestMethod]
        public void Reverse_SingleCharacter_ReturnsSameCharacter()
        {
            string result = OpenSslKeyV1.Reverse("A");
            Assert.AreEqual("A", result);
        }

        [TestMethod]
        public void CertificateData_FileNotExists_ThrowsException()
        {
            string fakePath = Path.Combine(Path.GetTempPath(), "no_existe_cert.cer");

            try
            {
                OpenSslKeyV1.CertificateData(fakePath, out _, out _);
                Assert.Fail("Se esperaba una excepción pero no fue lanzada.");
            }
            catch (Exception ex)
            {
                Assert.IsInstanceOfType(ex, typeof(Exception));
            }
        }

        [TestMethod]
        public void CertificateData_InvalidBytes_ThrowsException()
        {
            byte[] invalidBytes = Encoding.UTF8.GetBytes("esto no es un certificado");

            try
            {
                OpenSslKeyV1.CertificateData(invalidBytes, out _, out _, out _);
                Assert.Fail("Se esperaba una excepción pero no fue lanzada.");
            }
            catch (Exception ex)
            {
                Assert.IsInstanceOfType(ex, typeof(Exception));
            }
        }

        [TestMethod]
        public void DecryptPBDK2_EmptyPassword_ReturnsNull()
        {
            byte[] edata = { 1, 2, 3, 4 };
            byte[] salt = { 5, 6, 7, 8 };
            byte[] iv = new byte[16];
            SecureString pwd = new SecureString();

            var result = OpenSslKeyV1.DecryptPBDK2(edata, salt, iv, pwd, 1000);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void Reverse_UnicodeString_ReversesCorrectly()
        {
            string result = OpenSslKeyV1.Reverse("123");
            Assert.AreEqual("321", result);
        }

        [TestMethod]
        public void CertificateData_ValidBytes_ReturnsNonEmptyCertificateNumber()
        {
            var cert2 = TestCertificateHelper.CreatePublicOnlyCertificate();
            byte[] raw = cert2.Export(X509ContentType.Cert);

            OpenSslKeyV1.CertificateData(raw, out X509Certificate cert, out string certificate, out string number);

            Assert.IsTrue(number.Length > 0);
        }

        [TestMethod]
        public void OpenKeyFile_WhenPasswordEmpty_ReturnsNull()
        {
            string tempFile = Path.GetTempFileName();
            File.WriteAllText(tempFile, "contenido inválido");

            var result = OpenSslKeyV1.OpenKeyFile(tempFile, "");

            Assert.IsNull(result);
        }

    }

}

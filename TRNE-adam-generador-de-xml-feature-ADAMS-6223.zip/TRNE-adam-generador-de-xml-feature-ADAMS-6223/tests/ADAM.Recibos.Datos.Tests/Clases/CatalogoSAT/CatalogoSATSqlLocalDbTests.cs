using Moq;
using System.Data;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Datos.Clases.Common;
using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoSAT
{
    [TestClass]
    [TestCategory("LocalDb")]
    public class CatalogoSatSqlLocalDbTests
    {
        private const string ConnectionString = "Server=(localdb)\\MSSQLLocalDB;Database=tempdb;Encrypt=false;";

        #region Class Setup / Teardown

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            // Create stored procedures
            string[] spDefinitions =
            [
                @"CREATE OR ALTER PROCEDURE dbo.sp_consulta_catalogos_adam
                    @tipo CHAR(4), @compania CHAR(10)
                  AS SELECT 'C001' AS clave, 'Concepto Test' AS descripcion",

                @"CREATE OR ALTER PROCEDURE dbo.sp_consulta_rel_datos_sat_adam
                    @tipo CHAR(4), @clave_sat CHAR(10), @compania CHAR(10)
                  AS SELECT 'C001' AS clave, 'Relacion Test' AS descripcion",

                @"CREATE OR ALTER PROCEDURE dbo.sp_alta_dato_catalogos_sat_adam
                    @tipo INT, @compania VARCHAR(10), @clave_sat VARCHAR(10), @clave_adam VARCHAR(10)
                  AS SELECT 1",

                @"CREATE OR ALTER PROCEDURE dbo.sp_baja_dato_catalogos_sat_adam
                    @tipo INT, @compania VARCHAR(10), @clave_sat VARCHAR(10), @clave_adam VARCHAR(10)
                  AS SELECT 1"
            ];

            foreach (var sql in spDefinitions)
            {
                using var cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }

            // Create tables (idempotent)
            string[] tableDefinitions =
            [
                @"IF OBJECT_ID('dbo.criterios_valores_sat','U') IS NULL
                  CREATE TABLE dbo.criterios_valores_sat (campo CHAR(20), item VARCHAR(10), descripcion VARCHAR(100))",

                @"IF OBJECT_ID('dbo.catalogos_valores_sat_adam','U') IS NULL
                  CREATE TABLE dbo.catalogos_valores_sat_adam (clave_sat VARCHAR(10), descripcion_sat VARCHAR(100), tipo INT)",

                @"IF OBJECT_ID('dbo.tb_catalogos_dian','U') IS NULL
                  CREATE TABLE dbo.tb_catalogos_dian (id INT, nombre VARCHAR(100))"
            ];

            foreach (var sql in tableDefinitions)
            {
                using var cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }

            // Seed data
            string[] seedData =
            [
                // criterios_valores already exists from CatalogoAdicionalSqlLocalDbTests, but seed our own table
                @"IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'criterios_valores')
                  CREATE TABLE dbo.criterios_valores (campo CHAR(20), item VARCHAR(10), descripcion VARCHAR(100))",
                "DELETE FROM dbo.criterios_valores WHERE campo = 'tipo_catalogo_sat'",
                "INSERT INTO dbo.criterios_valores VALUES ('tipo_catalogo_sat','1','Bancos')",
                "INSERT INTO dbo.criterios_valores VALUES ('tipo_catalogo_sat','2','Tipo Contrato')",

                "DELETE FROM dbo.catalogos_valores_sat_adam WHERE tipo = 99",
                "INSERT INTO dbo.catalogos_valores_sat_adam VALUES ('SAT01','Descripcion SAT 01',99)",
                "INSERT INTO dbo.catalogos_valores_sat_adam VALUES ('SAT02','Descripcion SAT 02',99)",

                "DELETE FROM dbo.tb_catalogos_dian",
                "INSERT INTO dbo.tb_catalogos_dian VALUES (1,'Catalogo DIAN Test')"
            ];

            foreach (var sql in seedData)
            {
                using var cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            try
            {
                using var conn = new SqlConnection(ConnectionString);
                conn.Open();

                string[] drops =
                [
                    "DROP PROCEDURE IF EXISTS dbo.sp_consulta_catalogos_adam",
                    "DROP PROCEDURE IF EXISTS dbo.sp_consulta_rel_datos_sat_adam",
                    "DROP PROCEDURE IF EXISTS dbo.sp_alta_dato_catalogos_sat_adam",
                    "DROP PROCEDURE IF EXISTS dbo.sp_baja_dato_catalogos_sat_adam",
                    "DROP TABLE IF EXISTS dbo.criterios_valores_sat",
                    "DROP TABLE IF EXISTS dbo.tb_catalogos_dian"
                ];

                foreach (var sql in drops)
                {
                    using var cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* best-effort cleanup */ }
        }

        #endregion

        #region Helpers

        private static CatalogoSatSql CreateServiceWithLocalDb()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection(ConnectionString));
            return new CatalogoSatSql(mockFactory.Object);
        }

        #endregion

        #region dsListaCatalogosSAT Tests

        [TestMethod]
        public void DsListaCatalogosSAT_LocalDb_ShouldReturnDataSet()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.dsListaCatalogosSAT();

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenDatasetCatalogosSAT Tests

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_LocalDb_ShouldReturnDataSet()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetCatalogosSAT("99");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_LocalDb_NonExistentTipo_ShouldReturnEmptyDataSet()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetCatalogosSAT("999");

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenCatalogoADAM Tests

        [TestMethod]
        public void ObtenCatalogoADAM_LocalDb_ShouldReturnDataSet()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.obtenCatalogoADAM("1", "0001");

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        #endregion

        #region obtenDatasetRelacionCatalogosSATADAM Tests

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_LocalDb_ShouldReturnDataSet()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "0001");

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        #endregion

        #region AltaRelacionDatoCatalogoADAM Tests

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_LocalDb_ShouldExecute()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.AltaRelacionDatoCatalogoADAM("1", "0001", "SAT01", "ADAM01");

            // SP executes without error
        }

        #endregion

        #region BajaRelacionDatoCatalogoADAM Tests

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_LocalDb_ShouldExecute()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.BajaRelacionDatoCatalogoADAM("1", "0001", "SAT01", "ADAM01");
        }

        #endregion

        #region obtenDatasetCatalogos Tests

        [TestMethod]
        public void ObtenDatasetCatalogos_LocalDb_WhitelistedTable_ShouldReturnDataSet()
        {
            var service = CreateServiceWithLocalDb();

            // tb_catalogos_dian is in SafeTables.WhiteList
            var result = service.obtenDatasetCatalogos("tb_catalogos_dian");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_LocalDb_NonWhitelistedTable_ShouldReturnNull()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetCatalogos("non_existent_table");

            Assert.IsNull(result);
        }

        #endregion
    }
}

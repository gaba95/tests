﻿using System;
using System.Globalization;
using ADAM.GeneracionRecibosElectronicos.Enums;

namespace ADAM.GeneracionRecibosElectronicos.Helpers
{
    public static class Extensions
    {
        public static string EmptyIfNull(this object value)
        {
            return (value == null ? "" : value.ToString().Trim());
        }
        
        public static string FormatDate(this object value, string format)
        {
            try
            {
                return (value == null
                        ? ""
                        : DateTime.Parse(value.ToString(), CultureInfo.InvariantCulture).ToString(format));
            }
            catch
            {
                return String.Empty;
            }
        }
        
        public static string FixedLength(this object value, int size, PadType ePadType = PadType.Right, char padChar = ' ', int decimals = 0)
        {
            string newValue;
            if (value == null)
            {
                newValue = "";
            }
            else if (value is decimal)
            {
                newValue = string.Format("{0:F" + decimals + "}", value);
            }
            else
            {
                newValue = value.ToString().Trim();
            }
            newValue = (newValue.Length > size ? newValue.Substring(0, size) : newValue);
            if (ePadType == PadType.Left)
            { newValue = newValue.PadLeft(size, padChar); }
            if (ePadType == PadType.Right)
            { newValue = newValue.PadRight(size, padChar); }
            return newValue;
        }
        
        public static string FixedDecimals(this object value, int decimals = 0)
        {
            try
            {
                if (value == null) return "0";
                if (value is decimal) return string.Format("{0:F" + decimals + "}", value);
                return value.ToString().Trim();
            }
            catch
            {
                return "0";
            }
        }
        
        public static string NoSpaceSequence(this object value)
        {
            return value.ToString()
                        .Trim()
                        .Replace("\n", "")
                        .Replace("\t", "")
                        .Replace("\a", "")
                        .Replace("\b", "")
                        .Replace("\r", "");
        }
    }
}

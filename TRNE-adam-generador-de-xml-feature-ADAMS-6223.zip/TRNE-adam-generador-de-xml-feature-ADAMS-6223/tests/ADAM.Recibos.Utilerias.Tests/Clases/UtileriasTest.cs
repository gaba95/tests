﻿using ADAM.Recibos.Utilerias.Helpers;
using System.Data;
using System.Reflection;

namespace ADAM.Recibos.Utilerias.Tests.Clases
{
    [TestClass]
    public class UtileriasTest
    {
        [TestMethod]
        public void ToXml_GeneratesExpectedXml()
        {
            var table = ADAM.Recibos.Utilerias.Tests.Helpers.DatatableHelper.CreateSampleTable();
            var xml = GlobalHelper.ToXml(table);
            Assert.IsTrue(xml.Contains("<SampleTable>"));
            Assert.IsTrue(xml.Contains("<row1>Uno</row1>"));
            Assert.IsTrue(xml.Contains("<row2>Dos</row2>"));
            Assert.IsTrue(xml.Contains("<row3>Tres</row3>"));
        }
        
        [TestMethod]
        public void ToXml_UseDifferentMetaIndex()
        {
            var table = ADAM.Recibos.Utilerias.Tests.Helpers.DatatableHelper.CreateSampleTable();
            var xml = GlobalHelper.ToXml(table, metaIndex:1);
            Assert.IsTrue(xml.Contains("<SampleTable>"));
            Assert.IsTrue(xml.Contains("<Uno>row1</Uno>"));
        }
        
        [TestMethod]
        public void ToXml_EmptyTable_ReturnsValidXml()
        {
            var table = ADAM.Recibos.Utilerias.Tests.Helpers.DatatableHelper.CreateEmptyTable();
            string xml = GlobalHelper.ToXml(table);
            Assert.IsTrue(xml.Contains("<EmptyTable>"));
        }
        
        [TestMethod]
        public void ToXml_InvalidMetaIndex_Throws()
        {
            var table = ADAM.Recibos.Utilerias.Tests.Helpers.DatatableHelper.CreateSampleTable();
            Assert.Throws<IndexOutOfRangeException>(() => GlobalHelper.ToXml(table, metaIndex:10));
        }
        
        [TestMethod]
        public void GetMeses_ReturnsTwelveRows()
        {
            var result = GlobalHelper.Meses();
            Assert.IsNotNull(result);
            Assert.AreEqual(12, result.Rows.Count);
        }
        
        [TestMethod]
        public void GetMeses_FirstMonth_IsJanuaryInSpanishUppercase()
        {
            var result = GlobalHelper.Meses();
            var row = result.Rows[0];
            Assert.AreEqual("1", row["mes"].ToString());
            Assert.AreEqual("ENERO", row["descripcion"].ToString());
        }
        
        [TestMethod]
        public void GetMeses_LastMonth_IsDecemberInSpanishUppercase()
        {
            var result = GlobalHelper.Meses();
            var height = result.Rows.Count - 1;
            var row = result.Rows[height];
            Assert.AreEqual("12", row["mes"].ToString());
            Assert.AreEqual("DICIEMBRE", row["descripcion"].ToString());
        }
        
        [TestMethod]
        public void RutaAplicacion_ReturnsValidDirectory()
        {
            var ruta = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            Assert.IsFalse(string.IsNullOrEmpty(ruta));
            Assert.IsTrue(System.IO.Directory.Exists(ruta));
        }
        
        [TestMethod]
        public void RutaAplicacion_DoesNotContainFilePrefix()
        {
            var ruta = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            Assert.IsFalse(ruta.Contains("file:\\"));
        }
        
        [TestMethod]
        public void CreateFuncGetParam_WhenParamExists_ReturnValue()
        {
            var table = new DataTable();
            table.Columns.Add("param", typeof(string));
            table.Columns.Add("value", typeof(string));
            table.Rows.Add("A", "100");
            table.Rows.Add("B", "200");
            var ds = new DataSet();
            ds.Tables.Add(table);

            var resultFunc = GlobalHelper.CreateFuncGetParam(ds, "param", "value");
            var result = resultFunc("A");
            Assert.AreEqual("100", result);
        }
        
        [TestMethod]
        public void CreateFuncGetParam_WhenParamDoesNotExists_ReturnEmpty()
        {
            var table = new DataTable();
            table.Columns.Add("param", typeof(string));
            table.Columns.Add("value", typeof(string));
            table.Rows.Add("A", "100");
            table.Rows.Add("B", "200");
            var ds = new DataSet();
            ds.Tables.Add(table);

            var resultFunc = GlobalHelper.CreateFuncGetParam(ds, "param", "value");
            var result = resultFunc("C");
            Assert.AreEqual(string.Empty, result);
        }
        
        [TestMethod]
        public void CreateFuncGetParam_EmptyTable_ReturnsEmpty()
        {
            var table = new DataTable();
            table.Columns.Add("param", typeof(string));
            table.Columns.Add("value", typeof(string));
            var ds = new DataSet();
            ds.Tables.Add(table);

            var resultFunc = GlobalHelper.CreateFuncGetParam(ds, "param", "value");
            var result = resultFunc("A");
            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void ValidateUrl_EmptyString_ThrowsArgumentException()
        {
            Assert.ThrowsExactly<ArgumentException>(() => GlobalHelper.ValidateUrl(""));
        }

        [TestMethod]
        public void ValidateUrl_WhitespaceOnly_ThrowsArgumentException()
        {
            Assert.ThrowsExactly<ArgumentException>(() => GlobalHelper.ValidateUrl("   "));
        }

        [TestMethod]
        public void ValidateUrl_InvalidUri_ThrowsArgumentException()
        {
            Assert.ThrowsExactly<ArgumentException>(() => GlobalHelper.ValidateUrl("not-a-valid-uri"));
        }

        [TestMethod]
        public void ValidateUrl_FtpScheme_ThrowsArgumentException()
        {
            Assert.ThrowsExactly<ArgumentException>(() => GlobalHelper.ValidateUrl("ftp://example.com/file"));
        }

        [TestMethod]
        public void ValidateUrl_Localhost_ThrowsArgumentException()
        {
            Assert.ThrowsExactly<ArgumentException>(() => GlobalHelper.ValidateUrl("http://localhost/api"));
        }

        [TestMethod]
        public void ValidateUrl_LoopbackIp_ThrowsArgumentException()
        {
            Assert.ThrowsExactly<ArgumentException>(() => GlobalHelper.ValidateUrl("http://127.0.0.1/api"));
        }

        [TestMethod]
        public void ValidateUrl_ValidHttpsUrl_DoesNotThrow()
        {
            GlobalHelper.ValidateUrl("https://www.google.com");
        }

        [TestMethod]
        public void ValidateUrl_ValidHttpUrl_DoesNotThrow()
        {
            GlobalHelper.ValidateUrl("http://www.google.com");
        }
    }
}

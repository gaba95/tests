﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security;
using System.Xml;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Helpers
{
    internal sealed class TestConfigHelper
    {
        public string ConfigPath { get; }
        public string BackupPath { get; }

        private readonly string _tempRoot;

        public TestConfigHelper()
        {
            ConfigPath = GetConfigPathAsProductionDoes();

            _tempRoot = Path.Combine(
                Path.GetTempPath(),
                "ADAM.GeneracionRecibosElectronicos.Tests",
                "ConfigBackups",
                Guid.NewGuid().ToString("N"));

            Directory.CreateDirectory(_tempRoot);
            BackupPath = Path.Combine(_tempRoot, Path.GetFileName(ConfigPath) + ".bak_unit_tests");
        }

        public void BackupAndDeleteIfExists()
        {
            if (File.Exists(ConfigPath))
            {
                SafeCopy(ConfigPath, BackupPath, overwrite: true);
                SafeDelete(ConfigPath);
            }
        }

        public void CleanupRestore()
        {
            try
            {
                if (File.Exists(ConfigPath))
                    SafeDelete(ConfigPath);

                if (File.Exists(BackupPath))
                {
                    SafeCopy(BackupPath, ConfigPath, overwrite: true);
                    SafeDelete(BackupPath);
                }

                TryDeleteDirectory(_tempRoot);
            }
            catch
            {
                // 
            }
        }

        public void WriteConfigWithEndpointNode(string address)
        {
            var xml =
                $@"<?xml version=""1.0"" encoding=""utf-8"" ?>
                <configuration>
                  <system.serviceModel>
                    <client>
                      <endpoint address=""{XmlAttrEscape(address)}"" />
                    </client>
                  </system.serviceModel>
                </configuration>";
            SafeWriteAllText(ConfigPath, xml);
        }

        public void WriteConfigWithoutEndpointNode()
        {
            var xml =
                @"<?xml version=""1.0"" encoding=""utf-8"" ?>
                <configuration>
                  <system.serviceModel>
                    <client>
                      <!-- endpoint node missing on purpose -->
                    </client>
                  </system.serviceModel>
                </configuration>";
            SafeWriteAllText(ConfigPath, xml);
        }

        public void WriteConfigWithAppSetting(string key, string value)
        {
            var xml =
                $@"<?xml version=""1.0"" encoding=""utf-8"" ?>
                <configuration>
                  <appSettings>
                    <add key=""{XmlAttrEscape(key)}"" value=""{XmlAttrEscape(value)}"" />
                  </appSettings>
                </configuration>";
            SafeWriteAllText(ConfigPath, xml);
        }

        public XmlDocument LoadXmlFromConfig()
        {
            var doc = new XmlDocument();
            doc.Load(ConfigPath);
            return doc;
        }

        public static XmlDocument InvokePrivateStaticLoadConfigDocument(Type targetType)
        {
            var mi = 
                targetType.GetMethod("LoadConfigDocument", BindingFlags.Public | BindingFlags.Static)
                ?? targetType.GetMethod("LoadConfigDocument", BindingFlags.NonPublic | BindingFlags.Static);

            Assert.IsNotNull(mi, "Private method LoadConfigDocument Not Found. Check the name.");

            var result = mi.Invoke(null, null);
            return (XmlDocument)result!;
        }

        private static string GetConfigPathAsProductionDoes()
        {
            var exe = Process.GetCurrentProcess().MainModule!.FileName!;
            var dllLike = exe.Replace("exe", "dll");
            return $"{dllLike}.config";
        }

        private static string XmlAttrEscape(string s)
        {
            return s
                .Replace("&", "&amp;")
                .Replace("\"", "&quot;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;");
        }
        private static void SafeCopy(string sourcePath, string destPath, bool overwrite)
        {
            EnsureDirectory(destPath);
            EnsureNotReadOnly(destPath);

            RetryIO(() =>
            {
                File.Copy(sourcePath, destPath, overwrite);
            });
        }

        private static void SafeDelete(string path)
        {
            if (!File.Exists(path)) return;

            EnsureNotReadOnly(path);

            RetryIO(() =>
            {
                File.Delete(path);
            });
        }

        private static void SafeWriteAllText(string path, string content)
        {
            EnsureDirectory(path);
            EnsureNotReadOnly(path);

            RetryIO(() =>
            {
                File.WriteAllText(path, content);
            });
        }

        private static void EnsureDirectory(string filePath)
        {
            var dir = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrWhiteSpace(dir))
                Directory.CreateDirectory(dir);
        }

        private static void EnsureNotReadOnly(string path)
        {
            if (!File.Exists(path)) return;

            var attr = File.GetAttributes(path);
            if ((attr & FileAttributes.ReadOnly) != 0)
            {
                File.SetAttributes(path, attr & ~FileAttributes.ReadOnly);
            }
        }

        private static void RetryIO(Action action, int attempts = 6, int baseDelayMs = 80)
        {
            Exception? last = null;

            for (int i = 0; i < attempts; i++)
            {
                try
                {
                    action();
                    return;
                }
                catch (UnauthorizedAccessException ex)
                {
                    last = ex;
                }
                catch (IOException ex)
                {
                    last = ex;
                }

                Thread.Sleep(baseDelayMs * (i + 1));
            }

            throw last!;
        }

        private static void TryDeleteDirectory(string dir)
        {
            try
            {
                if (Directory.Exists(dir))
                    Directory.Delete(dir, recursive: true);
            }
            catch
            {
                // 
            }
        }
    }
}
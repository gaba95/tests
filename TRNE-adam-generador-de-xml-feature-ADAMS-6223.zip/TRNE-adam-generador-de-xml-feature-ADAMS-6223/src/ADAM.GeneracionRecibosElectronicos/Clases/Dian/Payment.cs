﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("pago", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Payment
    {
        public int forma { get; set; }
        public string metodo { get; set; }
        public string banco { get; set; }
        public string tipoCuenta { get; set; }
        public string numeroCuenta { get; set; }
    }
}

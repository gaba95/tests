﻿using System.Data;
using System.Data.Odbc;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.Recibos.Datos.Clases.CatalogoAdicional
{
    public class CatalogoAdicionalOdbc : ICatalogoAdicional
    {
        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoAdicionalOdbc(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public bool CheckDbConnection()
        {
            return _connectionFactory.CheckConnection();
        }

        public string obtenCompaniasIdiomas()
        {
            return "";
        }

        public DataSet obtenDatasetTrabajadoresRecibo(string compania, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            string consulta = Properties.AppSettings.Default.Empleados;
            string query = consulta
                .Replace("@@anio", "?", StringComparison.Ordinal)
                .Replace("@@periodo", "?", StringComparison.Ordinal);

            OdbcCommand comando = new OdbcCommand(query, odbcConnection);
            comando.Parameters.Add("@@anio", OdbcType.Int).Value = anio;
            comando.Parameters.Add("@@periodo", OdbcType.Int).Value = periodo;

            DataSet ds = new DataSet();
            OdbcDataAdapter adapter = new OdbcDataAdapter(comando);
            adapter.Fill(ds);
            return ds;
        }

        public DataSet obtenDatasetCompanias(string szLangCode)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            string consulta = Properties.AppSettings.Default.Companias;

            OdbcCommand comando = new OdbcCommand(consulta, odbcConnection);
            DataSet ds = new DataSet();

            OdbcDataAdapter adapter = new OdbcDataAdapter(comando.CommandText, odbcConnection);
            adapter.Fill(ds);

            return ds;
        }

        public DataSet obtenDatasetClasesNomina(string compania)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            string consulta = Properties.AppSettings.Default.ClasesNomina;
            OdbcCommand comando = new OdbcCommand(consulta, odbcConnection);
            DataSet ds = new();

            OdbcDataAdapter adapter = new OdbcDataAdapter(comando.CommandText, odbcConnection);
            adapter.Fill(ds);

            return ds;
        }

        public DataSet obtenDatasetTiposNomina(string compania)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            string consulta = Properties.AppSettings.Default.TiposNomina;

            OdbcCommand comando = new OdbcCommand(consulta, odbcConnection);
            DataSet ds = new();

            OdbcDataAdapter adapter = new OdbcDataAdapter(comando.CommandText, odbcConnection);
            adapter.Fill(ds);

            return ds;
        }

        public DataSet obtenDatasetFormaPago()
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            string consulta = Properties.AppSettings.Default.MetodosPago;

            OdbcCommand comando = new OdbcCommand(consulta, odbcConnection);
            DataSet ds = new DataSet();

            OdbcDataAdapter adapter = new OdbcDataAdapter(comando.CommandText, odbcConnection);

            adapter.Fill(ds);

            return ds;
        }

        public DataSet obtenBasesDisponibles()
        {
            DataSet ds = new("BasesDisponibles");

            return ds;
        }

        public DataSet obtenListaPeriodosMes(string compania, string tipoNomina, int anio, int mesAcumular)
        {
            DataSet ds = new("ListaPeriodosMes");
            return ds;
        }

        #region Metodos tipos Percepcion

        public DataSet obtenDatasetTiposPercepcionDeduccion(int tipo)
        {
            return obtenBasesDisponibles();
        }

        public DataSet obtenDatasetDescripcionTipos()
        {
            DataSet ds = new("DescripcionTipos");
            return ds;
        }

        public DataSet obtenDatasetRelacionConceptos(int tipoConcepto, string claveTipo)
        {
            DataSet ds = new("RelacionConceptos");
            return ds;

        }

        public DataSet obtenDatasetConceptosRelacionar(int tipoConcepto, string claveTipo)
        {
            return obtenDatasetRelacionConceptos(tipoConcepto, claveTipo);

        }

        public bool AltaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            int resultadoEjecucion = 0;
            return resultadoEjecucion != 0;
        }

        public bool BajaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            return AltaRelacionConcepto(tipo, claveTipo, concepto);
        }

        #endregion

        #region Metodos Regimen Contratacion

        public DataSet obtenDatasetTrabajadoresRegimen(string compania)
        {
            DataSet ds = new("TrabajadoresRegimen");
            return ds;

        }

        public DataSet obtenDatasetRegimen()
        {
            return obtenBasesDisponibles();    

        }

        public bool AltaRelacionRegimen(string compania, string trabajador, string regimen)
        {
            int resultadoEjecucion = 0;
            return resultadoEjecucion != 0;
        }

        #endregion

        public bool existeTablaConfiguracion()
        {
            return false;
        }

        public bool DeletePayslipsData(string companyId, string payrollType, string payrollClass, int payrollYear, int payrollPeriod, string employee)
        {
            return false;
        }

        public DataSet obtenConfiguracionCompania(string compania)
        {
            return null;
        }

        public void GuardaConfiguracionCompania(string company, ConfigurationTypes parameterId, string description, string alphanumeric, decimal num_decimal = 0, int num_int = 0)
        {
            throw new NotImplementedException();
        }

        DataSet ICatalogoAdicional.ReadCSD()
        {
            throw new NotImplementedException();
        }

        bool ICatalogoAdicional.DeleteCSD(string client)
        {
            throw new NotImplementedException();
        }

        bool ICatalogoAdicional.CreateReplaceCSD(byte[] certBytes, byte[] keyBytes, string client, string key_pass)
        {
            throw new NotImplementedException();
        }

        DataSet ICatalogoAdicional.obtenParametrosCompania(string compania)
        {
            throw new NotImplementedException();
        }
    }
}

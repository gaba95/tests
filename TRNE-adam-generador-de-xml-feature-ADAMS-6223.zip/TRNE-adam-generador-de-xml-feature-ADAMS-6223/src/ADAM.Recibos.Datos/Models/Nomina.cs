﻿using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos.Clases
{
    public class Nomina
    {
        public string Compania { get; set; }
        public string Trabajador { get; set; }
        public string TipoNomina { get; set; }
        public string ClaseNomina { get; set; }
        public int Anio { get; set; }
        public int Periodo { get; set; }
        public ManejoNomina ManejoNomina { get; set; }
        public int NumeroLiquidacion { get; set; }
        public string ConceptoFactura { get; set; }
        public string FormaPagoDefault { get; set; }

        public Nomina(
            string compania,
            string trabajador,
            string tipoNomina,
            string claseNomina,
            int anio,
            int periodo,
            ManejoNomina manejoNomina,
            int numeroLiquidacion,
            string conceptoFactura,
            string formaPagoDefault)
        {
            Compania = compania;
            Trabajador = trabajador;
            TipoNomina = tipoNomina;
            ClaseNomina = claseNomina;
            Anio = anio;
            Periodo = periodo;
            ManejoNomina = manejoNomina;
            NumeroLiquidacion = numeroLiquidacion;
            ConceptoFactura = conceptoFactura;
            FormaPagoDefault = formaPagoDefault;
        }
    }
}

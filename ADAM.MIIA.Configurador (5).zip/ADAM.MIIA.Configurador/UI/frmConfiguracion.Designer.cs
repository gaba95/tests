namespace ADAM.MIIA.Configurador.UI;

partial class frmConfiguracion
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConfiguracion));
        pnlSuperior = new Panel();
        lblTitulo = new Label();
        pnlPrincipal = new Panel();
        tabParametros = new TabControl();
        tabServicio = new TabPage();
        pnlEventosServicio = new Panel();
        lvEventos = new ListView();
        ColumnHeader1 = new ColumnHeader();
        ilIconos = new ImageList(components);
        Panel2 = new Panel();
        cmdEventViewer = new Button();
        lblNotaEventos = new Label();
        pnlServicio = new Panel();
        lblEstadoServicio2 = new Label();
        cmdDetener = new Button();
        lblEstadoServicio = new Label();
        cmdActualizar = new Button();
        chkActualiza = new CheckBox();
        lblEventos = new Label();
        cmdReinicia = new Button();
        tabGeneral = new TabPage();
        pnlGenerales = new Panel();
        Label6 = new Label();
        nupdTimeConnectionRetries = new NumericUpDown();
        lblTimeConnectionRetries = new Label();
        nupdConnectionRetries = new NumericUpDown();
        lblConnectionRetries = new Label();
        cmdRutaResumenEnExcel = new Button();
        Label5 = new Label();
        txtRutaResumenEnExcel = new TextBox();
        cboUsarJobsSQL = new ComboBox();
        lblUsarJobsSQL = new Label();
        cboArchivosEncriptados = new ComboBox();
        lblEncriptados = new Label();
        txtPasswordGPG = new TextBox();
        lblContrasenia = new Label();
        txtNombresArchivosInmediata = new TextBox();
        lblNombresArchivosInmediata = new Label();
        cboEjecucionInmediata = new ComboBox();
        lblEjecucionInmediata = new Label();
        txtPatron = new TextBox();
        lblPatron = new Label();
        cboArchivoControl = new ComboBox();
        cboVeces = new ComboBox();
        cmdRutaDestino = new Button();
        txtCarpetas = new TextBox();
        lblCarpetas = new Label();
        lblUsarControl = new Label();
        lblVecesEjecutar = new Label();
        cmdRutaOrigen = new Button();
        cmdAceptar = new Button();
        txtNombresArchivosCtrl = new TextBox();
        txtRutaDestino = new TextBox();
        txtRutaOrigen = new TextBox();
        lblNombresArchivosCtrl = new Label();
        lblRutaDestino = new Label();
        lblRutaOrigen = new Label();
        tabCorreo = new TabPage();
        pnlCorreo = new Panel();
        cmdGuardaCorreo = new Button();
        cmdProbar = new Button();
        txtTimeOut = new TextBox();
        lblTimeOut = new Label();
        txtPassword = new TextBox();
        label2 = new Label();
        txtUsuario = new TextBox();
        lblUsuario = new Label();
        cboSSL = new ComboBox();
        lblSsl = new Label();
        txtPuerto = new TextBox();
        lblPuerto = new Label();
        txtServidorCorreo = new TextBox();
        lblServidor = new Label();
        cboPrioridad = new ComboBox();
        lblPrioridad = new Label();
        cboHtml = new ComboBox();
        lblHtml = new Label();
        txtMensaje = new TextBox();
        lblMensaje = new Label();
        txtMail = new TextBox();
        lblCorreoDe = new Label();
        txtTitulo = new TextBox();
        lblTituloCorreo = new Label();
        txtNombre = new TextBox();
        lblDeCorreo = new Label();
        tabClientes = new TabPage();
        gridParametrosCliente = new DataGridView();
        pnlBotonesClientes = new Panel();
        cmdEliminar = new Button();
        cmdModificar = new Button();
        cmdAgregar = new Button();
        tabProcedures = new TabPage();
        gridProcedures = new DataGridView();
        pnlBotonesProcs = new Panel();
        cmdEliminarProc = new Button();
        cmdModificarProc = new Button();
        cmdAgregarProc = new Button();
        tabOnDemand = new TabPage();
        gridOnDemand = new DataGridView();
        Panel1 = new Panel();
        cmdEliminarOnDemand = new Button();
        cmdModificarOnDemand = new Button();
        cmdAgregarOnDemand = new Button();
        tabOrderProcess = new TabPage();
        gridOrderProcess = new DataGridView();
        Panel3 = new Panel();
        btnDeleteOrderProcess = new Button();
        btnUpdateOrderProcess = new Button();
        btnAddOrderProcess = new Button();
        tabTalentDB = new TabPage();
        btnSaveTalentDB = new Button();
        chkEnableTalentDB = new CheckBox();
        grpTalentDBConnection = new GroupBox();
        cboConnectionType = new ComboBox();
        Label1 = new Label();
        txtDatabaseTalent = new TextBox();
        txtServerTalent = new TextBox();
        lblBase = new Label();
        Label3 = new Label();
        btnTestConnection = new Button();
        txtPasswordTalent = new TextBox();
        lblPassword = new Label();
        txtUserTalent = new TextBox();
        Label4 = new Label();
        lblConnectionString = new Label();
        cmdCancelar = new Button();
        pnlEstado = new Panel();
        pnlBotones = new Panel();
        fbdRuta = new FolderBrowserDialog();
        scMIIA = new System.ServiceProcess.ServiceController();
        timerEventos = new System.Windows.Forms.Timer(components);
        EventLogADAM = new System.Diagnostics.EventLog();
        pnlSuperior.SuspendLayout();
        pnlPrincipal.SuspendLayout();
        tabParametros.SuspendLayout();
        tabServicio.SuspendLayout();
        pnlEventosServicio.SuspendLayout();
        Panel2.SuspendLayout();
        pnlServicio.SuspendLayout();
        tabGeneral.SuspendLayout();
        pnlGenerales.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)nupdTimeConnectionRetries).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nupdConnectionRetries).BeginInit();
        tabCorreo.SuspendLayout();
        pnlCorreo.SuspendLayout();
        tabClientes.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridParametrosCliente).BeginInit();
        pnlBotonesClientes.SuspendLayout();
        tabProcedures.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridProcedures).BeginInit();
        pnlBotonesProcs.SuspendLayout();
        tabOnDemand.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridOnDemand).BeginInit();
        Panel1.SuspendLayout();
        tabOrderProcess.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridOrderProcess).BeginInit();
        Panel3.SuspendLayout();
        tabTalentDB.SuspendLayout();
        grpTalentDBConnection.SuspendLayout();
        pnlBotones.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)EventLogADAM).BeginInit();
        SuspendLayout();
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(92, 145, 163);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(1370, 42);
        pnlSuperior.TabIndex = 2;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(12, 8);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(360, 29);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Configuración del Servicio MIIA";
        // 
        // pnlPrincipal
        // 
        pnlPrincipal.Controls.Add(tabParametros);
        pnlPrincipal.Dock = DockStyle.Fill;
        pnlPrincipal.Location = new Point(0, 102);
        pnlPrincipal.Name = "pnlPrincipal";
        pnlPrincipal.Size = new Size(1370, 776);
        pnlPrincipal.TabIndex = 6;
        // 
        // tabParametros
        // 
        tabParametros.Controls.Add(tabServicio);
        tabParametros.Controls.Add(tabGeneral);
        tabParametros.Controls.Add(tabCorreo);
        tabParametros.Controls.Add(tabClientes);
        tabParametros.Controls.Add(tabProcedures);
        tabParametros.Controls.Add(tabOnDemand);
        tabParametros.Controls.Add(tabOrderProcess);
        tabParametros.Controls.Add(tabTalentDB);
        tabParametros.Dock = DockStyle.Fill;
        tabParametros.Font = new Font("Tahoma", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
        tabParametros.Location = new Point(0, 0);
        tabParametros.Name = "tabParametros";
        tabParametros.SelectedIndex = 0;
        tabParametros.Size = new Size(1370, 776);
        tabParametros.TabIndex = 0;
        tabParametros.Click += tabParametros_Click;
        // 
        // tabServicio
        // 
        tabServicio.BackColor = Color.FromArgb(227, 237, 239);
        tabServicio.Controls.Add(pnlEventosServicio);
        tabServicio.Controls.Add(pnlServicio);
        tabServicio.Location = new Point(4, 30);
        tabServicio.Name = "tabServicio";
        tabServicio.Padding = new Padding(3);
        tabServicio.Size = new Size(1362, 742);
        tabServicio.TabIndex = 5;
        tabServicio.Text = "Servicio";
        // 
        // pnlEventosServicio
        // 
        pnlEventosServicio.Controls.Add(lvEventos);
        pnlEventosServicio.Controls.Add(Panel2);
        pnlEventosServicio.Dock = DockStyle.Fill;
        pnlEventosServicio.Location = new Point(3, 197);
        pnlEventosServicio.Name = "pnlEventosServicio";
        pnlEventosServicio.Size = new Size(1356, 542);
        pnlEventosServicio.TabIndex = 1;
        // 
        // lvEventos
        // 
        lvEventos.BorderStyle = BorderStyle.FixedSingle;
        lvEventos.Columns.AddRange(new ColumnHeader[] { ColumnHeader1 });
        lvEventos.FullRowSelect = true;
        lvEventos.Location = new Point(7, 6);
        lvEventos.Name = "lvEventos";
        lvEventos.Size = new Size(1346, 480);
        lvEventos.SmallImageList = ilIconos;
        lvEventos.TabIndex = 1;
        lvEventos.UseCompatibleStateImageBehavior = false;
        lvEventos.View = View.Details;
        lvEventos.SizeChanged += lvEventos_SizeChanged;
        // 
        // ColumnHeader1
        // 
        ColumnHeader1.Text = "";
        ColumnHeader1.Width = 2000;
        // 
        // ilIconos
        // 
        ilIconos.ColorDepth = ColorDepth.Depth8Bit;
        ilIconos.ImageSize = new Size(16, 16);
        ilIconos.TransparentColor = Color.Transparent;
        // 
        // Panel2
        // 
        Panel2.Controls.Add(cmdEventViewer);
        Panel2.Controls.Add(lblNotaEventos);
        Panel2.Location = new Point(4, 492);
        Panel2.Name = "Panel2";
        Panel2.Size = new Size(1356, 61);
        Panel2.TabIndex = 0;
        // 
        // cmdEventViewer
        // 
        cmdEventViewer.Anchor = AnchorStyles.Right;
        cmdEventViewer.BackColor = Color.FromArgb(227, 237, 239);
        cmdEventViewer.FlatAppearance.BorderColor = Color.Gray;
        cmdEventViewer.FlatStyle = FlatStyle.Flat;
        cmdEventViewer.Font = new Font("Tahoma", 8.25F);
        cmdEventViewer.ForeColor = Color.Black;
        cmdEventViewer.Location = new Point(668, 9);
        cmdEventViewer.Name = "cmdEventViewer";
        cmdEventViewer.Size = new Size(39, 35);
        cmdEventViewer.TabIndex = 11;
        cmdEventViewer.Text = "...";
        cmdEventViewer.UseVisualStyleBackColor = false;
        cmdEventViewer.Click += cmdEventViewer_Click;
        // 
        // lblNotaEventos
        // 
        lblNotaEventos.AutoSize = true;
        lblNotaEventos.Font = new Font("Tahoma", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
        lblNotaEventos.Location = new Point(11, 17);
        lblNotaEventos.Name = "lblNotaEventos";
        lblNotaEventos.Size = new Size(648, 21);
        lblNotaEventos.TabIndex = 10;
        lblNotaEventos.Text = "Para depurar o ver más detalle de los eventos ingrese al visor de eventos de Windows";
        // 
        // pnlServicio
        // 
        pnlServicio.BackColor = Color.FromArgb(227, 237, 239);
        pnlServicio.Controls.Add(lblEstadoServicio2);
        pnlServicio.Controls.Add(cmdDetener);
        pnlServicio.Controls.Add(lblEstadoServicio);
        pnlServicio.Controls.Add(cmdActualizar);
        pnlServicio.Controls.Add(chkActualiza);
        pnlServicio.Controls.Add(lblEventos);
        pnlServicio.Controls.Add(cmdReinicia);
        pnlServicio.Dock = DockStyle.Top;
        pnlServicio.Location = new Point(3, 3);
        pnlServicio.Name = "pnlServicio";
        pnlServicio.Size = new Size(1356, 194);
        pnlServicio.TabIndex = 0;
        // 
        // lblEstadoServicio2
        // 
        lblEstadoServicio2.AutoSize = true;
        lblEstadoServicio2.Font = new Font("Tahoma", 8.25F);
        lblEstadoServicio2.Location = new Point(23, 43);
        lblEstadoServicio2.Name = "lblEstadoServicio2";
        lblEstadoServicio2.Size = new Size(156, 21);
        lblEstadoServicio2.TabIndex = 10;
        lblEstadoServicio2.Text = "Estado del Servicio:";
        // 
        // cmdDetener
        // 
        cmdDetener.Anchor = AnchorStyles.Right;
        cmdDetener.BackColor = Color.FromArgb(227, 237, 239);
        cmdDetener.FlatAppearance.BorderColor = Color.Gray;
        cmdDetener.FlatStyle = FlatStyle.Flat;
        cmdDetener.Font = new Font("Tahoma", 8.25F);
        cmdDetener.ForeColor = Color.Black;
        cmdDetener.Location = new Point(86, 69);
        cmdDetener.Name = "cmdDetener";
        cmdDetener.Size = new Size(174, 35);
        cmdDetener.TabIndex = 7;
        cmdDetener.Text = "Detener Servicio";
        cmdDetener.UseVisualStyleBackColor = false;
        cmdDetener.Click += cmdDetener_Click;
        // 
        // lblEstadoServicio
        // 
        lblEstadoServicio.AutoSize = true;
        lblEstadoServicio.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblEstadoServicio.Location = new Point(3, 18);
        lblEstadoServicio.Name = "lblEstadoServicio";
        lblEstadoServicio.Size = new Size(0, 26);
        lblEstadoServicio.TabIndex = 6;
        // 
        // cmdActualizar
        // 
        cmdActualizar.Anchor = AnchorStyles.Right;
        cmdActualizar.BackColor = Color.FromArgb(227, 237, 239);
        cmdActualizar.FlatAppearance.BorderColor = Color.Gray;
        cmdActualizar.FlatStyle = FlatStyle.Flat;
        cmdActualizar.Font = new Font("Tahoma", 8.25F);
        cmdActualizar.ForeColor = Color.Black;
        cmdActualizar.Location = new Point(457, 118);
        cmdActualizar.Name = "cmdActualizar";
        cmdActualizar.Size = new Size(156, 30);
        cmdActualizar.TabIndex = 7;
        cmdActualizar.Text = "Renovar";
        cmdActualizar.UseVisualStyleBackColor = false;
        cmdActualizar.Click += cmdActualizar_Click;
        // 
        // chkActualiza
        // 
        chkActualiza.Anchor = AnchorStyles.Right;
        chkActualiza.AutoSize = true;
        chkActualiza.FlatStyle = FlatStyle.Popup;
        chkActualiza.Font = new Font("Tahoma", 8.25F);
        chkActualiza.Location = new Point(199, 120);
        chkActualiza.Name = "chkActualiza";
        chkActualiza.Size = new Size(243, 25);
        chkActualiza.TabIndex = 8;
        chkActualiza.Text = "Actualizar Automaticamente";
        chkActualiza.UseVisualStyleBackColor = true;
        chkActualiza.CheckedChanged += chkActualiza_CheckedChanged;
        // 
        // lblEventos
        // 
        lblEventos.AutoSize = true;
        lblEventos.Font = new Font("Tahoma", 8.25F);
        lblEventos.Location = new Point(15, 122);
        lblEventos.Name = "lblEventos";
        lblEventos.Size = new Size(163, 21);
        lblEventos.TabIndex = 9;
        lblEventos.Text = "Eventos del servicio:";
        // 
        // cmdReinicia
        // 
        cmdReinicia.Anchor = AnchorStyles.Right;
        cmdReinicia.BackColor = Color.FromArgb(227, 237, 239);
        cmdReinicia.FlatAppearance.BorderColor = Color.Gray;
        cmdReinicia.FlatStyle = FlatStyle.Flat;
        cmdReinicia.Font = new Font("Tahoma", 8.25F);
        cmdReinicia.ForeColor = Color.Black;
        cmdReinicia.Location = new Point(266, 69);
        cmdReinicia.Name = "cmdReinicia";
        cmdReinicia.Size = new Size(179, 35);
        cmdReinicia.TabIndex = 5;
        cmdReinicia.Text = "Reiniciar Servicio";
        cmdReinicia.UseVisualStyleBackColor = false;
        cmdReinicia.Click += cmdReinicia_Click;
        // 
        // tabGeneral
        // 
        tabGeneral.BackColor = Color.FromArgb(227, 237, 239);
        tabGeneral.Controls.Add(pnlGenerales);
        tabGeneral.Location = new Point(4, 30);
        tabGeneral.Name = "tabGeneral";
        tabGeneral.Size = new Size(1362, 742);
        tabGeneral.TabIndex = 0;
        tabGeneral.Text = "Parámetros Generales";
        // 
        // pnlGenerales
        // 
        pnlGenerales.AutoScroll = true;
        pnlGenerales.Controls.Add(Label6);
        pnlGenerales.Controls.Add(nupdTimeConnectionRetries);
        pnlGenerales.Controls.Add(lblTimeConnectionRetries);
        pnlGenerales.Controls.Add(nupdConnectionRetries);
        pnlGenerales.Controls.Add(lblConnectionRetries);
        pnlGenerales.Controls.Add(cmdRutaResumenEnExcel);
        pnlGenerales.Controls.Add(Label5);
        pnlGenerales.Controls.Add(txtRutaResumenEnExcel);
        pnlGenerales.Controls.Add(cboUsarJobsSQL);
        pnlGenerales.Controls.Add(lblUsarJobsSQL);
        pnlGenerales.Controls.Add(cboArchivosEncriptados);
        pnlGenerales.Controls.Add(lblEncriptados);
        pnlGenerales.Controls.Add(txtPasswordGPG);
        pnlGenerales.Controls.Add(lblContrasenia);
        pnlGenerales.Controls.Add(txtNombresArchivosInmediata);
        pnlGenerales.Controls.Add(lblNombresArchivosInmediata);
        pnlGenerales.Controls.Add(cboEjecucionInmediata);
        pnlGenerales.Controls.Add(lblEjecucionInmediata);
        pnlGenerales.Controls.Add(txtPatron);
        pnlGenerales.Controls.Add(lblPatron);
        pnlGenerales.Controls.Add(cboArchivoControl);
        pnlGenerales.Controls.Add(cboVeces);
        pnlGenerales.Controls.Add(cmdRutaDestino);
        pnlGenerales.Controls.Add(txtCarpetas);
        pnlGenerales.Controls.Add(lblCarpetas);
        pnlGenerales.Controls.Add(lblUsarControl);
        pnlGenerales.Controls.Add(lblVecesEjecutar);
        pnlGenerales.Controls.Add(cmdRutaOrigen);
        pnlGenerales.Controls.Add(cmdAceptar);
        pnlGenerales.Controls.Add(txtNombresArchivosCtrl);
        pnlGenerales.Controls.Add(txtRutaDestino);
        pnlGenerales.Controls.Add(txtRutaOrigen);
        pnlGenerales.Controls.Add(lblNombresArchivosCtrl);
        pnlGenerales.Controls.Add(lblRutaDestino);
        pnlGenerales.Controls.Add(lblRutaOrigen);
        pnlGenerales.Dock = DockStyle.Fill;
        pnlGenerales.Location = new Point(0, 0);
        pnlGenerales.Name = "pnlGenerales";
        pnlGenerales.Size = new Size(1362, 742);
        pnlGenerales.TabIndex = 0;
        // 
        // Label6
        // 
        Label6.AutoSize = true;
        Label6.Font = new Font("Trebuchet MS", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
        Label6.Location = new Point(500, 580);
        Label6.Name = "Label6";
        Label6.Size = new Size(122, 23);
        Label6.TabIndex = 41;
        Label6.Text = "(en segundos)";
        // 
        // nupdTimeConnectionRetries
        // 
        nupdTimeConnectionRetries.Location = new Point(419, 579);
        nupdTimeConnectionRetries.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nupdTimeConnectionRetries.Name = "nupdTimeConnectionRetries";
        nupdTimeConnectionRetries.Size = new Size(75, 27);
        nupdTimeConnectionRetries.TabIndex = 40;
        // 
        // lblTimeConnectionRetries
        // 
        lblTimeConnectionRetries.AutoSize = true;
        lblTimeConnectionRetries.Location = new Point(12, 582);
        lblTimeConnectionRetries.Name = "lblTimeConnectionRetries";
        lblTimeConnectionRetries.Size = new Size(366, 21);
        lblTimeConnectionRetries.TabIndex = 39;
        lblTimeConnectionRetries.Text = "Tiempo de espera entre reintentos de conexión:";
        // 
        // nupdConnectionRetries
        // 
        nupdConnectionRetries.Location = new Point(419, 539);
        nupdConnectionRetries.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nupdConnectionRetries.Name = "nupdConnectionRetries";
        nupdConnectionRetries.Size = new Size(75, 27);
        nupdConnectionRetries.TabIndex = 38;
        // 
        // lblConnectionRetries
        // 
        lblConnectionRetries.AutoSize = true;
        lblConnectionRetries.Location = new Point(12, 541);
        lblConnectionRetries.Name = "lblConnectionRetries";
        lblConnectionRetries.Size = new Size(248, 21);
        lblConnectionRetries.TabIndex = 37;
        lblConnectionRetries.Text = "Reintentos de conexión a la BD:";
        // 
        // cmdRutaResumenEnExcel
        // 
        cmdRutaResumenEnExcel.BackColor = Color.FromArgb(227, 237, 239);
        cmdRutaResumenEnExcel.FlatAppearance.BorderColor = Color.Gray;
        cmdRutaResumenEnExcel.FlatStyle = FlatStyle.Flat;
        cmdRutaResumenEnExcel.Font = new Font("Tahoma", 8.25F);
        cmdRutaResumenEnExcel.ForeColor = Color.Black;
        cmdRutaResumenEnExcel.Location = new Point(941, 499);
        cmdRutaResumenEnExcel.Name = "cmdRutaResumenEnExcel";
        cmdRutaResumenEnExcel.Size = new Size(40, 30);
        cmdRutaResumenEnExcel.TabIndex = 36;
        cmdRutaResumenEnExcel.Text = "...";
        cmdRutaResumenEnExcel.UseVisualStyleBackColor = false;
        cmdRutaResumenEnExcel.Click += cmdRutaResumenEnExcel_Click;
        // 
        // Label5
        // 
        Label5.AutoSize = true;
        Label5.Location = new Point(12, 504);
        Label5.Name = "Label5";
        Label5.Size = new Size(214, 21);
        Label5.TabIndex = 35;
        Label5.Text = "Ruta del resumen en Excel:";
        // 
        // txtRutaResumenEnExcel
        // 
        txtRutaResumenEnExcel.BorderStyle = BorderStyle.None;
        txtRutaResumenEnExcel.Enabled = false;
        txtRutaResumenEnExcel.Location = new Point(419, 504);
        txtRutaResumenEnExcel.MaxLength = 300;
        txtRutaResumenEnExcel.Name = "txtRutaResumenEnExcel";
        txtRutaResumenEnExcel.Size = new Size(516, 20);
        txtRutaResumenEnExcel.TabIndex = 34;
        // 
        // cboUsarJobsSQL
        // 
        cboUsarJobsSQL.FormattingEnabled = true;
        cboUsarJobsSQL.Items.AddRange(new object[] { "True", "False" });
        cboUsarJobsSQL.Location = new Point(419, 459);
        cboUsarJobsSQL.Name = "cboUsarJobsSQL";
        cboUsarJobsSQL.Size = new Size(148, 29);
        cboUsarJobsSQL.TabIndex = 29;
        // 
        // lblUsarJobsSQL
        // 
        lblUsarJobsSQL.AutoSize = true;
        lblUsarJobsSQL.Location = new Point(12, 462);
        lblUsarJobsSQL.Name = "lblUsarJobsSQL";
        lblUsarJobsSQL.Size = new Size(122, 21);
        lblUsarJobsSQL.TabIndex = 28;
        lblUsarJobsSQL.Text = "Usar Jobs SQL:";
        // 
        // cboArchivosEncriptados
        // 
        cboArchivosEncriptados.FormattingEnabled = true;
        cboArchivosEncriptados.Items.AddRange(new object[] { "True", "False" });
        cboArchivosEncriptados.Location = new Point(419, 382);
        cboArchivosEncriptados.Name = "cboArchivosEncriptados";
        cboArchivosEncriptados.Size = new Size(148, 29);
        cboArchivosEncriptados.TabIndex = 27;
        // 
        // lblEncriptados
        // 
        lblEncriptados.AutoSize = true;
        lblEncriptados.Location = new Point(12, 390);
        lblEncriptados.Name = "lblEncriptados";
        lblEncriptados.Size = new Size(170, 21);
        lblEncriptados.TabIndex = 26;
        lblEncriptados.Text = "Archivos encriptados:";
        // 
        // txtPasswordGPG
        // 
        txtPasswordGPG.BorderStyle = BorderStyle.None;
        txtPasswordGPG.Location = new Point(419, 426);
        txtPasswordGPG.MaxLength = 300;
        txtPasswordGPG.Name = "txtPasswordGPG";
        txtPasswordGPG.Size = new Size(516, 20);
        txtPasswordGPG.TabIndex = 25;
        txtPasswordGPG.UseSystemPasswordChar = true;
        // 
        // lblContrasenia
        // 
        lblContrasenia.AutoSize = true;
        lblContrasenia.Location = new Point(12, 426);
        lblContrasenia.Name = "lblContrasenia";
        lblContrasenia.Size = new Size(100, 21);
        lblContrasenia.TabIndex = 24;
        lblContrasenia.Text = "Contraseña:";
        // 
        // txtNombresArchivosInmediata
        // 
        txtNombresArchivosInmediata.BorderStyle = BorderStyle.None;
        txtNombresArchivosInmediata.Location = new Point(419, 344);
        txtNombresArchivosInmediata.MaxLength = 300;
        txtNombresArchivosInmediata.Name = "txtNombresArchivosInmediata";
        txtNombresArchivosInmediata.Size = new Size(516, 20);
        txtNombresArchivosInmediata.TabIndex = 19;
        // 
        // lblNombresArchivosInmediata
        // 
        lblNombresArchivosInmediata.AutoSize = true;
        lblNombresArchivosInmediata.Location = new Point(12, 344);
        lblNombresArchivosInmediata.Name = "lblNombresArchivosInmediata";
        lblNombresArchivosInmediata.Size = new Size(324, 21);
        lblNombresArchivosInmediata.TabIndex = 18;
        lblNombresArchivosInmediata.Text = "Nombres de archivos ejecucion inmediata:";
        // 
        // cboEjecucionInmediata
        // 
        cboEjecucionInmediata.FormattingEnabled = true;
        cboEjecucionInmediata.Items.AddRange(new object[] { "True", "False" });
        cboEjecucionInmediata.Location = new Point(419, 300);
        cboEjecucionInmediata.Name = "cboEjecucionInmediata";
        cboEjecucionInmediata.Size = new Size(148, 29);
        cboEjecucionInmediata.TabIndex = 17;
        // 
        // lblEjecucionInmediata
        // 
        lblEjecucionInmediata.AutoSize = true;
        lblEjecucionInmediata.Location = new Point(12, 303);
        lblEjecucionInmediata.Name = "lblEjecucionInmediata";
        lblEjecucionInmediata.Size = new Size(227, 21);
        lblEjecucionInmediata.TabIndex = 16;
        lblEjecucionInmediata.Text = "Permitir ejecución inmediata:";
        // 
        // txtPatron
        // 
        txtPatron.BorderStyle = BorderStyle.None;
        txtPatron.Location = new Point(419, 263);
        txtPatron.MaxLength = 300;
        txtPatron.Name = "txtPatron";
        txtPatron.Size = new Size(516, 20);
        txtPatron.TabIndex = 15;
        // 
        // lblPatron
        // 
        lblPatron.AutoSize = true;
        lblPatron.Location = new Point(12, 263);
        lblPatron.Name = "lblPatron";
        lblPatron.Size = new Size(254, 21);
        lblPatron.TabIndex = 14;
        lblPatron.Text = "Patrón de validación de archivos:";
        // 
        // cboArchivoControl
        // 
        cboArchivoControl.FormattingEnabled = true;
        cboArchivoControl.Items.AddRange(new object[] { "True", "False" });
        cboArchivoControl.Location = new Point(419, 220);
        cboArchivoControl.Name = "cboArchivoControl";
        cboArchivoControl.Size = new Size(148, 29);
        cboArchivoControl.TabIndex = 13;
        // 
        // cboVeces
        // 
        cboVeces.FormattingEnabled = true;
        cboVeces.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
        cboVeces.Location = new Point(419, 176);
        cboVeces.Name = "cboVeces";
        cboVeces.Size = new Size(148, 29);
        cboVeces.TabIndex = 12;
        // 
        // cmdRutaDestino
        // 
        cmdRutaDestino.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdRutaDestino.BackColor = Color.FromArgb(227, 237, 239);
        cmdRutaDestino.DialogResult = DialogResult.Cancel;
        cmdRutaDestino.FlatAppearance.BorderColor = Color.Gray;
        cmdRutaDestino.FlatStyle = FlatStyle.Flat;
        cmdRutaDestino.Font = new Font("Tahoma", 8.25F);
        cmdRutaDestino.ForeColor = Color.Black;
        cmdRutaDestino.Location = new Point(941, 69);
        cmdRutaDestino.Name = "cmdRutaDestino";
        cmdRutaDestino.Size = new Size(40, 30);
        cmdRutaDestino.TabIndex = 11;
        cmdRutaDestino.Text = "...";
        cmdRutaDestino.UseVisualStyleBackColor = false;
        cmdRutaDestino.Click += cmdRutaDestino_Click;
        // 
        // txtCarpetas
        // 
        txtCarpetas.BorderStyle = BorderStyle.None;
        txtCarpetas.Location = new Point(419, 144);
        txtCarpetas.MaxLength = 300;
        txtCarpetas.Name = "txtCarpetas";
        txtCarpetas.Size = new Size(759, 20);
        txtCarpetas.TabIndex = 10;
        // 
        // lblCarpetas
        // 
        lblCarpetas.AutoSize = true;
        lblCarpetas.Location = new Point(12, 144);
        lblCarpetas.Name = "lblCarpetas";
        lblCarpetas.Size = new Size(165, 21);
        lblCarpetas.TabIndex = 9;
        lblCarpetas.Text = "Carpetas a procesar:";
        // 
        // lblUsarControl
        // 
        lblUsarControl.AutoSize = true;
        lblUsarControl.Location = new Point(12, 223);
        lblUsarControl.Name = "lblUsarControl";
        lblUsarControl.Size = new Size(187, 21);
        lblUsarControl.TabIndex = 8;
        lblUsarControl.Text = "Usar archivo de control:";
        // 
        // lblVecesEjecutar
        // 
        lblVecesEjecutar.AutoSize = true;
        lblVecesEjecutar.Location = new Point(12, 179);
        lblVecesEjecutar.Name = "lblVecesEjecutar";
        lblVecesEjecutar.Size = new Size(209, 21);
        lblVecesEjecutar.TabIndex = 7;
        lblVecesEjecutar.Text = "Veces que ejecuta los SPs:";
        // 
        // cmdRutaOrigen
        // 
        cmdRutaOrigen.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdRutaOrigen.BackColor = Color.FromArgb(227, 237, 239);
        cmdRutaOrigen.FlatAppearance.BorderColor = Color.Gray;
        cmdRutaOrigen.FlatStyle = FlatStyle.Flat;
        cmdRutaOrigen.Font = new Font("Tahoma", 8.25F);
        cmdRutaOrigen.ForeColor = Color.Black;
        cmdRutaOrigen.Location = new Point(941, 30);
        cmdRutaOrigen.Name = "cmdRutaOrigen";
        cmdRutaOrigen.Size = new Size(40, 30);
        cmdRutaOrigen.TabIndex = 6;
        cmdRutaOrigen.Text = "...";
        cmdRutaOrigen.TextAlign = ContentAlignment.TopCenter;
        cmdRutaOrigen.UseVisualStyleBackColor = false;
        cmdRutaOrigen.Click += cmdRutaOrigen_Click;
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cmdAceptar.BackColor = Color.FromArgb(227, 237, 239);
        cmdAceptar.FlatAppearance.BorderColor = Color.Gray;
        cmdAceptar.FlatStyle = FlatStyle.Flat;
        cmdAceptar.Font = new Font("Tahoma", 8.25F);
        cmdAceptar.ForeColor = Color.Black;
        cmdAceptar.Location = new Point(1229, 694);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 5;
        cmdAceptar.Text = "Guardar";
        cmdAceptar.UseVisualStyleBackColor = false;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // txtNombresArchivosCtrl
        // 
        txtNombresArchivosCtrl.BorderStyle = BorderStyle.None;
        txtNombresArchivosCtrl.Location = new Point(419, 107);
        txtNombresArchivosCtrl.MaxLength = 300;
        txtNombresArchivosCtrl.Name = "txtNombresArchivosCtrl";
        txtNombresArchivosCtrl.Size = new Size(516, 20);
        txtNombresArchivosCtrl.TabIndex = 4;
        // 
        // txtRutaDestino
        // 
        txtRutaDestino.BackColor = SystemColors.Control;
        txtRutaDestino.BorderStyle = BorderStyle.None;
        txtRutaDestino.Enabled = false;
        txtRutaDestino.Location = new Point(419, 74);
        txtRutaDestino.MaxLength = 300;
        txtRutaDestino.Name = "txtRutaDestino";
        txtRutaDestino.Size = new Size(516, 20);
        txtRutaDestino.TabIndex = 3;
        // 
        // txtRutaOrigen
        // 
        txtRutaOrigen.BorderStyle = BorderStyle.None;
        txtRutaOrigen.Enabled = false;
        txtRutaOrigen.Location = new Point(419, 35);
        txtRutaOrigen.MaxLength = 300;
        txtRutaOrigen.Name = "txtRutaOrigen";
        txtRutaOrigen.Size = new Size(516, 20);
        txtRutaOrigen.TabIndex = 2;
        // 
        // lblNombresArchivosCtrl
        // 
        lblNombresArchivosCtrl.AutoSize = true;
        lblNombresArchivosCtrl.Location = new Point(12, 107);
        lblNombresArchivosCtrl.Name = "lblNombresArchivosCtrl";
        lblNombresArchivosCtrl.Size = new Size(227, 21);
        lblNombresArchivosCtrl.TabIndex = 2;
        lblNombresArchivosCtrl.Text = "Nombres archivos de control:";
        // 
        // lblRutaDestino
        // 
        lblRutaDestino.AutoSize = true;
        lblRutaDestino.Location = new Point(12, 80);
        lblRutaDestino.Name = "lblRutaDestino";
        lblRutaDestino.Size = new Size(110, 21);
        lblRutaDestino.TabIndex = 1;
        lblRutaDestino.Text = "Ruta destino:";
        // 
        // lblRutaOrigen
        // 
        lblRutaOrigen.AutoSize = true;
        lblRutaOrigen.Location = new Point(12, 36);
        lblRutaOrigen.Name = "lblRutaOrigen";
        lblRutaOrigen.Size = new Size(102, 21);
        lblRutaOrigen.TabIndex = 0;
        lblRutaOrigen.Text = "Ruta origen:";
        // 
        // tabCorreo
        // 
        tabCorreo.BackColor = Color.FromArgb(227, 237, 239);
        tabCorreo.Controls.Add(pnlCorreo);
        tabCorreo.Location = new Point(4, 30);
        tabCorreo.Name = "tabCorreo";
        tabCorreo.Size = new Size(1362, 742);
        tabCorreo.TabIndex = 1;
        tabCorreo.Text = "Parámetros Correo";
        // 
        // pnlCorreo
        // 
        pnlCorreo.Controls.Add(cmdGuardaCorreo);
        pnlCorreo.Controls.Add(cmdProbar);
        pnlCorreo.Controls.Add(txtTimeOut);
        pnlCorreo.Controls.Add(lblTimeOut);
        pnlCorreo.Controls.Add(txtPassword);
        pnlCorreo.Controls.Add(label2);
        pnlCorreo.Controls.Add(txtUsuario);
        pnlCorreo.Controls.Add(lblUsuario);
        pnlCorreo.Controls.Add(cboSSL);
        pnlCorreo.Controls.Add(lblSsl);
        pnlCorreo.Controls.Add(txtPuerto);
        pnlCorreo.Controls.Add(lblPuerto);
        pnlCorreo.Controls.Add(txtServidorCorreo);
        pnlCorreo.Controls.Add(lblServidor);
        pnlCorreo.Controls.Add(cboPrioridad);
        pnlCorreo.Controls.Add(lblPrioridad);
        pnlCorreo.Controls.Add(cboHtml);
        pnlCorreo.Controls.Add(lblHtml);
        pnlCorreo.Controls.Add(txtMensaje);
        pnlCorreo.Controls.Add(lblMensaje);
        pnlCorreo.Controls.Add(txtMail);
        pnlCorreo.Controls.Add(lblCorreoDe);
        pnlCorreo.Controls.Add(txtTitulo);
        pnlCorreo.Controls.Add(lblTituloCorreo);
        pnlCorreo.Controls.Add(txtNombre);
        pnlCorreo.Controls.Add(lblDeCorreo);
        pnlCorreo.Dock = DockStyle.Fill;
        pnlCorreo.Location = new Point(0, 0);
        pnlCorreo.Name = "pnlCorreo";
        pnlCorreo.Size = new Size(1362, 742);
        pnlCorreo.TabIndex = 0;
        // 
        // cmdGuardaCorreo
        // 
        cmdGuardaCorreo.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cmdGuardaCorreo.BackColor = Color.FromArgb(227, 237, 239);
        cmdGuardaCorreo.FlatAppearance.BorderColor = Color.Gray;
        cmdGuardaCorreo.FlatStyle = FlatStyle.Flat;
        cmdGuardaCorreo.Font = new Font("Tahoma", 8.25F);
        cmdGuardaCorreo.ForeColor = Color.Black;
        cmdGuardaCorreo.Location = new Point(1231, 699);
        cmdGuardaCorreo.Name = "cmdGuardaCorreo";
        cmdGuardaCorreo.Size = new Size(124, 35);
        cmdGuardaCorreo.TabIndex = 28;
        cmdGuardaCorreo.Text = "Guardar";
        cmdGuardaCorreo.UseVisualStyleBackColor = false;
        cmdGuardaCorreo.Click += cmdGuardaCorreo_Click;
        // 
        // cmdProbar
        // 
        cmdProbar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cmdProbar.BackColor = Color.FromArgb(227, 237, 239);
        cmdProbar.FlatAppearance.BorderColor = Color.Gray;
        cmdProbar.FlatStyle = FlatStyle.Flat;
        cmdProbar.Font = new Font("Tahoma", 8.25F);
        cmdProbar.ForeColor = Color.Black;
        cmdProbar.Location = new Point(1100, 699);
        cmdProbar.Name = "cmdProbar";
        cmdProbar.Size = new Size(124, 35);
        cmdProbar.TabIndex = 27;
        cmdProbar.Text = "Probar";
        cmdProbar.UseVisualStyleBackColor = false;
        cmdProbar.Click += cmdProbar_Click;
        // 
        // txtTimeOut
        // 
        txtTimeOut.BorderStyle = BorderStyle.None;
        txtTimeOut.Location = new Point(375, 346);
        txtTimeOut.MaxLength = 200;
        txtTimeOut.Name = "txtTimeOut";
        txtTimeOut.Size = new Size(250, 20);
        txtTimeOut.TabIndex = 25;
        // 
        // lblTimeOut
        // 
        lblTimeOut.AutoSize = true;
        lblTimeOut.Location = new Point(28, 346);
        lblTimeOut.Name = "lblTimeOut";
        lblTimeOut.Size = new Size(85, 21);
        lblTimeOut.TabIndex = 24;
        lblTimeOut.Text = "Time Out:";
        // 
        // txtPassword
        // 
        txtPassword.BorderStyle = BorderStyle.None;
        txtPassword.Location = new Point(375, 320);
        txtPassword.MaxLength = 200;
        txtPassword.Name = "txtPassword";
        txtPassword.Size = new Size(250, 20);
        txtPassword.TabIndex = 23;
        txtPassword.UseSystemPasswordChar = true;
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Location = new Point(28, 320);
        label2.Name = "label2";
        label2.Size = new Size(87, 21);
        label2.TabIndex = 22;
        label2.Text = "Password:";
        // 
        // txtUsuario
        // 
        txtUsuario.BorderStyle = BorderStyle.None;
        txtUsuario.Location = new Point(375, 294);
        txtUsuario.MaxLength = 200;
        txtUsuario.Name = "txtUsuario";
        txtUsuario.Size = new Size(250, 20);
        txtUsuario.TabIndex = 21;
        // 
        // lblUsuario
        // 
        lblUsuario.AutoSize = true;
        lblUsuario.Location = new Point(28, 293);
        lblUsuario.Name = "lblUsuario";
        lblUsuario.Size = new Size(72, 21);
        lblUsuario.TabIndex = 20;
        lblUsuario.Text = "Usuario:";
        // 
        // cboSSL
        // 
        cboSSL.FlatStyle = FlatStyle.Popup;
        cboSSL.FormattingEnabled = true;
        cboSSL.Items.AddRange(new object[] { "True", "False" });
        cboSSL.Location = new Point(375, 259);
        cboSSL.Name = "cboSSL";
        cboSSL.Size = new Size(250, 29);
        cboSSL.TabIndex = 19;
        // 
        // lblSsl
        // 
        lblSsl.AutoSize = true;
        lblSsl.Location = new Point(28, 262);
        lblSsl.Name = "lblSsl";
        lblSsl.Size = new Size(42, 21);
        lblSsl.TabIndex = 18;
        lblSsl.Text = "SSL:";
        // 
        // txtPuerto
        // 
        txtPuerto.BorderStyle = BorderStyle.None;
        txtPuerto.Location = new Point(375, 233);
        txtPuerto.MaxLength = 200;
        txtPuerto.Name = "txtPuerto";
        txtPuerto.Size = new Size(250, 20);
        txtPuerto.TabIndex = 17;
        // 
        // lblPuerto
        // 
        lblPuerto.AutoSize = true;
        lblPuerto.Location = new Point(28, 233);
        lblPuerto.Name = "lblPuerto";
        lblPuerto.Size = new Size(64, 21);
        lblPuerto.TabIndex = 16;
        lblPuerto.Text = "Puerto:";
        // 
        // txtServidorCorreo
        // 
        txtServidorCorreo.BorderStyle = BorderStyle.None;
        txtServidorCorreo.Location = new Point(375, 207);
        txtServidorCorreo.MaxLength = 200;
        txtServidorCorreo.Name = "txtServidorCorreo";
        txtServidorCorreo.Size = new Size(250, 20);
        txtServidorCorreo.TabIndex = 15;
        // 
        // lblServidor
        // 
        lblServidor.AutoSize = true;
        lblServidor.Location = new Point(28, 207);
        lblServidor.Name = "lblServidor";
        lblServidor.Size = new Size(76, 21);
        lblServidor.TabIndex = 14;
        lblServidor.Text = "Servidor:";
        // 
        // cboPrioridad
        // 
        cboPrioridad.FlatStyle = FlatStyle.Popup;
        cboPrioridad.FormattingEnabled = true;
        cboPrioridad.Items.AddRange(new object[] { "0", "1", "2" });
        cboPrioridad.Location = new Point(375, 172);
        cboPrioridad.Name = "cboPrioridad";
        cboPrioridad.Size = new Size(250, 29);
        cboPrioridad.TabIndex = 13;
        // 
        // lblPrioridad
        // 
        lblPrioridad.AutoSize = true;
        lblPrioridad.Location = new Point(28, 175);
        lblPrioridad.Name = "lblPrioridad";
        lblPrioridad.Size = new Size(81, 21);
        lblPrioridad.TabIndex = 12;
        lblPrioridad.Text = "Prioridad:";
        // 
        // cboHtml
        // 
        cboHtml.FlatStyle = FlatStyle.Popup;
        cboHtml.FormattingEnabled = true;
        cboHtml.Items.AddRange(new object[] { "True", "False" });
        cboHtml.Location = new Point(375, 137);
        cboHtml.Name = "cboHtml";
        cboHtml.Size = new Size(250, 29);
        cboHtml.TabIndex = 11;
        // 
        // lblHtml
        // 
        lblHtml.AutoSize = true;
        lblHtml.Location = new Point(28, 140);
        lblHtml.Name = "lblHtml";
        lblHtml.Size = new Size(118, 21);
        lblHtml.TabIndex = 10;
        lblHtml.Text = "Formato Html:";
        // 
        // txtMensaje
        // 
        txtMensaje.BorderStyle = BorderStyle.None;
        txtMensaje.Location = new Point(375, 111);
        txtMensaje.MaxLength = 500;
        txtMensaje.Name = "txtMensaje";
        txtMensaje.Size = new Size(250, 20);
        txtMensaje.TabIndex = 9;
        // 
        // lblMensaje
        // 
        lblMensaje.AutoSize = true;
        lblMensaje.Location = new Point(28, 111);
        lblMensaje.Name = "lblMensaje";
        lblMensaje.Size = new Size(78, 21);
        lblMensaje.TabIndex = 8;
        lblMensaje.Text = "Mensaje:";
        // 
        // txtMail
        // 
        txtMail.BorderStyle = BorderStyle.None;
        txtMail.Location = new Point(375, 59);
        txtMail.MaxLength = 200;
        txtMail.Name = "txtMail";
        txtMail.Size = new Size(250, 20);
        txtMail.TabIndex = 7;
        // 
        // lblCorreoDe
        // 
        lblCorreoDe.AutoSize = true;
        lblCorreoDe.Location = new Point(28, 59);
        lblCorreoDe.Name = "lblCorreoDe";
        lblCorreoDe.Size = new Size(65, 21);
        lblCorreoDe.TabIndex = 6;
        lblCorreoDe.Text = "Correo:";
        // 
        // txtTitulo
        // 
        txtTitulo.BorderStyle = BorderStyle.None;
        txtTitulo.Location = new Point(375, 85);
        txtTitulo.MaxLength = 200;
        txtTitulo.Name = "txtTitulo";
        txtTitulo.Size = new Size(250, 20);
        txtTitulo.TabIndex = 5;
        // 
        // lblTituloCorreo
        // 
        lblTituloCorreo.AutoSize = true;
        lblTituloCorreo.Location = new Point(25, 85);
        lblTituloCorreo.Name = "lblTituloCorreo";
        lblTituloCorreo.Size = new Size(58, 21);
        lblTituloCorreo.TabIndex = 4;
        lblTituloCorreo.Text = "Título:";
        // 
        // txtNombre
        // 
        txtNombre.BorderStyle = BorderStyle.None;
        txtNombre.Location = new Point(375, 33);
        txtNombre.MaxLength = 200;
        txtNombre.Name = "txtNombre";
        txtNombre.Size = new Size(250, 20);
        txtNombre.TabIndex = 3;
        // 
        // lblDeCorreo
        // 
        lblDeCorreo.AutoSize = true;
        lblDeCorreo.Location = new Point(28, 33);
        lblDeCorreo.Name = "lblDeCorreo";
        lblDeCorreo.Size = new Size(74, 21);
        lblDeCorreo.TabIndex = 2;
        lblDeCorreo.Text = "Nombre:";
        // 
        // tabClientes
        // 
        tabClientes.BackColor = Color.FromArgb(227, 237, 239);
        tabClientes.Controls.Add(gridParametrosCliente);
        tabClientes.Controls.Add(pnlBotonesClientes);
        tabClientes.Location = new Point(4, 30);
        tabClientes.Name = "tabClientes";
        tabClientes.Padding = new Padding(3);
        tabClientes.Size = new Size(1362, 742);
        tabClientes.TabIndex = 2;
        tabClientes.Text = "Clientes";
        // 
        // gridParametrosCliente
        // 
        gridParametrosCliente.AllowUserToAddRows = false;
        gridParametrosCliente.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridParametrosCliente.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridParametrosCliente.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridParametrosCliente.Dock = DockStyle.Fill;
        gridParametrosCliente.Location = new Point(3, 3);
        gridParametrosCliente.Name = "gridParametrosCliente";
        gridParametrosCliente.ReadOnly = true;
        gridParametrosCliente.RowHeadersVisible = false;
        gridParametrosCliente.RowHeadersWidth = 51;
        gridParametrosCliente.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridParametrosCliente.Size = new Size(1356, 696);
        gridParametrosCliente.TabIndex = 1;
        gridParametrosCliente.CellDoubleClick += gridParametrosCliente_CellDoubleClick;
        gridParametrosCliente.CellFormatting += gridParametrosCliente_CellFormatting;
        // 
        // pnlBotonesClientes
        // 
        pnlBotonesClientes.Controls.Add(cmdEliminar);
        pnlBotonesClientes.Controls.Add(cmdModificar);
        pnlBotonesClientes.Controls.Add(cmdAgregar);
        pnlBotonesClientes.Dock = DockStyle.Bottom;
        pnlBotonesClientes.Location = new Point(3, 699);
        pnlBotonesClientes.Name = "pnlBotonesClientes";
        pnlBotonesClientes.Size = new Size(1356, 40);
        pnlBotonesClientes.TabIndex = 2;
        // 
        // cmdEliminar
        // 
        cmdEliminar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdEliminar.BackColor = Color.FromArgb(227, 237, 239);
        cmdEliminar.FlatAppearance.BorderColor = Color.Gray;
        cmdEliminar.FlatStyle = FlatStyle.Flat;
        cmdEliminar.Font = new Font("Tahoma", 8.25F);
        cmdEliminar.ForeColor = Color.Black;
        cmdEliminar.Location = new Point(261, 1);
        cmdEliminar.Name = "cmdEliminar";
        cmdEliminar.Size = new Size(124, 35);
        cmdEliminar.TabIndex = 4;
        cmdEliminar.Text = "Eliminar";
        cmdEliminar.UseVisualStyleBackColor = false;
        cmdEliminar.Click += cmdEliminar_Click;
        // 
        // cmdModificar
        // 
        cmdModificar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdModificar.BackColor = Color.FromArgb(227, 237, 239);
        cmdModificar.FlatAppearance.BorderColor = Color.Gray;
        cmdModificar.FlatStyle = FlatStyle.Flat;
        cmdModificar.Font = new Font("Tahoma", 8.25F);
        cmdModificar.ForeColor = Color.Black;
        cmdModificar.Location = new Point(131, 1);
        cmdModificar.Name = "cmdModificar";
        cmdModificar.Size = new Size(124, 35);
        cmdModificar.TabIndex = 3;
        cmdModificar.Text = "Modificar";
        cmdModificar.UseVisualStyleBackColor = false;
        cmdModificar.Click += cmdModificar_Click;
        // 
        // cmdAgregar
        // 
        cmdAgregar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdAgregar.BackColor = Color.FromArgb(227, 237, 239);
        cmdAgregar.DialogResult = DialogResult.Cancel;
        cmdAgregar.FlatAppearance.BorderColor = Color.Gray;
        cmdAgregar.FlatStyle = FlatStyle.Flat;
        cmdAgregar.Font = new Font("Tahoma", 8.25F);
        cmdAgregar.ForeColor = Color.Black;
        cmdAgregar.Location = new Point(1, 1);
        cmdAgregar.Name = "cmdAgregar";
        cmdAgregar.Size = new Size(124, 35);
        cmdAgregar.TabIndex = 2;
        cmdAgregar.Text = "Agregar";
        cmdAgregar.UseVisualStyleBackColor = false;
        cmdAgregar.Click += cmdAgregar_Click;
        // 
        // tabProcedures
        // 
        tabProcedures.BackColor = Color.FromArgb(227, 237, 239);
        tabProcedures.Controls.Add(gridProcedures);
        tabProcedures.Controls.Add(pnlBotonesProcs);
        tabProcedures.Location = new Point(4, 30);
        tabProcedures.Name = "tabProcedures";
        tabProcedures.Padding = new Padding(3);
        tabProcedures.Size = new Size(1362, 742);
        tabProcedures.TabIndex = 3;
        tabProcedures.Text = "Procedimientos";
        // 
        // gridProcedures
        // 
        gridProcedures.AllowUserToAddRows = false;
        gridProcedures.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridProcedures.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridProcedures.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridProcedures.Dock = DockStyle.Fill;
        gridProcedures.Location = new Point(3, 3);
        gridProcedures.Name = "gridProcedures";
        gridProcedures.ReadOnly = true;
        gridProcedures.RowHeadersVisible = false;
        gridProcedures.RowHeadersWidth = 51;
        gridProcedures.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridProcedures.Size = new Size(1356, 696);
        gridProcedures.TabIndex = 3;
        gridProcedures.DoubleClick += gridProcedures_DoubleClick;
        // 
        // pnlBotonesProcs
        // 
        pnlBotonesProcs.Controls.Add(cmdEliminarProc);
        pnlBotonesProcs.Controls.Add(cmdModificarProc);
        pnlBotonesProcs.Controls.Add(cmdAgregarProc);
        pnlBotonesProcs.Dock = DockStyle.Bottom;
        pnlBotonesProcs.Location = new Point(3, 699);
        pnlBotonesProcs.Name = "pnlBotonesProcs";
        pnlBotonesProcs.Size = new Size(1356, 40);
        pnlBotonesProcs.TabIndex = 10;
        // 
        // cmdEliminarProc
        // 
        cmdEliminarProc.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdEliminarProc.BackColor = Color.FromArgb(227, 237, 239);
        cmdEliminarProc.FlatAppearance.BorderColor = Color.Gray;
        cmdEliminarProc.FlatStyle = FlatStyle.Flat;
        cmdEliminarProc.Font = new Font("Tahoma", 8.25F);
        cmdEliminarProc.ForeColor = Color.Black;
        cmdEliminarProc.Location = new Point(261, 1);
        cmdEliminarProc.Name = "cmdEliminarProc";
        cmdEliminarProc.Size = new Size(124, 35);
        cmdEliminarProc.TabIndex = 12;
        cmdEliminarProc.Text = "Eliminar";
        cmdEliminarProc.UseVisualStyleBackColor = false;
        cmdEliminarProc.Click += cmdEliminarProc_Click;
        // 
        // cmdModificarProc
        // 
        cmdModificarProc.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdModificarProc.BackColor = Color.FromArgb(227, 237, 239);
        cmdModificarProc.FlatAppearance.BorderColor = Color.Gray;
        cmdModificarProc.FlatStyle = FlatStyle.Flat;
        cmdModificarProc.Font = new Font("Tahoma", 8.25F);
        cmdModificarProc.ForeColor = Color.Black;
        cmdModificarProc.Location = new Point(131, 1);
        cmdModificarProc.Name = "cmdModificarProc";
        cmdModificarProc.Size = new Size(124, 35);
        cmdModificarProc.TabIndex = 11;
        cmdModificarProc.Text = "Modificar";
        cmdModificarProc.UseVisualStyleBackColor = false;
        cmdModificarProc.Click += cmdModificarProc_Click;
        // 
        // cmdAgregarProc
        // 
        cmdAgregarProc.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdAgregarProc.BackColor = Color.FromArgb(227, 237, 239);
        cmdAgregarProc.FlatAppearance.BorderColor = Color.Gray;
        cmdAgregarProc.FlatStyle = FlatStyle.Flat;
        cmdAgregarProc.Font = new Font("Tahoma", 8.25F);
        cmdAgregarProc.ForeColor = Color.Black;
        cmdAgregarProc.Location = new Point(1, 1);
        cmdAgregarProc.Name = "cmdAgregarProc";
        cmdAgregarProc.Size = new Size(124, 35);
        cmdAgregarProc.TabIndex = 10;
        cmdAgregarProc.Text = "Agregar";
        cmdAgregarProc.UseVisualStyleBackColor = false;
        cmdAgregarProc.Click += cmdAgregarProc_Click;
        // 
        // tabOnDemand
        // 
        tabOnDemand.BackColor = Color.FromArgb(227, 237, 239);
        tabOnDemand.Controls.Add(gridOnDemand);
        tabOnDemand.Controls.Add(Panel1);
        tabOnDemand.Location = new Point(4, 30);
        tabOnDemand.Name = "tabOnDemand";
        tabOnDemand.Padding = new Padding(3);
        tabOnDemand.Size = new Size(1362, 742);
        tabOnDemand.TabIndex = 6;
        tabOnDemand.Text = "Ejecución Inmediata";
        tabOnDemand.UseVisualStyleBackColor = true;
        // 
        // gridOnDemand
        // 
        gridOnDemand.AllowUserToAddRows = false;
        gridOnDemand.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridOnDemand.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridOnDemand.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridOnDemand.Dock = DockStyle.Fill;
        gridOnDemand.Location = new Point(3, 3);
        gridOnDemand.Name = "gridOnDemand";
        gridOnDemand.ReadOnly = true;
        gridOnDemand.RowHeadersVisible = false;
        gridOnDemand.RowHeadersWidth = 51;
        gridOnDemand.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridOnDemand.Size = new Size(1356, 696);
        gridOnDemand.TabIndex = 3;
        gridOnDemand.DoubleClick += gridOnDemand_DoubleClick;
        // 
        // Panel1
        // 
        Panel1.Controls.Add(cmdEliminarOnDemand);
        Panel1.Controls.Add(cmdModificarOnDemand);
        Panel1.Controls.Add(cmdAgregarOnDemand);
        Panel1.Dock = DockStyle.Bottom;
        Panel1.Location = new Point(3, 699);
        Panel1.Name = "Panel1";
        Panel1.Size = new Size(1356, 40);
        Panel1.TabIndex = 12;
        // 
        // cmdEliminarOnDemand
        // 
        cmdEliminarOnDemand.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdEliminarOnDemand.BackColor = Color.FromArgb(227, 237, 239);
        cmdEliminarOnDemand.FlatAppearance.BorderColor = Color.Gray;
        cmdEliminarOnDemand.FlatStyle = FlatStyle.Flat;
        cmdEliminarOnDemand.Font = new Font("Tahoma", 8.25F);
        cmdEliminarOnDemand.ForeColor = Color.Black;
        cmdEliminarOnDemand.Location = new Point(261, 1);
        cmdEliminarOnDemand.Name = "cmdEliminarOnDemand";
        cmdEliminarOnDemand.Size = new Size(124, 35);
        cmdEliminarOnDemand.TabIndex = 12;
        cmdEliminarOnDemand.Text = "Eliminar";
        cmdEliminarOnDemand.UseVisualStyleBackColor = false;
        cmdEliminarOnDemand.Click += cmdEliminarOnDemand_Click;
        // 
        // cmdModificarOnDemand
        // 
        cmdModificarOnDemand.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdModificarOnDemand.BackColor = Color.FromArgb(227, 237, 239);
        cmdModificarOnDemand.FlatAppearance.BorderColor = Color.Gray;
        cmdModificarOnDemand.FlatStyle = FlatStyle.Flat;
        cmdModificarOnDemand.Font = new Font("Tahoma", 8.25F);
        cmdModificarOnDemand.ForeColor = Color.Black;
        cmdModificarOnDemand.Location = new Point(131, 1);
        cmdModificarOnDemand.Name = "cmdModificarOnDemand";
        cmdModificarOnDemand.Size = new Size(124, 35);
        cmdModificarOnDemand.TabIndex = 11;
        cmdModificarOnDemand.Text = "Modificar";
        cmdModificarOnDemand.UseVisualStyleBackColor = false;
        cmdModificarOnDemand.Click += cmdModificarOnDemand_Click;
        // 
        // cmdAgregarOnDemand
        // 
        cmdAgregarOnDemand.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdAgregarOnDemand.BackColor = Color.FromArgb(227, 237, 239);
        cmdAgregarOnDemand.DialogResult = DialogResult.Cancel;
        cmdAgregarOnDemand.FlatAppearance.BorderColor = Color.Gray;
        cmdAgregarOnDemand.FlatStyle = FlatStyle.Flat;
        cmdAgregarOnDemand.Font = new Font("Tahoma", 8.25F);
        cmdAgregarOnDemand.ForeColor = Color.Black;
        cmdAgregarOnDemand.Location = new Point(1, 1);
        cmdAgregarOnDemand.Name = "cmdAgregarOnDemand";
        cmdAgregarOnDemand.Size = new Size(124, 35);
        cmdAgregarOnDemand.TabIndex = 10;
        cmdAgregarOnDemand.Text = "Agregar";
        cmdAgregarOnDemand.UseVisualStyleBackColor = false;
        cmdAgregarOnDemand.Click += cmdAgregarOnDemand_Click;
        // 
        // tabOrderProcess
        // 
        tabOrderProcess.Controls.Add(gridOrderProcess);
        tabOrderProcess.Controls.Add(Panel3);
        tabOrderProcess.Location = new Point(4, 30);
        tabOrderProcess.Name = "tabOrderProcess";
        tabOrderProcess.Padding = new Padding(3);
        tabOrderProcess.Size = new Size(1362, 742);
        tabOrderProcess.TabIndex = 8;
        tabOrderProcess.Text = "Prioridad de Procesamiento";
        tabOrderProcess.UseVisualStyleBackColor = true;
        // 
        // gridOrderProcess
        // 
        gridOrderProcess.AllowUserToAddRows = false;
        gridOrderProcess.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridOrderProcess.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridOrderProcess.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridOrderProcess.Dock = DockStyle.Fill;
        gridOrderProcess.Location = new Point(3, 3);
        gridOrderProcess.Name = "gridOrderProcess";
        gridOrderProcess.ReadOnly = true;
        gridOrderProcess.RowHeadersVisible = false;
        gridOrderProcess.RowHeadersWidth = 51;
        gridOrderProcess.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridOrderProcess.Size = new Size(1356, 696);
        gridOrderProcess.TabIndex = 13;
        // 
        // Panel3
        // 
        Panel3.BackColor = Color.FromArgb(227, 237, 239);
        Panel3.Controls.Add(btnDeleteOrderProcess);
        Panel3.Controls.Add(btnUpdateOrderProcess);
        Panel3.Controls.Add(btnAddOrderProcess);
        Panel3.Dock = DockStyle.Bottom;
        Panel3.Location = new Point(3, 699);
        Panel3.Name = "Panel3";
        Panel3.Size = new Size(1356, 40);
        Panel3.TabIndex = 14;
        // 
        // btnDeleteOrderProcess
        // 
        btnDeleteOrderProcess.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnDeleteOrderProcess.BackColor = Color.FromArgb(227, 237, 239);
        btnDeleteOrderProcess.FlatAppearance.BorderColor = Color.Gray;
        btnDeleteOrderProcess.FlatStyle = FlatStyle.Flat;
        btnDeleteOrderProcess.Font = new Font("Tahoma", 8.25F);
        btnDeleteOrderProcess.ForeColor = Color.Black;
        btnDeleteOrderProcess.Location = new Point(261, 1);
        btnDeleteOrderProcess.Name = "btnDeleteOrderProcess";
        btnDeleteOrderProcess.Size = new Size(124, 35);
        btnDeleteOrderProcess.TabIndex = 12;
        btnDeleteOrderProcess.Text = "Eliminar";
        btnDeleteOrderProcess.UseVisualStyleBackColor = false;
        btnDeleteOrderProcess.Click += btnDeleteOrderProcess_Click;
        // 
        // btnUpdateOrderProcess
        // 
        btnUpdateOrderProcess.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnUpdateOrderProcess.BackColor = Color.FromArgb(227, 237, 239);
        btnUpdateOrderProcess.FlatAppearance.BorderColor = Color.Gray;
        btnUpdateOrderProcess.FlatStyle = FlatStyle.Flat;
        btnUpdateOrderProcess.Font = new Font("Tahoma", 8.25F);
        btnUpdateOrderProcess.ForeColor = Color.Black;
        btnUpdateOrderProcess.Location = new Point(131, 1);
        btnUpdateOrderProcess.Name = "btnUpdateOrderProcess";
        btnUpdateOrderProcess.Size = new Size(124, 35);
        btnUpdateOrderProcess.TabIndex = 11;
        btnUpdateOrderProcess.Text = "Modificar";
        btnUpdateOrderProcess.UseVisualStyleBackColor = false;
        btnUpdateOrderProcess.Click += btnUpdateOrderProcess_Click;
        // 
        // btnAddOrderProcess
        // 
        btnAddOrderProcess.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnAddOrderProcess.BackColor = Color.FromArgb(227, 237, 239);
        btnAddOrderProcess.DialogResult = DialogResult.Cancel;
        btnAddOrderProcess.FlatAppearance.BorderColor = Color.Gray;
        btnAddOrderProcess.FlatStyle = FlatStyle.Flat;
        btnAddOrderProcess.Font = new Font("Tahoma", 8.25F);
        btnAddOrderProcess.ForeColor = Color.Black;
        btnAddOrderProcess.Location = new Point(1, 1);
        btnAddOrderProcess.Name = "btnAddOrderProcess";
        btnAddOrderProcess.Size = new Size(124, 35);
        btnAddOrderProcess.TabIndex = 10;
        btnAddOrderProcess.Text = "Agregar";
        btnAddOrderProcess.UseVisualStyleBackColor = false;
        btnAddOrderProcess.Click += btnAddOrderProcess_Click;
        // 
        // tabTalentDB
        // 
        tabTalentDB.BackColor = Color.FromArgb(227, 237, 239);
        tabTalentDB.Controls.Add(btnSaveTalentDB);
        tabTalentDB.Controls.Add(chkEnableTalentDB);
        tabTalentDB.Controls.Add(grpTalentDBConnection);
        tabTalentDB.Location = new Point(4, 30);
        tabTalentDB.Name = "tabTalentDB";
        tabTalentDB.Padding = new Padding(3);
        tabTalentDB.Size = new Size(1362, 742);
        tabTalentDB.TabIndex = 9;
        tabTalentDB.Text = "Talent DB";
        // 
        // btnSaveTalentDB
        // 
        btnSaveTalentDB.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnSaveTalentDB.BackColor = Color.FromArgb(227, 237, 239);
        btnSaveTalentDB.DialogResult = DialogResult.Cancel;
        btnSaveTalentDB.FlatAppearance.BorderColor = Color.Gray;
        btnSaveTalentDB.FlatStyle = FlatStyle.Flat;
        btnSaveTalentDB.Font = new Font("Tahoma", 8.25F);
        btnSaveTalentDB.ForeColor = Color.Black;
        btnSaveTalentDB.Location = new Point(1230, 703);
        btnSaveTalentDB.Name = "btnSaveTalentDB";
        btnSaveTalentDB.Size = new Size(124, 35);
        btnSaveTalentDB.TabIndex = 46;
        btnSaveTalentDB.Text = "Guardar";
        btnSaveTalentDB.UseVisualStyleBackColor = false;
        btnSaveTalentDB.Visible = false;
        btnSaveTalentDB.Click += btnSaveTalentDB_Click;
        // 
        // chkEnableTalentDB
        // 
        chkEnableTalentDB.AutoSize = true;
        chkEnableTalentDB.FlatStyle = FlatStyle.Popup;
        chkEnableTalentDB.Location = new Point(22, 15);
        chkEnableTalentDB.Name = "chkEnableTalentDB";
        chkEnableTalentDB.Size = new Size(161, 25);
        chkEnableTalentDB.TabIndex = 0;
        chkEnableTalentDB.Text = "Enable Talent DB";
        chkEnableTalentDB.UseVisualStyleBackColor = true;
        chkEnableTalentDB.CheckedChanged += chkEnableTalentDB_CheckedChanged;
        // 
        // grpTalentDBConnection
        // 
        grpTalentDBConnection.Anchor = AnchorStyles.None;
        grpTalentDBConnection.Controls.Add(cboConnectionType);
        grpTalentDBConnection.Controls.Add(Label1);
        grpTalentDBConnection.Controls.Add(txtDatabaseTalent);
        grpTalentDBConnection.Controls.Add(txtServerTalent);
        grpTalentDBConnection.Controls.Add(lblBase);
        grpTalentDBConnection.Controls.Add(Label3);
        grpTalentDBConnection.Controls.Add(btnTestConnection);
        grpTalentDBConnection.Controls.Add(txtPasswordTalent);
        grpTalentDBConnection.Controls.Add(lblPassword);
        grpTalentDBConnection.Controls.Add(txtUserTalent);
        grpTalentDBConnection.Controls.Add(Label4);
        grpTalentDBConnection.Controls.Add(lblConnectionString);
        grpTalentDBConnection.Enabled = false;
        grpTalentDBConnection.Location = new Point(22, 43);
        grpTalentDBConnection.Name = "grpTalentDBConnection";
        grpTalentDBConnection.Size = new Size(631, 249);
        grpTalentDBConnection.TabIndex = 40;
        grpTalentDBConnection.TabStop = false;
        // 
        // cboConnectionType
        // 
        cboConnectionType.FlatStyle = FlatStyle.Popup;
        cboConnectionType.FormattingEnabled = true;
        cboConnectionType.Location = new Point(209, 121);
        cboConnectionType.Name = "cboConnectionType";
        cboConnectionType.Size = new Size(308, 29);
        cboConnectionType.TabIndex = 51;
        // 
        // Label1
        // 
        Label1.AutoSize = true;
        Label1.Location = new Point(14, 113);
        Label1.Name = "Label1";
        Label1.Size = new Size(120, 21);
        Label1.TabIndex = 50;
        Label1.Text = "Tipo Conexión:";
        // 
        // txtDatabaseTalent
        // 
        txtDatabaseTalent.BorderStyle = BorderStyle.None;
        txtDatabaseTalent.Location = new Point(209, 192);
        txtDatabaseTalent.MaxLength = 200;
        txtDatabaseTalent.Name = "txtDatabaseTalent";
        txtDatabaseTalent.Size = new Size(308, 20);
        txtDatabaseTalent.TabIndex = 48;
        // 
        // txtServerTalent
        // 
        txtServerTalent.BorderStyle = BorderStyle.None;
        txtServerTalent.Location = new Point(209, 158);
        txtServerTalent.MaxLength = 200;
        txtServerTalent.Name = "txtServerTalent";
        txtServerTalent.Size = new Size(308, 20);
        txtServerTalent.TabIndex = 46;
        // 
        // lblBase
        // 
        lblBase.AutoSize = true;
        lblBase.Location = new Point(15, 179);
        lblBase.Name = "lblBase";
        lblBase.Size = new Size(124, 21);
        lblBase.TabIndex = 47;
        lblBase.Text = "Base de Datos:";
        // 
        // Label3
        // 
        Label3.AutoSize = true;
        Label3.Location = new Point(14, 149);
        Label3.Name = "Label3";
        Label3.Size = new Size(76, 21);
        Label3.TabIndex = 45;
        Label3.Text = "Servidor:";
        // 
        // btnTestConnection
        // 
        btnTestConnection.Anchor = AnchorStyles.None;
        btnTestConnection.BackColor = Color.FromArgb(227, 237, 239);
        btnTestConnection.DialogResult = DialogResult.Cancel;
        btnTestConnection.FlatAppearance.BorderColor = Color.Gray;
        btnTestConnection.FlatStyle = FlatStyle.Flat;
        btnTestConnection.Font = new Font("Tahoma", 8.25F);
        btnTestConnection.ForeColor = Color.Black;
        btnTestConnection.Location = new Point(523, 158);
        btnTestConnection.Name = "btnTestConnection";
        btnTestConnection.Size = new Size(90, 54);
        btnTestConnection.TabIndex = 49;
        btnTestConnection.Text = "Probar\r\nConexion";
        btnTestConnection.UseVisualStyleBackColor = false;
        btnTestConnection.Click += btnTestConnection_Click;
        // 
        // txtPasswordTalent
        // 
        txtPasswordTalent.BorderStyle = BorderStyle.None;
        txtPasswordTalent.Location = new Point(209, 87);
        txtPasswordTalent.MaxLength = 200;
        txtPasswordTalent.Name = "txtPasswordTalent";
        txtPasswordTalent.Size = new Size(308, 20);
        txtPasswordTalent.TabIndex = 44;
        txtPasswordTalent.UseSystemPasswordChar = true;
        // 
        // lblPassword
        // 
        lblPassword.AutoSize = true;
        lblPassword.Location = new Point(14, 83);
        lblPassword.Name = "lblPassword";
        lblPassword.Size = new Size(87, 21);
        lblPassword.TabIndex = 43;
        lblPassword.Text = "Password:";
        // 
        // txtUserTalent
        // 
        txtUserTalent.BorderStyle = BorderStyle.None;
        txtUserTalent.Location = new Point(209, 53);
        txtUserTalent.MaxLength = 200;
        txtUserTalent.Name = "txtUserTalent";
        txtUserTalent.Size = new Size(308, 20);
        txtUserTalent.TabIndex = 42;
        // 
        // Label4
        // 
        Label4.AutoSize = true;
        Label4.Location = new Point(14, 53);
        Label4.Name = "Label4";
        Label4.Size = new Size(72, 21);
        Label4.TabIndex = 41;
        Label4.Text = "Usuario:";
        // 
        // lblConnectionString
        // 
        lblConnectionString.AutoSize = true;
        lblConnectionString.Font = new Font("Trebuchet MS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblConnectionString.Location = new Point(15, 22);
        lblConnectionString.Name = "lblConnectionString";
        lblConnectionString.Size = new Size(197, 23);
        lblConnectionString.TabIndex = 40;
        lblConnectionString.Text = "Talent DB Connection:";
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.BackColor = Color.FromArgb(227, 237, 239);
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.FlatAppearance.BorderColor = Color.Gray;
        cmdCancelar.FlatStyle = FlatStyle.Flat;
        cmdCancelar.Font = new Font("Tahoma", 8.25F);
        cmdCancelar.ForeColor = Color.Black;
        cmdCancelar.Location = new Point(1235, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cerrar";
        cmdCancelar.UseVisualStyleBackColor = false;
        cmdCancelar.Click += cmdCancelar_Click;
        // 
        // pnlEstado
        // 
        pnlEstado.Dock = DockStyle.Top;
        pnlEstado.Location = new Point(0, 42);
        pnlEstado.Name = "pnlEstado";
        pnlEstado.Size = new Size(1370, 60);
        pnlEstado.TabIndex = 7;
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 878);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(1370, 40);
        pnlBotones.TabIndex = 8;
        // 
        // scMIIA
        // 
        scMIIA.MachineName = ".";
        // 
        // timerEventos
        // 
        timerEventos.Interval = 10000;
        timerEventos.Tick += timerEventos_Tick;
        // 
        // EventLogADAM
        // 
        EventLogADAM.SynchronizingObject = this;
        // 
        // frmConfiguracion
        // 
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        ClientSize = new Size(1370, 918);
        Controls.Add(pnlPrincipal);
        Controls.Add(pnlEstado);
        Controls.Add(pnlSuperior);
        Controls.Add(pnlBotones);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        Icon = (Icon)resources.GetObject("$this.Icon");
        Name = "frmConfiguracion";
        Text = "Configuración MIIA";
        Load += frmConfiguracion_Load;
        Resize += frmConfiguracion_Resize;
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        pnlPrincipal.ResumeLayout(false);
        tabParametros.ResumeLayout(false);
        tabServicio.ResumeLayout(false);
        pnlEventosServicio.ResumeLayout(false);
        Panel2.ResumeLayout(false);
        Panel2.PerformLayout();
        pnlServicio.ResumeLayout(false);
        pnlServicio.PerformLayout();
        tabGeneral.ResumeLayout(false);
        pnlGenerales.ResumeLayout(false);
        pnlGenerales.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)nupdTimeConnectionRetries).EndInit();
        ((System.ComponentModel.ISupportInitialize)nupdConnectionRetries).EndInit();
        tabCorreo.ResumeLayout(false);
        pnlCorreo.ResumeLayout(false);
        pnlCorreo.PerformLayout();
        tabClientes.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridParametrosCliente).EndInit();
        pnlBotonesClientes.ResumeLayout(false);
        tabProcedures.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridProcedures).EndInit();
        pnlBotonesProcs.ResumeLayout(false);
        tabOnDemand.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridOnDemand).EndInit();
        Panel1.ResumeLayout(false);
        tabOrderProcess.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridOrderProcess).EndInit();
        Panel3.ResumeLayout(false);
        tabTalentDB.ResumeLayout(false);
        tabTalentDB.PerformLayout();
        grpTalentDBConnection.ResumeLayout(false);
        grpTalentDBConnection.PerformLayout();
        pnlBotones.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)EventLogADAM).EndInit();
        ResumeLayout(false);
    }

    #endregion

    private System.Windows.Forms.Button cmdProbar;
    private System.Windows.Forms.Button cmdGuardaCorreo;
    private System.Windows.Forms.TextBox txtTimeOut;
    private System.Windows.Forms.Panel pnlSuperior;
    private System.Windows.Forms.Label lblTitulo;
    private System.Windows.Forms.Label lblTimeOut;
    private System.Windows.Forms.TextBox txtPassword;
    private System.Windows.Forms.Panel pnlCorreo;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtUsuario;
    private System.Windows.Forms.Label lblUsuario;
    private System.Windows.Forms.ComboBox cboSSL;
    private System.Windows.Forms.Label lblSsl;
    private System.Windows.Forms.TextBox txtPuerto;
    private System.Windows.Forms.Label lblPuerto;
    private System.Windows.Forms.TextBox txtServidorCorreo;
    private System.Windows.Forms.Label lblServidor;
    private System.Windows.Forms.ComboBox cboPrioridad;
    private System.Windows.Forms.Label lblPrioridad;
    private System.Windows.Forms.ComboBox cboHtml;
    private System.Windows.Forms.Label lblHtml;
    private System.Windows.Forms.TextBox txtMensaje;
    private System.Windows.Forms.Label lblMensaje;
    private System.Windows.Forms.TextBox txtMail;
    private System.Windows.Forms.Label lblCorreoDe;
    private System.Windows.Forms.TextBox txtTitulo;
    private System.Windows.Forms.Label lblTituloCorreo;
    private System.Windows.Forms.TextBox txtNombre;
    private System.Windows.Forms.Label lblDeCorreo;
    private System.Windows.Forms.TabPage tabGeneral;
    private System.Windows.Forms.Panel pnlGenerales;
    private System.Windows.Forms.TextBox txtCarpetas;
    private System.Windows.Forms.Label lblCarpetas;
    private System.Windows.Forms.Label lblUsarControl;
    private System.Windows.Forms.Label lblVecesEjecutar;
    private System.Windows.Forms.Button cmdRutaOrigen;
    private System.Windows.Forms.Button cmdAceptar;
    private System.Windows.Forms.TextBox txtNombresArchivosCtrl;
    private System.Windows.Forms.TextBox txtRutaDestino;
    private System.Windows.Forms.TextBox txtRutaOrigen;
    private System.Windows.Forms.Label lblNombresArchivosCtrl;
    private System.Windows.Forms.Label lblRutaDestino;
    private System.Windows.Forms.Label lblRutaOrigen;
    private System.Windows.Forms.TabPage tabCorreo;
    private System.Windows.Forms.Panel pnlPrincipal;
    private System.Windows.Forms.TabControl tabParametros;
    private System.Windows.Forms.Button cmdCancelar;
    private System.Windows.Forms.Panel pnlEstado;
    private System.Windows.Forms.Button cmdDetener;
    private System.Windows.Forms.Label lblEstadoServicio;
    private System.Windows.Forms.Button cmdReinicia;
    private System.Windows.Forms.Panel pnlBotones;
    private System.Windows.Forms.FolderBrowserDialog fbdRuta;
    private System.Windows.Forms.Button cmdRutaDestino;
    private System.Windows.Forms.ComboBox cboArchivoControl;
    private System.Windows.Forms.ComboBox cboVeces;
    private System.Windows.Forms.ComboBox cboEjecucionInmediata;
    private System.Windows.Forms.Label lblEjecucionInmediata;
    private System.Windows.Forms.TextBox txtPatron;
    private System.Windows.Forms.Label lblPatron;
    internal System.Windows.Forms.TabPage tabClientes;
    private System.Windows.Forms.DataGridView gridParametrosCliente;
    internal System.Windows.Forms.TabPage tabProcedures;
    private System.Windows.Forms.DataGridView gridProcedures;
    internal System.Windows.Forms.TabPage tabOnDemand;
    private System.Windows.Forms.DataGridView gridOnDemand;
    internal System.Windows.Forms.Panel pnlBotonesClientes;
    private System.Windows.Forms.Button cmdEliminar;
    private System.Windows.Forms.Button cmdModificar;
    private System.Windows.Forms.Button cmdAgregar;
    internal System.Windows.Forms.Panel pnlBotonesProcs;
    private System.Windows.Forms.Button cmdEliminarProc;
    private System.Windows.Forms.Button cmdModificarProc;
    private System.Windows.Forms.Button cmdAgregarProc;
    internal System.Windows.Forms.Panel Panel1;
    private System.Windows.Forms.Button cmdEliminarOnDemand;
    private System.Windows.Forms.Button cmdModificarOnDemand;
    private System.Windows.Forms.Button cmdAgregarOnDemand;
    internal System.ServiceProcess.ServiceController scMIIA;
    private System.Windows.Forms.Label lblNombresArchivosInmediata;
    private System.Windows.Forms.TextBox txtNombresArchivosInmediata;
    internal System.Windows.Forms.TabPage tabServicio;
    internal System.Windows.Forms.Panel pnlEventosServicio;
    internal System.Windows.Forms.Panel pnlServicio;
    internal System.Windows.Forms.Timer timerEventos;
    internal System.Diagnostics.EventLog EventLogADAM;
    internal System.Windows.Forms.ListView lvEventos;
    internal System.Windows.Forms.ImageList ilIconos;
    private System.Windows.Forms.Label lblEventos;
    internal System.Windows.Forms.ColumnHeader ColumnHeader1;
    internal System.Windows.Forms.CheckBox chkActualiza;
    private System.Windows.Forms.Button cmdActualizar;
    private System.Windows.Forms.TextBox txtPasswordGPG;
    private System.Windows.Forms.Label lblContrasenia;
    private System.Windows.Forms.ComboBox cboArchivosEncriptados;
    private System.Windows.Forms.Label lblEncriptados;
    private System.Windows.Forms.ComboBox cboUsarJobsSQL;
    private System.Windows.Forms.Label lblUsarJobsSQL;
    internal System.Windows.Forms.Panel Panel2;
    private System.Windows.Forms.Label lblNotaEventos;
    private System.Windows.Forms.Button cmdEventViewer;
    internal System.Windows.Forms.TabPage tabOrderProcess;
    private System.Windows.Forms.DataGridView gridOrderProcess;
    internal System.Windows.Forms.Panel Panel3;
    private System.Windows.Forms.Button btnDeleteOrderProcess;
    private System.Windows.Forms.Button btnUpdateOrderProcess;
    private System.Windows.Forms.Button btnAddOrderProcess;
    internal System.Windows.Forms.TabPage tabTalentDB;
    internal System.Windows.Forms.CheckBox chkEnableTalentDB;
    internal System.Windows.Forms.GroupBox grpTalentDBConnection;
    internal System.Windows.Forms.ComboBox cboConnectionType;
    private System.Windows.Forms.Label Label1;
    private System.Windows.Forms.TextBox txtDatabaseTalent;
    private System.Windows.Forms.TextBox txtServerTalent;
    private System.Windows.Forms.Label lblBase;
    private System.Windows.Forms.Label Label3;
    private System.Windows.Forms.Button btnTestConnection;
    private System.Windows.Forms.TextBox txtPasswordTalent;
    private System.Windows.Forms.Label lblPassword;
    private System.Windows.Forms.TextBox txtUserTalent;
    private System.Windows.Forms.Label Label4;
    internal System.Windows.Forms.Label lblConnectionString;
    private System.Windows.Forms.Button btnSaveTalentDB;
    private System.Windows.Forms.TextBox txtRutaResumenEnExcel;
    private System.Windows.Forms.Label Label5;
    private System.Windows.Forms.Button cmdRutaResumenEnExcel;
    private System.Windows.Forms.Label Label6;
    internal System.Windows.Forms.NumericUpDown nupdTimeConnectionRetries;
    private System.Windows.Forms.Label lblTimeConnectionRetries;
    internal System.Windows.Forms.NumericUpDown nupdConnectionRetries;
    private System.Windows.Forms.Label lblConnectionRetries;
    private Label lblEstadoServicio2;
}

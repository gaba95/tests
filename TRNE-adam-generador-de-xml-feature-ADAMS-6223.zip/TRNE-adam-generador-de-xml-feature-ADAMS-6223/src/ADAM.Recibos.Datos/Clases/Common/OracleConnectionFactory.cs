﻿using System.Data;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos.Clases.Common
{
    public class OracleConnectionFactory : IDbConnectionFactory
    {
        #region Members 

        protected ApplicationSettingsBase _appSettings;
        protected string _applicationUser;

        #endregion

        #region Properties 

        public string ApplicationUser
        {
            get
            {
                return _applicationUser.Replace("-", "_");
            }
        }

        #endregion

        #region Methods

        public OracleConnectionFactory(ApplicationSettingsBase appSettings)
        {
            this._appSettings = appSettings;
        }

        private string BuildConnectionString()
        {
            this._applicationUser = _appSettings[ConfigParameters.applicationUser.ToString()].ToString();

            return new OracleConnectionStringBuilder
                       {
                            { "user id", _appSettings[ConfigParameters.user.ToString()] },
                            { "password", _appSettings[ConfigParameters.password.ToString()] },
                            { "data source", $@"(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)
                                    (HOST={_appSettings[ConfigParameters.server.ToString()]})
                                    (PORT={_appSettings[ConfigParameters.puertoOracle.ToString()]}))
                                    (CONNECT_DATA=({_appSettings[ConfigParameters.tipoOracle.ToString()]}={_appSettings[ConfigParameters.database.ToString()]})"
                            },
                            { "Enlist", "false" },
                            { "Pooling", "true" },
                            { "Statement Cache Size", "100" }
                        }.ConnectionString;
        }

        public IDbConnection CreateConnection()
        {
            try
            {
                return new OracleConnection(BuildConnectionString());
            }
            catch (OracleException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public bool CheckConnection()
        {
            using (OracleConnection oracleConnection = (OracleConnection)CreateConnection())
            {
                try
                {
                    oracleConnection.Open();
                    return true;
                }
                catch
                {
                    return false;
                }
            }

        }
        
        #endregion 
    }
}

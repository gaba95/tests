﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("licencias", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Licenses
    {
        public int tipoLicencia { get; set; }

        [JsonProperty("pago")]
        public decimal Pago { get; set; }

        [JsonProperty("numeroDias")]
        public int PagoCantidad { get; set; }

        [JsonProperty("fechaInicio")]
        public string FechaInicio { get; set; }

        [JsonProperty("fechaFin")]
        public string FechaFin { get; set; }
    }
}

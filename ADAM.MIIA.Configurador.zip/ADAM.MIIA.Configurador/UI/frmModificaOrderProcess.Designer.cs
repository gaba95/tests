#nullable enable
namespace ADAM.MIIA.Configurador.UI;

partial class frmModificaOrderProcess
{
    private System.ComponentModel.IContainer? components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        cmdAceptar = new Button();
        cmdCancelar = new Button();
        pnlBotones = new Panel();
        txtRegEx = new TextBox();
        pnlSuperior = new Panel();
        lblTitulo = new Label();
        lblRegExpr = new Label();
        lblOrder = new Label();
        nudOrder = new NumericUpDown();
        pnlBotones.SuspendLayout();
        pnlSuperior.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)nudOrder).BeginInit();
        SuspendLayout();
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdAceptar.DialogResult = DialogResult.Cancel;
        cmdAceptar.Location = new Point(230, 2);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 0;
        cmdAceptar.Text = "Guardar";
        cmdAceptar.UseVisualStyleBackColor = true;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.Location = new Point(360, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cerrar";
        cmdCancelar.UseVisualStyleBackColor = true;
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Controls.Add(cmdAceptar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 228);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(494, 40);
        pnlBotones.TabIndex = 17;
        // 
        // txtRegEx
        // 
        txtRegEx.Location = new Point(150, 80);
        txtRegEx.MaxLength = 100;
        txtRegEx.Name = "txtRegEx";
        txtRegEx.Size = new Size(250, 28);
        txtRegEx.TabIndex = 14;
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(92, 145, 163);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(494, 30);
        pnlSuperior.TabIndex = 10;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 10.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(10, 5);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(392, 27);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Configuración Orden de Procesamiento";
        // 
        // lblRegExpr
        // 
        lblRegExpr.AutoSize = true;
        lblRegExpr.Location = new Point(10, 80);
        lblRegExpr.Name = "lblRegExpr";
        lblRegExpr.Size = new Size(69, 23);
        lblRegExpr.TabIndex = 13;
        lblRegExpr.Text = "Patrón:";
        // 
        // lblOrder
        // 
        lblOrder.AutoSize = true;
        lblOrder.Location = new Point(10, 50);
        lblOrder.Name = "lblOrder";
        lblOrder.Size = new Size(66, 23);
        lblOrder.TabIndex = 11;
        lblOrder.Text = "Orden:";
        // 
        // nudOrder
        // 
        nudOrder.Location = new Point(150, 48);
        nudOrder.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
        nudOrder.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
        nudOrder.Name = "nudOrder";
        nudOrder.Size = new Size(55, 28);
        nudOrder.TabIndex = 18;
        nudOrder.TextAlign = HorizontalAlignment.Right;
        nudOrder.Value = new decimal(new int[] { 1, 0, 0, 0 });
        // 
        // frmModificaOrderProcess
        // 
        AcceptButton = cmdAceptar;
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        CancelButton = cmdCancelar;
        ClientSize = new Size(494, 268);
        Controls.Add(nudOrder);
        Controls.Add(pnlBotones);
        Controls.Add(txtRegEx);
        Controls.Add(pnlSuperior);
        Controls.Add(lblRegExpr);
        Controls.Add(lblOrder);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "frmModificaOrderProcess";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Modifica Orden de Procesamiento";
        Load += frmModificaOrderProcess_Load;
        pnlBotones.ResumeLayout(false);
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)nudOrder).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private Button cmdAceptar;
    private Button cmdCancelar;
    private Panel pnlBotones;
    private TextBox txtRegEx;
    private Panel pnlSuperior;
    private Label lblTitulo;
    private Label lblRegExpr;
    private Label lblOrder;
    internal NumericUpDown nudOrder;
}

﻿using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Utilerias.Tests.Clases
{
    [TestClass]
    public class SafeProceduresTests
    {
        [TestMethod]
        public void WhiteList_ShouldNotBeNull()
        {
            Assert.IsNotNull(SafeProcedures.WhiteList);
        }

        [TestMethod]
        public void WhiteList_ShouldContainsElements()
        {
            Assert.IsTrue(SafeProcedures.WhiteList.Count > 0);
        }

        [TestMethod]
        public void WhiteList_ShouldContain_sp_acumulados_recibo_Key()
        {
            Assert.IsTrue(SafeProcedures.WhiteList.ContainsKey("sp_acumulados_recibo"));
        }

        [TestMethod]
        public void WhiteList_Key_sp_acumulados_recibo_ShouldMatchValue()
        {
            var value = SafeProcedures.WhiteList["sp_acumulados_recibo"];

            Assert.AreEqual("sp_acumulados_recibo", value);
        }

        [TestMethod]
        public void WhiteList_ShouldNotContain_InvalidKey()
        {
            Assert.IsFalse(SafeProcedures.WhiteList.ContainsKey("sp_inexistente"));
        }
    }
}

using System.Data;
using Microsoft.Data.SqlClient;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos.Clases.CatalogoSAT
{
    public class CatalogoSatSql : ICatalogoSat
    {
        private const string ParamCompania = "@compania";
        private const string ParamTipo = "@tipo";

        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoSatSql(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public DataSet dsListaCatalogosSAT()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT item AS clave, descripcion 
                                        FROM criterios_valores 
                                       WHERE campo = @value";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Parameters.Add("@value", SqlDbType.Char, 20).Value = "tipo_catalogo_sat";
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetCatalogosSAT(string tipo)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tipo, clave_sat, descripcion_sat 
                                        FROM catalogos_valores_sat_adam 
                                       WHERE tipo = @tipo";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Parameters.Add(ParamTipo, SqlDbType.Int).Value = tipo;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenCatalogoADAM(string tipo, string compania)
        {
            using var dbConnection = this._connectionFactory.CreateConnection();

            if (dbConnection.State == ConnectionState.Closed)
                dbConnection.Open();

            var ds = new DataSet();
            ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_consulta_catalogos_adam", "Table", cmd =>
            {
                SqlHelpers.AddCharParam(cmd, ParamTipo, 4, tipo);
                SqlHelpers.AddCharParam(cmd, ParamCompania, 10, compania);
            }));

            return ds;
        }

        public DataSet obtenDatasetRelacionCatalogosSATADAM(string tipo, string claveSAT, string compania)
        {
            using var dbConnection = this._connectionFactory.CreateConnection();

            if (dbConnection.State == ConnectionState.Closed)
                dbConnection.Open();

            var ds = new DataSet();
            ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_consulta_rel_datos_sat_adam", "Table", cmd =>
            {
                SqlHelpers.AddCharParam(cmd, ParamTipo, 4, tipo);
                SqlHelpers.AddCharParam(cmd, "@clave_sat", 10, claveSAT);
                SqlHelpers.AddCharParam(cmd, ParamCompania, 10, compania);
            }));

            return ds;
        }

        public bool AltaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_alta_dato_catalogos_sat_adam";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.CommandType = CommandType.StoredProcedure;
            sqlStmt.Parameters.Add(ParamTipo, SqlDbType.Int).Value = tipo;
            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.VarChar).Value = compania;
            sqlStmt.Parameters.Add("@clave_sat", SqlDbType.VarChar).Value = claveSAT;
            sqlStmt.Parameters.Add("@clave_adam", SqlDbType.VarChar).Value = claveADAM;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public bool BajaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_baja_dato_catalogos_sat_adam";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.CommandType = CommandType.StoredProcedure;
            sqlStmt.Parameters.Add(ParamTipo, SqlDbType.Int).Value = tipo;
            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.VarChar).Value = compania;
            sqlStmt.Parameters.Add("@clave_sat", SqlDbType.VarChar).Value = claveSAT;
            sqlStmt.Parameters.Add("@clave_adam", SqlDbType.VarChar).Value = claveADAM;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public DataSet obtenDatasetCatalogos(string tabla)
        {
            if (SafeTables.WhiteList.TryGetValue(tabla, out string safeTable))
            {
                using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                if (sqlConnection.State == ConnectionState.Closed)
                    sqlConnection.Open();

                var sqlQuery = $"SELECT * FROM {safeTable}";
                var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
                sqlStmt.Prepare();

                return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            }
            else
            {
                return null;
            }
        }
    }
}

using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmAgregarConcepto : Form
    {
        #region Properties

        private string _claveTipo = "";
        private string _DescripcionTipo = "";

        private ICatalogoAdicional _catalogoAdicional;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int tipoConcepto { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string claveTipo
        {
            get
            {
                return _claveTipo;
            }
            set
            {
                _claveTipo = value;
                lblClaveTipo.Text = "Tipo " + _claveTipo;
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DescripcionTipo
        {
            get
            {
                return _DescripcionTipo;
            }
            set
            {
                _DescripcionTipo = value;
                lblDescripcionTipo.Text = _DescripcionTipo;
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FrmTiposPercepcionDeduccionSAT FrmPadre { get; set; }

        #endregion

        #region Events

        private void FrmAgregarConcepto_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }

        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            if (GuardaCambios())
            {
                FrmPadre.llenaGridConceptos();
                LlenaComboConceptos();
            }

        }

        #endregion

        #region Methods

        public FrmAgregarConcepto()
        {
            InitializeComponent();
        }

        private void InicializaClase()
        {
            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            LlenaComboConceptos();
        }

        private void LlenaComboConceptos()
        {
            try
            {
                cboConceptos.ValueMember = "concepto";
                cboConceptos.DisplayMember = "descripcion";
                cboConceptos.DataSource = _catalogoAdicional.obtenDatasetConceptosRelacionar(tipoConcepto, _claveTipo).Tables[0];
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }

        }

        private bool GuardaCambios()
        {
            try
            {
                if (cboConceptos.SelectedValue == null)
                    return false;

                return _catalogoAdicional.AltaRelacionConcepto(tipoConcepto, _claveTipo, int.Parse(cboConceptos.SelectedValue.ToString()));

            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
                return false;
            }

        }

        #endregion
    }
}

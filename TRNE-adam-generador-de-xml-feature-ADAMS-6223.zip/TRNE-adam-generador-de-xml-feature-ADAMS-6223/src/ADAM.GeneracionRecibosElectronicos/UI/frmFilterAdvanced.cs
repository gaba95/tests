using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics.CodeAnalysis;
using ADAM.GeneracionRecibosElectronicos.Helpers;
using ADAM.GeneracionRecibosElectronicos.Clases.Filter;

namespace ADAM.GeneracionRecibosElectronicos.UI
{
    [ExcludeFromCodeCoverage]
    public partial class FrmFilterAdvanced : Form
    {
        #region Properties

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DgQuery Query { get; set; }

        #endregion

        #region Variables
        
        private DgFilter filter { get; set; }
        private DataGridViewColumn column { get; set; }

        private Type colValueType { get; set; }

        #endregion

        #region Constructors
        /// <summary>
        /// Class Constructor
        /// </summary>
        /// <param name="pQuery">Query Object</param>
        /// <param name="pColumn">Column to work</param>
        /// <param name="pColValueType">Value Type for values of the Column on the grid</param>
        public FrmFilterAdvanced(DgQuery pQuery, DataGridViewColumn pColumn, Type pColValueType)
        {
            InitializeComponent();

            if (pQuery is null)
            {
                Query = new DgQuery();
            }
            else
            {
                Query = pQuery;
            }

            column = pColumn;
            colValueType = pColValueType;

            // Get the filter applied to the column if exist
            filter = Query.FilterEnumerable.FirstOrDefault(t => t.ColumnIndex == pColumn.Index);
        }

        #endregion

        #region Methods

        #region RemoveFilter
        /// <summary>
        /// Delete the filter applied to the column in Query.filterEnumerable List
        /// </summary>
        private void RemoveFilter()
        {
            var actualfilter = Query.FilterEnumerable.FirstOrDefault(t => t.ColumnIndex == column.Index);
            if (actualfilter != null)
            {
                Query.FilterEnumerable.Remove(actualfilter);
            }
        }
        #endregion 

        #endregion

        #region Events

        #region cmdOk_Click
        /// <summary>
        /// Triggered when the button Aceptar is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdOk_Click(object sender, EventArgs e)
        {
            if (cmbConditions1.SelectedIndex > 0 && txtValue1.Text != String.Empty)
            {
                // If a new condition values on the form are valid remove the actual filter,  create a new one to be added to the list of the Query Object
                RemoveFilter();
                filter = new DgFilter(column.Index, column.Name, Enums.ColumnValueType.Num);
                filter.Comparation = (Enums.ComparationOperator)((KeyValuePair<int, string>)cmbConditions1.SelectedItem).Key;
                filter.Condition = Enums.ConditionalOperator.And;

                short coltype = (short)Enums.ColumnValueType.Num;

                // Populate the value with raw if number
                string value = txtValue1.Text;

                // If the value is not a number populate with a '' characters added to the original values 
                if (colValueType == typeof(string))
                {
                    coltype = (short)Enums.ColumnValueType.String;

                    // Switch filter to IN (' ', ' ') if the user enters a comma delimited set of values
                    if (value.Split(',').Length > 1)
                    {
                        filter.Comparation = Enums.ComparationOperator.In;
                        value = string.Join(",", 
                                            value.Split(',').Select(x => string.Format("'{0}','{0}'", 
                                                                         x.FixedLength(10, Enums.PadType.Left),
                                                                         x.FixedLength(10, Enums.PadType.Right)
                                                                    )
                                           ).ToList());
                    }
                    else
                    {
                        value = $"'{txtValue1.Text}'";
                    }
                }

                if (colValueType == typeof(DateTime))
                {
                    coltype = (short)Enums.ColumnValueType.Date;
                    value = $"'{txtValue1.Text}'";
                }

                filter.ColValueType = (Enums.ColumnValueType)coltype;
                filter.Value = value;

                Query.FilterEnumerable.Add(filter);
            }

            Close();
        }
        #endregion 

        #region FrmFilterAdvanced_Load
        /// <summary>
        /// Triggered when form loads
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmFilterAdvanced_Load(object sender, EventArgs e)
        {
            // Create a default list of values for the comparation combobox to be applied if type of value is a number type or a date
            // the contained values of the list need to be equal on Keys to the values on ComparationOperator Enum
            List<KeyValuePair<int, string>>  opciones = new List<KeyValuePair<int, string>>();
            opciones.Add(new KeyValuePair<int, string>(1, "Igual"));
            opciones.Add(new KeyValuePair<int, string>(2, "Diferente"));
            opciones.Add(new KeyValuePair<int, string>(5, "Mayor A"));
            opciones.Add(new KeyValuePair<int, string>(6, "Mayor o Igual A"));
            opciones.Add(new KeyValuePair<int, string>(7, "Menor A"));
            opciones.Add(new KeyValuePair<int, string>(8, "Menor o Igual A"));

            if (colValueType == typeof(string))
            {
                // If type of value is a string change the default list
                opciones = new List<KeyValuePair<int, string>>();
                opciones.Add(new KeyValuePair<int, string>(1,"Igual"));
                opciones.Add(new KeyValuePair<int, string>(2,"Diferente"));
                opciones.Add(new KeyValuePair<int, string>(3,"Contiene"));
                opciones.Add(new KeyValuePair<int, string>(4,"No Contiene"));
            }

            // Set datasource for comparation combobox
            cmbConditions1.DataSource = opciones;
            cmbConditions1.DisplayMember = "Value";
            cmbConditions1.ValueMember = "Key";

            lblColumnName.Text = column.HeaderText;

            // This form can't apply a filter of types in or not in, loads any other type of filter values on the controls
            if (filter != null && filter.Comparation != Enums.ComparationOperator.In && filter.Comparation != Enums.ComparationOperator.NotIn)
            {
                txtValue1.Text = filter.Value;
                int comparation = (int)filter.Comparation;
                cmbConditions1.SelectedItem = opciones.FirstOrDefault(t=>t.Key == comparation);
            }
        }
        #endregion

        #region cmdCancel_Click
        /// <summary>
        /// Triggered when the button cancelar is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
        #endregion 

        #endregion
    }
}

﻿using System.Data;
using System.Data.Odbc;
using System.Configuration;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos.Clases.Common
{
    public class OdbcConnectionFactory : IDbConnectionFactory
    {
        #region Members 

        protected ApplicationSettingsBase _appSettings;
        protected string _applicationUser;

        #endregion

        #region Properties 

        public string ApplicationUser
        {
            get
            {
                return _applicationUser.Replace("-", "_");
            }
        }

        #endregion

        #region Methods

        public OdbcConnectionFactory(ApplicationSettingsBase appSettings)
        {
            this._appSettings = appSettings;
        }

        private string BuildConnectionString()
        {
            this._applicationUser = _appSettings[ConfigParameters.applicationUser.ToString()].ToString();

            return new OdbcConnectionStringBuilder
                    {
                        { "DSN", _appSettings[ConfigParameters.dsn.ToString()] },
                        { "Uid", _appSettings[ConfigParameters.user.ToString()] },
                        { "Pwd", _appSettings[ConfigParameters.password.ToString()] }
                    }.ConnectionString;
        }

        public IDbConnection CreateConnection()
        {
            try
            {
                return new OdbcConnection(BuildConnectionString());
            }
            catch (OdbcException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public bool CheckConnection()
        {
            using (OdbcConnection odbcConnection = (OdbcConnection)CreateConnection())
            {
                try
                {
                    odbcConnection.Open();
                    return true;
                }
                catch
                {
                    return false;
                }
            }

        }

        #endregion
    }
}

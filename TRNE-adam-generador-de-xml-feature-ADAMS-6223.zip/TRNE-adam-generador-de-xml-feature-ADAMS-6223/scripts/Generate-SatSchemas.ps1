<#
.SYNOPSIS
    Generates XSD/XSLT files from templates by replacing namespace placeholders
    with actual SAT/W3C namespace URIs.

.DESCRIPTION
    This script reads .template files and replaces {{PLACEHOLDER}} tokens with
    the actual namespace values from sat-namespaces.json.
    
    Run this script:
    - Locally after cloning the repository
    - In the CI/CD pipeline before building the solution

.EXAMPLE
    .\scripts\Generate-SatSchemas.ps1
#>

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$xmlDir = Join-Path $scriptDir "..\src\ADAM.GeneracionRecibosElectronicos\xml"
$namespacesFile = Join-Path $xmlDir "sat-namespaces.json"

if (-not (Test-Path $namespacesFile)) {
    Write-Error "Namespaces file not found: $namespacesFile"
    exit 1
}

$namespaces = Get-Content $namespacesFile -Raw | ConvertFrom-Json

$templates = Get-ChildItem -Path $xmlDir -Filter "*.template" -Recurse

if ($templates.Count -eq 0) {
    Write-Warning "No .template files found in $xmlDir"
    exit 0
}

foreach ($template in $templates) {
    $content = Get-Content $template.FullName -Raw -Encoding UTF8
    
    foreach ($prop in $namespaces.PSObject.Properties) {
        $placeholder = "{{$($prop.Name)}}"
        $content = $content.Replace($placeholder, $prop.Value)
    }
    
    $outputPath = $template.FullName -replace '\.template$', ''
    Set-Content -Path $outputPath -Value $content -NoNewline -Encoding UTF8
    Write-Host "Generated: $($template.Name -replace '\.template$', '')"
}

Write-Host "`nAll SAT schema files generated successfully."

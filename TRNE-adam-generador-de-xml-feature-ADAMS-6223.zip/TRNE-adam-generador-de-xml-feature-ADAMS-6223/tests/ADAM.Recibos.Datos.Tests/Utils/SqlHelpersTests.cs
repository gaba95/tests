using ADAM.Recibos.Datos.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Data;

namespace ADAM.Recibos.Datos.Tests.Utils
{
    [TestClass]
    public class SqlHelpersTests
    {
        #region AddCharParam

        [TestMethod]
        public void AddCharParam_AddsParameterWithCorrectProperties()
        {
            var mockCmd = new Mock<IDbCommand>();
            var mockParam = new Mock<IDbDataParameter>();
            var mockParams = new Mock<IDataParameterCollection>();

            mockCmd.Setup(c => c.CreateParameter()).Returns(mockParam.Object);
            mockCmd.Setup(c => c.Parameters).Returns(mockParams.Object);

            SqlHelpers.AddCharParam(mockCmd.Object, "@name", 10, "value");

            mockParam.VerifySet(p => p.ParameterName = "@name");
            mockParam.VerifySet(p => p.DbType = DbType.AnsiStringFixedLength);
            mockParam.VerifySet(p => p.Size = 10);
            mockParam.VerifySet(p => p.Value = "value");
            mockParams.Verify(p => p.Add(mockParam.Object), Times.Once);
        }

        #endregion

        #region AddIntParam

        [TestMethod]
        public void AddIntParam_AddsParameterWithCorrectProperties()
        {
            var mockCmd = new Mock<IDbCommand>();
            var mockParam = new Mock<IDbDataParameter>();
            var mockParams = new Mock<IDataParameterCollection>();

            mockCmd.Setup(c => c.CreateParameter()).Returns(mockParam.Object);
            mockCmd.Setup(c => c.Parameters).Returns(mockParams.Object);

            SqlHelpers.AddIntParam(mockCmd.Object, "@id", 42);

            mockParam.VerifySet(p => p.ParameterName = "@id");
            mockParam.VerifySet(p => p.DbType = DbType.Int32);
            mockParam.VerifySet(p => p.Value = 42);
            mockParams.Verify(p => p.Add(mockParam.Object), Times.Once);
        }

        #endregion

        #region AddVarCharParam

        [TestMethod]
        public void AddVarCharParam_AddsParameterWithCorrectProperties()
        {
            var mockCmd = new Mock<IDbCommand>();
            var mockParam = new Mock<IDbDataParameter>();
            var mockParams = new Mock<IDataParameterCollection>();

            mockCmd.Setup(c => c.CreateParameter()).Returns(mockParam.Object);
            mockCmd.Setup(c => c.Parameters).Returns(mockParams.Object);

            SqlHelpers.AddVarCharParam(mockCmd.Object, "@desc", "some text");

            mockParam.VerifySet(p => p.ParameterName = "@desc");
            mockParam.VerifySet(p => p.DbType = DbType.AnsiString);
            mockParam.VerifySet(p => p.Value = "some text");
            mockParams.Verify(p => p.Add(mockParam.Object), Times.Once);
        }

        #endregion

        #region ExecuteSpToDataTable

        [TestMethod]
        public void ExecuteSpToDataTable_SetsCommandProperties()
        {
            var mockConnection = new Mock<IDbConnection>();
            var mockCmd = new Mock<IDbCommand>();
            var mockReader = new Mock<IDataReader>();

            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCmd.Object);
            mockCmd.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            // Setup reader to return no rows (empty result set)
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.FieldCount).Returns(0);

            var result = SqlHelpers.ExecuteSpToDataTable(
                mockConnection.Object,
                "sp_test",
                "TestTable",
                cmd => { });

            mockCmd.VerifySet(c => c.CommandText = "sp_test");
            mockCmd.VerifySet(c => c.CommandType = CommandType.StoredProcedure);
            mockCmd.VerifySet(c => c.CommandTimeout = 600);
            Assert.AreEqual("TestTable", result.TableName);
        }

        #endregion
    }
}

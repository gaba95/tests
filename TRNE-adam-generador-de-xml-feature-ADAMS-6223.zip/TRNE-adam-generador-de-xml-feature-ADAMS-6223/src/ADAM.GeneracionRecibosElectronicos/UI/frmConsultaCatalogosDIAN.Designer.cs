namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmConsultaCatalogosDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmConsultaCatalogosDIAN));
            this.lblRegimen = new System.Windows.Forms.Label();
            this.gridDatosDIAN = new System.Windows.Forms.DataGridView();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.lblCatalogos = new System.Windows.Forms.Label();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            this.pnlArbol = new System.Windows.Forms.Panel();
            this.arbolCatalogos = new System.Windows.Forms.TreeView();
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.pnlBotones = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosDIAN)).BeginInit();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            this.pnlHerramientas.SuspendLayout();
            this.pnlArbol.SuspendLayout();
            this.pnlTitulo.SuspendLayout();
            this.pnlBotones.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRegimen
            // 
            this.lblRegimen.AutoSize = true;
            this.lblRegimen.Location = new System.Drawing.Point(0, -40);
            this.lblRegimen.Name = "lblRegimen";
            this.lblRegimen.Size = new System.Drawing.Size(143, 18);
            this.lblRegimen.TabIndex = 0;
            this.lblRegimen.Text = "Regimen de Contatación";
            // 
            // gridDatosDIAN
            // 
            this.gridDatosDIAN.AllowUserToAddRows = false;
            this.gridDatosDIAN.AllowUserToDeleteRows = false;
            this.gridDatosDIAN.AllowUserToResizeRows = false;
            this.gridDatosDIAN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosDIAN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosDIAN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDatosDIAN.Location = new System.Drawing.Point(10, 30);
            this.gridDatosDIAN.Name = "gridDatosDIAN";
            this.gridDatosDIAN.RowHeadersVisible = false;
            this.gridDatosDIAN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosDIAN.Size = new System.Drawing.Size(692, 481);
            this.gridDatosDIAN.TabIndex = 3;
            this.gridDatosDIAN.SelectionChanged += new System.EventHandler(this.gridDatosDIAN_SelectionChanged);
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(1055, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(391, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Consulta de Catálogos ADAM - DIAN";
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.gridDatosDIAN);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(223, 50);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(10, 30, 10, 10);
            this.pnlPrincipal.Size = new System.Drawing.Size(712, 521);
            this.pnlPrincipal.TabIndex = 16;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cmdCerrar.Location = new System.Drawing.Point(0, 461);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 12;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // lblCatalogos
            // 
            this.lblCatalogos.AutoSize = true;
            this.lblCatalogos.Location = new System.Drawing.Point(3, 8);
            this.lblCatalogos.Name = "lblCatalogos";
            this.lblCatalogos.Size = new System.Drawing.Size(60, 18);
            this.lblCatalogos.TabIndex = 9;
            this.lblCatalogos.Text = "Catálogos";
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.pnlArbol);
            this.pnlHerramientas.Controls.Add(this.pnlTitulo);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlHerramientas.Location = new System.Drawing.Point(0, 50);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Size = new System.Drawing.Size(223, 521);
            this.pnlHerramientas.TabIndex = 17;
            // 
            // pnlArbol
            //
            this.pnlArbol.Controls.Add(this.arbolCatalogos);
            this.pnlArbol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlArbol.Location = new System.Drawing.Point(0, 29);
            this.pnlArbol.Name = "pnlArbol";
            this.pnlArbol.Padding = new System.Windows.Forms.Padding(5, 0, 0, 10);
            this.pnlArbol.Size = new System.Drawing.Size(223, 492);
            this.pnlArbol.TabIndex = 10;
            // 
            // arbolCatalogos
            // 
            this.arbolCatalogos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arbolCatalogos.Location = new System.Drawing.Point(5, 0);
            this.arbolCatalogos.Name = "arbolCatalogos";
            this.arbolCatalogos.Size = new System.Drawing.Size(218, 482);
            this.arbolCatalogos.TabIndex = 9;
            this.arbolCatalogos.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.arbolCatalogos_AfterSelect);
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.Controls.Add(this.lblCatalogos);
            this.pnlTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitulo.Location = new System.Drawing.Point(0, 0);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(223, 29);
            this.pnlTitulo.TabIndex = 9;
            // 
            // pnlBotones
            // 
            this.pnlBotones.Controls.Add(this.cmdCerrar);
            this.pnlBotones.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlBotones.Location = new System.Drawing.Point(935, 50);
            this.pnlBotones.Name = "pnlBotones";
            this.pnlBotones.Padding = new System.Windows.Forms.Padding(0, 0, 10, 10);
            this.pnlBotones.Size = new System.Drawing.Size(120, 521);
            this.pnlBotones.TabIndex = 17;
            // 
            // FrmConsultaCatalogosDIAN
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1055, 571);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.pnlBotones);
            this.Controls.Add(this.lblRegimen);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FrmConsultaCatalogosDIAN";
            this.ShowInTaskbar = false;
            this.Text = "Consulta de Catálogos ADAM - DIAN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmConsultaCatalogosDIAN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosDIAN)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlHerramientas.ResumeLayout(false);
            this.pnlArbol.ResumeLayout(false);
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlBotones.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblRegimen;
        private System.Windows.Forms.DataGridView gridDatosDIAN;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.Panel pnlBotones;
        private System.Windows.Forms.Label lblCatalogos;
        private System.Windows.Forms.Panel pnlArbol;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.TreeView arbolCatalogos;
        private System.Windows.Forms.Panel pnlTitulo;
    }
}
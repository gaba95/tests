﻿using Newtonsoft.Json;

namespace ADAM.Recibos.Hangfire.Models
{
    public class EmployeeRequest
    {
        [JsonProperty("Culture")]
        public string Culture { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("processId")]
        public string ProcessId { get; set; }

        [JsonProperty("totalEmployees")]
        public string TotalEmployees { get; set; }

        [JsonProperty("Employees")]
        public List<EmployeeInfo> Employees { get; set; }
    }
}

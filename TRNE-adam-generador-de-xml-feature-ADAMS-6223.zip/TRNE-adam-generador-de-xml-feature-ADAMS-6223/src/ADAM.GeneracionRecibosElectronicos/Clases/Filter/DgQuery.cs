﻿using ADAM.GeneracionRecibosElectronicos.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Filter
{
    /// <summary>
    /// This class was created to save a List of the filter for different columns of a datagridview and generate a strign with a valid query to be applied 
    /// to datagridview datasource by DefaultView.RowFilter function
    /// </summary>
    public class DgQuery
    {
        #region Variables

        // Filter Enum
        public List<DgFilter> FilterEnumerable { get; set; }

        #endregion 

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public DgQuery()
        {
            FilterEnumerable = new List<DgFilter>();
        }
        #endregion 

        #region GetQuery
        /// <summary>
        /// Generate a valid string query based on each filter saved on the list FilterEnumerable
        /// </summary>
        /// <returns></returns>
        public string GetQuery() {

            short counter = 1;
            string query = "";

            // Set Filters
            foreach (DgFilter f in FilterEnumerable) {

                string condition = "";

                switch (f.Condition) {
                    case ConditionalOperator.And: 
                        condition = " And ";
                        break;
                    case ConditionalOperator.Or:
                        condition = " Or ";
                        break;
                }

                // Local Values
                string comparation = "";
                string postcomparation = f.Value;

                // Check Condition
                switch (f.Comparation) {
                    case ComparationOperator.Equal:
                        comparation = " = ";
                        switch (f.ColValueType)
                        {
                            // If a string or date value add '' characters
                            case ColumnValueType.String:
                                postcomparation = "'" + f.Value + "'";
                                break;
                            case ColumnValueType.Date:
                                postcomparation = "'" + f.Value + "'";
                                break;
                        }
                        break;
                    case ComparationOperator.NotEqual:
                        comparation = " <> ";
                        switch (f.ColValueType) {
                            //if a string or date value add '' characters
                            case ColumnValueType.String:
                                postcomparation = "'" + f.Value + "'";
                                break;
                            case ColumnValueType.Date:
                                postcomparation = "'" + f.Value + "'";
                                break;
                        }
                        break;
                    case ComparationOperator.Contain:
                        comparation = " LIKE '%" ;
                        postcomparation =  f.Value.Substring(1,f.Value.Length -2)  + "%' ";
                        break;
                    case ComparationOperator.NoContain:
                        comparation = " NOT LIKE '%";
                        postcomparation = f.Value.Substring(1, f.Value.Length - 2) + "%' ";
                        break;
                    case ComparationOperator.Greater:
                        comparation = " > ";
                        break;
                    case ComparationOperator.GreaterOrEqual:
                        comparation = " >= ";
                        break;
                    case ComparationOperator.Less:
                        comparation = " < ";
                        break; 
                    case ComparationOperator.LessOrEqual:
                        comparation = " <= ";
                        break;
                    // Values for IN and NOT IN filters needed to be already populate with '' characters,
                    // this methods does not add the characters in order to not validate the type of the value and repeat a procedure
                    // intented to be already do
                    case ComparationOperator.In:
                        comparation = " IN (";
                        postcomparation = f.Value + ")";
                        break;
                    case ComparationOperator.NotIn:
                        comparation = " NOT IN (";
                        postcomparation = f.Value + ")";
                        break;
                }

                if (counter == 1)
                {
                    query += " " + f.FieldName + comparation + postcomparation;
                }
                else {
                    query += condition + f.FieldName + comparation + postcomparation;
                }

                counter++;
            }

            // Default
            return query;
        }
        #endregion 
    }
}

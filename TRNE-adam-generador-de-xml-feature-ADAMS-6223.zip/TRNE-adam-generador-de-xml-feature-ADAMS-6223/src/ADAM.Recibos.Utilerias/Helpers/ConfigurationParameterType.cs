﻿namespace ADAM.Recibos.Utilerias.Helpers
{
    public enum ConfigurationTypes
    {
        temp_path,
        api_url,
        ws_user,
        ws_password,
        stamping_site,
        xslt_file,
        xsd_file,
        generation_type,
        additional_generation,
        additional_proc,
        default_country,
        timeout
    }
}

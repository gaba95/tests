using System;
using System.Data;
using System.Data.Odbc;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos
{
    public class BRReciboElectronicoOdbc : IBRReciboElectronico
    {
        private const string ParamAnio = "@@anio";
        private const string ParamPeriodo = "@@periodo";
        private const string ParamNumEmpleado = "@@numEmpleado";

        private readonly IDbConnectionFactory _connectionFactory;

        public string ApplicationUser
        {
            get
            {
                return _connectionFactory.ApplicationUser;
            }
        }

        public BRReciboElectronicoOdbc(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public bool CheckDbConnection()
        {
            return _connectionFactory.CheckConnection();
        }

        public DataSet ObtenDatasetReciboFull(string compania, string trabajador, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina, int numeroLiquidacion, string conceptoFactura, string formaPagoDefault)
        {
            Nomina nomina = new(compania, trabajador, tipoNomina, claseNomina, anio, periodo, manejoNomina, numeroLiquidacion, conceptoFactura, formaPagoDefault);
            return ObtenDatasetRecibo(nomina);
        }

        public DataSet ObtenDatasetRecibo(Nomina nomina)
        {
            DataSet ds = new();

            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            string consulta = Odbc.Properties.AppSettings.Default.Nomina;

            using (OdbcCommand comando = BuildParameterizedCommand(
                odbcConnection,
                consulta,
                (ParamAnio, OdbcType.Int, nomina.Anio),
                (ParamPeriodo, OdbcType.Int, nomina.Periodo),
                (ParamNumEmpleado, OdbcType.VarChar, nomina.Trabajador)))
            {
                OdbcDataAdapter adapter = new(comando);
                adapter.Fill(ds);
            }

            // Cuando se obtuvo el Dataset principal se obtienen los restantes
            ds.Tables[0].TableName = "TablePrincipal";

            // Agregar horas extra
            DataSet dsHorasExtra = ObtenDatasetAdicional(nomina, Odbc.Properties.AppSettings.Default.HorasExtra);
            dsHorasExtra.Tables[0].TableName = "TableHorasExtra";
            ds.Tables.Add(dsHorasExtra.Tables["TableHorasExtra"].Copy());

            // Incapacidades
            DataSet dsIncapacidades = ObtenDatasetAdicional(nomina, Odbc.Properties.AppSettings.Default.Incapacidades);
            dsIncapacidades.Tables[0].TableName = "TableIncapacidades";
            ds.Tables.Add(dsIncapacidades.Tables["TableIncapacidades"].Copy());

            // Otros Pagos
            DataSet dsOtrosPagos = ObtenDatasetAdicional(nomina, Odbc.Properties.AppSettings.Default.OtrosPagos);
            dsOtrosPagos.Tables[0].TableName = "TableOtrosPagos";
            ds.Tables.Add(dsOtrosPagos.Tables["TableOtrosPagos"].Copy());

            // Acciones Titulos
            DataSet dsAccionesTitulos = ObtenDatasetAdicional(nomina, Odbc.Properties.AppSettings.Default.AccionesTitulos);
            dsAccionesTitulos.Tables[0].TableName = "TableAccionesTitulos";
            ds.Tables.Add(dsAccionesTitulos.Tables["TableAccionesTitulos"].Copy());

            // Jubilacion Pension Retiro
            DataSet dsJubilacionPensionRetiro = ObtenDatasetAdicional(nomina, Odbc.Properties.AppSettings.Default.JubilacionPensionRetiro);
            dsJubilacionPensionRetiro.Tables[0].TableName = "TableJubilacionPensionRetiro";
            ds.Tables.Add(dsJubilacionPensionRetiro.Tables["TableJubilacionPensionRetiro"].Copy());

            //Separacion Indemnizacion
            DataSet dsSeparacionIndemnizacion = ObtenDatasetAdicional(nomina, Odbc.Properties.AppSettings.Default.SeparacionIndemnizacion);
            dsSeparacionIndemnizacion.Tables[0].TableName = "TableSeparacionIndemnizacion";
            ds.Tables.Add(dsSeparacionIndemnizacion.Tables["TableSeparacionIndemnizacion"].Copy());

            return ds;
        }

        public DataSet ObtenDatasetAdicionales(Nomina nomina, string procedimiento)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            var odbcStmt = Odbc.Properties.AppSettings.Default.HorasExtra;

            OdbcCommand comando = new(odbcStmt, odbcConnection);
            DataSet ds = new();

            OdbcDataAdapter adapter = new(comando.CommandText, odbcConnection);

            adapter.Fill(ds);

            return ds;
        }

        private DataSet ObtenDatasetAdicional(Nomina nomina, string consulta)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            DataSet ds = new();

            using (OdbcCommand comando = BuildParameterizedCommand(
                odbcConnection,
                consulta,
                ("@@compania", OdbcType.VarChar, nomina.Compania),
                (ParamNumEmpleado, OdbcType.VarChar, nomina.Trabajador),
                ("@@tipoNomina", OdbcType.VarChar, nomina.TipoNomina),
                ("@@claseNomina", OdbcType.VarChar, nomina.ClaseNomina),
                (ParamAnio, OdbcType.Int, nomina.Anio),
                (ParamPeriodo, OdbcType.Int, nomina.Periodo),
                ("@@manejoNomina", OdbcType.VarChar, nomina.ManejoNomina.ToString()),
                ("@@numeroLiquidacion", OdbcType.Int, nomina.NumeroLiquidacion)))
            {
                OdbcDataAdapter adapter = new(comando);
                adapter.Fill(ds);
            }

            return ds;
        }

        private static OdbcCommand BuildParameterizedCommand(
            OdbcConnection connection,
            string queryTemplate,
            params (string Token, OdbcType Type, object Value)[] replacements)
        {
            var commandText = queryTemplate;
            var command = new OdbcCommand
            {
                Connection = connection,
                CommandType = CommandType.Text
            };

            foreach (var replacement in replacements)
            {
                ReplaceTokenAndAddParameters(command, ref commandText, replacement.Token, replacement.Type, replacement.Value);
            }

            command.CommandText = commandText;
            return command;
        }

        private static void ReplaceTokenAndAddParameters(OdbcCommand command, ref string commandText, string token, OdbcType type, object value)
        {
            var quotedToken = $"'{token}'";
            int quotedMatches = CountOccurrences(commandText, quotedToken);

            if (quotedMatches > 0)
            {
                commandText = commandText.Replace(quotedToken, "?", StringComparison.Ordinal);
                for (int i = 0; i < quotedMatches; i++)
                {
                    command.Parameters.Add(token, type).Value = value ?? DBNull.Value;
                }
            }

            int plainMatches = CountOccurrences(commandText, token);
            if (plainMatches > 0)
            {
                commandText = commandText.Replace(token, "?", StringComparison.Ordinal);
                for (int i = 0; i < plainMatches; i++)
                {
                    command.Parameters.Add(token, type).Value = value ?? DBNull.Value;
                }
            }
        }

        private static int CountOccurrences(string source, string token)
        {
            int count = 0;
            int index = 0;

            while (true)
            {
                index = source.IndexOf(token, index, StringComparison.Ordinal);
                if (index < 0)
                {
                    break;
                }

                count++;
                index += token.Length;
            }

            return count;
        }

    }
}

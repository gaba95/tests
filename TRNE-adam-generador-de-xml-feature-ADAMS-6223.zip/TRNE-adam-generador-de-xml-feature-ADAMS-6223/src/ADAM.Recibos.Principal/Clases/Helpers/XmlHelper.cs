using System.Data;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Collections.Specialized;
using ADAM.Recibos.Controls;
using ADAM.Recibos.Principal.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.Recibos.Principal.Clases
{
    public static class XmlHelper
    {
        private const string NominaNamespaceUri = "http://www.sat.gob.mx/nomina";

        public static string ConvierteDatasetXml(DataSet ds)
        {
            try
            {
                if (ds.Tables.Count == 1)
                {
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();

                    // Xml with UTF8
                    StringWriterUtf8 sw = new StringWriterUtf8(sb);

                    XmlWriter writer = XmlWriter.Create(sw);

                    ds.Tables[0].WriteXml(writer, XmlWriteMode.IgnoreSchema, true);
                    writer.Flush();
                    writer.Close();

                    // Regresa la cadena con el XML completo
                    return sw.ToString();
                }
                else
                {
                    MemoryStream stream = new MemoryStream();
                    ds.WriteXml(stream);

                    stream.Position = 0;
                    StreamReader reader = new StreamReader(stream);
                    return reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                CustomMessageBox.Show("Error al generar el XML, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxIcon.Error);
                return string.Empty;
            }
        }

        public static string TransformaXml(string appPath, string xmlOriginal, string xslTemplate, bool debug, XmlWriterSettings settings, bool extValidations)
        {
            // Check if the template for Extended validations template exists
            if (extValidations)
            {
                var extXsltTemplate = xslTemplate.Replace(".xslt", "_ext.xsd");

                if (File.Exists(appPath + extXsltTemplate))
                {
                    xslTemplate = extXsltTemplate;
                }
                else
                {
                    return string.Empty;
                }
            }

            try
            {
                if (XslTemplates.xslWhiteList.TryGetValue(Path.GetFileName(xslTemplate), out string xslSafeTemplate))
                {
                    var xsltPath = Path.Combine(appPath, "xml", xslSafeTemplate);

                    XmlDocument xmlDocOriginal = new XmlDocument() { XmlResolver = null };
                    xmlDocOriginal.LoadXml(xmlOriginal);

                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    StringWriterUtf8 sw = new StringWriterUtf8(sb);
                    XmlWriter writer = XmlWriter.Create(sw, settings);

                    XslCompiledTransform xslTransform = new XslCompiledTransform(debug);

                    if (File.Exists(xsltPath))
                    {
                        var xslReaderSettings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
                        using var xslReader = XmlReader.Create(xsltPath, xslReaderSettings);
                        XPathDocument document = new XPathDocument(xslReader);

                        xslTransform.Load(document, new XsltSettings { EnableScript = false }, null);

                        xslTransform.Transform(xmlDocOriginal, null, writer);
                    }

                    writer.Flush();
                    writer.Close();

                    return sw.ToString();
                }
                else
                {
                    CustomMessageBox.Show($"Error al intentar transformar el Archivo Xml" + Environment.NewLine + $"La plantilla {xslTemplate} no es segura", "ADAM", MessageBoxIcon.Error);
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                CustomMessageBox.Show("Error al intentar transformar el Archivo Xml " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxIcon.Error);
                return string.Empty;
            }
        }

        public static string DepuraNodosNomina(string xmlOriginal)
        {
            try
            {
                // Obtiene el XML de la cadena
                XmlDocument docRecibo = new XmlDocument();
                docRecibo.LoadXml(xmlOriginal);

                // Establece el elemento a modificar
                XmlElement elemento = (XmlElement)docRecibo.GetElementsByTagName("Nomina", NominaNamespaceUri)[0];

                if (elemento != null)
                {
                    foreach (XmlNode nodoHijo in elemento.ChildNodes)
                    {
                        if (!nodoHijo.HasChildNodes)
                        {
                            elemento.RemoveChild(nodoHijo);
                        }
                    }
                }
                return docRecibo.OuterXml;
            }
            catch
            {
                return xmlOriginal;
            }
        }

        public static XmlSchemaSet LoadAllSchemas(string rootXsdPath)
        {
            FileInfo xsdInfo = new(rootXsdPath);
            var targetNamespace = xsdInfo.Name.Contains("12") ? "http://www.sat.gob.mx/nomina12" : "http://www.sat.gob.mx/nomina";

            var xmlSet = new XmlSchemaSet
            {
                XmlResolver = new XmlUrlResolver() // enables resolving imports/includes
            }; 
            
            using var reader = XmlReader.Create(rootXsdPath);
            xmlSet.Add(targetNamespace, reader);   // This step is essential — it resolves <xs:include> and <xs:import>
            xmlSet.Compile(); 

            return xmlSet; 
        }

        public static bool ValidaXmlvsXsd(string appPath, string xmlFile, string xsdTemplate, string trabajador, CallBackThread objetoCallBack)
        {
            try
            {
                if (XsdTemplates.xsdWhiteList.TryGetValue(xsdTemplate, out string xsdSafeTemplate))
                {
                    var xsdPath = Path.Combine(appPath, "xml", xsdSafeTemplate);

                    var schemas = LoadAllSchemas(xsdPath);

                    var settings = new XmlReaderSettings { 
                        ValidationType = ValidationType.Schema, 
                        Schemas = schemas, 
                        ValidationFlags = XmlSchemaValidationFlags.ProcessSchemaLocation | 
                                          XmlSchemaValidationFlags.ReportValidationWarnings 
                    };

                    StringCollection cadenasValidaciones = [];

                    settings.ValidationEventHandler += (sender, e) =>
                    {
                        if (e.Severity == XmlSeverityType.Error)
                        {
                            cadenasValidaciones.Add($"{e.Severity}: {e.Message}");
                        }
                    };

                    using var reader = XmlReader.Create(new StringReader(xmlFile), settings);
                    
                    cadenasValidaciones.Clear();

                    // Hace la lectura para que se ejecuten las validaciones
                    while (reader.Read()) { /* Side-effect driven: Read() triggers XSD validation callbacks */ }

                    // Si se generaron errores notificarlos
                    if (cadenasValidaciones.Count > 0)
                    {
                        foreach (string validacion in cadenasValidaciones.Cast<string>().ToList())
                        {
                            objetoCallBack.UpdateUI($"Trabajador: {trabajador}\t validacion xsd: {validacion}");
                        }
                        return false;
                    }

                    return true;
                }
                else
                {
                    CustomMessageBox.Show($"Error al validar el Archivo Xml" + Environment.NewLine + $"La plantilla {xsdTemplate} no es segura", "ADAM", MessageBoxIcon.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                CustomMessageBox.Show($"Error al validar el Archivo Xml, Plantilla XSD ({xsdTemplate}), error: {ex.Message}{Environment.NewLine}{ex.StackTrace}", "ADAM", MessageBoxIcon.Error);
                return false;
            }
        }

    }
}

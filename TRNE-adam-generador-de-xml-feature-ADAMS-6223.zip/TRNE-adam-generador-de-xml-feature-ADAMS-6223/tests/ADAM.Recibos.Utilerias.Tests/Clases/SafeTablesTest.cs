﻿using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Utilerias.Tests.Clases
{
    [TestClass]
    public class SafeTablesTest
    {
        private Dictionary<string, string>? _snapshot;

        [TestInitialize]
        public void Init()
        {
            _snapshot = Clone(SafeTables.WhiteList);
        }

        [TestCleanup]
        public void Cleanup()
        {
            if (_snapshot is null) return;
            SafeTables.WhiteList.Clear();
            foreach (var kvp in _snapshot)
            {
                SafeTables.WhiteList[kvp.Key] = kvp.Value;
            }
        }

        private static Dictionary<string, string> Clone(Dictionary<string, string> source)
            => source.ToDictionary(k => k.Key, v => v.Value, StringComparer.Ordinal);

        private static readonly string[] ExpectedKeys =
        {
            "tb_catalogos_dian",
            "tb_catalogo_paises_dian",
            "tb_catalogo_departamentos_dian",
            "tb_catalogo_municipios_dian",
            "tb_catalogo_periodo_nomina_dian",
            "tb_catalogo_monedas_dian",
            "tb_catalogo_tipo_trabajador_dian",
            "tb_catalogo_tipo_doc_identidad_dian",
            "tb_catalogo_tipo_contrato_dian",
            "tb_catalogo_medios_pago_dian",
            "tb_catalogo_tipos_hora_dian",
            "tb_catalogo_tipos_incapacidad_dian"
        };

        [TestMethod]
        public void WhiteList_Should_NotBeNull()
        {
            Assert.IsNotNull(SafeTables.WhiteList, "WhiteList should not be null.");
        }

        [TestMethod]
        public void WhiteList_Should_HaveExpectedCount()
        {
            const int expectedCount = 12;
            Assert.AreEqual(expectedCount, SafeTables.WhiteList.Count, $"WhiteList should contain {expectedCount} entries.");
        }

        [TestMethod]
        public void WhiteList_Should_Contain_AllAndOnly_ExpectedKeys()
        {
            var actualKeys = SafeTables.WhiteList.Keys.OrderBy(k => k).ToArray();
            var expectedKeys = ExpectedKeys.OrderBy(k => k).ToArray();

            CollectionAssert.AreEqual(expectedKeys, actualKeys, "WhiteList keys should match the expected set exactly.");
        }

        [TestMethod]
        public void WhiteList_Values_Should_Match_Keys_IdentityMapping()
        {
            foreach (var kvp in SafeTables.WhiteList)
            {
                Assert.AreEqual(kvp.Key, kvp.Value, $"For key '{kvp.Key}', the value should match the key (identity mapping).");
            }
        }

        [TestMethod]
        public void WhiteList_Should_NotContain_UnexpectedKey()
        {
            const string unexpectedKey = "tb_no_permitida";
            Assert.IsFalse(SafeTables.WhiteList.ContainsKey(unexpectedKey), $"WhiteList should not contain unexpected key '{unexpectedKey}'.");
        }

        [TestMethod]
        public void WhiteList_Modifications_Should_Affect_StaticInstance()
        {
            const string newKey = "tb_catalogo_demo";
            const string newVal = "tb_catalogo_demo";

            Assert.IsFalse(SafeTables.WhiteList.ContainsKey(newKey), "Precondition failed: test key should not exist before adding.");
            SafeTables.WhiteList[newKey] = newVal;

            Assert.IsTrue(SafeTables.WhiteList.ContainsKey(newKey), "After modification, WhiteList should contain the new key.");
            Assert.AreEqual(newVal, SafeTables.WhiteList[newKey], "Newly added key should map to the expected value.");
        }

        [TestMethod]
        public void WhiteList_Should_Be_CaseSensitive_With_OrdinalComparer()
        {
            const string existingKey = "tb_catalogos_dian";
            const string upperKey = "TB_CATALOGOS_DIAN";

            Assert.IsTrue(SafeTables.WhiteList.ContainsKey(existingKey), "Baseline key should be exist.");
            Assert.IsFalse(SafeTables.WhiteList.ContainsKey(upperKey), "Uppercase variant should not exist if dictionary is case-sensitive");
        }
    }
}

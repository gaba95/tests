namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmFiltroAvanzado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFiltroAvanzado));
            this.gridDisponibles = new System.Windows.Forms.DataGridView();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.lblFiltro = new System.Windows.Forms.Label();
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.cmdAceptar = new System.Windows.Forms.Button();
            this.lblDisponible = new System.Windows.Forms.Label();
            this.gridSeleccionados = new System.Windows.Forms.DataGridView();
            this.pnlIntermedio = new System.Windows.Forms.Panel();
            this.cmdQuitar = new System.Windows.Forms.Button();
            this.cmdAgregar = new System.Windows.Forms.Button();
            this.lblSeleccionados = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridDisponibles)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSeleccionados)).BeginInit();
            this.pnlIntermedio.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridDisponibles
            // 
            this.gridDisponibles.AllowUserToAddRows = false;
            this.gridDisponibles.AllowUserToDeleteRows = false;
            this.gridDisponibles.AllowUserToResizeRows = false;
            this.gridDisponibles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDisponibles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDisponibles.Dock = System.Windows.Forms.DockStyle.Top;
            this.gridDisponibles.Location = new System.Drawing.Point(0, 50);
            this.gridDisponibles.Name = "gridDisponibles";
            this.gridDisponibles.ReadOnly = true;
            this.gridDisponibles.RowHeadersVisible = false;
            this.gridDisponibles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDisponibles.Size = new System.Drawing.Size(884, 200);
            this.gridDisponibles.TabIndex = 3;
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.txtFiltro);
            this.pnlPrincipal.Controls.Add(this.lblFiltro);
            this.pnlPrincipal.Controls.Add(this.cmdCancelar);
            this.pnlPrincipal.Controls.Add(this.cmdAceptar);
            this.pnlPrincipal.Controls.Add(this.lblDisponible);
            this.pnlPrincipal.Controls.Add(this.gridSeleccionados);
            this.pnlPrincipal.Controls.Add(this.pnlIntermedio);
            this.pnlPrincipal.Controls.Add(this.gridDisponibles);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 0);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(0, 50, 0, 40);
            this.pnlPrincipal.Size = new System.Drawing.Size(884, 662);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(150, 28);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(100, 21);
            this.txtFiltro.TabIndex = 2;
            this.txtFiltro.TextChanged += new System.EventHandler(this.txtFiltro_TextChanged);
            // 
            // lblFiltro
            // 
            this.lblFiltro.AutoSize = true;
            this.lblFiltro.Location = new System.Drawing.Point(3, 28);
            this.lblFiltro.Name = "lblFiltro";
            this.lblFiltro.Size = new System.Drawing.Size(121, 18);
            this.lblFiltro.TabIndex = 1;
            this.lblFiltro.Text = "Filtrar por empleado";
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancelar.Location = new System.Drawing.Point(797, 627);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(75, 23);
            this.cmdCancelar.TabIndex = 7;
            this.cmdCancelar.Text = "Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            this.cmdCancelar.Click += new System.EventHandler(this.cmdCancelar_Click);
            // 
            // cmdAceptar
            // 
            this.cmdAceptar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAceptar.Location = new System.Drawing.Point(704, 628);
            this.cmdAceptar.Name = "cmdAceptar";
            this.cmdAceptar.Size = new System.Drawing.Size(75, 23);
            this.cmdAceptar.TabIndex = 6;
            this.cmdAceptar.Text = "Aceptar";
            this.cmdAceptar.UseVisualStyleBackColor = true;
            this.cmdAceptar.Click += new System.EventHandler(this.cmdAceptar_Click);
            // 
            // lblDisponible
            // 
            this.lblDisponible.AutoSize = true;
            this.lblDisponible.Location = new System.Drawing.Point(0, 10);
            this.lblDisponible.Name = "lblDisponible";
            this.lblDisponible.Size = new System.Drawing.Size(69, 18);
            this.lblDisponible.TabIndex = 0;
            this.lblDisponible.Text = "Disponibles";
            // 
            // gridSeleccionados
            // 
            this.gridSeleccionados.AllowUserToAddRows = false;
            this.gridSeleccionados.AllowUserToDeleteRows = false;
            this.gridSeleccionados.AllowUserToResizeRows = false;
            this.gridSeleccionados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridSeleccionados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridSeleccionados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridSeleccionados.Location = new System.Drawing.Point(0, 310);
            this.gridSeleccionados.Name = "gridSeleccionados";
            this.gridSeleccionados.ReadOnly = true;
            this.gridSeleccionados.RowHeadersVisible = false;
            this.gridSeleccionados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridSeleccionados.Size = new System.Drawing.Size(884, 312);
            this.gridSeleccionados.TabIndex = 5;
            // 
            // pnlIntermedio
            // 
            this.pnlIntermedio.Controls.Add(this.cmdQuitar);
            this.pnlIntermedio.Controls.Add(this.cmdAgregar);
            this.pnlIntermedio.Controls.Add(this.lblSeleccionados);
            this.pnlIntermedio.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlIntermedio.Location = new System.Drawing.Point(0, 250);
            this.pnlIntermedio.Name = "pnlIntermedio";
            this.pnlIntermedio.Size = new System.Drawing.Size(884, 60);
            this.pnlIntermedio.TabIndex = 4;
            // 
            // cmdQuitar
            // 
            this.cmdQuitar.Location = new System.Drawing.Point(249, 18);
            this.cmdQuitar.Name = "cmdQuitar";
            this.cmdQuitar.Size = new System.Drawing.Size(75, 23);
            this.cmdQuitar.TabIndex = 2;
            this.cmdQuitar.Text = "Quitar";
            this.cmdQuitar.UseVisualStyleBackColor = true;
            this.cmdQuitar.Click += new System.EventHandler(this.cmdQuitar_Click);
            // 
            // cmdAgregar
            // 
            this.cmdAgregar.Location = new System.Drawing.Point(150, 18);
            this.cmdAgregar.Name = "cmdAgregar";
            this.cmdAgregar.Size = new System.Drawing.Size(75, 23);
            this.cmdAgregar.TabIndex = 1;
            this.cmdAgregar.Text = "Agregar";
            this.cmdAgregar.UseVisualStyleBackColor = true;
            this.cmdAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // lblSeleccionados
            // 
            this.lblSeleccionados.AutoSize = true;
            this.lblSeleccionados.Location = new System.Drawing.Point(0, 20);
            this.lblSeleccionados.Name = "lblSeleccionados";
            this.lblSeleccionados.Size = new System.Drawing.Size(87, 18);
            this.lblSeleccionados.TabIndex = 0;
            this.lblSeleccionados.Text = "Seleccionados";
            // 
            // FrmFiltroAvanzado
            // 
            this.AcceptButton = this.cmdAceptar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCancelar;
            this.ClientSize = new System.Drawing.Size(884, 662);
            this.Controls.Add(this.pnlPrincipal);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFiltroAvanzado";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Filtro Avanzado";
            this.Load += new System.EventHandler(this.FrmFiltroAvanzado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridDisponibles)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSeleccionados)).EndInit();
            this.pnlIntermedio.ResumeLayout(false);
            this.pnlIntermedio.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridDisponibles;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.DataGridView gridSeleccionados;
        private System.Windows.Forms.Panel pnlIntermedio;
        private System.Windows.Forms.Label lblDisponible;
        private System.Windows.Forms.Label lblSeleccionados;
        private System.Windows.Forms.Button cmdAgregar;
        private System.Windows.Forms.Button cmdQuitar;
        private System.Windows.Forms.Button cmdCancelar;
        private System.Windows.Forms.Button cmdAceptar;
        private System.Windows.Forms.TextBox txtFiltro;
        private System.Windows.Forms.Label lblFiltro;
    }
}
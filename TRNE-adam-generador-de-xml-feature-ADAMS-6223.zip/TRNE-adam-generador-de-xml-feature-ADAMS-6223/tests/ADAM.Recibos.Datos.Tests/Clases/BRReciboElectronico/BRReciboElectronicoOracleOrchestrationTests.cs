using Moq;
using System.Data;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.DatosTests
{
    [TestClass]
    public class BRReciboElectronicoOracleOrchestrationTests
    {
        #region Test Subclass

        /// <summary>
        /// Subclass that overrides the internal virtual data-fetching methods 
        /// to return pre-built DataSets, enabling unit testing of orchestration logic
        /// without a real Oracle connection.
        /// </summary>
        private class TestableBRReciboElectronicoOracle : BRReciboElectronicoOracle
        {
            public DataSet PrincipalResult { get; set; }
            public DataSet HorasExtraResult { get; set; }
            public DataSet IncapacidadesResult { get; set; }
            public DataSet OtrosPagosResult { get; set; }
            public DataSet AccionesTitulosResult { get; set; }
            public DataSet JubilacionPensionRetiroResult { get; set; }
            public DataSet SeparacionIndemnizacionResult { get; set; }

            public Nomina LastNominaPrincipal { get; private set; }
            public Nomina LastNominaHorasExtra { get; private set; }
            public Nomina LastNominaIncapacidades { get; private set; }
            public Nomina LastNominaOtrosPagos { get; private set; }
            public Nomina LastNominaAccionesTitulos { get; private set; }
            public Nomina LastNominaJubilacion { get; private set; }
            public Nomina LastNominaSeparacion { get; private set; }

            public TestableBRReciboElectronicoOracle(IDbConnectionFactory connectionFactory)
                : base(connectionFactory) { }

            internal override DataSet ObtenDatasetPrincipal(Nomina nomina)
            {
                LastNominaPrincipal = nomina;
                return PrincipalResult;
            }

            internal override DataSet ObtenDatasetHorasExtra(Nomina nomina)
            {
                LastNominaHorasExtra = nomina;
                return HorasExtraResult;
            }

            internal override DataSet ObtenDatasetIncapacidades(Nomina nomina)
            {
                LastNominaIncapacidades = nomina;
                return IncapacidadesResult;
            }

            internal override DataSet ObtenDatasetOtrosPagos(Nomina nomina)
            {
                LastNominaOtrosPagos = nomina;
                return OtrosPagosResult;
            }

            internal override DataSet ObtenDatasetAccionesTitulos(Nomina nomina)
            {
                LastNominaAccionesTitulos = nomina;
                return AccionesTitulosResult;
            }

            internal override DataSet ObtenDatasetJubilacionPensionRetiro(Nomina nomina)
            {
                LastNominaJubilacion = nomina;
                return JubilacionPensionRetiroResult;
            }

            internal override DataSet ObtenDatasetSeparacionIndemnizacion(Nomina nomina)
            {
                LastNominaSeparacion = nomina;
                return SeparacionIndemnizacionResult;
            }
        }

        #endregion

        #region Helpers

        private static Mock<IDbConnectionFactory> CreateMockFactory()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            return mockFactory;
        }

        private static Nomina CreateNomina(
            ManejoNomina manejoNomina = ManejoNomina.periodica,
            string conceptoFactura = "1000")
        {
            return new Nomina(
                compania: "0001",
                trabajador: "  90901010",
                tipoNomina: "01",
                claseNomina: "01",
                anio: 2026,
                periodo: 1,
                manejoNomina: manejoNomina,
                numeroLiquidacion: 0,
                conceptoFactura: conceptoFactura,
                formaPagoDefault: "EFEC"
            );
        }

        private static DataSet CreateDataSetWithTable(string tableName, params string[] columnNames)
        {
            var ds = new DataSet();
            var table = new DataTable(tableName);
            foreach (var col in columnNames)
            {
                table.Columns.Add(col, typeof(string));
            }
            table.Rows.Add(columnNames.Select(c => (object)$"val_{c}").ToArray());
            ds.Tables.Add(table);
            return ds;
        }

        private static TestableBRReciboElectronicoOracle CreateTestableService()
        {
            var mockFactory = CreateMockFactory();
            var service = new TestableBRReciboElectronicoOracle(mockFactory.Object);

            service.PrincipalResult = CreateDataSetWithTable("TablePrincipal", "Col1", "Col2");
            service.HorasExtraResult = CreateDataSetWithTable("TableHorasExtra", "TipoHoras", "Horas");
            service.IncapacidadesResult = CreateDataSetWithTable("TableIncapacidades", "Tipo", "Dias");
            service.OtrosPagosResult = CreateDataSetWithTable("TableOtrosPagos", "Clave", "Importe");
            service.AccionesTitulosResult = CreateDataSetWithTable("TableAccionesTitulos", "Valor", "Mercado");
            service.JubilacionPensionRetiroResult = CreateDataSetWithTable("TableJubilacionPensionRetiro", "TotalPago", "TotalGravado");
            service.SeparacionIndemnizacionResult = CreateDataSetWithTable("TableSeparacionIndemnizacion", "TotalPagado", "Anios");

            return service;
        }

        #endregion

        #region ObtenDatasetRecibo Orchestration Tests

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldReturnDataSetWithAllSevenTables()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(7, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTablePrincipal()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TablePrincipal"]);
            Assert.AreEqual(1, result.Tables["TablePrincipal"].Rows.Count);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTableHorasExtra()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TableHorasExtra"]);
            Assert.AreEqual(1, result.Tables["TableHorasExtra"].Rows.Count);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTableIncapacidades()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TableIncapacidades"]);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTableOtrosPagos()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TableOtrosPagos"]);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTableAccionesTitulos()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TableAccionesTitulos"]);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTableJubilacionPensionRetiro()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TableJubilacionPensionRetiro"]);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldContainTableSeparacionIndemnizacion()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result.Tables["TableSeparacionIndemnizacion"]);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldPassSameNominaToAllMethods()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.AreSame(nomina, service.LastNominaPrincipal);
            Assert.AreSame(nomina, service.LastNominaHorasExtra);
            Assert.AreSame(nomina, service.LastNominaIncapacidades);
            Assert.AreSame(nomina, service.LastNominaOtrosPagos);
            Assert.AreSame(nomina, service.LastNominaAccionesTitulos);
            Assert.AreSame(nomina, service.LastNominaJubilacion);
            Assert.AreSame(nomina, service.LastNominaSeparacion);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldCopyTableData_NotReference()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert — Tables are copies, not references
            Assert.AreNotSame(
                service.PrincipalResult.Tables["TablePrincipal"],
                result.Tables["TablePrincipal"]);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_Interactiva_ShouldReturnAllSevenTables()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina(ManejoNomina.interactiva, "1");

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(7, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_ShouldPreserveTableColumnStructure()
        {
            // Arrange
            var service = CreateTestableService();
            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.AreEqual(2, result.Tables["TablePrincipal"].Columns.Count);
            Assert.AreEqual(2, result.Tables["TableHorasExtra"].Columns.Count);
            Assert.AreEqual(2, result.Tables["TableIncapacidades"].Columns.Count);
            Assert.AreEqual(2, result.Tables["TableOtrosPagos"].Columns.Count);
            Assert.AreEqual(2, result.Tables["TableAccionesTitulos"].Columns.Count);
            Assert.AreEqual(2, result.Tables["TableJubilacionPensionRetiro"].Columns.Count);
            Assert.AreEqual(2, result.Tables["TableSeparacionIndemnizacion"].Columns.Count);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_WithMultipleRows_ShouldPreserveAllRows()
        {
            // Arrange
            var service = CreateTestableService();
            var ds = new DataSet();
            var table = new DataTable("TablePrincipal");
            table.Columns.Add("Col1", typeof(string));
            table.Rows.Add("Row1");
            table.Rows.Add("Row2");
            table.Rows.Add("Row3");
            ds.Tables.Add(table);
            service.PrincipalResult = ds;

            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.AreEqual(3, result.Tables["TablePrincipal"].Rows.Count);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_WithEmptyTables_ShouldReturnEmptyTablesInResult()
        {
            // Arrange
            var service = CreateTestableService();

            // Replace principal with empty table
            var ds = new DataSet();
            ds.Tables.Add(new DataTable("TablePrincipal"));
            service.PrincipalResult = ds;

            var nomina = CreateNomina();

            // Act
            var result = service.ObtenDatasetRecibo(nomina);

            // Assert
            Assert.AreEqual(0, result.Tables["TablePrincipal"].Rows.Count);
            Assert.AreEqual(7, result.Tables.Count);
        }

        #endregion

        #region ObtenDatasetReciboFull Orchestration Tests

        [TestMethod]
        public void ObtenDatasetReciboFull_Periodica_ShouldReturnAllSevenTables()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            var result = service.ObtenDatasetReciboFull(
                "0001", "  90901010", "01", "01",
                2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(7, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_ShouldReturnAllSevenTables()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            var result = service.ObtenDatasetReciboFull(
                "0001", "  90901010", "01", "01",
                2026, 1, ManejoNomina.interactiva, 1, "1", "EFEC");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(7, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_ShouldConstructNominaAndPassToRecibo()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            var result = service.ObtenDatasetReciboFull(
                "0001", "  90901010", "01", "01",
                2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Assert — verifies Nomina was passed through to all sub-methods
            Assert.IsNotNull(service.LastNominaPrincipal);
            Assert.AreEqual("0001", service.LastNominaPrincipal.Compania);
            Assert.AreEqual("  90901010", service.LastNominaPrincipal.Trabajador);
            Assert.AreEqual("01", service.LastNominaPrincipal.TipoNomina);
            Assert.AreEqual("01", service.LastNominaPrincipal.ClaseNomina);
            Assert.AreEqual(2026, service.LastNominaPrincipal.Anio);
            Assert.AreEqual(1, service.LastNominaPrincipal.Periodo);
            Assert.AreEqual(ManejoNomina.periodica, service.LastNominaPrincipal.ManejoNomina);
            Assert.AreEqual(0, service.LastNominaPrincipal.NumeroLiquidacion);
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_ShouldPassCorrectManejoNomina()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            service.ObtenDatasetReciboFull(
                "0001", "  90901010", "01", "01",
                2026, 1, ManejoNomina.interactiva, 5, "2", "EFEC");

            // Assert
            Assert.AreEqual(ManejoNomina.interactiva, service.LastNominaPrincipal.ManejoNomina);
            Assert.AreEqual(5, service.LastNominaPrincipal.NumeroLiquidacion);
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_ShouldContainAllExpectedTableNames()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            var result = service.ObtenDatasetReciboFull(
                "0001", "  90901010", "01", "01",
                2026, 1, ManejoNomina.periodica, 0, "1000", "EFEC");

            // Assert
            var expectedTables = new[]
            {
                "TablePrincipal", "TableHorasExtra", "TableIncapacidades",
                "TableOtrosPagos", "TableAccionesTitulos",
                "TableJubilacionPensionRetiro", "TableSeparacionIndemnizacion"
            };

            foreach (var tableName in expectedTables)
            {
                Assert.IsNotNull(result.Tables[tableName], $"Missing table: {tableName}");
            }
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_WithDifferentCompany_ShouldPassCorrectCompany()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            service.ObtenDatasetReciboFull(
                "9999", "  12345678", "02", "03",
                2025, 12, ManejoNomina.periodica, 0, "500", "TRAN");

            // Assert
            Assert.AreEqual("9999", service.LastNominaPrincipal.Compania);
            Assert.AreEqual("  12345678", service.LastNominaPrincipal.Trabajador);
            Assert.AreEqual("02", service.LastNominaPrincipal.TipoNomina);
            Assert.AreEqual("03", service.LastNominaPrincipal.ClaseNomina);
            Assert.AreEqual(2025, service.LastNominaPrincipal.Anio);
            Assert.AreEqual(12, service.LastNominaPrincipal.Periodo);
        }

        #endregion
    }
}

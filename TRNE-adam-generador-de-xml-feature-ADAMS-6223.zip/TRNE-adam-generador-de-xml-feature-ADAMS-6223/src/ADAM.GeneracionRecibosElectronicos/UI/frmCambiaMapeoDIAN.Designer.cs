namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmCambiaMapeoDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCambiaMapeoDIAN));
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdCambiar = new System.Windows.Forms.Button();
            this.cboDatoADAM = new System.Windows.Forms.ComboBox();
            this.lblDatoADAM = new System.Windows.Forms.Label();
            this.lblDatoDIAN = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblSeccion = new System.Windows.Forms.Label();
            this.lblClave = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblCampo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(314, 288);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 13;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            this.cmdCerrar.Click += new System.EventHandler(this.cmdCerrar_Click);
            // 
            // cmdCambiar
            // 
            this.cmdCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCambiar.Location = new System.Drawing.Point(198, 288);
            this.cmdCambiar.Name = "cmdCambiar";
            this.cmdCambiar.Size = new System.Drawing.Size(110, 50);
            this.cmdCambiar.TabIndex = 12;
            this.cmdCambiar.Text = "&Asignar Dato";
            this.cmdCambiar.UseVisualStyleBackColor = true;
            this.cmdCambiar.Click += new System.EventHandler(this.cmdCambiar_Click);
            // 
            // cboDatoADAM
            // 
            this.cboDatoADAM.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboDatoADAM.DropDownWidth = 350;
            this.cboDatoADAM.FormattingEnabled = true;
            this.cboDatoADAM.Location = new System.Drawing.Point(328, 110);
            this.cboDatoADAM.Name = "cboDatoADAM";
            this.cboDatoADAM.Size = new System.Drawing.Size(250, 26);
            this.cboDatoADAM.TabIndex = 11;
            // 
            // lblDatoADAM
            // 
            this.lblDatoADAM.AutoSize = true;
            this.lblDatoADAM.Location = new System.Drawing.Point(322, 80);
            this.lblDatoADAM.Name = "lblDatoADAM";
            this.lblDatoADAM.Size = new System.Drawing.Size(67, 18);
            this.lblDatoADAM.TabIndex = 10;
            this.lblDatoADAM.Text = "Dato ADAM";
            // 
            // lblDatoDIAN
            // 
            this.lblDatoDIAN.Location = new System.Drawing.Point(10, 80);
            this.lblDatoDIAN.Name = "lblDatoDIAN";
            this.lblDatoDIAN.Size = new System.Drawing.Size(80, 18);
            this.lblDatoDIAN.TabIndex = 8;
            this.lblDatoDIAN.Text = "Dato DIAN";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.Location = new System.Drawing.Point(10, 20);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(446, 42);
            this.lblDescripcion.TabIndex = 7;
            this.lblDescripcion.Text = "Relaciona las Secciones y Campos DIAN con los Catálogos existentes de ADAM";
            // 
            // lblSeccion
            // 
            this.lblSeccion.Location = new System.Drawing.Point(12, 113);
            this.lblSeccion.Name = "lblSeccion";
            this.lblSeccion.Size = new System.Drawing.Size(296, 18);
            this.lblSeccion.TabIndex = 14;
            this.lblSeccion.Text = "Sección:";
            // 
            // lblClave
            // 
            this.lblClave.Location = new System.Drawing.Point(12, 174);
            this.lblClave.Name = "lblClave";
            this.lblClave.Size = new System.Drawing.Size(296, 18);
            this.lblClave.TabIndex = 15;
            this.lblClave.Text = "Clave:";
            // 
            // lblDesc
            // 
            this.lblDesc.Location = new System.Drawing.Point(12, 206);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(296, 50);
            this.lblDesc.TabIndex = 16;
            this.lblDesc.Text = "Descripción:";
            // 
            // lblCampo
            // 
            this.lblCampo.Location = new System.Drawing.Point(12, 143);
            this.lblCampo.Name = "lblCampo";
            this.lblCampo.Size = new System.Drawing.Size(296, 18);
            this.lblCampo.TabIndex = 17;
            this.lblCampo.Text = "Campo:";
            // 
            // FrmCambiaMapeoDIAN
            // 
            this.AcceptButton = this.cmdCambiar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(618, 350);
            this.Controls.Add(this.lblCampo);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.lblClave);
            this.Controls.Add(this.lblSeccion);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdCambiar);
            this.Controls.Add(this.cboDatoADAM);
            this.Controls.Add(this.lblDatoADAM);
            this.Controls.Add(this.lblDatoDIAN);
            this.Controls.Add(this.lblDescripcion);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCambiaMapeoDIAN";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asignar Valor Mapeo";
            this.Load += new System.EventHandler(this.FrmCambiaMapeo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Button cmdCambiar;
        private System.Windows.Forms.ComboBox cboDatoADAM;
        private System.Windows.Forms.Label lblDatoADAM;
        private System.Windows.Forms.Label lblDatoDIAN;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblSeccion;
        private System.Windows.Forms.Label lblClave;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.Label lblCampo;
    }
}
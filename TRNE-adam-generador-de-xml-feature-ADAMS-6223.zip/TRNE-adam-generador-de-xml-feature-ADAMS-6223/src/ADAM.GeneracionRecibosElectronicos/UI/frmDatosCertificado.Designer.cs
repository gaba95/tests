namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmDatosCertificado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDatosCertificado));
            this.lblCertificado = new System.Windows.Forms.Label();
            this.lblContraseña = new System.Windows.Forms.Label();
            this.ofArchivoCertificado = new System.Windows.Forms.OpenFileDialog();
            this.cmdBuscarArchivoCer = new System.Windows.Forms.Button();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdAceptar = new System.Windows.Forms.Button();
            this.txtRutaLlave = new System.Windows.Forms.TextBox();
            this.cmdBuscarArchivoKey = new System.Windows.Forms.Button();
            this.lblLlave = new System.Windows.Forms.Label();
            this.txtPasswordLlave = new System.Windows.Forms.TextBox();
            this.lblPasswordLlave = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblCertificado
            // 
            this.lblCertificado.AutoSize = true;
            this.lblCertificado.Location = new System.Drawing.Point(10, 40);
            this.lblCertificado.Name = "lblCertificado";
            this.lblCertificado.Size = new System.Drawing.Size(136, 18);
            this.lblCertificado.TabIndex = 0;
            this.lblCertificado.Text = "Archivo de Certificado:";
            // 
            // lblContraseña
            // 
            this.lblContraseña.AutoSize = true;
            this.lblContraseña.Location = new System.Drawing.Point(10, 70);
            this.lblContraseña.Name = "lblContraseña";
            this.lblContraseña.Size = new System.Drawing.Size(156, 18);
            this.lblContraseña.TabIndex = 1;
            this.lblContraseña.Text = "Contraseña del Certificado";
            // 
            // cmdBuscarArchivoCer
            // 
            this.cmdBuscarArchivoCer.Location = new System.Drawing.Point(406, 41);
            this.cmdBuscarArchivoCer.Name = "cmdBuscarArchivoCer";
            this.cmdBuscarArchivoCer.Size = new System.Drawing.Size(30, 23);
            this.cmdBuscarArchivoCer.TabIndex = 2;
            this.cmdBuscarArchivoCer.Text = "...";
            this.cmdBuscarArchivoCer.UseVisualStyleBackColor = true;
            this.cmdBuscarArchivoCer.Click += new System.EventHandler(this.cmdBuscarArchivo_Click);
            // 
            // txtRuta
            // 
            this.txtRuta.Location = new System.Drawing.Point(200, 40);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.ReadOnly = true;
            this.txtRuta.Size = new System.Drawing.Size(200, 21);
            this.txtRuta.TabIndex = 3;
            this.txtRuta.Text = "C:\\Users\\jorge.espinosa.ADAM\\Desktop\\08_TimbradoRecibos\\certificados\\CSD01_AAA010" +
    "101AAA.cer";
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(346, 200);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 15;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // cmdAceptar
            // 
            this.cmdAceptar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAceptar.Location = new System.Drawing.Point(200, 200);
            this.cmdAceptar.Name = "cmdAceptar";
            this.cmdAceptar.Size = new System.Drawing.Size(110, 50);
            this.cmdAceptar.TabIndex = 14;
            this.cmdAceptar.Text = "&Aceptar";
            this.cmdAceptar.UseVisualStyleBackColor = true;
            this.cmdAceptar.Click += new System.EventHandler(this.cmdAceptar_Click);
            // 
            // txtRutaLlave
            // 
            this.txtRutaLlave.Location = new System.Drawing.Point(200, 100);
            this.txtRutaLlave.Name = "txtRutaLlave";
            this.txtRutaLlave.ReadOnly = true;
            this.txtRutaLlave.Size = new System.Drawing.Size(200, 21);
            this.txtRutaLlave.TabIndex = 18;
            this.txtRutaLlave.Text = "C:\\Users\\jorge.espinosa.ADAM\\Desktop\\08_TimbradoRecibos\\certificados\\CSD01_AAA010" +
    "101AAA.key";
            // 
            // cmdBuscarArchivoKey
            // 
            this.cmdBuscarArchivoKey.Location = new System.Drawing.Point(406, 98);
            this.cmdBuscarArchivoKey.Name = "cmdBuscarArchivoKey";
            this.cmdBuscarArchivoKey.Size = new System.Drawing.Size(30, 23);
            this.cmdBuscarArchivoKey.TabIndex = 17;
            this.cmdBuscarArchivoKey.Text = "...";
            this.cmdBuscarArchivoKey.UseVisualStyleBackColor = true;
            this.cmdBuscarArchivoKey.Click += new System.EventHandler(this.cmdBuscarArchivoKey_Click);
            // 
            // lblLlave
            // 
            this.lblLlave.AutoSize = true;
            this.lblLlave.Location = new System.Drawing.Point(10, 100);
            this.lblLlave.Name = "lblLlave";
            this.lblLlave.Size = new System.Drawing.Size(80, 18);
            this.lblLlave.TabIndex = 16;
            this.lblLlave.Text = "Archivo Llave";
            // 
            // txtPasswordLlave
            // 
            this.txtPasswordLlave.Location = new System.Drawing.Point(200, 130);
            this.txtPasswordLlave.Name = "txtPasswordLlave";
            this.txtPasswordLlave.PasswordChar = '*';
            this.txtPasswordLlave.Size = new System.Drawing.Size(200, 21);
            this.txtPasswordLlave.TabIndex = 20;
            // 
            // lblPasswordLlave
            // 
            this.lblPasswordLlave.AutoSize = true;
            this.lblPasswordLlave.Location = new System.Drawing.Point(10, 130);
            this.lblPasswordLlave.Name = "lblPasswordLlave";
            this.lblPasswordLlave.Size = new System.Drawing.Size(129, 18);
            this.lblPasswordLlave.TabIndex = 19;
            this.lblPasswordLlave.Text = "Contraseña de la llave";
            // 
            // FrmDatosCertificado
            // 
            this.AcceptButton = this.cmdAceptar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(484, 262);
            this.Controls.Add(this.txtPasswordLlave);
            this.Controls.Add(this.lblPasswordLlave);
            this.Controls.Add(this.txtRutaLlave);
            this.Controls.Add(this.cmdBuscarArchivoKey);
            this.Controls.Add(this.lblLlave);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdAceptar);
            this.Controls.Add(this.txtRuta);
            this.Controls.Add(this.cmdBuscarArchivoCer);
            this.Controls.Add(this.lblContraseña);
            this.Controls.Add(this.lblCertificado);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmDatosCertificado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Datos del Certificado";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCertificado;
        private System.Windows.Forms.Label lblContraseña;
        private System.Windows.Forms.OpenFileDialog ofArchivoCertificado;
        private System.Windows.Forms.Button cmdBuscarArchivoCer;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Button cmdAceptar;
        private System.Windows.Forms.TextBox txtRutaLlave;
        private System.Windows.Forms.Button cmdBuscarArchivoKey;
        private System.Windows.Forms.Label lblLlave;
        private System.Windows.Forms.TextBox txtPasswordLlave;
        private System.Windows.Forms.Label lblPasswordLlave;
    }
}
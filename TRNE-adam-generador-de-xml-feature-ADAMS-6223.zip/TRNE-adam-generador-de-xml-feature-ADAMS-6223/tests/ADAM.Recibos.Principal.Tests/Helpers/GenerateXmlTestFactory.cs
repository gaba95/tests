﻿using ADAM.Recibos.Datos;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Test.Fakes;
using ADAM.Recibos.Utilerias.Enums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAM.Recibos.Principal.Test.Helpers
{
    internal static class GenerateXmlTestFactory
    {
        public const string DefaultCompany = "CBS";
        public const string DefaultInvoiceConcept = "X";
        public const string DefaultPaymentMethod = "01";
        public const string DefaultCertificatePath = @"C:\tmp\a.cer";
        public const string DefaultKeyPath = @"C:\tmp\a.key";
        public const string DefaultKeyPasswotd = "Test1234!";

        public const string ApplicationUserKey = "applicationUser";
        public const string DefaultApplicationUser = "unit_test_user";

        public static ApplicationSettingsBase CreateDefaultAppSettings()
        {
            return new FakeAppSettings()
                .With(ApplicationUserKey, DefaultApplicationUser);
        }

        public static GenerateXml Create(ApplicationSettingsBase? settings = null, Trabajadores? workertList = null)
        {
            settings = settings ?? CreateDefaultAppSettings();
            workertList = workertList ?? new Trabajadores();

            return new GenerateXml(
                tipoPlataforma: TipoPlataforma.SQLServer,
                appSettings: settings,
                listaTrabajadores: workertList,
                compania: DefaultCompany,
                conceptoFactura: DefaultInvoiceConcept,
                metodoPagoDefault: DefaultPaymentMethod,
                rutaCertificado: DefaultCertificatePath,
                rutaLlave: DefaultKeyPath,
                passwordLlave: DefaultKeyPasswotd
                );
        }

        public static GenerateXml CreateWithFakeBR(
            FakeBRReciboElectronico fakeBR,
            Trabajadores? workers = null,
            ApplicationSettingsBase? settings = null)
        {
            var sut = Create(settings: settings, workertList: workers);
            sut.CreateBRReciboElectronico = (_, __) => fakeBR;
            return sut;
        }

    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("otrosConceptos", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class OtherConcepts
    {
        [JsonProperty("descripcionConcepto")]
        public string valorDescripcionConcepto { get; set; } = "";

        public decimal valor { get; set; }
        public bool esParteSalario { get; set; }
    }
}

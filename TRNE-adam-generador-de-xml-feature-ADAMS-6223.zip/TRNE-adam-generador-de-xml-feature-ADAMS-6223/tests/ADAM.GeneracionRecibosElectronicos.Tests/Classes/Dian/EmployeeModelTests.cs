using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using ADAM.GeneracionRecibosElectronicos.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class EmployeeTests
    {
        [TestMethod]
        public void Employee_NombreCompleto_ConcatenatesNames()
        {
            var emp = new Employee
            {
                primerApellido = "García",
                segundoApellido = "López",
                primerNombre = "Juan",
                otrosNombres = "Carlos"
            };

            Assert.AreEqual("García López Juan Carlos", emp.nombreCompleto);
        }

        [TestMethod]
        public void Employee_NombreCompleto_TrimsWhenFieldsAreNull()
        {
            var emp = new Employee
            {
                primerApellido = "García",
                segundoApellido = null,
                primerNombre = "Juan",
                otrosNombres = null
            };

            // Format with nulls still produces a string (null becomes "")
            var result = emp.nombreCompleto;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Employee_RespuestaDianMessage_ReturnsEmptyString()
        {
            var emp = new Employee();
            Assert.AreEqual("", emp.respuestaDianMessage);
        }

        [TestMethod]
        public void Employee_CodigoMensajeDian_ReturnsMinusOne()
        {
            var emp = new Employee();
            Assert.AreEqual("-1", emp.codigoMensajeDian);
        }

        [TestMethod]
        public void Employee_RespuestaDianEstatus_ReturnsNotValid()
        {
            var emp = new Employee();
            Assert.AreEqual("NotValid", emp.respuestaDianEstatus);
        }

        [TestMethod]
        public void Employee_ImplementsIEmployee()
        {
            var emp = new Employee();
            Assert.IsInstanceOfType(emp, typeof(IEmployee));
        }

        [TestMethod]
        public void Employee_Serialization_IgnoresEmployeeId()
        {
            var emp = new Employee { employeeId = "E001", primerNombre = "Test" };
            var json = JsonConvert.SerializeObject(emp);

            Assert.IsFalse(json.Contains("employeeId"));
            Assert.IsTrue(json.Contains("primerNombre"));
        }

        [TestMethod]
        public void Employee_Properties_SetAndGet()
        {
            var emp = new Employee
            {
                employeeId = "E001",
                tipoTrabajador = "01",
                subtipoTrabajador = "00",
                altoRiesgoPension = true,
                tipoDocumento = "CC",
                numeroDocumento = "123456789",
                lugarTrabajoPais = "CO",
                lugarTrabajoDepartamentoEstado = "BOG",
                lugarTrabajoMunicipioCiudad = "Bogota",
                lugarTrabajoDireccion = "Calle 1",
                salarioIntegral = false,
                tipoContrato = 1,
                sueldo = 2500000m,
                fechaIngreso = "2020-01-15",
                fechaRetiro = null,
                tiempoLaborado = 365,
                emailTrabajador = "test@test.com",
                comprobanteTotal = 3000000m,
                tipoMoneda = "COP",
                trm = 1m,
                notas = "N/A",
                redondeo = 0.5m,
                devengadosTotal = 2800000m,
                deduccionesTotal = 200000m
            };

            Assert.AreEqual("E001", emp.employeeId);
            Assert.AreEqual("01", emp.tipoTrabajador);
            Assert.IsTrue(emp.altoRiesgoPension);
            Assert.AreEqual(2500000m, emp.sueldo);
            Assert.AreEqual("COP", emp.tipoMoneda);
        }

        [TestMethod]
        public void Employee_ComplexProperties_SetAndGet()
        {
            var emp = new Employee
            {
                pago = new Payment { forma = 1, metodo = "10", banco = "Banco1" },
                devengados = new Perceptions(),
                deducciones = new Deductions(),
                fechasPago = new List<PaymentDates> { new PaymentDates { fechaPago = "2026-01-15" } },
                numeroSecuenciaXML = new XMLSequenceNumber { CodigoTrabajador = "CT1" },
                lugarGeneracionXML = new PlaceGenerationXML { Pais = "CO" },
                informacionPredecesor = new PredecessorInformation { cunePred = "CUNE1" }
            };

            Assert.IsNotNull(emp.pago);
            Assert.AreEqual(1, emp.pago.forma);
            Assert.IsNotNull(emp.devengados);
            Assert.IsNotNull(emp.deducciones);
            Assert.AreEqual(1, emp.fechasPago.Count);
            Assert.AreEqual("CT1", emp.numeroSecuenciaXML.CodigoTrabajador);
            Assert.AreEqual("CO", emp.lugarGeneracionXML.Pais);
            Assert.AreEqual("CUNE1", emp.informacionPredecesor.cunePred);
        }
    }
}

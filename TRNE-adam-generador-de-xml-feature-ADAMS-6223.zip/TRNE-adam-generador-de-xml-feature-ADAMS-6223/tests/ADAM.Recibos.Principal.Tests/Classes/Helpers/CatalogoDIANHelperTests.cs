using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Principal.Test.Fakes;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Test.Classes.Helpers
{
    [TestClass]
    public class CatalogoDianHelperTests
    {
        #region Helpers

        private static FakeAppSettings CreateSqlSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "TestDB")
                .With(ConfigParameters.user.ToString(), "sa")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.version.ToString(), "5");
        }

        private static FakeAppSettings CreateOracleSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "ORCL")
                .With(ConfigParameters.user.ToString(), "system")
                .With(ConfigParameters.password.ToString(), "oracle")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.puertoOracle.ToString(), "1521")
                .With(ConfigParameters.tipoOracle.ToString(), "SERVICE_NAME");
        }

        #endregion

        #region CreateInstance - SQLServer

        [TestMethod]
        public void CreateInstance_SQLServer_ReturnsCatalogoDianSql()
        {
            var result = CatalogoDianHelper.CreateInstance(
                TipoPlataforma.SQLServer, CreateSqlSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoDianSql>(result);
        }

        #endregion

        #region CreateInstance - ORACLE

        [TestMethod]
        public void CreateInstance_Oracle_ReturnsCatalogoDianOracle()
        {
            var result = CatalogoDianHelper.CreateInstance(
                TipoPlataforma.ORACLE, CreateOracleSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoDianOracle>(result);
        }

        #endregion

        #region CreateInstance - Default

        [TestMethod]
        public void CreateInstance_InvalidPlatform_ReturnsCatalogoDianSql()
        {
            var result = CatalogoDianHelper.CreateInstance(
                (TipoPlataforma)999, CreateSqlSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoDianSql>(result);
        }

        #endregion

        #region CreateInstance - ODBC not supported

        [TestMethod]
        public void CreateInstance_ODBC_FallsBackToSql()
        {
            var settings = new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "TestDB")
                .With(ConfigParameters.user.ToString(), "sa")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.version.ToString(), "5");

            var result = CatalogoDianHelper.CreateInstance(
                TipoPlataforma.ODBC, settings);

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<CatalogoDianSql>(result);
        }

        #endregion

        #region CreateInstance - Interface

        [TestMethod]
        public void CreateInstance_AllPlatforms_ReturnICatalogoDian()
        {
            var sql = CatalogoDianHelper.CreateInstance(TipoPlataforma.SQLServer, CreateSqlSettings());
            var oracle = CatalogoDianHelper.CreateInstance(TipoPlataforma.ORACLE, CreateOracleSettings());

            Assert.IsInstanceOfType<ICatalogoDian>(sql);
            Assert.IsInstanceOfType<ICatalogoDian>(oracle);
        }

        #endregion
    }
}

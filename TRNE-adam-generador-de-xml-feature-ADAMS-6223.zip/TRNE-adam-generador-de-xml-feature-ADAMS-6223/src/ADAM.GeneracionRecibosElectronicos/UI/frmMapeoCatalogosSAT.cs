﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.GeneracionRecibosElectronicos.Enums;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmMapeoCatalogosSAT : Form
    {
        #region Properties

        private const string ColClaveSat = "clave_sat";

        private ICatalogoSat _catalogoSAT;
        private ICatalogoAdicional _catalogoAdicional;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Institucion { get; set; }

        #endregion

        #region Events

        private void FrmMapeoCatalogosSAT_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }
        
        private void cmdCambiar_Click(object sender, EventArgs e)
        {
            if (gridDatosSAT.RowCount == 0)
                return;

            FrmCambiaMapeoSAT cambia = new FrmCambiaMapeoSAT();
            cambia.tipo = gridDatosSAT.CurrentRow.Cells["tipo"].Value.ToString();
            cambia.claveSat = gridDatosSAT.CurrentRow.Cells[ColClaveSat].Value.ToString();
            cambia.compania = this.compania;
            cambia.descripcion = gridDatosSAT.CurrentRow.Cells["descripcion_sat"].Value.ToString();
            cambia.tipoPlataforma = this.tipoPlataforma;
            cambia.FrmMapeoCatalogosSAT = this;

            cambia.ShowDialog();
        }
        
        private void cmdQuitar_Click(object sender, EventArgs e)
        {
            if (gridDatosSAT.RowCount == 0)
                return;

            if (gridDatosSAT.CurrentRow.Cells[ColClaveSat].Value.ToString().Trim() == "")
                return;

            if (MessageBox.Show("¿Esta seguro?", "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes
                && _catalogoSAT.BajaRelacionDatoCatalogoADAM(cboCatalogos.SelectedValue.ToString(), compania, gridDatosSAT.CurrentRow.Cells[ColClaveSat].Value.ToString(), gridDatosADAM.CurrentRow.Cells["clave_adam"].Value.ToString()))
                    LlenaGridEquivalenciasADAM(cboCatalogos.SelectedValue.ToString(), gridDatosSAT.CurrentRow.Cells[ColClaveSat].Value.ToString().Trim());
        }
        
        private void cboCompania_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Set Selected Company
            if (cboCompania.SelectedIndex >= 0)
            {
                DataRowView dtRowView = cboCompania.SelectedItem as DataRowView;
                compania = (dtRowView != null ? dtRowView.Row[0].ToString() : "");
            }

            // Fill Combos
            llenaComboTipo();
            LlenaGridDatosSAT(cboCatalogos.SelectedValue.ToString());
            LlenaGridEquivalenciasADAM(cboCatalogos.SelectedValue.ToString(), String.Empty);
        }
        
        private void cboCatalogos_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboCatalogos.Tag != null) return;

            LlenaGridDatosSAT(cboCatalogos.SelectedValue.ToString());
            LlenaGridEquivalenciasADAM(cboCatalogos.SelectedValue.ToString(), String.Empty);
        }
        
        private void gridValores_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            cmdCambiar_Click(sender, new EventArgs());
        }
        
        private void gridDatosSAT_SelectionChanged(object sender, EventArgs e)
        {
            if (gridDatosSAT.RowCount == 0)
                return;

            string tipo = gridDatosSAT.CurrentRow.Cells["tipo"].Value.ToString();
            string claveSAT = gridDatosSAT.CurrentRow.Cells[ColClaveSat].Value.ToString();
            LlenaGridEquivalenciasADAM(tipo, claveSAT);
        }

        #endregion

        #region Methods

        public FrmMapeoCatalogosSAT()
        {
            InitializeComponent();
        }
        
        private void InicializaClase()
        {

            _catalogoSAT = CatalogoSatHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            // Fill Company Dropdown
            cboCompania.DataSource = _catalogoAdicional.obtenDatasetCompanias(LanguageCodes.Mexico).Tables[0];
            cboCompania.DisplayMember = "nombre_cia";
            cboCompania.ValueMember = "compania";

            // Select Default Company
            if (!string.IsNullOrEmpty(compania))
            { cboCompania.SelectedItem = compania; }

            // Fill Combo
            llenaComboTipo();

            // Fill Grid automatically
            LlenaGridDatosSAT(cboCatalogos.SelectedValue.ToString());

            // Fill SAT Parameters automatically
            LlenaGridEquivalenciasADAM(cboCatalogos.SelectedValue.ToString(), String.Empty);

            //PTF-4277 Config Catalogs by Institution
            lblTitulo.Text = String.Format("Mapeo de Catálogos ADAM - {0}", this.Institucion);
            lblDatosSAT.Text = String.Format("Catálogo {0}", this.Institucion);
        }
        
        private void llenaComboTipo()
        {
            // Set Tag to avoid events 
            this.cboCatalogos.Tag = true;

            // Fill Combo
            cboCatalogos.ValueMember = "clave";
            cboCatalogos.DisplayMember = "descripcion";
            cboCatalogos.DataSource = _catalogoSAT.dsListaCatalogosSAT().Tables[0];

            // Set Tag
            this.cboCatalogos.Tag = null;
        }
        
        public void LlenaGridDatosSAT(string tipo)
        {
            try
            {
                gridDatosSAT.DataSource = _catalogoSAT.obtenDatasetCatalogosSAT(tipo).Tables[0];

                gridDatosSAT.Columns["tipo"].HeaderText = "Tipo";
                gridDatosSAT.Columns[ColClaveSat].HeaderText = String.Format("Cve. {0}", this.Institucion); //PTF-4277
                gridDatosSAT.Columns["descripcion_sat"].HeaderText = "Descripción";
                gridDatosSAT.Refresh();
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
        
        public void LlenaGridEquivalenciasADAM(string tipo, string claveSAT)
        {
            try
            {
                // Clean the Grid
                gridDatosADAM.DataSource = null;

                // Load the Data
                DataSet dsMapeo = _catalogoSAT.obtenDatasetRelacionCatalogosSATADAM(tipo, claveSAT, compania);

                if (dsMapeo.Tables.Count > 0)
                {
                    gridDatosADAM.DataSource = dsMapeo.Tables[0];

                    gridDatosADAM.Columns["tipo"].HeaderText = "Tipo";
                    gridDatosADAM.Columns[ColClaveSat].HeaderText = String.Format("Cve. {0}", this.Institucion); //PTF-4277
                    gridDatosADAM.Columns["clave_adam"].HeaderText = "Cve. ADAM";
                    gridDatosADAM.Columns["descripcion"].HeaderText = "Descripción ADAM";
                    gridDatosADAM.Refresh();
                }

            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        #endregion
    }
}

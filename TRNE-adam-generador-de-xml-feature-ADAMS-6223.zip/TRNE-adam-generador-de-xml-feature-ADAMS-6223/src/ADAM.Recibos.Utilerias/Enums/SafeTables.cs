﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public static class SafeTables
    {
        public static Dictionary<string, string> WhiteList { get; } = new Dictionary<string, string>
        {
            { "tb_catalogos_dian", "tb_catalogos_dian" },
            { "tb_catalogo_paises_dian", "tb_catalogo_paises_dian" },
            { "tb_catalogo_departamentos_dian", "tb_catalogo_departamentos_dian" },
            { "tb_catalogo_municipios_dian", "tb_catalogo_municipios_dian" },
            { "tb_catalogo_periodo_nomina_dian", "tb_catalogo_periodo_nomina_dian" },
            { "tb_catalogo_monedas_dian", "tb_catalogo_monedas_dian" },
            { "tb_catalogo_tipo_trabajador_dian", "tb_catalogo_tipo_trabajador_dian" },
            { "tb_catalogo_tipo_doc_identidad_dian", "tb_catalogo_tipo_doc_identidad_dian" },
            { "tb_catalogo_tipo_contrato_dian", "tb_catalogo_tipo_contrato_dian" },
            { "tb_catalogo_medios_pago_dian", "tb_catalogo_medios_pago_dian" },
            { "tb_catalogo_tipos_hora_dian", "tb_catalogo_tipos_hora_dian" },
            { "tb_catalogo_tipos_incapacidad_dian", "tb_catalogo_tipos_incapacidad_dian" }
        };
    }
}

﻿using System.Data;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos
{
    public interface IBRReciboElectronico 
    {
        string ApplicationUser { get; }

        bool CheckDbConnection();

        DataSet ObtenDatasetRecibo(Nomina nomina);

        DataSet ObtenDatasetReciboFull(string compania, string trabajador, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina, int numeroLiquidacion, string conceptoFactura, string formaPagoDefault);

        //Para datos adicionales agregados al recibo electronico
        DataSet ObtenDatasetAdicionales(Nomina nomina, string procedimiento);
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("informacionGeneral", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class GeneralInformation
    {
        public bool nominaAjuste { get; set; }
        public string periodoNomina { get; set; }
    }
}

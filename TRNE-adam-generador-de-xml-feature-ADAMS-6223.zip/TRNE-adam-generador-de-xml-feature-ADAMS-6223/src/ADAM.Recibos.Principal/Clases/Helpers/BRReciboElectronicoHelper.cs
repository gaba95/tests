﻿using System.Configuration;
using System.Data;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Clases
{
    public static class BRReciboElectronicoHelper
    {
        public static IBRReciboElectronico CreateInstance(TipoPlataforma tipoPlataforma, 
                                                          ApplicationSettingsBase appSettings)
        {
            
            switch (tipoPlataforma)
            {
                case TipoPlataforma.SQLServer:
                    return new BRReciboElectronicoSql(new SqlConnectionFactory(appSettings));

                case TipoPlataforma.ORACLE:
                    return new BRReciboElectronicoOracle(new OracleConnectionFactory(appSettings));

                case TipoPlataforma.ODBC:
                    return new BRReciboElectronicoOdbc(new OdbcConnectionFactory(appSettings));

                default:
                    return new BRReciboElectronicoSql(new SqlConnectionFactory(appSettings));
            }
        }

    }
}

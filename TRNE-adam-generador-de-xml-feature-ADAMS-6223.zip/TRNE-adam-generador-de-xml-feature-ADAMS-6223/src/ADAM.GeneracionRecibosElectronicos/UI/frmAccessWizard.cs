﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmAccessWizard : Form
    {
        #region Properties

        public string Pais { 
            get {
                if (cboPaises.SelectedIndex > -1)
                    return cboPaises.SelectedItem.ToString();
                return "";
            } 
        }

        #endregion

        #region Methods

        public FrmAccessWizard()
        {
            InitializeComponent();
        }

        #endregion 

        #region Events

        private void ctrButtonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void ctrButtonOK_Click(object sender, EventArgs e)
        {
            if (cboPaises.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar un pais para poder continuar", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.ctrButtonOK.DialogResult = DialogResult.None;
                return;
            }
            this.AcceptButton = this.ctrButtonOK;
            this.ctrButtonOK.DialogResult = DialogResult.OK;
            this.Close();
        }

        #endregion 
    }
}

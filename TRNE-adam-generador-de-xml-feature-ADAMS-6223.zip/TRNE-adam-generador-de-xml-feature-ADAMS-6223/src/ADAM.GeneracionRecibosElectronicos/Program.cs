using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            SetOutputFolder();

            if (args.Length == 0)
            {
                FrmGeneracionRecibo frm = new FrmGeneracionRecibo(args);
                Application.Run(frm);
            }
            else
            {
                GetConnectionStringParams(ref args);
                Application.Run(new FrmGeneracionRecibo(args));
            }
        }

        public static void GetConnectionStringParams(ref string[] args)
        {
            try
            {
                var plainConnection = new StringBuilder("TBM");
                for(int i = 1; i < args.Length; i++)
                {
                    plainConnection.Append(';').Append(args[i]);
                }
                args = plainConnection.ToString().Split(';');
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private static void SetOutputFolder()
        {
            var appPath = Path.GetDirectoryName(Environment.ProcessPath).Replace("file\\", "");
            Properties.AppSettings.Default[ConfigParameters.applicationPath.ToString()] = appPath;
            var outputPath = Path.Combine(appPath,"output");

            if (Directory.Exists(outputPath))
            {
                var outputPathInfo = new DirectoryInfo(outputPath);

                // Delete older files
                var filesToDelete = outputPathInfo.EnumerateFiles()
                                                  .Where(f => f.LastWriteTime < DateTime.Now.AddDays(-2));

                foreach (var file in filesToDelete)
                {
                    File.Delete(file.FullName);
                }

                // Delete older sub directories
                var foldersToDelete = outputPathInfo.EnumerateDirectories()
                                                    .Where(f => f.LastWriteTime < DateTime.Now.AddDays(-2));

                foreach (var folder in foldersToDelete)
                {
                    Directory.Delete(folder.FullName, true);
                }
            }
            else
            {
                Directory.CreateDirectory(outputPath);
            }
        }
    }
}

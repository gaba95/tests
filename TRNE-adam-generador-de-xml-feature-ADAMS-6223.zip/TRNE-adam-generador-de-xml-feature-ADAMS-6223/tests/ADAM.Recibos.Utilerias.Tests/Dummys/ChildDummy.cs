﻿namespace ADAM.Recibos.Utilerias.Tests.Dummys
{
    internal class ChildDummy : BaseDummy
    {
    }
}

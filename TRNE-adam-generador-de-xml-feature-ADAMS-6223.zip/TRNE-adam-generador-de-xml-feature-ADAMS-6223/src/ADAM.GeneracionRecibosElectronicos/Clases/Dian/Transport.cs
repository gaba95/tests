﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("transporte", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Transport
    {
        [JsonProperty("auxilioTransporte")]
        public decimal AuxilioTransporte { get; set; }

        [JsonProperty("viaticoManuAlojS")]
        public decimal ViaticoManuAlojS { get; set; }

        [JsonProperty("viaticoManuAlojNS")]
        public decimal ViaticoManuAlojNS { get; set; }
    }
}

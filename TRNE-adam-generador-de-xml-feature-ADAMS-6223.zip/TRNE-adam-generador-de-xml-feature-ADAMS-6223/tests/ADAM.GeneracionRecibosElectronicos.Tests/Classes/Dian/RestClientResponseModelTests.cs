using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class RestClientResponseModelTests
    {
        #region Notificaciones

        [TestMethod]
        public void Notificaciones_Properties_SetAndGet()
        {
            var notif = new Notificaciones
            {
                categoriaMensaje = "Info",
                codigoMensaje = "0",
                mensaje = "Documento procesado correctamente",
                documentoID = "DOC001",
                estadoAccion = "Exitoso",
                tipoDocumento = "NE",
                numeroDocumento = "NE0001",
                resultadoValidacion = new List<ResultadoValidacion>
                {
                    new ResultadoValidacion { documentoID = "DOC001", errorCode = "", errorMessage = "" }
                }
            };

            Assert.AreEqual("Info", notif.categoriaMensaje);
            Assert.AreEqual("0", notif.codigoMensaje);
            Assert.AreEqual("Documento procesado correctamente", notif.mensaje);
            Assert.AreEqual("DOC001", notif.documentoID);
            Assert.AreEqual("Exitoso", notif.estadoAccion);
            Assert.AreEqual(1, notif.resultadoValidacion.Count);
        }

        [TestMethod]
        public void Notificaciones_Serialization_RoundTrip()
        {
            var notif = new Notificaciones
            {
                categoriaMensaje = "Error",
                codigoMensaje = "100",
                mensaje = "Error de validación"
            };

            var json = JsonConvert.SerializeObject(notif);
            var deserialized = JsonConvert.DeserializeObject<Notificaciones>(json);

            Assert.AreEqual("Error", deserialized!.categoriaMensaje);
            Assert.AreEqual("100", deserialized.codigoMensaje);
            Assert.AreEqual("Error de validación", deserialized.mensaje);
        }

        #endregion

        #region ResultadoValidacion

        [TestMethod]
        public void ResultadoValidacion_Properties_SetAndGet()
        {
            var rv = new ResultadoValidacion
            {
                documentoID = "DOC001",
                errorCode = "ERR01",
                errorMessage = "Campo requerido",
                fechaInicioPeriodo = "2026-01-01",
                identificacion = "CC123456",
                numeroDocumento = "NE001",
                propertyName = "sueldo",
                tipoDocumento = "NE",
                trabajador = "T001"
            };

            Assert.AreEqual("DOC001", rv.documentoID);
            Assert.AreEqual("ERR01", rv.errorCode);
            Assert.AreEqual("Campo requerido", rv.errorMessage);
            Assert.AreEqual("2026-01-01", rv.fechaInicioPeriodo);
            Assert.AreEqual("CC123456", rv.identificacion);
            Assert.AreEqual("sueldo", rv.propertyName);
            Assert.AreEqual("T001", rv.trabajador);
        }

        #endregion

        #region AddGlobalPayrollResponse

        [TestMethod]
        public void AddGlobalPayrollResponse_Properties_SetAndGet()
        {
            var response = new AddGlobalPayrollResponse
            {
                message = "Success"
            };

            Assert.AreEqual("Success", response.message);
        }

        [TestMethod]
        public void AddGlobalPayrollResponse_ExtensionData_StoresExtraProperties()
        {
            var json = @"{""message"":""OK"",""extraField"":""extraValue""}";
            var response = JsonConvert.DeserializeObject<AddGlobalPayrollResponse>(json);

            Assert.IsNotNull(response);
            Assert.AreEqual("OK", response!.message);
            Assert.IsNotNull(response.errores);
            Assert.IsTrue(response.errores.ContainsKey("extraField"));
        }

        #endregion

        #region DianErrors

        [TestMethod]
        public void DianErrors_Properties_SetAndGet()
        {
            var error = new DianErrors
            {
                code = "DIAN001",
                description = "Error de formato XML"
            };

            Assert.AreEqual("DIAN001", error.code);
            Assert.AreEqual("Error de formato XML", error.description);
        }

        #endregion

        #region DocumentStateResponse

        [TestMethod]
        public void DocumentStateResponse_Properties_SetAndGet()
        {
            var response = new DocumentStateResponse
            {
                estadoDocumento = "Aprobado",
                fechaGeneracion = new DateTime(2026, 1, 15),
                cune = "CUNE12345",
                numeroDocumento = "NE001",
                dianErrors = new List<DianErrors>()
            };

            Assert.AreEqual("Aprobado", response.estadoDocumento);
            Assert.AreEqual(new DateTime(2026, 1, 15), response.fechaGeneracion);
            Assert.AreEqual("CUNE12345", response.cune);
            Assert.AreEqual("NE001", response.numeroDocumento);
            Assert.AreEqual(0, response.dianErrors.Count);
        }

        [TestMethod]
        public void DocumentStateResponse_WithErrors()
        {
            var response = new DocumentStateResponse
            {
                estadoDocumento = "Rechazado",
                dianErrors = new List<DianErrors>
                {
                    new DianErrors { code = "ERR1", description = "Error 1" },
                    new DianErrors { code = "ERR2", description = "Error 2" }
                }
            };

            Assert.AreEqual(2, response.dianErrors.Count);
            Assert.AreEqual("ERR1", response.dianErrors[0].code);
        }

        #endregion

        #region JsonDianFull

        [TestMethod]
        public void JsonDianFull_RespuestaDian_SetAndGet()
        {
            var jdf = new JsonDianFull
            {
                respuestaDian = new AddGlobalPayrollResponse { message = "Processed" }
            };

            Assert.IsNotNull(jdf.respuestaDian);
            Assert.AreEqual("Processed", jdf.respuestaDian.message);
        }

        #endregion
    }
}

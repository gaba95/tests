using Moq;
using System;
using System.Data;
using System.Reflection;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;
using Oracle.ManagedDataAccess.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoAdicional
{
    [TestClass]
    public class CatalogoAdicionalOracleTests
    {
        #region Constructor & Basic Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoAdicionalOracle(mockFactory.Object);

            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        [TestMethod]
        public void CheckDbConnection_ShouldReturnTrue_WhenConnectionIsAvailable()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            var service = new CatalogoAdicionalOracle(mockFactory.Object);
            var result = service.CheckDbConnection();

            Assert.IsTrue(result);
            mockFactory.Verify(f => f.CheckConnection(), Times.Once());
        }

        [TestMethod]
        public void CheckDbConnection_ShouldReturnFalse_WhenConnectionIsNotAvailable()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(false);

            var service = new CatalogoAdicionalOracle(mockFactory.Object);
            var result = service.CheckDbConnection();

            Assert.IsFalse(result);
        }

        #endregion

        #region Stub Methods (return fixed values)

        [TestMethod]
        public void ObtenCompaniasIdiomas_ShouldReturnEmptyString()
        {
            var service = CreateServiceWithMockDB();
            var result = service.obtenCompaniasIdiomas();
            Assert.AreEqual("", result);
        }

        [TestMethod]
        public void ExisteTablaConfiguracion_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            var result = service.existeTablaConfiguracion();
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void DeletePayslipsData_ShouldReturnFalse()
        {
            var service = CreateServiceWithMockDB();
            var result = service.DeletePayslipsData("COMP", "TN", "CN", 2026, 1, "EMP001");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ObtenConfiguracionCompania_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            var result = service.obtenConfiguracionCompania("COMP");
            Assert.IsNull(result);
        }

        #endregion

        #region NotImplementedException Methods

        [TestMethod]
        public void GuardaConfiguracionCompania_ShouldThrowNotImplementedException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() =>
                service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "desc", "alpha", 1.5m, 10));
        }

        [TestMethod]
        public void ReadCSD_ShouldThrowNotImplementedException()
        {
            ICatalogoAdicional service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.ReadCSD());
        }

        [TestMethod]
        public void DeleteCSD_ShouldThrowNotImplementedException()
        {
            ICatalogoAdicional service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.DeleteCSD("CLIENT"));
        }

        [TestMethod]
        public void CreateReplaceCSD_ShouldThrowNotImplementedException()
        {
            ICatalogoAdicional service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() =>
                service.CreateReplaceCSD(new byte[] { 0x01 }, new byte[] { 0x02 }, "CLIENT", "pass123"));
        }

        [TestMethod]
        public void ObtenParametrosCompania_ShouldThrowNotImplementedException()
        {
            ICatalogoAdicional service = CreateServiceWithMockDB();
            Assert.Throws<NotImplementedException>(() => service.obtenParametrosCompania("COMP"));
        }

        #endregion

        #region Structure / Reflection Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoAdicional()
        {
            Assert.IsTrue(typeof(ICatalogoAdicional).IsAssignableFrom(typeof(CatalogoAdicionalOracle)));
        }

        [DataTestMethod]
        [DataRow("obtenDatasetTrabajadoresRecibo")]
        [DataRow("obtenCompaniasIdiomas")]
        [DataRow("obtenDatasetCompanias")]
        [DataRow("obtenDatasetClasesNomina")]
        [DataRow("obtenDatasetTiposNomina")]
        [DataRow("obtenBasesDisponibles")]
        [DataRow("obtenListaPeriodosMes")]
        [DataRow("obtenDatasetTiposPercepcionDeduccion")]
        [DataRow("obtenDatasetDescripcionTipos")]
        [DataRow("obtenDatasetRelacionConceptos")]
        [DataRow("obtenDatasetConceptosRelacionar")]
        [DataRow("AltaRelacionConcepto")]
        [DataRow("BajaRelacionConcepto")]
        [DataRow("obtenDatasetTrabajadoresRegimen")]
        [DataRow("obtenDatasetRegimen")]
        [DataRow("AltaRelacionRegimen")]
        [DataRow("obtenDatasetFormaPago")]
        [DataRow("existeTablaConfiguracion")]
        [DataRow("DeletePayslipsData")]
        [DataRow("obtenConfiguracionCompania")]
        [DataRow("GuardaConfiguracionCompania")]
        public void ShouldContainMethod(string methodName)
        {
            var method = typeof(CatalogoAdicionalOracle).GetMethod(methodName,
                BindingFlags.Public | BindingFlags.Instance);
            Assert.IsNotNull(method, $"Method {methodName} should exist");
        }

        #endregion

        #region InvalidCastException Tests (mock IDbConnection, not OracleConnection)

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica));
        }

        [TestMethod]
        public void ObtenDatasetCompanias_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetCompanias("es-MX"));
        }

        [TestMethod]
        public void ObtenDatasetClasesNomina_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetClasesNomina("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetTiposNomina_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTiposNomina("COMP"));
        }

        [TestMethod]
        public void ObtenBasesDisponibles_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenBasesDisponibles());
        }

        [TestMethod]
        public void ObtenListaPeriodosMes_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenListaPeriodosMes("COMP", "TN", 2026, 6));
        }

        [TestMethod]
        public void ObtenDatasetTiposPercepcionDeduccion_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTiposPercepcionDeduccion(1));
        }

        [TestMethod]
        public void ObtenDatasetDescripcionTipos_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetDescripcionTipos());
        }

        [TestMethod]
        public void ObtenDatasetRelacionConceptos_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetRelacionConceptos(1, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Deducciones_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetConceptosRelacionar(2, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Incapacidad_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetConceptosRelacionar(4, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Default_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetConceptosRelacionar(1, "001"));
        }

        [TestMethod]
        public void AltaRelacionConcepto_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.AltaRelacionConcepto(1, "001", 100));
        }

        [TestMethod]
        public void BajaRelacionConcepto_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.BajaRelacionConcepto(1, "001", 100));
        }

        [TestMethod]
        public void ObtenDatasetTrabajadoresRegimen_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTrabajadoresRegimen("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetRegimen_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetRegimen());
        }

        [TestMethod]
        public void AltaRelacionRegimen_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.AltaRelacionRegimen("COMP", "TRAB001", "02"));
        }

        [TestMethod]
        public void ObtenDatasetFormaPago_ShouldThrowInvalidCastException_WhenNotOracleConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetFormaPago());
        }

        #endregion

        #region RealOracleConnection Tests

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica));
        }

        [TestMethod]
        public void ObtenDatasetCompanias_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetCompanias("es-MX"));
        }

        [TestMethod]
        public void ObtenDatasetClasesNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetClasesNomina("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetTiposNomina_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetTiposNomina("COMP"));
        }

        [TestMethod]
        public void ObtenBasesDisponibles_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenBasesDisponibles());
        }

        [TestMethod]
        public void ObtenListaPeriodosMes_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() =>
                service.obtenListaPeriodosMes("COMP", "TN", 2026, 6));
        }

        [TestMethod]
        public void ObtenDatasetTiposPercepcionDeduccion_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetTiposPercepcionDeduccion(1));
        }

        [TestMethod]
        public void ObtenDatasetDescripcionTipos_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetDescripcionTipos());
        }

        [TestMethod]
        public void ObtenDatasetRelacionConceptos_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetRelacionConceptos(1, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Deducciones_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetConceptosRelacionar(2, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Incapacidad_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetConceptosRelacionar(4, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Default_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetConceptosRelacionar(1, "001"));
        }

        [TestMethod]
        public void AltaRelacionConcepto_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.AltaRelacionConcepto(1, "001", 100));
        }

        [TestMethod]
        public void BajaRelacionConcepto_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.BajaRelacionConcepto(1, "001", 100));
        }

        [TestMethod]
        public void ObtenDatasetTrabajadoresRegimen_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetTrabajadoresRegimen("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetRegimen_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetRegimen());
        }

        [TestMethod]
        public void AltaRelacionRegimen_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.AltaRelacionRegimen("COMP", "TRAB001", "02"));
        }

        [TestMethod]
        public void ObtenDatasetFormaPago_RealOracleConnection_ShouldThrowOracleException()
        {
            var service = CreateServiceWithRealOracleConnection();
            Assert.Throws<OracleException>(() => service.obtenDatasetFormaPago());
        }

        #endregion

        #region Helpers

        private CatalogoAdicionalOracle CreateServiceWithRealOracleConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new OracleConnection("Data Source=localhost/FAKE;User Id=test;Password=test;Connection Timeout=1"));

            return new CatalogoAdicionalOracle(mockFactory.Object);
        }

        private CatalogoAdicionalOracle CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            return new CatalogoAdicionalOracle(mockFactory.Object);
        }

        private Nomina CreateTestNomina()
        {
            return new Nomina("COMP", "TRAB000001", "TN", "CN", 2026, 1, ManejoNomina.periodica, 1, "CF", "01");
        }

        #endregion
    }
}

namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmCargaConceptosDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCargaConceptosDIAN));
            this.FileDialog = new System.Windows.Forms.OpenFileDialog();
            this.cmdBuscarArchivoCer = new System.Windows.Forms.Button();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdCargar = new System.Windows.Forms.Button();
            this.GroupBox_Archivo = new System.Windows.Forms.GroupBox();
            this.GroupBox_Columnas = new System.Windows.Forms.GroupBox();
            this.chkColumnaConcepto = new System.Windows.Forms.CheckBox();
            this.chkColumnaIdCampo = new System.Windows.Forms.CheckBox();
            this.chkColumnaSeccion = new System.Windows.Forms.CheckBox();
            this.chkColumnaTipoConcepto = new System.Windows.Forms.CheckBox();
            this.GroupBox_Archivo.SuspendLayout();
            this.GroupBox_Columnas.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdBuscarArchivoCer
            // 
            this.cmdBuscarArchivoCer.Location = new System.Drawing.Point(442, 41);
            this.cmdBuscarArchivoCer.Name = "cmdBuscarArchivoCer";
            this.cmdBuscarArchivoCer.Size = new System.Drawing.Size(30, 23);
            this.cmdBuscarArchivoCer.TabIndex = 2;
            this.cmdBuscarArchivoCer.Text = "...";
            this.cmdBuscarArchivoCer.UseVisualStyleBackColor = true;
            this.cmdBuscarArchivoCer.Click += new System.EventHandler(this.cmdBuscarArchivo_Click);
            // 
            // txtRuta
            // 
            this.txtRuta.Location = new System.Drawing.Point(29, 42);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.ReadOnly = true;
            this.txtRuta.Size = new System.Drawing.Size(389, 21);
            this.txtRuta.TabIndex = 3;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(273, 279);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 15;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // cmdCargar
            // 
            this.cmdCargar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCargar.Location = new System.Drawing.Point(143, 279);
            this.cmdCargar.Name = "cmdCargar";
            this.cmdCargar.Size = new System.Drawing.Size(110, 50);
            this.cmdCargar.TabIndex = 14;
            this.cmdCargar.Text = "&Cargar";
            this.cmdCargar.UseVisualStyleBackColor = true;
            this.cmdCargar.Click += new System.EventHandler(this.cmdCargar_Click);
            // 
            // GroupBox_Archivo
            // 
            this.GroupBox_Archivo.Controls.Add(this.txtRuta);
            this.GroupBox_Archivo.Controls.Add(this.cmdBuscarArchivoCer);
            this.GroupBox_Archivo.Location = new System.Drawing.Point(12, 12);
            this.GroupBox_Archivo.Name = "GroupBox_Archivo";
            this.GroupBox_Archivo.Size = new System.Drawing.Size(502, 100);
            this.GroupBox_Archivo.TabIndex = 16;
            this.GroupBox_Archivo.TabStop = false;
            this.GroupBox_Archivo.Text = "Archivo Origen";
            // 
            // GroupBox_Columnas
            // 
            this.GroupBox_Columnas.Controls.Add(this.chkColumnaConcepto);
            this.GroupBox_Columnas.Controls.Add(this.chkColumnaIdCampo);
            this.GroupBox_Columnas.Controls.Add(this.chkColumnaSeccion);
            this.GroupBox_Columnas.Controls.Add(this.chkColumnaTipoConcepto);
            this.GroupBox_Columnas.Enabled = false;
            this.GroupBox_Columnas.Location = new System.Drawing.Point(12, 118);
            this.GroupBox_Columnas.Name = "GroupBox_Columnas";
            this.GroupBox_Columnas.Size = new System.Drawing.Size(502, 151);
            this.GroupBox_Columnas.TabIndex = 17;
            this.GroupBox_Columnas.TabStop = false;
            this.GroupBox_Columnas.Text = "Columnas del Archivo";
            // 
            // chkColumnaConcepto
            // 
            this.chkColumnaConcepto.AutoSize = true;
            this.chkColumnaConcepto.Checked = true;
            this.chkColumnaConcepto.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnaConcepto.Enabled = false;
            this.chkColumnaConcepto.Location = new System.Drawing.Point(15, 113);
            this.chkColumnaConcepto.Name = "chkColumnaConcepto";
            this.chkColumnaConcepto.Size = new System.Drawing.Size(177, 22);
            this.chkColumnaConcepto.TabIndex = 3;
            this.chkColumnaConcepto.Text = "Concepto de Nómina ADAM";
            this.chkColumnaConcepto.UseVisualStyleBackColor = true;
            // 
            // chkColumnaIdCampo
            // 
            this.chkColumnaIdCampo.AutoSize = true;
            this.chkColumnaIdCampo.Checked = true;
            this.chkColumnaIdCampo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnaIdCampo.Enabled = false;
            this.chkColumnaIdCampo.Location = new System.Drawing.Point(15, 85);
            this.chkColumnaIdCampo.Name = "chkColumnaIdCampo";
            this.chkColumnaIdCampo.Size = new System.Drawing.Size(186, 22);
            this.chkColumnaIdCampo.TabIndex = 2;
            this.chkColumnaIdCampo.Text = "Identificador del Campo XML";
            this.chkColumnaIdCampo.UseVisualStyleBackColor = true;
            // 
            // chkColumnaSeccion
            // 
            this.chkColumnaSeccion.AutoSize = true;
            this.chkColumnaSeccion.Checked = true;
            this.chkColumnaSeccion.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnaSeccion.Enabled = false;
            this.chkColumnaSeccion.Location = new System.Drawing.Point(15, 57);
            this.chkColumnaSeccion.Name = "chkColumnaSeccion";
            this.chkColumnaSeccion.Size = new System.Drawing.Size(71, 22);
            this.chkColumnaSeccion.TabIndex = 1;
            this.chkColumnaSeccion.Text = "Sección";
            this.chkColumnaSeccion.UseVisualStyleBackColor = true;
            // 
            // chkColumnaTipoConcepto
            // 
            this.chkColumnaTipoConcepto.AutoSize = true;
            this.chkColumnaTipoConcepto.Checked = true;
            this.chkColumnaTipoConcepto.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnaTipoConcepto.Enabled = false;
            this.chkColumnaTipoConcepto.Location = new System.Drawing.Point(15, 29);
            this.chkColumnaTipoConcepto.Name = "chkColumnaTipoConcepto";
            this.chkColumnaTipoConcepto.Size = new System.Drawing.Size(127, 22);
            this.chkColumnaTipoConcepto.TabIndex = 0;
            this.chkColumnaTipoConcepto.Text = "Tipo de Concepto";
            this.chkColumnaTipoConcepto.UseVisualStyleBackColor = true;
            // 
            // FrmCargaConceptosDIAN
            // 
            this.AcceptButton = this.cmdCargar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(526, 341);
            this.Controls.Add(this.GroupBox_Columnas);
            this.Controls.Add(this.GroupBox_Archivo);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdCargar);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmCargaConceptosDIAN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carga de Conceptos";
            this.GroupBox_Archivo.ResumeLayout(false);
            this.GroupBox_Archivo.PerformLayout();
            this.GroupBox_Columnas.ResumeLayout(false);
            this.GroupBox_Columnas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog FileDialog;
        private System.Windows.Forms.Button cmdBuscarArchivoCer;
        private System.Windows.Forms.TextBox txtRuta;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Button cmdCargar;
        private System.Windows.Forms.GroupBox GroupBox_Archivo;
        private System.Windows.Forms.GroupBox GroupBox_Columnas;
        private System.Windows.Forms.CheckBox chkColumnaSeccion;
        private System.Windows.Forms.CheckBox chkColumnaTipoConcepto;
        private System.Windows.Forms.CheckBox chkColumnaConcepto;
        private System.Windows.Forms.CheckBox chkColumnaIdCampo;
    }
}
﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Windows.Forms;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmCargaConceptosDIAN : Form
    {
        #region Properties

        private const string ColConcepto = "concepto";

        private ICatalogoDian _catalogosDIAN;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string tipoConcepto { get; set; } = string.Empty;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string idCampo { get; set; } = string.Empty;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; } = string.Empty;

        #endregion

        #region Methods

        public FrmCargaConceptosDIAN()
        {
            _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            InitializeComponent();
        }

        private void cmdBuscarArchivo_Click(object sender, EventArgs e)
        {
            // Get File Path Name
            FileDialog.Filter = "Archivo txt|*.txt|Archivo csv|*.csv";
            FileDialog.ShowDialog();
            txtRuta.Text = FileDialog.FileName;

            // Enable Columns Group Box
            GroupBox_Columnas.Enabled = true;
        }

        private void cmdCargar_Click(object sender, EventArgs e)
        {
            LeerArchivo();
        }

        private void LeerArchivo()
        {
            int nPos = 0;
            int nRows = 0;
            int nErrors = 0;
            int nConcept = 0;
            bool bError = false;
            bool bErrorGral = false;

            char delimiter = '|';
            var fieldId = string.Empty;
            string errorMsg;
            string[] arrData;

            try
            {
                DataSet dsData = new DataSet();
                System.IO.StreamReader srFileStream;
                System.IO.StreamWriter srErrorsFileSteam;

                // Set DataSet Tables
                dsData.Tables.Add();
                dsData.Tables[0].Columns.AddRange(new DataColumn[] { new DataColumn("id_campo", typeof(System.String)), new DataColumn(ColConcepto, typeof(System.String)) });

                var fileName = FileDialog.FileName;
                var errorsFile = FileDialog.FileName;

                // Set Records Demiliter & Errors File Name
                switch (Enum.Parse<FileExtension>(Path.GetExtension(fileName).Replace(".", "")))
                {
                    case FileExtension.txt:
                        {
                            delimiter = '|';
                            errorsFile = errorsFile.Replace("." + FileExtension.txt.ToString(), "_Errores." + FileExtension.txt.ToString());
                            break;
                        }
                    case FileExtension.csv:
                        {
                            delimiter = ',';
                            errorsFile = errorsFile.Replace("." + FileExtension.csv.ToString(), "_Errores." + FileExtension.csv.ToString());
                            break;
                        }
                }

                // Valid Output File
                if (System.IO.File.Exists(errorsFile))
                    System.IO.File.Delete(errorsFile);

                // Set File Stream Vars
                srFileStream = new System.IO.StreamReader(fileName, System.Text.Encoding.GetEncoding(1252));
                srErrorsFileSteam = new System.IO.StreamWriter(errorsFile, true, System.Text.Encoding.GetEncoding(1252));

                while (srFileStream.Peek() != -1)
                {
                    nRows++;
                    bError = false;

                    // Read Line
                    string fileLine = srFileStream.ReadLine();
                    arrData = fileLine.Split(delimiter);

                    // Validate Records
                    if (arrData == null || (arrData.Length == 1 && arrData[0] == string.Empty))
                    {
                        bError = true;
                        errorMsg = $"Linea {nRows} : No se encontraron datos para procesar";
                        srErrorsFileSteam.WriteLine(errorMsg);
                    }

                    // Validate Concepto Type Column
                    if (chkColumnaTipoConcepto.Checked)
                    {
                        // Set Concept Type Var
                        tipoConcepto = arrData[nPos].ToString().Trim();

                        // Validate
                        if (tipoConcepto != "percepcion" && tipoConcepto != "deduccion")
                        {
                            bError = true;
                            errorMsg = $"Linea {nRows} : El tipo de concepto no existe";
                            srErrorsFileSteam.WriteLine(errorMsg);
                        }

                        nPos++;
                    }

                    // Validate Section Column
                    if (chkColumnaSeccion.Checked)
                    {
                        DataRow[] foundRows = null;

                        // Set Id Field Var
                        idCampo = arrData[nPos].ToString().Trim();
                        var dsTemp = _catalogosDIAN.dsListaSeccionesDIAN(ColConcepto, tipoConcepto);

                        try
                        {
                            // Search Data
                            foundRows = dsTemp.Tables[0].Select($"clave = '{arrData[nPos].ToString().Trim()}'");
                        }
                        catch
                        {
                            // Intentionally left empty: foundRows stays null and is handled below
                        }

                        if (foundRows == null || foundRows.Length == 0)
                        {
                            bError = true;
                            errorMsg = $"Linea {nRows} : La sección no existe";
                            srErrorsFileSteam.WriteLine(errorMsg);
                        }

                        nPos++;
                    }

                    // Validate Id Field Column
                    if (chkColumnaIdCampo.Checked)
                    {
                        DataRow[] foundRows = null;

                        // Get Data
                        var dsTemp = _catalogosDIAN.dsListaCamposDIAN(idCampo, ColConcepto, tipoConcepto);

                        try
                        {
                            foundRows = dsTemp.Tables[0].Select($"clave = '{arrData[nPos].ToString().Trim()}'");
                        }
                        catch
                        {
                            // Intentionally left empty: foundRows stays null and is handled below
                        }

                        // Validate
                        if (foundRows == null || foundRows.Length == 0)
                        {
                            bError = true;
                            errorMsg = $"Linea {nRows} : El Identificador de Campo no existe";
                            srErrorsFileSteam.WriteLine(errorMsg);
                        }
                        else
                        {
                            fieldId = arrData[nPos].ToString().Trim();
                        }

                        nPos++;
                    }

                    // Validate Concept Column
                    if (chkColumnaConcepto.Checked)
                    {
                        bool bExist = _catalogosDIAN.getDatasetConceptosADAM(tipoConcepto, arrData[nPos].ToString());

                        if (!bExist)
                        {
                            bError = true;
                            errorMsg = $"Linea {nRows} : El Concepto de Nómina no existe";
                            srErrorsFileSteam.WriteLine(errorMsg);
                        }
                        else
                        {
                            nConcept = System.Convert.ToInt32(arrData[nPos].ToString().Trim());
                        }
                    }

                    // Validate If the Concept Map Exists
                    try
                    {
                        DataRow[] foundRows = null;

                        var dsTemp = _catalogosDIAN.obtenDatasetRelacionConceptosDIAN(compania, fieldId);
                        foundRows = dsTemp.Tables[0].Select($"concepto_adam = {nConcept.ToString().Trim()}");

                        if (foundRows.Length > 0)
                        {
                            bError = true;
                            errorMsg = $"Linea {nRows} : El Concepto de Nómina ya se encuentra mapeado";
                            srErrorsFileSteam.WriteLine(errorMsg);
                        }
                    }
                    catch
                    {
                        // Intentionally left empty: duplicate check failure is non-critical
                    }

                    if (bError)
                    {
                        nErrors += 1;
                        bErrorGral = true;
                    }

                    if (!bError)
                    {
                        dsData.Tables[0].Rows.Add(new object[] { fieldId, nConcept });
                    }

                    nPos = 0;
                }

                srFileStream?.Close();

                srErrorsFileSteam?.Close();

                // Save Records to Database
                foreach (DataRow dr in dsData.Tables[0].Rows)
                {
                    _catalogosDIAN.altaRelacionDatoConceptoDIAN(compania, dr["id_campo"].ToString().Trim(), dr[ColConcepto].ToString().Trim());
                }

                if (bErrorGral)
                {
                    // Set Msg
                    errorMsg = $"Detalle del proceso de lectura {Environment.NewLine}" +
                               $"Registros correctos: {dsData.Tables[0].Rows.Count}{Environment.NewLine}" +
                               $"Registros incorrectos: {nErrors}{Environment.NewLine}" + 
                               $"Ruta archivo errores: {errorsFile}";
                    MessageBox.Show(errorMsg);
                }
                else
                {
                   if (File.Exists(errorsFile))
                       File.Delete(errorsFile);

                    this.Cursor = Cursors.Default;
                    MessageBox.Show("Los datos fueron cargados exitosamente.");
                }

                srFileStream?.Close();

                srErrorsFileSteam?.Close();

                this.Close();
            }
            catch (Exception ex)
            {
                // Show Exception Msg
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al cargar los datos: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        #endregion 
    }
}

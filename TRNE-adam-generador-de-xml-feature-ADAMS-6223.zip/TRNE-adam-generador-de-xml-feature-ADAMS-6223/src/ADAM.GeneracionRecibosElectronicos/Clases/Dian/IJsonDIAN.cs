﻿using System.Collections.Generic;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    public interface IJsonDIAN
    {
        Employer empleador { get; set; }
        GeneralInformation informacionGeneral { get; set; }
        Period periodo { get; set; }
        List<IEmployee> trabajador { get; set; }
        string WriteJsonRequest(string jsonPath, string company, string year, string month);
        IJsonDIAN JsonDianByEmployee(IEmployee employee);
    }
}
﻿using ADAM.GeneracionRecibosElectronicos.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Filter
{
    /// <summary>
    /// the class contains properties to save the values for a new filter to be applied to datagridview datasource by DefaultView.RowFilter function
    /// </summary>
    public class DgFilter : ICloneable
    {
        public int ColumnIndex { get; set; }

        public ConditionalOperator Condition { get; set; }

        public string FieldName { get; set; }

        public ComparationOperator Comparation { get; set; }

        public string Value { get; set; }

        public ColumnValueType ColValueType { get; set; }

        //list of the values in case an IN or NOT IN filter was applied
        public List<object> RawValue { get; set; }

        public DgFilter(int pColumnIndex, string pFieldName, ColumnValueType pColValueType)
        {
            ColumnIndex = pColumnIndex;
            FieldName = pFieldName;
            ColValueType = pColValueType;
            RawValue = new List<object>();
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}

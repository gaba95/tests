﻿namespace ADAM.Recibos.Utilerias.Tests.Dummys
{
    internal class DummyClass
    {
        private string PrivatePop => "secret";
        private string _privateField = "value";
    }
}

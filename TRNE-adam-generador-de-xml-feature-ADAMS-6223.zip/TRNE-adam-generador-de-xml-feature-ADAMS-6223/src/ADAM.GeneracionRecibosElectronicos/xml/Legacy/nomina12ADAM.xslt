﻿<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" >
	<xsl:output method="xml"/>
	<xsl:template match="/NewDataSet">
		<nomina>
			<ADAM 
				instancia = "{TablePrincipal[1]/Instancia}"
				Compania = "{TablePrincipal[1]/Compania}"
				TipoNomina = "{TablePrincipal[1]/TipoNomina}"
				ClaseNomina = "{TablePrincipal[1]/ClaseNomina}"
				Anio = "{TablePrincipal[1]/Anio}"
				Periodo = "{TablePrincipal[1]/Periodo}"
				correoEmpleado = "{TablePrincipal[1]/correoEmpleado}"
				netoPagar = "{TablePrincipal[1]/netoPagar}"
				netoPagarLetra = "{TablePrincipal[1]/netoPagarLetra}"
				netoAnterior = "{TablePrincipal[1]/netoAnterior}"
				sueldo = "{format-number(TablePrincipal[1]/Sueldo,'#0.00')}"
				folio="{TablePrincipal[1]/Compania}-{TablePrincipal[1]/NumEmpleado}-{TablePrincipal[1]/TipoNomina}{TablePrincipal[1]/Periodo}"
			/>
			
			<cfdi:Comprobante
				xmlns:cfdi="http://www.sat.gob.mx/cfd/3" 
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
				xsi:schemaLocation="http://www.sat.gob.mx/cfd/3 http://www.sat.gob.mx/sitio_internet/cfd/3/cfdv32.xsd" 
				version="{TablePrincipal[1]/VersionFactura}"
				serie=""
				folio=""
				fecha="{TablePrincipal[1]/Fecha}"
				tipoDeComprobante="{TablePrincipal[1]/tipoDeComprobante}" 
				formaDePago="Pago en una sola exhibicion"
				metodoDePago="NA"
				noCertificado="0"
				subTotal="{format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')}"
				motivoDescuento="Deducciones nomina"
				Moneda="MXN"
				tiposCambio="1"
				total="{format-number(TablePrincipal[1]/netoPagar,'#0.00')}"
				LugarExpedicion="{TablePrincipal[1]/LugarExpedicion}"
				certificado="" 
				sello="" 
			>

				<xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
					<xsl:attribute name="descuento"><xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/></xsl:attribute>
				</xsl:if>

				<cfdi:Emisor 
					nombre="{TablePrincipal[1]/emisorNombre}" 
					rfc="{TablePrincipal[1]/emisorRfc}"
				>
					<cfdi:RegimenFiscal Regimen="{TablePrincipal[1]/emisorRegimen}"/>
				</cfdi:Emisor>

				<cfdi:Receptor 
					rfc="{TablePrincipal[1]/receptorRfc}"
					nombre="{TablePrincipal[1]/receptorNombre}"> 
				</cfdi:Receptor>
				
				<cfdi:Conceptos>
					<cfdi:Concepto 
						importe="{format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')}"
						valorUnitario="{format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')}"
						descripcion="Pago de nómina"
						unidad="ACT" 
						cantidad="1"
					/>
				</cfdi:Conceptos>

				<cfdi:Impuestos/>

				<cfdi:Complemento>
					<nomina:Nomina
						xmlns:nomina="http://www.sat.gob.mx/nomina12"
						xsi:schemaLocation="http://www.sat.gob.mx/informacion_fiscal/factura_electronica/Documents/Complementoscfdi/nomina12.xsd"
						Version="{TablePrincipal[1]/Version}"
						TipoNomina="{TablePrincipal[1]/TipoNominaSat}"
						FechaPago="{TablePrincipal[1]/FechaPago}"
						FechaInicialPago="{TablePrincipal[1]/FechaInicialPago}" 
						FechaFinalPago="{TablePrincipal[1]/FechaFinalPago}"
						NumDiasPagados="{format-number(TablePrincipal[1]/NumDiasPagados,'#0.000')}"
					>
						<xsl:if test="TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
							<xsl:attribute name="TotalPercepciones"><xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro,'#0.00')"/></xsl:attribute>
						</xsl:if>
						<xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
							<xsl:attribute name="TotalDeducciones"><xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/></xsl:attribute>
						</xsl:if>
						<xsl:if test="TablePrincipal[1]/TotalOtrosPagos!=0">
							<xsl:attribute name="TotalOtrosPagos"><xsl:value-of select="format-number(TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/></xsl:attribute>
						</xsl:if>
						
						<xsl:choose>
							<xsl:when test="TablePrincipal[1]/longitudRegistroPatronal &lt;= 12">
								<xsl:if test="TablePrincipal[1]/TipoContrato='01' or TablePrincipal[1]/TipoContrato='02' or TablePrincipal[1]/TipoContrato='03' or TablePrincipal[1]/TipoContrato='04' or TablePrincipal[1]/TipoContrato='05' or TablePrincipal[1]/TipoContrato='06' or TablePrincipal[1]/TipoContrato='07' or TablePrincipal[1]/TipoContrato='08'">
									<xsl:element name="nomina:Emisor">
										<xsl:attribute name="RegistroPatronal"><xsl:value-of select="TablePrincipal[1]/RegistroPatronal"/></xsl:attribute>
									
										<xsl:if test="TablePrincipal[1]/EmpresaSNCF!=0">
											<xsl:element name="nomina:EntidadSNCF">
												<xsl:attribute name="OrigenRecurso"><xsl:value-of select="TablePrincipal[1]/OrigenRecurso"/></xsl:attribute>
												<xsl:attribute name="MontoRecursoPropio"><xsl:value-of select="TablePrincipal[1]/MontoRecursoPropio"/></xsl:attribute>
											</xsl:element>
										</xsl:if>							
									</xsl:element>
								</xsl:if>
							</xsl:when>
							<xsl:otherwise>
								<nomina:Emisor
									Curp="{TablePrincipal[1]/CURPEmisor}"
									RfcPatronOrigen="{TablePrincipal[1]/RFCPatronOrigen}"
								>
									<xsl:if test="TablePrincipal[1]/TipoContrato='01' or TablePrincipal[1]/TipoContrato='02' or TablePrincipal[1]/TipoContrato='03' or TablePrincipal[1]/TipoContrato='04' or TablePrincipal[1]/TipoContrato='05' or TablePrincipal[1]/TipoContrato='06' or TablePrincipal[1]/TipoContrato='07' or TablePrincipal[1]/TipoContrato='08'">
										<xsl:attribute name="RegistroPatronal"><xsl:value-of select="TablePrincipal[1]/RegistroPatronal"/></xsl:attribute>
									</xsl:if>

									<xsl:if test="TablePrincipal[1]/EmpresaSNCF!=0">
										<nomina:EntidadSNCF 
											OrigenRecurso="{TablePrincipal[1]/OrigenRecurso}"
											MontoRecursoPropio="{TablePrincipal[1]/MontoRecursoPropio}"
										/>
									</xsl:if>
								</nomina:Emisor>
							</xsl:otherwise>
						</xsl:choose>

						<xsl:element name="nomina:Receptor">
							<xsl:attribute name="Curp"><xsl:value-of select="TablePrincipal[1]/CURP"/></xsl:attribute>
							<!--No se muestran los siguientes campos para tipos de contrato mayor a 08-->							
							<xsl:if test="TablePrincipal[1]/TipoContrato='01' or TablePrincipal[1]/TipoContrato='02' or TablePrincipal[1]/TipoContrato='03' or TablePrincipal[1]/TipoContrato='04' or TablePrincipal[1]/TipoContrato='05' or TablePrincipal[1]/TipoContrato='06' or TablePrincipal[1]/TipoContrato='07' or TablePrincipal[1]/TipoContrato='08'">
								<xsl:attribute name="NumSeguridadSocial"><xsl:value-of select="TablePrincipal[1]/NumSeguridadSocial"/></xsl:attribute>
								<xsl:attribute name="FechaInicioRelLaboral"><xsl:value-of select="TablePrincipal[1]/FechaInicioRelLaboral"/></xsl:attribute>
								<xsl:attribute name="Antigüedad"><xsl:value-of select="TablePrincipal[1]/Antiguedad"/></xsl:attribute>
								<xsl:attribute name="RiesgoPuesto"><xsl:value-of select="TablePrincipal[1]/RiesgoPuesto"/></xsl:attribute>
								<xsl:attribute name="SalarioDiarioIntegrado"><xsl:value-of select="format-number(TablePrincipal[1]/SalarioDiarioIntegrado,'#0.00')"/></xsl:attribute>
							</xsl:if>		
							<xsl:attribute name="TipoContrato"><xsl:value-of select="TablePrincipal[1]/TipoContrato"/></xsl:attribute>
							<xsl:attribute name="Sindicalizado"><xsl:value-of select="TablePrincipal[1]/Sindicalizado"/></xsl:attribute>
							<xsl:attribute name="TipoJornada"><xsl:value-of select="TablePrincipal[1]/TipoJornada"/></xsl:attribute>

							<xsl:variable name="trabajador" select="TablePrincipal[1]/NumEmpleado"/>
							<xsl:choose>
								<xsl:when test="count(/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]])>0">
									<xsl:attribute name="TipoRegimen">10</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="TipoRegimen"><xsl:value-of select="TablePrincipal[1]/TipoRegimen"/></xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
							
							<xsl:attribute name="NumEmpleado"><xsl:value-of select="TablePrincipal[1]/NumEmpleado"/></xsl:attribute>
							<xsl:attribute name="Departamento"><xsl:value-of select="TablePrincipal[1]/Departamento"/></xsl:attribute>
							<xsl:attribute name="Puesto"><xsl:value-of select="TablePrincipal[1]/Puesto"/></xsl:attribute>
							
							<xsl:attribute name="PeriodicidadPago"><xsl:value-of select="TablePrincipal[1]/PeriodicidadPago"/></xsl:attribute>
							<xsl:if test="TablePrincipal[1]/Banco!=''">
								<xsl:attribute name="Banco"><xsl:value-of select="TablePrincipal[1]/Banco"/></xsl:attribute>
							</xsl:if>
							<xsl:if test="TablePrincipal[1]/CuentaBancaria!=''">
								<xsl:attribute name="CuentaBancaria"><xsl:value-of select="TablePrincipal[1]/CuentaBancaria"/></xsl:attribute>
							</xsl:if>
							<xsl:attribute name="SalarioBaseCotApor"><xsl:value-of select="format-number(TablePrincipal[1]/SalarioBaseCotApor,'#0.00')"/></xsl:attribute>
							
							<xsl:attribute name="ClaveEntFed"><xsl:value-of select="TablePrincipal[1]/ClaveEntFed"/></xsl:attribute>

							<xsl:if test="count(/NewDataSet/TableSubcontratacion)>0">
								<xsl:for-each select = "TableSubcontratacion">
									<nomina:SubContratacion>
										<xsl:attribute name="RfcLabora"><xsl:value-of select="RfcLabora" /></xsl:attribute>
										<xsl:attribute name="PorcentajeTiempo"><xsl:value-of select="PorcentajeTiempo" /></xsl:attribute>
									</nomina:SubContratacion>
								</xsl:for-each>
							</xsl:if>
							
						</xsl:element>

						<xsl:if test="TablePrincipal[1]/TotalSueldos!=0 or TablePrincipal[1]/TotalSeparacionIndemnizacion!=0 or TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
							<nomina:Percepciones>
								<xsl:attribute name="TotalExento"><xsl:value-of select="format-number(TablePrincipal[1]/TotalExento,'#0.00')"/></xsl:attribute>

								<xsl:attribute name="TotalGravado"><xsl:value-of select="format-number(TablePrincipal[1]/TotalGravado,'#0.00')"/></xsl:attribute>

								<xsl:if test="TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
									<xsl:attribute name="TotalJubilacionPensionRetiro"><xsl:value-of select="format-number(TablePrincipal[1]/TotalJubilacionPensionRetiro,'#0.00')"/></xsl:attribute>
								</xsl:if>

								<xsl:if test="TablePrincipal[1]/TotalSeparacionIndemnizacion!=0">
									<xsl:attribute name="TotalSeparacionIndemnizacion"><xsl:value-of select="format-number(TablePrincipal[1]/TotalSeparacionIndemnizacion,'#0.00')"/></xsl:attribute>
								</xsl:if>
								
								<xsl:if test="TablePrincipal[1]/TotalSueldos!=0">
									<xsl:attribute name="TotalSueldos"><xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos,'#0.00')"/></xsl:attribute>
								</xsl:if>
							
								<xsl:for-each select = "TablePrincipal[TipoTransaccion=1]">
									<nomina:Percepcion>
											<xsl:attribute name="TipoPercepcion"><xsl:value-of select="TipoSAT" /></xsl:attribute>
											<xsl:attribute name="Clave"><xsl:value-of select="Clave" /></xsl:attribute>
											<xsl:attribute name="Concepto"><xsl:value-of select="Concepto" /></xsl:attribute>
											<xsl:attribute name="ImporteGravado"><xsl:value-of select="format-number(ImporteGravado,'#0.00')" /></xsl:attribute>
											<xsl:attribute name="ImporteExento"><xsl:value-of select="format-number(ImporteExento,'#0.00')" /></xsl:attribute>
											<xsl:attribute name="Tiempo"><xsl:value-of select="format-number(tiempo,'#0.00')" /></xsl:attribute>
										<xsl:if test="TipoSAT='019'">
											<xsl:variable name="claveConcepto" select="Clave"/>
											<xsl:for-each select = "/NewDataSet/TableHorasExtra[Clave=$claveConcepto[1]]">
												<nomina:HorasExtra>
													<xsl:choose>
														<xsl:when test="Dias=0">
															<xsl:attribute name="Dias">1</xsl:attribute>
														</xsl:when>
														<xsl:otherwise>
															<xsl:attribute name="Dias"><xsl:value-of select="Dias"/></xsl:attribute>
														</xsl:otherwise>
													</xsl:choose>
													<xsl:attribute name="TipoHoras"><xsl:value-of select="TipoHoras" /></xsl:attribute>
													<xsl:choose>
														<xsl:when test="HorasExtra=0">
															<xsl:attribute name="HorasExtra">1</xsl:attribute>
														</xsl:when>
														<xsl:otherwise>
															<xsl:attribute name="HorasExtra"><xsl:value-of select="HorasExtra" /></xsl:attribute>
														</xsl:otherwise>
													</xsl:choose>
													<xsl:attribute name="ImportePagado"><xsl:value-of select="ImportePagado" /></xsl:attribute>
												</nomina:HorasExtra>
											</xsl:for-each>
										</xsl:if>
										<xsl:if test="TipoSAT='045'">
											<xsl:variable name="trabajador" select="NumEmpleado"/>
											<xsl:for-each select = "/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]]">
												<nomina:AccionesOTitulos>
													<xsl:attribute name="ValorMercado"><xsl:value-of select="format-number(ValorMercadoAcciones,'#0.00')" /></xsl:attribute>
													<xsl:attribute name="PrecioAlOtorgarse"><xsl:value-of select="format-number(PrecioEstTitulosVal,'#0.00')" /></xsl:attribute>
												</nomina:AccionesOTitulos>
											</xsl:for-each>
										</xsl:if>
									</nomina:Percepcion>
								</xsl:for-each>

								<!--Inicial las tablas adicionales de percepciones-->
								<!--Si hay datos para jubilacionPensionRetiro-->
								<xsl:if test="count(/NewDataSet/TableJubilacionPensionRetiro)>0">
									<!--Solo puede tener de un tipo JubilacionPensionRetiro 039(en una exhibicion) o 044(en parcialidades)-->
									<xsl:if test="/NewDataSet/TablePrincipal[TipoSAT='039']">
										<nomina:JubilacionPensionRetiro>
											<xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
												<xsl:attribute name="IngresoAcumulable"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoNoAcumulable"><xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="TotalUnaExhibicion"><xsl:value-of select="format-number(TotalUnaExhibicion,'#0.00')"/></xsl:attribute>
											</xsl:for-each>
										</nomina:JubilacionPensionRetiro>
									</xsl:if>
									<xsl:if test="/NewDataSet/TablePrincipal[TipoSAT='044']">
										<nomina:JubilacionPensionRetiro>
											<xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
												<xsl:attribute name="IngresoAcumulable"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoNoAcumulable"><xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="TotalParcialidad"><xsl:value-of select="format-number(TotalParcialidad,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="MontoDiario"><xsl:value-of select="format-number(MontoDiario,'#0.00')"/></xsl:attribute>
											</xsl:for-each>
										</nomina:JubilacionPensionRetiro>
									</xsl:if>
								</xsl:if>
								
								<!--SeparacionIndemnizacion 022(Prima por Antigüedad) 023(pagos separacion) 025(Indemnizaciones)-->
								<xsl:if test="count(/NewDataSet/TableSeparacionIndemnizacion)>0">
									<xsl:if test="/NewDataSet/TableSeparacionIndemnizacion/TotalPagado!=0">
										<nomina:SeparacionIndemnizacion>
											<xsl:for-each select = "/NewDataSet/TableSeparacionIndemnizacion">
												<xsl:attribute name="TotalPagado"><xsl:value-of select="format-number(TotalPagado,'#0.00')"/></xsl:attribute>
												
												<xsl:choose>
													<xsl:when test="number(/NewDataSet/TablePrincipal/AntiguedadAnios)>0">
														<xsl:attribute name="NumAñosServicio"><xsl:value-of select="/NewDataSet/TablePrincipal/AntiguedadAnios"/></xsl:attribute>
													</xsl:when>
													<xsl:otherwise>
														<xsl:attribute name="NumAñosServicio">0</xsl:attribute>
													</xsl:otherwise>
												</xsl:choose>
												
												<xsl:attribute name="UltimoSueldoMensOrd"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoAcumulable"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoNoAcumulable"><xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/></xsl:attribute>
											</xsl:for-each>
										</nomina:SeparacionIndemnizacion>
									</xsl:if>
								</xsl:if>
							</nomina:Percepciones>
						</xsl:if>
						
						<xsl:if test="count(TablePrincipal[TipoTransaccion=2])>0">
							<xsl:element name="nomina:Deducciones">
								<xsl:attribute name="TotalOtrasDeducciones"><xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones,'#0.00')"/></xsl:attribute>
								<xsl:if test="TablePrincipal[1]/TotalImpuestosRetenidos>0">
									<xsl:attribute name="TotalImpuestosRetenidos"><xsl:value-of select="format-number(TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/></xsl:attribute>
								</xsl:if>
								<xsl:for-each select = "TablePrincipal[TipoTransaccion=2]">
									<nomina:Deduccion
										>
											<xsl:attribute name="TipoDeduccion"><xsl:value-of select="TipoSAT"/></xsl:attribute>
											<xsl:attribute name="Clave"><xsl:value-of select="Clave" /></xsl:attribute>
											<xsl:attribute name="Concepto"><xsl:value-of select="Concepto"/></xsl:attribute>
											<xsl:attribute name="Importe"><xsl:value-of select="format-number(Importe,'#0.00')"/></xsl:attribute>
											<xsl:attribute name="Tiempo"><xsl:value-of select="format-number(tiempo,'#0.00')"/></xsl:attribute>
										</nomina:Deduccion>
								</xsl:for-each>
							</xsl:element>
						</xsl:if>
					
						<xsl:if test="count(/NewDataSet/TableOtrosPagos)>0">
							<nomina:OtrosPagos>
								<xsl:for-each select = "TableOtrosPagos">
									<nomina:OtroPago>
										<xsl:attribute name="TipoOtroPago"><xsl:value-of select="TipoOtroPago"/></xsl:attribute>
										<xsl:attribute name="Clave"><xsl:value-of select="Clave"/></xsl:attribute>
										<xsl:attribute name="Concepto"><xsl:value-of select="Concepto"/></xsl:attribute>
										<xsl:attribute name="Importe"><xsl:value-of select="format-number(Importe,'#0.00')"/></xsl:attribute>
										
										<xsl:if test="TipoOtroPago='002'">
											<nomina:SubsidioAlEmpleo
												SubsidioCausado="{SubsidioCausado}"
												>
											</nomina:SubsidioAlEmpleo>
										</xsl:if>
										
										<xsl:if test="TipoOtroPago='004'">
											<nomina:CompensacionSaldosAFavor
												SaldoAFavor="{format-number(SaldoAFavor,'#0.00')}"
												Año="{Anio}"
												RemanenteSalFav="{format-number(RemanenteSalFav,'#0.00')}"
												>
											</nomina:CompensacionSaldosAFavor>
										</xsl:if>
									</nomina:OtroPago>
								</xsl:for-each>
							</nomina:OtrosPagos>
						</xsl:if>
						
						<xsl:if test="count(/NewDataSet/TableIncapacidades)>0">
							<nomina:Incapacidades>
								<xsl:for-each select = "/NewDataSet/TableIncapacidades">
									<nomina:Incapacidad>
										<xsl:attribute name="DiasIncapacidad"><xsl:value-of select="DiasIncapacidad" /></xsl:attribute>
										<xsl:attribute name="TipoIncapacidad"><xsl:value-of select="TipoIncapacidad" /></xsl:attribute>
										<xsl:attribute name="ImporteMonetario"><xsl:value-of select="Descuento" /></xsl:attribute>
									</nomina:Incapacidad>
								</xsl:for-each>
							</nomina:Incapacidades>
						</xsl:if>
					</nomina:Nomina>
				</cfdi:Complemento>
			</cfdi:Comprobante>
		</nomina>	
	</xsl:template>
</xsl:stylesheet>
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ADAM.Recibos.Mexico.Tests.Helper
{
    public class TestCertificateHelper
    {
        public static X509Certificate2 CreatePublicOnlyCertificate()
        {
            // Crear un par de claves RSA temporal
            using var rsa = RSA.Create(2048);

            var request = new CertificateRequest(
                "CN=TestCert",
                rsa,
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pkcs1);

            // Extensión básica para que sea válido como certificado
            request.CertificateExtensions.Add(
                new X509BasicConstraintsExtension(false, false, 0, false));

            request.CertificateExtensions.Add(
                new X509SubjectKeyIdentifierExtension(request.PublicKey, false));

            // Crear un certificado autofirmado válido por 1 año
            var certWithPrivateKey = request.CreateSelfSigned(
                DateTimeOffset.UtcNow.AddDays(-1),
                DateTimeOffset.UtcNow.AddYears(1));

            // Exportar solo la parte pública
            byte[] publicOnly = certWithPrivateKey.Export(X509ContentType.Cert);

            // Importar nuevamente para obtener un X509Certificate2 sin clave privada
            return new X509Certificate2(publicOnly);
        }

    }
}

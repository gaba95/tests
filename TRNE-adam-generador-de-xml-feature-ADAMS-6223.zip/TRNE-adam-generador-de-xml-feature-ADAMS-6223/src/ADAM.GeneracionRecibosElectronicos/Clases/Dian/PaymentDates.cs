﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("fechasPago", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PaymentDates
    {
        public string fechaPago { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("heDs", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class HeDs
    {
        [JsonProperty("horaInicio")]
        public string HoraInicio { get; set; }

        [JsonProperty("horaFin")]
        public string HoraFin { get; set; }

        [JsonProperty("cantidad")]
        public int PagoCantidad { get; set; }

        [JsonProperty("porcentaje")]
        public decimal PagoPorcentaje { get; set; }

        [JsonProperty("pago")]
        public decimal Pago { get; set; }
    }
}

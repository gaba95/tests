﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("comisiones", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Commissions
    {
        [JsonProperty("descripcion")]
        public string ComisionDescripcion { get; set; } = "";

        [JsonProperty("comision")]
        public decimal Comision { get; set; }
    }
}

namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmMapeoCatalogosDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMapeoCatalogosDIAN));
            this.cmdCambiar = new System.Windows.Forms.Button();
            this.lblRegimen = new System.Windows.Forms.Label();
            this.gridDatosDIAN = new System.Windows.Forms.DataGridView();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.lblCampo = new System.Windows.Forms.Label();
            this.cboCampo = new System.Windows.Forms.ComboBox();
            this.lblCatalogoADAM = new System.Windows.Forms.Label();
            this.lblArbol = new System.Windows.Forms.Label();
            this.cboCompania = new System.Windows.Forms.ComboBox();
            this.lblCompania = new System.Windows.Forms.Label();
            this.gridDatosADAM = new System.Windows.Forms.DataGridView();
            this.lblDatosDIAN = new System.Windows.Forms.Label();
            this.pnlRelleno = new System.Windows.Forms.Panel();
            this.pnlSeparador = new System.Windows.Forms.Panel();
            this.lblSeccion = new System.Windows.Forms.Label();
            this.cboSeccion = new System.Windows.Forms.ComboBox();
            this.pnlArbol = new System.Windows.Forms.Panel();
            this.arbolCatalogos = new System.Windows.Forms.TreeView();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            this.cmdQuitar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosDIAN)).BeginInit();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosADAM)).BeginInit();
            this.pnlArbol.SuspendLayout();
            this.pnlHerramientas.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdCambiar
            // 
            this.cmdCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCambiar.Location = new System.Drawing.Point(0, 130);
            this.cmdCambiar.Name = "cmdCambiar";
            this.cmdCambiar.Size = new System.Drawing.Size(110, 50);
            this.cmdCambiar.TabIndex = 5;
            this.cmdCambiar.Text = "&Asignar Valor";
            this.cmdCambiar.UseVisualStyleBackColor = true;
            this.cmdCambiar.Click += new System.EventHandler(this.cmdCambiar_Click);
            // 
            // lblRegimen
            // 
            this.lblRegimen.AutoSize = true;
            this.lblRegimen.Location = new System.Drawing.Point(0, -40);
            this.lblRegimen.Name = "lblRegimen";
            this.lblRegimen.Size = new System.Drawing.Size(143, 18);
            this.lblRegimen.TabIndex = 0;
            this.lblRegimen.Text = "Regimen de Contatación";
            // 
            // gridDatosDIAN
            // 
            this.gridDatosDIAN.AllowUserToAddRows = false;
            this.gridDatosDIAN.AllowUserToDeleteRows = false;
            this.gridDatosDIAN.AllowUserToResizeRows = false;
            this.gridDatosDIAN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosDIAN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosDIAN.Dock = System.Windows.Forms.DockStyle.Left;
            this.gridDatosDIAN.Location = new System.Drawing.Point(10, 130);
            this.gridDatosDIAN.Name = "gridDatosDIAN";
            this.gridDatosDIAN.RowHeadersVisible = false;
            this.gridDatosDIAN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosDIAN.Size = new System.Drawing.Size(400, 483);
            this.gridDatosDIAN.TabIndex = 3;
            this.gridDatosDIAN.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridValores_CellDoubleClick);
            this.gridDatosDIAN.SelectionChanged += new System.EventHandler(this.gridDatosSAT_SelectionChanged);
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(0, 563);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 7;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(1325, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(367, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Mapeo de Catálogos ADAM - DIAN";
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.lblCampo);
            this.pnlPrincipal.Controls.Add(this.cboCampo);
            this.pnlPrincipal.Controls.Add(this.lblCatalogoADAM);
            this.pnlPrincipal.Controls.Add(this.lblArbol);
            this.pnlPrincipal.Controls.Add(this.cboCompania);
            this.pnlPrincipal.Controls.Add(this.lblCompania);
            this.pnlPrincipal.Controls.Add(this.gridDatosADAM);
            this.pnlPrincipal.Controls.Add(this.lblDatosDIAN);
            this.pnlPrincipal.Controls.Add(this.pnlRelleno);
            this.pnlPrincipal.Controls.Add(this.pnlSeparador);
            this.pnlPrincipal.Controls.Add(this.lblSeccion);
            this.pnlPrincipal.Controls.Add(this.cboSeccion);
            this.pnlPrincipal.Controls.Add(this.gridDatosDIAN);
            this.pnlPrincipal.Controls.Add(this.pnlArbol);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 50);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(10, 130, 10, 10);
            this.pnlPrincipal.Size = new System.Drawing.Size(1205, 623);
            this.pnlPrincipal.TabIndex = 16;
            // 
            // lblCampo
            // 
            this.lblCampo.AutoSize = true;
            this.lblCampo.Location = new System.Drawing.Point(13, 73);
            this.lblCampo.Name = "lblCampo";
            this.lblCampo.Size = new System.Drawing.Size(48, 18);
            this.lblCampo.TabIndex = 13;
            this.lblCampo.Text = "Campo:";
            // 
            // cboCampo
            // 
            this.cboCampo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboCampo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboCampo.DropDownWidth = 350;
            this.cboCampo.FormattingEnabled = true;
            this.cboCampo.Location = new System.Drawing.Point(160, 70);
            this.cboCampo.Name = "cboCampo";
            this.cboCampo.Size = new System.Drawing.Size(300, 26);
            this.cboCampo.TabIndex = 12;
            this.cboCampo.SelectedIndexChanged += new System.EventHandler(this.cboCampo_SelectedIndexChanged);
            // 
            // lblCatalogoADAM
            // 
            this.lblCatalogoADAM.AutoSize = true;
            this.lblCatalogoADAM.Location = new System.Drawing.Point(419, 106);
            this.lblCatalogoADAM.Name = "lblCatalogoADAM";
            this.lblCatalogoADAM.Size = new System.Drawing.Size(109, 18);
            this.lblCatalogoADAM.TabIndex = 10;
            this.lblCatalogoADAM.Text = "Equivalencia ADAM";
            // 
            // lblArbol
            // 
            this.lblArbol.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblArbol.Location = new System.Drawing.Point(895, 106);
            this.lblArbol.Name = "lblArbol";
            this.lblArbol.Size = new System.Drawing.Size(450, 18);
            this.lblArbol.TabIndex = 10;
            this.lblArbol.Text = "Vista de elementos mapeados";
            // 
            // cboCompania
            // 
            this.cboCompania.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompania.FormattingEnabled = true;
            this.cboCompania.Location = new System.Drawing.Point(160, 6);
            this.cboCompania.Name = "cboCompania";
            this.cboCompania.Size = new System.Drawing.Size(300, 26);
            this.cboCompania.TabIndex = 1;
            this.cboCompania.SelectedIndexChanged += new System.EventHandler(this.cboCompania_SelectedIndexChanged);
            // 
            // lblCompania
            // 
            this.lblCompania.AutoSize = true;
            this.lblCompania.Location = new System.Drawing.Point(13, 9);
            this.lblCompania.Name = "lblCompania";
            this.lblCompania.Size = new System.Drawing.Size(64, 18);
            this.lblCompania.TabIndex = 11;
            this.lblCompania.Text = "Compañia:";
            // 
            // gridDatosADAM
            // 
            this.gridDatosADAM.AllowUserToAddRows = false;
            this.gridDatosADAM.AllowUserToDeleteRows = false;
            this.gridDatosADAM.AllowUserToResizeRows = false;
            this.gridDatosADAM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosADAM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosADAM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDatosADAM.Location = new System.Drawing.Point(420, 130);
            this.gridDatosADAM.Name = "gridDatosADAM";
            this.gridDatosADAM.ReadOnly = true;
            this.gridDatosADAM.RowHeadersVisible = false;
            this.gridDatosADAM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosADAM.Size = new System.Drawing.Size(465, 483);
            this.gridDatosADAM.TabIndex = 4;
            // 
            // lblDatosDIAN
            // 
            this.lblDatosDIAN.AutoSize = true;
            this.lblDatosDIAN.Location = new System.Drawing.Point(10, 106);
            this.lblDatosDIAN.Name = "lblDatosDIAN";
            this.lblDatosDIAN.Size = new System.Drawing.Size(65, 18);
            this.lblDatosDIAN.TabIndex = 9;
            this.lblDatosDIAN.Text = "Tabla DIAN";
            // 
            // pnlRelleno
            // 
            this.pnlRelleno.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlRelleno.Location = new System.Drawing.Point(410, 130);
            this.pnlRelleno.Name = "pnlRelleno";
            this.pnlRelleno.Size = new System.Drawing.Size(10, 483);
            this.pnlRelleno.TabIndex = 8;
            // 
            // pnlSeparador
            // 
            this.pnlSeparador.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlSeparador.Location = new System.Drawing.Point(885, 130);
            this.pnlSeparador.Name = "pnlSeparador";
            this.pnlSeparador.Size = new System.Drawing.Size(5, 483);
            this.pnlSeparador.TabIndex = 8;
            // 
            // lblSeccion
            // 
            this.lblSeccion.AutoSize = true;
            this.lblSeccion.Location = new System.Drawing.Point(13, 41);
            this.lblSeccion.Name = "lblSeccion";
            this.lblSeccion.Size = new System.Drawing.Size(60, 18);
            this.lblSeccion.TabIndex = 6;
            this.lblSeccion.Text = "Sección: ";
            // 
            // cboSeccion
            // 
            this.cboSeccion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSeccion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboSeccion.DropDownWidth = 350;
            this.cboSeccion.FormattingEnabled = true;
            this.cboSeccion.Location = new System.Drawing.Point(160, 38);
            this.cboSeccion.Name = "cboSeccion";
            this.cboSeccion.Size = new System.Drawing.Size(300, 26);
            this.cboSeccion.TabIndex = 2;
            this.cboSeccion.SelectedIndexChanged += new System.EventHandler(this.cboSeccion_SelectedIndexChanged);
            // 
            // pnlArbol
            // 
            this.pnlArbol.Controls.Add(this.arbolCatalogos);
            this.pnlArbol.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlArbol.Location = new System.Drawing.Point(895, 130);
            this.pnlArbol.Name = "pnlArbol";
            this.pnlArbol.Padding = new System.Windows.Forms.Padding(5, 0, 0, 10);
            this.pnlArbol.Size = new System.Drawing.Size(300, 483);
            this.pnlArbol.TabIndex = 10;
            // 
            // arbolCatalogos
            // 
            this.arbolCatalogos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arbolCatalogos.Location = new System.Drawing.Point(5, 0);
            this.arbolCatalogos.Name = "arbolCatalogos";
            this.arbolCatalogos.Size = new System.Drawing.Size(295, 473);
            this.arbolCatalogos.TabIndex = 9;
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.cmdQuitar);
            this.pnlHerramientas.Controls.Add(this.cmdCerrar);
            this.pnlHerramientas.Controls.Add(this.cmdCambiar);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlHerramientas.Location = new System.Drawing.Point(1205, 50);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Padding = new System.Windows.Forms.Padding(0, 50, 0, 0);
            this.pnlHerramientas.Size = new System.Drawing.Size(120, 623);
            this.pnlHerramientas.TabIndex = 17;
            // 
            // cmdQuitar
            // 
            this.cmdQuitar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdQuitar.Location = new System.Drawing.Point(0, 182);
            this.cmdQuitar.Name = "cmdQuitar";
            this.cmdQuitar.Size = new System.Drawing.Size(110, 50);
            this.cmdQuitar.TabIndex = 6;
            this.cmdQuitar.Text = "&Quitar Relación";
            this.cmdQuitar.UseVisualStyleBackColor = true;
            this.cmdQuitar.Click += new System.EventHandler(this.cmdQuitar_Click);
            // 
            // FrmMapeoCatalogosDIAN
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(1325, 673);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.lblRegimen);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FrmMapeoCatalogosDIAN";
            this.ShowInTaskbar = false;
            this.Text = "Mapeo de Catálogos ADAM - DIAN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMapeoCatalogosDIAN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosDIAN)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosADAM)).EndInit();
            this.pnlArbol.ResumeLayout(false);
            this.pnlHerramientas.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCambiar;
        private System.Windows.Forms.Label lblRegimen;
        private System.Windows.Forms.DataGridView gridDatosDIAN;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.Button cmdQuitar;
        private System.Windows.Forms.ComboBox cboSeccion;
        private System.Windows.Forms.Label lblSeccion;
        private System.Windows.Forms.Panel pnlRelleno;
        private System.Windows.Forms.Panel pnlSeparador;
        private System.Windows.Forms.DataGridView gridDatosADAM;
        private System.Windows.Forms.Label lblDatosDIAN;
        private System.Windows.Forms.Label lblCatalogoADAM;
        private System.Windows.Forms.Label lblArbol;
        private System.Windows.Forms.Label lblCompania;
        private System.Windows.Forms.ComboBox cboCompania;
        private System.Windows.Forms.Label lblCampo;
        private System.Windows.Forms.ComboBox cboCampo;
        private System.Windows.Forms.Panel pnlArbol;
        private System.Windows.Forms.TreeView arbolCatalogos;
    }
}
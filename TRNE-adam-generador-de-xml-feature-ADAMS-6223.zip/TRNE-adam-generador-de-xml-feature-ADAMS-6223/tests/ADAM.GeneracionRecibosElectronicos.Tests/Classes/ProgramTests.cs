using System;
using System.IO;
using System.Reflection;
using ADAM.GeneracionRecibosElectronicos.Properties;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes
{
    [TestClass]
    public class ProgramTests
    {
        #region Helpers

        private static void InvokeSetOutputFolder()
        {
            var method = typeof(Program).GetMethod("SetOutputFolder",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.IsNotNull(method, "SetOutputFolder method not found");
            method.Invoke(null, null);
        }

        private static string GetAppPath()
        {
            return Path.GetDirectoryName(Environment.ProcessPath)!.Replace("file\\", "");
        }

        private static string GetOutputPath()
        {
            return Path.Combine(GetAppPath(), "output");
        }

        #endregion

        #region Structure / Reflection Tests

        [TestMethod]
        public void Class_ShouldBeStatic()
        {
            Assert.IsTrue(typeof(Program).IsAbstract && typeof(Program).IsSealed,
                "Program class should be static");
        }

        [TestMethod]
        public void Class_ShouldContainMainMethod()
        {
            var method = typeof(Program).GetMethod("Main",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.IsNotNull(method, "Main method should exist");
        }

        [TestMethod]
        public void Class_ShouldContainGetConnectionStringParamsMethod()
        {
            var method = typeof(Program).GetMethod("GetConnectionStringParams",
                BindingFlags.Public | BindingFlags.Static);
            Assert.IsNotNull(method, "GetConnectionStringParams should be public static");
        }

        [TestMethod]
        public void Class_ShouldContainSetOutputFolderMethod()
        {
            var method = typeof(Program).GetMethod("SetOutputFolder",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.IsNotNull(method, "SetOutputFolder should be private static");
        }

        [TestMethod]
        public void Main_ShouldHaveSTAThreadAttribute()
        {
            var method = typeof(Program).GetMethod("Main",
                BindingFlags.NonPublic | BindingFlags.Static);
            var attr = method?.GetCustomAttribute<STAThreadAttribute>();
            Assert.IsNotNull(attr, "Main should have [STAThread] attribute");
        }

        [TestMethod]
        public void Main_ShouldAcceptStringArrayParameter()
        {
            var method = typeof(Program).GetMethod("Main",
                BindingFlags.NonPublic | BindingFlags.Static);
            var parameters = method!.GetParameters();
            Assert.AreEqual(1, parameters.Length);
            Assert.AreEqual(typeof(string[]), parameters[0].ParameterType);
        }

        [TestMethod]
        public void GetConnectionStringParams_ShouldAcceptRefStringArrayParameter()
        {
            var method = typeof(Program).GetMethod("GetConnectionStringParams",
                BindingFlags.Public | BindingFlags.Static);
            var parameters = method!.GetParameters();
            Assert.AreEqual(1, parameters.Length);
            Assert.IsTrue(parameters[0].ParameterType.IsByRef, "Parameter should be ref");
        }

        #endregion

        #region GetConnectionStringParams Tests

        [TestMethod]
        public void GetConnectionStringParams_SingleArg_ShouldReturnTBMOnly()
        {
            // Arrange — single element, loop from i=1 never executes
            var args = new[] { "original" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            Assert.AreEqual(1, args.Length);
            Assert.AreEqual("TBM", args[0]);
        }

        [TestMethod]
        public void GetConnectionStringParams_TwoArgs_ShouldReturnTBMAndSecondArg()
        {
            // Arrange
            var args = new[] { "first", "second" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            Assert.AreEqual(2, args.Length);
            Assert.AreEqual("TBM", args[0]);
            Assert.AreEqual("second", args[1]);
        }

        [TestMethod]
        public void GetConnectionStringParams_MultipleArgs_ShouldReturnTBMFollowedByRemainingArgs()
        {
            // Arrange
            var args = new[] { "first", "a", "b", "c" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            Assert.AreEqual(4, args.Length);
            Assert.AreEqual("TBM", args[0]);
            Assert.AreEqual("a", args[1]);
            Assert.AreEqual("b", args[2]);
            Assert.AreEqual("c", args[3]);
        }

        [TestMethod]
        public void GetConnectionStringParams_EmptyArray_ShouldReturnSingleTBM()
        {
            // Arrange — no elements, loop doesn't execute
            var args = Array.Empty<string>();

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            Assert.AreEqual(1, args.Length);
            Assert.AreEqual("TBM", args[0]);
        }

        [TestMethod]
        public void GetConnectionStringParams_FirstArgAlwaysReplacedWithTBM()
        {
            // Arrange — regardless of first arg value
            var args = new[] { "anyValue", "param1" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            Assert.AreEqual("TBM", args[0]);
        }

        [TestMethod]
        public void GetConnectionStringParams_ArgWithSemicolon_ShouldBeSplitIntoSeparateElements()
        {
            // Arrange — semicolon inside an arg causes extra splitting
            var args = new[] { "first", "a;b" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert — "TBM;a;b" split by ; → ["TBM", "a", "b"]
            Assert.AreEqual(3, args.Length);
            Assert.AreEqual("TBM", args[0]);
            Assert.AreEqual("a", args[1]);
            Assert.AreEqual("b", args[2]);
        }

        [TestMethod]
        public void GetConnectionStringParams_EmptyStringArgs_ShouldPreserveEmptyElements()
        {
            // Arrange
            var args = new[] { "", "", "" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert — "TBM;;" split by ; → ["TBM", "", ""]
            Assert.AreEqual(3, args.Length);
            Assert.AreEqual("TBM", args[0]);
            Assert.AreEqual("", args[1]);
            Assert.AreEqual("", args[2]);
        }

        [TestMethod]
        public void GetConnectionStringParams_OriginalFirstArgIsIgnored()
        {
            // Arrange — first arg is never included in the output
            var args = new[] { "SHOULD_BE_DISCARDED", "keep" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            CollectionAssert.DoesNotContain(args, "SHOULD_BE_DISCARDED");
        }

        [TestMethod]
        public void GetConnectionStringParams_ArgsWithSpaces_ShouldPreserveSpaces()
        {
            // Arrange
            var args = new[] { "first", "hello world", "foo bar" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert
            Assert.AreEqual("hello world", args[1]);
            Assert.AreEqual("foo bar", args[2]);
        }

        [TestMethod]
        public void GetConnectionStringParams_SingleArgWithSemicolon_ShouldOnlyReturnTBM()
        {
            // Arrange — first arg has semicolons but loop starts at i=1 so it's ignored
            var args = new[] { "x;y;z" };

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert — plainConnection = "TBM", split = ["TBM"]
            Assert.AreEqual(1, args.Length);
            Assert.AreEqual("TBM", args[0]);
        }

        [TestMethod]
        public void GetConnectionStringParams_ShouldNotModifyOriginalReference_ButReplaceArray()
        {
            // Arrange
            var original = new[] { "first", "second" };
            var args = original;

            // Act
            Program.GetConnectionStringParams(ref args);

            // Assert — args now points to a new array
            Assert.AreNotSame(original, args, "ref parameter should point to a new array after split");
        }

        #endregion

        #region SetOutputFolder Tests

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldCreateOutputDirectory_WhenItDoesNotExist()
        {
            // Arrange
            var outputPath = GetOutputPath();
            if (Directory.Exists(outputPath))
                Directory.Delete(outputPath, true);

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsTrue(Directory.Exists(outputPath), "output directory should be created");
            }
            finally
            {
                // Cleanup — leave directory for other tests
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldSetApplicationPathInAppSettings()
        {
            // Arrange
            var expectedPath = GetAppPath();

            // Act
            InvokeSetOutputFolder();

            // Assert
            var storedValue = AppSettings.Default[ConfigParameters.applicationPath.ToString()];
            Assert.AreEqual(expectedPath, storedValue);
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldDeleteFilesOlderThanTwoDays()
        {
            // Arrange
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);
            var oldFile = Path.Combine(outputPath, "old_test_file.txt");
            File.WriteAllText(oldFile, "old content");
            File.SetLastWriteTime(oldFile, DateTime.Now.AddDays(-3));

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsFalse(File.Exists(oldFile), "File older than 2 days should be deleted");
            }
            finally
            {
                if (File.Exists(oldFile))
                    File.Delete(oldFile);
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldKeepRecentFiles()
        {
            // Arrange
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);
            var recentFile = Path.Combine(outputPath, "recent_test_file.txt");
            File.WriteAllText(recentFile, "recent content");
            File.SetLastWriteTime(recentFile, DateTime.Now);

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsTrue(File.Exists(recentFile), "Recent file should not be deleted");
            }
            finally
            {
                if (File.Exists(recentFile))
                    File.Delete(recentFile);
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldDeleteDirectoriesOlderThanTwoDays()
        {
            // Arrange
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);
            var oldDir = Path.Combine(outputPath, "old_test_dir");
            Directory.CreateDirectory(oldDir);
            Directory.SetLastWriteTime(oldDir, DateTime.Now.AddDays(-3));

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsFalse(Directory.Exists(oldDir), "Directory older than 2 days should be deleted");
            }
            finally
            {
                if (Directory.Exists(oldDir))
                    Directory.Delete(oldDir, true);
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldKeepRecentDirectories()
        {
            // Arrange
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);
            var recentDir = Path.Combine(outputPath, "recent_test_dir");
            Directory.CreateDirectory(recentDir);
            Directory.SetLastWriteTime(recentDir, DateTime.Now);

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsTrue(Directory.Exists(recentDir), "Recent directory should not be deleted");
            }
            finally
            {
                if (Directory.Exists(recentDir))
                    Directory.Delete(recentDir, true);
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldDeleteOldFilesButKeepRecentOnes()
        {
            // Arrange
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);

            var oldFile = Path.Combine(outputPath, "mixed_old.txt");
            var recentFile = Path.Combine(outputPath, "mixed_recent.txt");

            File.WriteAllText(oldFile, "old");
            File.SetLastWriteTime(oldFile, DateTime.Now.AddDays(-5));

            File.WriteAllText(recentFile, "recent");
            File.SetLastWriteTime(recentFile, DateTime.Now.AddHours(-1));

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsFalse(File.Exists(oldFile), "Old file should be deleted");
                Assert.IsTrue(File.Exists(recentFile), "Recent file should be kept");
            }
            finally
            {
                if (File.Exists(oldFile)) File.Delete(oldFile);
                if (File.Exists(recentFile)) File.Delete(recentFile);
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_FileSlightlyNewerThanTwoDays_ShouldNotBeDeleted()
        {
            // Arrange — file at 1.5 days old is clearly within the "keep" window
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);

            var nearBoundaryFile = Path.Combine(outputPath, "near_boundary_test_file.txt");
            File.WriteAllText(nearBoundaryFile, "near boundary");
            File.SetLastWriteTime(nearBoundaryFile, DateTime.Now.AddDays(-1.5));

            try
            {
                // Act
                InvokeSetOutputFolder();

                // Assert
                Assert.IsTrue(File.Exists(nearBoundaryFile), "File newer than 2 days should be kept");
            }
            finally
            {
                if (File.Exists(nearBoundaryFile)) File.Delete(nearBoundaryFile);
            }
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ShouldNotThrow_WhenOutputDirectoryAlreadyExists()
        {
            // Arrange
            var outputPath = GetOutputPath();
            Directory.CreateDirectory(outputPath);

            // Act & Assert — should not throw
            InvokeSetOutputFolder();

            Assert.IsTrue(Directory.Exists(outputPath));
        }

        [DoNotParallelize]
        [TestMethod]
        public void SetOutputFolder_ApplicationPath_ShouldNotContainFileBackslash()
        {
            // Arrange & Act
            InvokeSetOutputFolder();

            // Assert
            var storedValue = AppSettings.Default[ConfigParameters.applicationPath.ToString()] as string;
            Assert.IsNotNull(storedValue);
            Assert.IsFalse(storedValue.Contains("file\\"),
                "applicationPath should have 'file\\' removed");
        }

        #endregion
    }
}

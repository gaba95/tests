﻿<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" >
	<xsl:output method="xml"/>
	<xsl:template match="/NewDataSet">
	
			<Remision 
				xmlns="http://www.buzonfiscal.com/ns/xsd/bf/remision/52"
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
				xsi:schemaLocation="http://www.sat.gob.mx/cfd/3 http://www..sat.gob.mx/sitio_internet/cfd/3/cfdv32.xsd http://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/TimbreFiscalDigital/TimbreFiscalDigital.xsd http://www.sat.gob.mx/ventavehiculos http://www.sat.gob.mx/sitio_internet/cfd/ventavehiculos/ventavehiculos11.xsd http://www.buzonfiscal.com/ns/addenda/bf/2 http://www.buzonfiscal.com/schema/xsd/Addenda_BF_v20.xsd"
				version="5.2"
			>
			
			    <InfoBasica
					rfcEmisor="{Table[1]/emisorRfc}"
					rfcReceptor="{Table[1]/receptorRfc}"
					asignaFolio="false"
					folio=""
					serie=""
					refID="{Table[1]/Anio}{Table[1]/Periodo}{Table[1]/TipoNomina}{Table[1]/ClaseNomina}{Table[1]/NumEmpleado}"
				/> 
			
				<InfoAdicional 
					formaDePago="PAGO EN UNA SOLA EXHIBICION"
					subTotal="{Table[1]/TotalPercepciones}"
					total="{Table[1]/netoPagar}"
					metodoDePago="{Table[1]/metodoDePago}"
					tipoDeComprobante="egreso"
					lugarExpedicion="Monterrey, NL"
				/>
			 
				<Emisor>
					<RegimenFiscal Regimen="{Table[1]/emisorRegimen}"/>
				</Emisor>
				
				<DomicilioFiscal
					calle="{Table[1]/emisorCalle}"
					municipio="{Table[1]/emisorMunicipio}"
					estado="{Table[1]/emisorEstado}"
					pais="{Table[1]/emisorPais}"
					codigoPostal="{Table[1]/emisorCodigioPostal}"
					noExterior="{Table[1]/emisorNoExterior}"
					noInterior="{Table[1]/emisorNoInterior}"
				/>
			
				<Receptor nombre="{Table[1]/receptorNombre}"/>
				
				<DomicilioReceptor
				
					pais="{Table[1]/receptorPais}"
					calle="{Table[1]/receptorCalle}"
          noExterior="0"

					codigoPostal="{Table[1]/receptorCodigoPostal}"
					municipio="{Table[1]/receptorMunicipio}"
					estado="{Table[1]/receptorEstado}"

				/>
				
				<Conceptos>
					<Concepto
						cantidad="1" 
						unidad="Serv"
						descripcion="{Table[1]/conceptosDescripcion}"
						valorUnitario="{Table[1]/TotalPercepciones}"
						importe="{Table[1]/TotalPercepciones}"
					/>
				</Conceptos>

				<Impuestos>
					<Retenciones>
						<Retencion 
							impuesto="{Table[1]/conceptosImpuesto}"
							importe="{Table[1]/TotalRetenciones}"
						/>
					</Retenciones>

				</Impuestos>

				<Complemento>
					
					<nomina:Nomina 
						xmlns:ns2="http://www.sat.gob.mx/TimbreFiscalDigital" 
						xmlns="http://www.sat.gob.mx/cfd/3" 
						xmlns:nomina="http://www.sat.gob.mx/nomina" 

						Version="{Table[1]/Version}"
						RegistroPatronal="{Table[1]/RegistroPatronal}"
						NumEmpleado="{Table[1]/NumEmpleado}" 
						CURP="{Table[1]/CURP}" 
						TipoRegimen="{Table[1]/TipoRegimen}" 
						NumSeguridadSocial="{Table[1]/NumSeguridadSocial}" 
						FechaPago="{Table[1]/FechaPago}"
						FechaInicialPago="{Table[1]/FechaInicialPago}" 
						FechaFinalPago="{Table[1]/FechaFinalPago}"
						NumDiasPagados="{Table[1]/NumDiasPagados}"
						Departamento="{Table[1]/Departamento}" 
						CLABE="{Table[1]/CLABE}" 
						Banco="{Table[1]/Banco}" 
						FechaInicioRelLaboral="{Table[1]/FechaInicioRelLaboral}" 
						Antiguedad="{Table[1]/Antiguedad}" 
						Puesto="{Table[1]/Puesto}" 
						TipoContrato="{Table[1]/TipoContrato}" 
						TipoJornada="{Table[1]/TipoJornada}" 
						PeriodicidadPago="{Table[1]/PeriodicidadPago}" 
						SalarioBaseCotApor="{Table[1]/SalarioBaseCotApor}" 
						RiesgoPuesto="{Table[1]/RiesgoPuesto}" 
						SalarioDiarioIntegrado="{Table[1]/SalarioDiarioIntegrado}" 
					>
			  
						<nomina:Percepciones
							TotalGravado="{Table[1]/TotalGravado}"
							TotalExento="{Table[1]/TotalExento}"
							Total="{Table[1]/TotalPercepciones}"
						>
								
							<xsl:for-each select = "Table">
								<xsl:if test="TipoTransaccion=1">
									<nomina:Percepcion
									>
										<xsl:attribute name="TipoPercepcion"><xsl:value-of select="TipoSAT" /></xsl:attribute>
										<xsl:attribute name="Clave"><xsl:value-of select="Clave" /></xsl:attribute>
										<xsl:attribute name="Concepto"><xsl:value-of select="Concepto" /></xsl:attribute>										
										<xsl:attribute name="ImporteGravado"><xsl:value-of select="ImporteGravado" /></xsl:attribute>
										<xsl:attribute name="ImporteExento"><xsl:value-of select="ImporteExento" /></xsl:attribute>
									</nomina:Percepcion>
								</xsl:if>
							</xsl:for-each>
								
						</nomina:Percepciones>

            <xsl:if test="Table[1]/TotalDeducciones>0">
              							
						  <nomina:Deducciones
							  TotalGravado="{Table[1]/TotalGravadoDed}"
							  TotalExento="{Table[1]/TotalExentoDed}"
							  Total="{Table[1]/TotalDeducciones}"
						  > 
							
							  <xsl:for-each select = "Table">
								  <xsl:if test="TipoTransaccion=2">
									  <nomina:Deduccion
									  >
										  <xsl:attribute name="TipoDeduccion"><xsl:value-of select="TipoSAT" /></xsl:attribute>
										  <xsl:attribute name="Clave"><xsl:value-of select="Clave" /></xsl:attribute>
										  <xsl:attribute name="Concepto"><xsl:value-of select="Concepto" /></xsl:attribute>
										  <xsl:attribute name="ImporteGravado"><xsl:value-of select="ImporteGravado" /></xsl:attribute>
										  <xsl:attribute name="ImporteExento"><xsl:value-of select="ImporteExento" /></xsl:attribute>
									  </nomina:Deduccion>
								  </xsl:if>
							  </xsl:for-each>
							
						  </nomina:Deducciones>
              
            </xsl:if>

					</nomina:Nomina>
				
				</Complemento>
				
			</Remision>

  </xsl:template>
</xsl:stylesheet>
namespace ADAM.MIIA.Configurador.UI;

partial class frmConfiguracion
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConfiguracion));
        pnlSuperior = new Panel();
        lblTitulo = new Label();
        pnlPrincipal = new Panel();
        tabParametros = new TabControl();
        tabServicio = new TabPage();
        pnlEventosServicio = new Panel();
        lvEventos = new ListView();
        ColumnHeader1 = new ColumnHeader();
        ilIconos = new ImageList(components);
        Panel2 = new Panel();
        cmdEventViewer = new Button();
        lblNotaEventos = new Label();
        lblEventos = new Label();
        chkActualiza = new CheckBox();
        cmdActualizar = new Button();
        pnlServicio = new Panel();
        cmdDetener = new Button();
        lblEstadoServicio = new Label();
        cmdReinicia = new Button();
        tabGeneral = new TabPage();
        pnlGenerales = new Panel();
        Label6 = new Label();
        nupdTimeConnectionRetries = new NumericUpDown();
        lblTimeConnectionRetries = new Label();
        nupdConnectionRetries = new NumericUpDown();
        lblConnectionRetries = new Label();
        cmdRutaResumenEnExcel = new Button();
        Label5 = new Label();
        txtRutaResumenEnExcel = new TextBox();
        cboUsarJobsSQL = new ComboBox();
        lblUsarJobsSQL = new Label();
        cboArchivosEncriptados = new ComboBox();
        lblEncriptados = new Label();
        txtPasswordGPG = new TextBox();
        lblContrasenia = new Label();
        txtNombresArchivosInmediata = new TextBox();
        lblNombresArchivosInmediata = new Label();
        cboEjecucionInmediata = new ComboBox();
        lblEjecucionInmediata = new Label();
        txtPatron = new TextBox();
        lblPatron = new Label();
        cboArchivoControl = new ComboBox();
        cboVeces = new ComboBox();
        cmdRutaDestino = new Button();
        txtCarpetas = new TextBox();
        lblCarpetas = new Label();
        lblUsarControl = new Label();
        lblVecesEjecutar = new Label();
        cmdRutaOrigen = new Button();
        cmdAceptar = new Button();
        txtNombresArchivosCtrl = new TextBox();
        txtRutaDestino = new TextBox();
        txtRutaOrigen = new TextBox();
        lblNombresArchivosCtrl = new Label();
        lblRutaDestino = new Label();
        lblRutaOrigen = new Label();
        tabCorreo = new TabPage();
        pnlCorreo = new Panel();
        cmdGuardaCorreo = new Button();
        cmdProbar = new Button();
        txtTimeOut = new TextBox();
        lblTimeOut = new Label();
        txtPassword = new TextBox();
        label2 = new Label();
        txtUsuario = new TextBox();
        lblUsuario = new Label();
        cboSSL = new ComboBox();
        lblSsl = new Label();
        txtPuerto = new TextBox();
        lblPuerto = new Label();
        txtServidorCorreo = new TextBox();
        lblServidor = new Label();
        cboPrioridad = new ComboBox();
        lblPrioridad = new Label();
        cboHtml = new ComboBox();
        lblHtml = new Label();
        txtMensaje = new TextBox();
        lblMensaje = new Label();
        txtMail = new TextBox();
        lblCorreoDe = new Label();
        txtTitulo = new TextBox();
        lblTituloCorreo = new Label();
        txtNombre = new TextBox();
        lblDeCorreo = new Label();
        tabClientes = new TabPage();
        gridParametrosCliente = new DataGridView();
        pnlBotonesClientes = new Panel();
        cmdEliminar = new Button();
        cmdModificar = new Button();
        cmdAgregar = new Button();
        tabProcedures = new TabPage();
        gridProcedures = new DataGridView();
        pnlBotonesProcs = new Panel();
        cmdEliminarProc = new Button();
        cmdModificarProc = new Button();
        cmdAgregarProc = new Button();
        tabOnDemand = new TabPage();
        gridOnDemand = new DataGridView();
        Panel1 = new Panel();
        cmdEliminarOnDemand = new Button();
        cmdModificarOnDemand = new Button();
        cmdAgregarOnDemand = new Button();
        tabOrderProcess = new TabPage();
        gridOrderProcess = new DataGridView();
        Panel3 = new Panel();
        btnDeleteOrderProcess = new Button();
        btnUpdateOrderProcess = new Button();
        btnAddOrderProcess = new Button();
        tabTalentDB = new TabPage();
        btnSaveTalentDB = new Button();
        chkEnableTalentDB = new CheckBox();
        grpTalentDBConnection = new GroupBox();
        cboConnectionType = new ComboBox();
        Label1 = new Label();
        txtDatabaseTalent = new TextBox();
        txtServerTalent = new TextBox();
        lblBase = new Label();
        Label3 = new Label();
        btnTestConnection = new Button();
        txtPasswordTalent = new TextBox();
        lblPassword = new Label();
        txtUserTalent = new TextBox();
        Label4 = new Label();
        lblConnectionString = new Label();
        cmdCancelar = new Button();
        pnlEstado = new Panel();
        pnlBotones = new Panel();
        fbdRuta = new FolderBrowserDialog();
        scMIIA = new System.ServiceProcess.ServiceController();
        timerEventos = new System.Windows.Forms.Timer(components);
        EventLogADAM = new System.Diagnostics.EventLog();
        pnlSuperior.SuspendLayout();
        pnlPrincipal.SuspendLayout();
        tabParametros.SuspendLayout();
        tabServicio.SuspendLayout();
        pnlEventosServicio.SuspendLayout();
        Panel2.SuspendLayout();
        pnlServicio.SuspendLayout();
        tabGeneral.SuspendLayout();
        pnlGenerales.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)nupdTimeConnectionRetries).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nupdConnectionRetries).BeginInit();
        tabCorreo.SuspendLayout();
        pnlCorreo.SuspendLayout();
        tabClientes.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridParametrosCliente).BeginInit();
        pnlBotonesClientes.SuspendLayout();
        tabProcedures.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridProcedures).BeginInit();
        pnlBotonesProcs.SuspendLayout();
        tabOnDemand.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridOnDemand).BeginInit();
        Panel1.SuspendLayout();
        tabOrderProcess.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)gridOrderProcess).BeginInit();
        Panel3.SuspendLayout();
        tabTalentDB.SuspendLayout();
        grpTalentDBConnection.SuspendLayout();
        pnlBotones.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)EventLogADAM).BeginInit();
        SuspendLayout();
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(56, 88, 129);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(1370, 30);
        pnlSuperior.TabIndex = 2;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(12, 4);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(213, 28);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Configuración MIIA";
        // 
        // pnlPrincipal
        // 
        pnlPrincipal.Controls.Add(tabParametros);
        pnlPrincipal.Dock = DockStyle.Fill;
        pnlPrincipal.Location = new Point(0, 90);
        pnlPrincipal.Name = "pnlPrincipal";
        pnlPrincipal.Size = new Size(1370, 619);
        pnlPrincipal.TabIndex = 6;
        // 
        // tabParametros
        // 
        tabParametros.Controls.Add(tabServicio);
        tabParametros.Controls.Add(tabGeneral);
        tabParametros.Controls.Add(tabCorreo);
        tabParametros.Controls.Add(tabClientes);
        tabParametros.Controls.Add(tabProcedures);
        tabParametros.Controls.Add(tabOnDemand);
        tabParametros.Controls.Add(tabOrderProcess);
        tabParametros.Controls.Add(tabTalentDB);
        tabParametros.Dock = DockStyle.Fill;
        tabParametros.Location = new Point(0, 0);
        tabParametros.Name = "tabParametros";
        tabParametros.SelectedIndex = 0;
        tabParametros.Size = new Size(1370, 619);
        tabParametros.TabIndex = 0;
        tabParametros.Click += tabParametros_Click;
        // 
        // tabServicio
        // 
        tabServicio.BackColor = Color.FromArgb(227, 237, 239);
        tabServicio.Controls.Add(pnlEventosServicio);
        tabServicio.Controls.Add(pnlServicio);
        tabServicio.Location = new Point(4, 32);
        tabServicio.Name = "tabServicio";
        tabServicio.Padding = new Padding(3);
        tabServicio.Size = new Size(1362, 583);
        tabServicio.TabIndex = 5;
        tabServicio.Text = "Servicio";
        // 
        // pnlEventosServicio
        // 
        pnlEventosServicio.Controls.Add(lvEventos);
        pnlEventosServicio.Controls.Add(Panel2);
        pnlEventosServicio.Dock = DockStyle.Fill;
        pnlEventosServicio.Location = new Point(3, 55);
        pnlEventosServicio.Name = "pnlEventosServicio";
        pnlEventosServicio.Size = new Size(1356, 525);
        pnlEventosServicio.TabIndex = 1;
        // 
        // lvEventos
        // 
        lvEventos.Columns.AddRange(new ColumnHeader[] { ColumnHeader1 });
        lvEventos.Dock = DockStyle.Fill;
        lvEventos.FullRowSelect = true;
        lvEventos.Location = new Point(0, 52);
        lvEventos.Name = "lvEventos";
        lvEventos.Size = new Size(1356, 473);
        lvEventos.SmallImageList = ilIconos;
        lvEventos.TabIndex = 1;
        lvEventos.UseCompatibleStateImageBehavior = false;
        lvEventos.View = View.Details;
        lvEventos.SizeChanged += lvEventos_SizeChanged;
        // 
        // ColumnHeader1
        // 
        ColumnHeader1.Text = "";
        ColumnHeader1.Width = 2000;
        // 
        // ilIconos
        // 
        ilIconos.ColorDepth = ColorDepth.Depth8Bit;
        ilIconos.ImageSize = new Size(16, 16);
        ilIconos.TransparentColor = Color.Transparent;
        // 
        // Panel2
        // 
        Panel2.Controls.Add(cmdEventViewer);
        Panel2.Controls.Add(lblNotaEventos);
        Panel2.Controls.Add(lblEventos);
        Panel2.Controls.Add(chkActualiza);
        Panel2.Controls.Add(cmdActualizar);
        Panel2.Dock = DockStyle.Top;
        Panel2.Location = new Point(0, 0);
        Panel2.Name = "Panel2";
        Panel2.Size = new Size(1356, 52);
        Panel2.TabIndex = 0;
        // 
        // cmdEventViewer
        // 
        cmdEventViewer.Anchor = AnchorStyles.Right;
        cmdEventViewer.Location = new Point(1224, 8);
        cmdEventViewer.Name = "cmdEventViewer";
        cmdEventViewer.Size = new Size(124, 35);
        cmdEventViewer.TabIndex = 11;
        cmdEventViewer.Text = "Event Viewer";
        cmdEventViewer.UseVisualStyleBackColor = true;
        cmdEventViewer.Click += cmdEventViewer_Click;
        // 
        // lblNotaEventos
        // 
        lblNotaEventos.AutoSize = true;
        lblNotaEventos.Font = new Font("Trebuchet MS", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
        lblNotaEventos.Location = new Point(13, 30);
        lblNotaEventos.Name = "lblNotaEventos";
        lblNotaEventos.Size = new Size(577, 23);
        lblNotaEventos.TabIndex = 10;
        lblNotaEventos.Text = "NOTA: Si el log de eventos es nuevo, es necesario reiniciar el equipo ";
        // 
        // lblEventos
        // 
        lblEventos.AutoSize = true;
        lblEventos.Location = new Point(3, 9);
        lblEventos.Name = "lblEventos";
        lblEventos.Size = new Size(80, 23);
        lblEventos.TabIndex = 9;
        lblEventos.Text = "Eventos:";
        // 
        // chkActualiza
        // 
        chkActualiza.Anchor = AnchorStyles.Right;
        chkActualiza.AutoSize = true;
        chkActualiza.Location = new Point(1066, 16);
        chkActualiza.Name = "chkActualiza";
        chkActualiza.Size = new Size(22, 21);
        chkActualiza.TabIndex = 8;
        chkActualiza.UseVisualStyleBackColor = true;
        chkActualiza.CheckedChanged += chkActualiza_CheckedChanged;
        // 
        // cmdActualizar
        // 
        cmdActualizar.Anchor = AnchorStyles.Right;
        cmdActualizar.Location = new Point(1094, 8);
        cmdActualizar.Name = "cmdActualizar";
        cmdActualizar.Size = new Size(124, 35);
        cmdActualizar.TabIndex = 7;
        cmdActualizar.Text = "Actualizar";
        cmdActualizar.UseVisualStyleBackColor = true;
        cmdActualizar.Click += cmdActualizar_Click;
        // 
        // pnlServicio
        // 
        pnlServicio.BackColor = Color.FromArgb(227, 237, 239);
        pnlServicio.Controls.Add(cmdDetener);
        pnlServicio.Controls.Add(lblEstadoServicio);
        pnlServicio.Controls.Add(cmdReinicia);
        pnlServicio.Dock = DockStyle.Top;
        pnlServicio.Location = new Point(3, 3);
        pnlServicio.Name = "pnlServicio";
        pnlServicio.Size = new Size(1356, 52);
        pnlServicio.TabIndex = 0;
        // 
        // cmdDetener
        // 
        cmdDetener.Anchor = AnchorStyles.Right;
        cmdDetener.Location = new Point(1225, 8);
        cmdDetener.Name = "cmdDetener";
        cmdDetener.Size = new Size(124, 35);
        cmdDetener.TabIndex = 7;
        cmdDetener.Text = "Detener";
        cmdDetener.UseVisualStyleBackColor = true;
        cmdDetener.Click += cmdDetener_Click;
        // 
        // lblEstadoServicio
        // 
        lblEstadoServicio.AutoSize = true;
        lblEstadoServicio.Font = new Font("Trebuchet MS", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblEstadoServicio.Location = new Point(3, 18);
        lblEstadoServicio.Name = "lblEstadoServicio";
        lblEstadoServicio.Size = new Size(0, 26);
        lblEstadoServicio.TabIndex = 6;
        // 
        // cmdReinicia
        // 
        cmdReinicia.Anchor = AnchorStyles.Right;
        cmdReinicia.Location = new Point(1095, 8);
        cmdReinicia.Name = "cmdReinicia";
        cmdReinicia.Size = new Size(124, 35);
        cmdReinicia.TabIndex = 5;
        cmdReinicia.Text = "Reiniciar";
        cmdReinicia.UseVisualStyleBackColor = true;
        cmdReinicia.Click += cmdReinicia_Click;
        // 
        // tabGeneral
        // 
        tabGeneral.BackColor = Color.FromArgb(227, 237, 239);
        tabGeneral.Controls.Add(pnlGenerales);
        tabGeneral.Location = new Point(4, 34);
        tabGeneral.Name = "tabGeneral";
        tabGeneral.Size = new Size(1362, 581);
        tabGeneral.TabIndex = 0;
        tabGeneral.Text = "General";
        // 
        // pnlGenerales
        // 
        pnlGenerales.AutoScroll = true;
        pnlGenerales.Controls.Add(Label6);
        pnlGenerales.Controls.Add(nupdTimeConnectionRetries);
        pnlGenerales.Controls.Add(lblTimeConnectionRetries);
        pnlGenerales.Controls.Add(nupdConnectionRetries);
        pnlGenerales.Controls.Add(lblConnectionRetries);
        pnlGenerales.Controls.Add(cmdRutaResumenEnExcel);
        pnlGenerales.Controls.Add(Label5);
        pnlGenerales.Controls.Add(txtRutaResumenEnExcel);
        pnlGenerales.Controls.Add(cboUsarJobsSQL);
        pnlGenerales.Controls.Add(lblUsarJobsSQL);
        pnlGenerales.Controls.Add(cboArchivosEncriptados);
        pnlGenerales.Controls.Add(lblEncriptados);
        pnlGenerales.Controls.Add(txtPasswordGPG);
        pnlGenerales.Controls.Add(lblContrasenia);
        pnlGenerales.Controls.Add(txtNombresArchivosInmediata);
        pnlGenerales.Controls.Add(lblNombresArchivosInmediata);
        pnlGenerales.Controls.Add(cboEjecucionInmediata);
        pnlGenerales.Controls.Add(lblEjecucionInmediata);
        pnlGenerales.Controls.Add(txtPatron);
        pnlGenerales.Controls.Add(lblPatron);
        pnlGenerales.Controls.Add(cboArchivoControl);
        pnlGenerales.Controls.Add(cboVeces);
        pnlGenerales.Controls.Add(cmdRutaDestino);
        pnlGenerales.Controls.Add(txtCarpetas);
        pnlGenerales.Controls.Add(lblCarpetas);
        pnlGenerales.Controls.Add(lblUsarControl);
        pnlGenerales.Controls.Add(lblVecesEjecutar);
        pnlGenerales.Controls.Add(cmdRutaOrigen);
        pnlGenerales.Controls.Add(cmdAceptar);
        pnlGenerales.Controls.Add(txtNombresArchivosCtrl);
        pnlGenerales.Controls.Add(txtRutaDestino);
        pnlGenerales.Controls.Add(txtRutaOrigen);
        pnlGenerales.Controls.Add(lblNombresArchivosCtrl);
        pnlGenerales.Controls.Add(lblRutaDestino);
        pnlGenerales.Controls.Add(lblRutaOrigen);
        pnlGenerales.Dock = DockStyle.Fill;
        pnlGenerales.Location = new Point(0, 0);
        pnlGenerales.Name = "pnlGenerales";
        pnlGenerales.Size = new Size(1362, 581);
        pnlGenerales.TabIndex = 0;
        // 
        // Label6
        // 
        Label6.AutoSize = true;
        Label6.Font = new Font("Trebuchet MS", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
        Label6.Location = new Point(503, 504);
        Label6.Name = "Label6";
        Label6.Size = new Size(122, 23);
        Label6.TabIndex = 41;
        Label6.Text = "(en segundos)";
        // 
        // nupdTimeConnectionRetries
        // 
        nupdTimeConnectionRetries.Location = new Point(419, 502);
        nupdTimeConnectionRetries.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nupdTimeConnectionRetries.Name = "nupdTimeConnectionRetries";
        nupdTimeConnectionRetries.Size = new Size(75, 28);
        nupdTimeConnectionRetries.TabIndex = 40;
        // 
        // lblTimeConnectionRetries
        // 
        lblTimeConnectionRetries.AutoSize = true;
        lblTimeConnectionRetries.Location = new Point(12, 504);
        lblTimeConnectionRetries.Name = "lblTimeConnectionRetries";
        lblTimeConnectionRetries.Size = new Size(398, 23);
        lblTimeConnectionRetries.TabIndex = 39;
        lblTimeConnectionRetries.Text = "Tiempo de espera entre reintentos de conexión:";
        // 
        // nupdConnectionRetries
        // 
        nupdConnectionRetries.Location = new Point(419, 471);
        nupdConnectionRetries.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nupdConnectionRetries.Name = "nupdConnectionRetries";
        nupdConnectionRetries.Size = new Size(75, 28);
        nupdConnectionRetries.TabIndex = 38;
        // 
        // lblConnectionRetries
        // 
        lblConnectionRetries.AutoSize = true;
        lblConnectionRetries.Location = new Point(12, 473);
        lblConnectionRetries.Name = "lblConnectionRetries";
        lblConnectionRetries.Size = new Size(264, 23);
        lblConnectionRetries.TabIndex = 37;
        lblConnectionRetries.Text = "Reintentos de conexión a la BD:";
        // 
        // cmdRutaResumenEnExcel
        // 
        cmdRutaResumenEnExcel.Location = new Point(673, 440);
        cmdRutaResumenEnExcel.Name = "cmdRutaResumenEnExcel";
        cmdRutaResumenEnExcel.Size = new Size(40, 30);
        cmdRutaResumenEnExcel.TabIndex = 36;
        cmdRutaResumenEnExcel.Text = "...";
        cmdRutaResumenEnExcel.UseVisualStyleBackColor = true;
        cmdRutaResumenEnExcel.Click += cmdRutaResumenEnExcel_Click;
        // 
        // Label5
        // 
        Label5.AutoSize = true;
        Label5.Location = new Point(12, 444);
        Label5.Name = "Label5";
        Label5.Size = new Size(228, 23);
        Label5.TabIndex = 35;
        Label5.Text = "Ruta del resumen en Excel:";
        // 
        // txtRutaResumenEnExcel
        // 
        txtRutaResumenEnExcel.Location = new Point(419, 441);
        txtRutaResumenEnExcel.MaxLength = 300;
        txtRutaResumenEnExcel.Name = "txtRutaResumenEnExcel";
        txtRutaResumenEnExcel.Size = new Size(250, 28);
        txtRutaResumenEnExcel.TabIndex = 34;
        // 
        // cboUsarJobsSQL
        // 
        cboUsarJobsSQL.FormattingEnabled = true;
        cboUsarJobsSQL.Items.AddRange(new object[] { "True", "False" });
        cboUsarJobsSQL.Location = new Point(419, 407);
        cboUsarJobsSQL.Name = "cboUsarJobsSQL";
        cboUsarJobsSQL.Size = new Size(250, 31);
        cboUsarJobsSQL.TabIndex = 29;
        // 
        // lblUsarJobsSQL
        // 
        lblUsarJobsSQL.AutoSize = true;
        lblUsarJobsSQL.Location = new Point(12, 410);
        lblUsarJobsSQL.Name = "lblUsarJobsSQL";
        lblUsarJobsSQL.Size = new Size(128, 23);
        lblUsarJobsSQL.TabIndex = 28;
        lblUsarJobsSQL.Text = "Usar Jobs SQL:";
        // 
        // cboArchivosEncriptados
        // 
        cboArchivosEncriptados.FormattingEnabled = true;
        cboArchivosEncriptados.Items.AddRange(new object[] { "True", "False" });
        cboArchivosEncriptados.Location = new Point(419, 345);
        cboArchivosEncriptados.Name = "cboArchivosEncriptados";
        cboArchivosEncriptados.Size = new Size(250, 31);
        cboArchivosEncriptados.TabIndex = 27;
        // 
        // lblEncriptados
        // 
        lblEncriptados.AutoSize = true;
        lblEncriptados.Location = new Point(12, 348);
        lblEncriptados.Name = "lblEncriptados";
        lblEncriptados.Size = new Size(184, 23);
        lblEncriptados.TabIndex = 26;
        lblEncriptados.Text = "Archivos encriptados:";
        // 
        // txtPasswordGPG
        // 
        txtPasswordGPG.Location = new Point(419, 378);
        txtPasswordGPG.MaxLength = 300;
        txtPasswordGPG.Name = "txtPasswordGPG";
        txtPasswordGPG.Size = new Size(250, 28);
        txtPasswordGPG.TabIndex = 25;
        txtPasswordGPG.UseSystemPasswordChar = true;
        // 
        // lblContrasenia
        // 
        lblContrasenia.AutoSize = true;
        lblContrasenia.Location = new Point(12, 381);
        lblContrasenia.Name = "lblContrasenia";
        lblContrasenia.Size = new Size(107, 23);
        lblContrasenia.TabIndex = 24;
        lblContrasenia.Text = "Contraseña:";
        // 
        // txtNombresArchivosInmediata
        // 
        txtNombresArchivosInmediata.Location = new Point(419, 284);
        txtNombresArchivosInmediata.MaxLength = 300;
        txtNombresArchivosInmediata.Name = "txtNombresArchivosInmediata";
        txtNombresArchivosInmediata.Size = new Size(250, 28);
        txtNombresArchivosInmediata.TabIndex = 19;
        // 
        // lblNombresArchivosInmediata
        // 
        lblNombresArchivosInmediata.AutoSize = true;
        lblNombresArchivosInmediata.Location = new Point(12, 287);
        lblNombresArchivosInmediata.Name = "lblNombresArchivosInmediata";
        lblNombresArchivosInmediata.Size = new Size(351, 23);
        lblNombresArchivosInmediata.TabIndex = 18;
        lblNombresArchivosInmediata.Text = "Nombres de archivos ejecucion inmediata:";
        // 
        // cboEjecucionInmediata
        // 
        cboEjecucionInmediata.FormattingEnabled = true;
        cboEjecucionInmediata.Items.AddRange(new object[] { "True", "False" });
        cboEjecucionInmediata.Location = new Point(419, 250);
        cboEjecucionInmediata.Name = "cboEjecucionInmediata";
        cboEjecucionInmediata.Size = new Size(250, 31);
        cboEjecucionInmediata.TabIndex = 17;
        // 
        // lblEjecucionInmediata
        // 
        lblEjecucionInmediata.AutoSize = true;
        lblEjecucionInmediata.Location = new Point(12, 253);
        lblEjecucionInmediata.Name = "lblEjecucionInmediata";
        lblEjecucionInmediata.Size = new Size(250, 23);
        lblEjecucionInmediata.TabIndex = 16;
        lblEjecucionInmediata.Text = "Permitir ejecución inmediata:";
        // 
        // txtPatron
        // 
        txtPatron.Location = new Point(419, 220);
        txtPatron.MaxLength = 300;
        txtPatron.Name = "txtPatron";
        txtPatron.Size = new Size(250, 28);
        txtPatron.TabIndex = 15;
        // 
        // lblPatron
        // 
        lblPatron.AutoSize = true;
        lblPatron.Location = new Point(12, 223);
        lblPatron.Name = "lblPatron";
        lblPatron.Size = new Size(276, 23);
        lblPatron.TabIndex = 14;
        lblPatron.Text = "Patrón de validación de archivos:";
        // 
        // cboArchivoControl
        // 
        cboArchivoControl.FormattingEnabled = true;
        cboArchivoControl.Items.AddRange(new object[] { "True", "False" });
        cboArchivoControl.Location = new Point(419, 186);
        cboArchivoControl.Name = "cboArchivoControl";
        cboArchivoControl.Size = new Size(250, 31);
        cboArchivoControl.TabIndex = 13;
        // 
        // cboVeces
        // 
        cboVeces.FormattingEnabled = true;
        cboVeces.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
        cboVeces.Location = new Point(419, 153);
        cboVeces.Name = "cboVeces";
        cboVeces.Size = new Size(250, 31);
        cboVeces.TabIndex = 12;
        // 
        // cmdRutaDestino
        // 
        cmdRutaDestino.Location = new Point(673, 62);
        cmdRutaDestino.Name = "cmdRutaDestino";
        cmdRutaDestino.Size = new Size(40, 30);
        cmdRutaDestino.TabIndex = 11;
        cmdRutaDestino.Text = "...";
        cmdRutaDestino.UseVisualStyleBackColor = true;
        cmdRutaDestino.Click += cmdRutaDestino_Click;
        // 
        // txtCarpetas
        // 
        txtCarpetas.Location = new Point(419, 123);
        txtCarpetas.MaxLength = 300;
        txtCarpetas.Name = "txtCarpetas";
        txtCarpetas.Size = new Size(250, 28);
        txtCarpetas.TabIndex = 10;
        // 
        // lblCarpetas
        // 
        lblCarpetas.AutoSize = true;
        lblCarpetas.Location = new Point(12, 126);
        lblCarpetas.Name = "lblCarpetas";
        lblCarpetas.Size = new Size(175, 23);
        lblCarpetas.TabIndex = 9;
        lblCarpetas.Text = "Carpetas a procesar:";
        // 
        // lblUsarControl
        // 
        lblUsarControl.AutoSize = true;
        lblUsarControl.Location = new Point(12, 189);
        lblUsarControl.Name = "lblUsarControl";
        lblUsarControl.Size = new Size(204, 23);
        lblUsarControl.TabIndex = 8;
        lblUsarControl.Text = "Usar archivo de control:";
        // 
        // lblVecesEjecutar
        // 
        lblVecesEjecutar.AutoSize = true;
        lblVecesEjecutar.Location = new Point(12, 156);
        lblVecesEjecutar.Name = "lblVecesEjecutar";
        lblVecesEjecutar.Size = new Size(223, 23);
        lblVecesEjecutar.TabIndex = 7;
        lblVecesEjecutar.Text = "Veces que ejecuta los SPs:";
        // 
        // cmdRutaOrigen
        // 
        cmdRutaOrigen.Location = new Point(673, 32);
        cmdRutaOrigen.Name = "cmdRutaOrigen";
        cmdRutaOrigen.Size = new Size(40, 30);
        cmdRutaOrigen.TabIndex = 6;
        cmdRutaOrigen.Text = "...";
        cmdRutaOrigen.UseVisualStyleBackColor = true;
        cmdRutaOrigen.Click += cmdRutaOrigen_Click;
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cmdAceptar.Location = new Point(1229, 533);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 5;
        cmdAceptar.Text = "Guardar";
        cmdAceptar.UseVisualStyleBackColor = true;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // txtNombresArchivosCtrl
        // 
        txtNombresArchivosCtrl.Location = new Point(419, 93);
        txtNombresArchivosCtrl.MaxLength = 300;
        txtNombresArchivosCtrl.Name = "txtNombresArchivosCtrl";
        txtNombresArchivosCtrl.Size = new Size(250, 28);
        txtNombresArchivosCtrl.TabIndex = 4;
        // 
        // txtRutaDestino
        // 
        txtRutaDestino.Location = new Point(419, 63);
        txtRutaDestino.MaxLength = 300;
        txtRutaDestino.Name = "txtRutaDestino";
        txtRutaDestino.Size = new Size(250, 28);
        txtRutaDestino.TabIndex = 3;
        // 
        // txtRutaOrigen
        // 
        txtRutaOrigen.Location = new Point(419, 33);
        txtRutaOrigen.MaxLength = 300;
        txtRutaOrigen.Name = "txtRutaOrigen";
        txtRutaOrigen.Size = new Size(250, 28);
        txtRutaOrigen.TabIndex = 2;
        // 
        // lblNombresArchivosCtrl
        // 
        lblNombresArchivosCtrl.AutoSize = true;
        lblNombresArchivosCtrl.Location = new Point(12, 96);
        lblNombresArchivosCtrl.Name = "lblNombresArchivosCtrl";
        lblNombresArchivosCtrl.Size = new Size(245, 23);
        lblNombresArchivosCtrl.TabIndex = 2;
        lblNombresArchivosCtrl.Text = "Nombres archivos de control:";
        // 
        // lblRutaDestino
        // 
        lblRutaDestino.AutoSize = true;
        lblRutaDestino.Location = new Point(12, 66);
        lblRutaDestino.Name = "lblRutaDestino";
        lblRutaDestino.Size = new Size(116, 23);
        lblRutaDestino.TabIndex = 1;
        lblRutaDestino.Text = "Ruta destino:";
        // 
        // lblRutaOrigen
        // 
        lblRutaOrigen.AutoSize = true;
        lblRutaOrigen.Location = new Point(12, 36);
        lblRutaOrigen.Name = "lblRutaOrigen";
        lblRutaOrigen.Size = new Size(108, 23);
        lblRutaOrigen.TabIndex = 0;
        lblRutaOrigen.Text = "Ruta origen:";
        // 
        // tabCorreo
        // 
        tabCorreo.BackColor = Color.FromArgb(227, 237, 239);
        tabCorreo.Controls.Add(pnlCorreo);
        tabCorreo.Location = new Point(4, 34);
        tabCorreo.Name = "tabCorreo";
        tabCorreo.Size = new Size(1362, 581);
        tabCorreo.TabIndex = 1;
        tabCorreo.Text = "Correo";
        // 
        // pnlCorreo
        // 
        pnlCorreo.Controls.Add(cmdGuardaCorreo);
        pnlCorreo.Controls.Add(cmdProbar);
        pnlCorreo.Controls.Add(txtTimeOut);
        pnlCorreo.Controls.Add(lblTimeOut);
        pnlCorreo.Controls.Add(txtPassword);
        pnlCorreo.Controls.Add(label2);
        pnlCorreo.Controls.Add(txtUsuario);
        pnlCorreo.Controls.Add(lblUsuario);
        pnlCorreo.Controls.Add(cboSSL);
        pnlCorreo.Controls.Add(lblSsl);
        pnlCorreo.Controls.Add(txtPuerto);
        pnlCorreo.Controls.Add(lblPuerto);
        pnlCorreo.Controls.Add(txtServidorCorreo);
        pnlCorreo.Controls.Add(lblServidor);
        pnlCorreo.Controls.Add(cboPrioridad);
        pnlCorreo.Controls.Add(lblPrioridad);
        pnlCorreo.Controls.Add(cboHtml);
        pnlCorreo.Controls.Add(lblHtml);
        pnlCorreo.Controls.Add(txtMensaje);
        pnlCorreo.Controls.Add(lblMensaje);
        pnlCorreo.Controls.Add(txtMail);
        pnlCorreo.Controls.Add(lblCorreoDe);
        pnlCorreo.Controls.Add(txtTitulo);
        pnlCorreo.Controls.Add(lblTituloCorreo);
        pnlCorreo.Controls.Add(txtNombre);
        pnlCorreo.Controls.Add(lblDeCorreo);
        pnlCorreo.Dock = DockStyle.Fill;
        pnlCorreo.Location = new Point(0, 0);
        pnlCorreo.Name = "pnlCorreo";
        pnlCorreo.Size = new Size(1362, 581);
        pnlCorreo.TabIndex = 0;
        // 
        // cmdGuardaCorreo
        // 
        cmdGuardaCorreo.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cmdGuardaCorreo.Location = new Point(1231, 538);
        cmdGuardaCorreo.Name = "cmdGuardaCorreo";
        cmdGuardaCorreo.Size = new Size(124, 35);
        cmdGuardaCorreo.TabIndex = 28;
        cmdGuardaCorreo.Text = "Guardar";
        cmdGuardaCorreo.UseVisualStyleBackColor = true;
        cmdGuardaCorreo.Click += cmdGuardaCorreo_Click;
        // 
        // cmdProbar
        // 
        cmdProbar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cmdProbar.Location = new Point(1100, 538);
        cmdProbar.Name = "cmdProbar";
        cmdProbar.Size = new Size(124, 35);
        cmdProbar.TabIndex = 27;
        cmdProbar.Text = "Probar";
        cmdProbar.UseVisualStyleBackColor = true;
        cmdProbar.Click += cmdProbar_Click;
        // 
        // txtTimeOut
        // 
        txtTimeOut.Location = new Point(375, 393);
        txtTimeOut.MaxLength = 200;
        txtTimeOut.Name = "txtTimeOut";
        txtTimeOut.Size = new Size(250, 28);
        txtTimeOut.TabIndex = 25;
        // 
        // lblTimeOut
        // 
        lblTimeOut.AutoSize = true;
        lblTimeOut.Location = new Point(12, 396);
        lblTimeOut.Name = "lblTimeOut";
        lblTimeOut.Size = new Size(89, 23);
        lblTimeOut.TabIndex = 24;
        lblTimeOut.Text = "Time Out:";
        // 
        // txtPassword
        // 
        txtPassword.Location = new Point(375, 333);
        txtPassword.MaxLength = 200;
        txtPassword.Name = "txtPassword";
        txtPassword.Size = new Size(250, 28);
        txtPassword.TabIndex = 23;
        txtPassword.UseSystemPasswordChar = true;
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Location = new Point(12, 336);
        label2.Name = "label2";
        label2.Size = new Size(89, 23);
        label2.TabIndex = 22;
        label2.Text = "Password:";
        // 
        // txtUsuario
        // 
        txtUsuario.Location = new Point(375, 303);
        txtUsuario.MaxLength = 200;
        txtUsuario.Name = "txtUsuario";
        txtUsuario.Size = new Size(250, 28);
        txtUsuario.TabIndex = 21;
        // 
        // lblUsuario
        // 
        lblUsuario.AutoSize = true;
        lblUsuario.Location = new Point(12, 306);
        lblUsuario.Name = "lblUsuario";
        lblUsuario.Size = new Size(77, 23);
        lblUsuario.TabIndex = 20;
        lblUsuario.Text = "Usuario:";
        // 
        // cboSSL
        // 
        cboSSL.FormattingEnabled = true;
        cboSSL.Items.AddRange(new object[] { "True", "False" });
        cboSSL.Location = new Point(375, 273);
        cboSSL.Name = "cboSSL";
        cboSSL.Size = new Size(250, 31);
        cboSSL.TabIndex = 19;
        // 
        // lblSsl
        // 
        lblSsl.AutoSize = true;
        lblSsl.Location = new Point(12, 276);
        lblSsl.Name = "lblSsl";
        lblSsl.Size = new Size(44, 23);
        lblSsl.TabIndex = 18;
        lblSsl.Text = "SSL:";
        // 
        // txtPuerto
        // 
        txtPuerto.Location = new Point(375, 243);
        txtPuerto.MaxLength = 200;
        txtPuerto.Name = "txtPuerto";
        txtPuerto.Size = new Size(250, 28);
        txtPuerto.TabIndex = 17;
        // 
        // lblPuerto
        // 
        lblPuerto.AutoSize = true;
        lblPuerto.Location = new Point(12, 246);
        lblPuerto.Name = "lblPuerto";
        lblPuerto.Size = new Size(71, 23);
        lblPuerto.TabIndex = 16;
        lblPuerto.Text = "Puerto:";
        // 
        // txtServidorCorreo
        // 
        txtServidorCorreo.Location = new Point(375, 213);
        txtServidorCorreo.MaxLength = 200;
        txtServidorCorreo.Name = "txtServidorCorreo";
        txtServidorCorreo.Size = new Size(250, 28);
        txtServidorCorreo.TabIndex = 15;
        // 
        // lblServidor
        // 
        lblServidor.AutoSize = true;
        lblServidor.Location = new Point(12, 216);
        lblServidor.Name = "lblServidor";
        lblServidor.Size = new Size(84, 23);
        lblServidor.TabIndex = 14;
        lblServidor.Text = "Servidor:";
        // 
        // cboPrioridad
        // 
        cboPrioridad.FormattingEnabled = true;
        cboPrioridad.Items.AddRange(new object[] { "0", "1", "2" });
        cboPrioridad.Location = new Point(375, 183);
        cboPrioridad.Name = "cboPrioridad";
        cboPrioridad.Size = new Size(250, 31);
        cboPrioridad.TabIndex = 13;
        // 
        // lblPrioridad
        // 
        lblPrioridad.AutoSize = true;
        lblPrioridad.Location = new Point(12, 186);
        lblPrioridad.Name = "lblPrioridad";
        lblPrioridad.Size = new Size(89, 23);
        lblPrioridad.TabIndex = 12;
        lblPrioridad.Text = "Prioridad:";
        // 
        // cboHtml
        // 
        cboHtml.FormattingEnabled = true;
        cboHtml.Items.AddRange(new object[] { "True", "False" });
        cboHtml.Location = new Point(375, 153);
        cboHtml.Name = "cboHtml";
        cboHtml.Size = new Size(250, 31);
        cboHtml.TabIndex = 11;
        // 
        // lblHtml
        // 
        lblHtml.AutoSize = true;
        lblHtml.Location = new Point(12, 156);
        lblHtml.Name = "lblHtml";
        lblHtml.Size = new Size(126, 23);
        lblHtml.TabIndex = 10;
        lblHtml.Text = "Formato Html:";
        // 
        // txtMensaje
        // 
        txtMensaje.Location = new Point(375, 123);
        txtMensaje.MaxLength = 500;
        txtMensaje.Name = "txtMensaje";
        txtMensaje.Size = new Size(250, 28);
        txtMensaje.TabIndex = 9;
        // 
        // lblMensaje
        // 
        lblMensaje.AutoSize = true;
        lblMensaje.Location = new Point(12, 126);
        lblMensaje.Name = "lblMensaje";
        lblMensaje.Size = new Size(83, 23);
        lblMensaje.TabIndex = 8;
        lblMensaje.Text = "Mensaje:";
        // 
        // txtMail
        // 
        txtMail.Location = new Point(375, 63);
        txtMail.MaxLength = 200;
        txtMail.Name = "txtMail";
        txtMail.Size = new Size(250, 28);
        txtMail.TabIndex = 7;
        // 
        // lblCorreoDe
        // 
        lblCorreoDe.AutoSize = true;
        lblCorreoDe.Location = new Point(12, 66);
        lblCorreoDe.Name = "lblCorreoDe";
        lblCorreoDe.Size = new Size(72, 23);
        lblCorreoDe.TabIndex = 6;
        lblCorreoDe.Text = "Correo:";
        // 
        // txtTitulo
        // 
        txtTitulo.Location = new Point(375, 93);
        txtTitulo.MaxLength = 200;
        txtTitulo.Name = "txtTitulo";
        txtTitulo.Size = new Size(250, 28);
        txtTitulo.TabIndex = 5;
        // 
        // lblTituloCorreo
        // 
        lblTituloCorreo.AutoSize = true;
        lblTituloCorreo.Location = new Point(12, 96);
        lblTituloCorreo.Name = "lblTituloCorreo";
        lblTituloCorreo.Size = new Size(64, 23);
        lblTituloCorreo.TabIndex = 4;
        lblTituloCorreo.Text = "Título:";
        // 
        // txtNombre
        // 
        txtNombre.Location = new Point(375, 33);
        txtNombre.MaxLength = 200;
        txtNombre.Name = "txtNombre";
        txtNombre.Size = new Size(250, 28);
        txtNombre.TabIndex = 3;
        // 
        // lblDeCorreo
        // 
        lblDeCorreo.AutoSize = true;
        lblDeCorreo.Location = new Point(12, 36);
        lblDeCorreo.Name = "lblDeCorreo";
        lblDeCorreo.Size = new Size(79, 23);
        lblDeCorreo.TabIndex = 2;
        lblDeCorreo.Text = "Nombre:";
        // 
        // tabClientes
        // 
        tabClientes.BackColor = Color.FromArgb(227, 237, 239);
        tabClientes.Controls.Add(gridParametrosCliente);
        tabClientes.Controls.Add(pnlBotonesClientes);
        tabClientes.Location = new Point(4, 34);
        tabClientes.Name = "tabClientes";
        tabClientes.Padding = new Padding(3);
        tabClientes.Size = new Size(1362, 581);
        tabClientes.TabIndex = 2;
        tabClientes.Text = "Clientes";
        // 
        // gridParametrosCliente
        // 
        gridParametrosCliente.AllowUserToAddRows = false;
        gridParametrosCliente.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridParametrosCliente.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridParametrosCliente.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridParametrosCliente.Dock = DockStyle.Fill;
        gridParametrosCliente.Location = new Point(3, 3);
        gridParametrosCliente.Name = "gridParametrosCliente";
        gridParametrosCliente.ReadOnly = true;
        gridParametrosCliente.RowHeadersVisible = false;
        gridParametrosCliente.RowHeadersWidth = 51;
        gridParametrosCliente.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridParametrosCliente.Size = new Size(1356, 535);
        gridParametrosCliente.TabIndex = 1;
        gridParametrosCliente.CellDoubleClick += gridParametrosCliente_CellDoubleClick;
        gridParametrosCliente.CellFormatting += gridParametrosCliente_CellFormatting;
        // 
        // pnlBotonesClientes
        // 
        pnlBotonesClientes.Controls.Add(cmdEliminar);
        pnlBotonesClientes.Controls.Add(cmdModificar);
        pnlBotonesClientes.Controls.Add(cmdAgregar);
        pnlBotonesClientes.Dock = DockStyle.Bottom;
        pnlBotonesClientes.Location = new Point(3, 538);
        pnlBotonesClientes.Name = "pnlBotonesClientes";
        pnlBotonesClientes.Size = new Size(1356, 40);
        pnlBotonesClientes.TabIndex = 2;
        // 
        // cmdEliminar
        // 
        cmdEliminar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdEliminar.Location = new Point(261, 1);
        cmdEliminar.Name = "cmdEliminar";
        cmdEliminar.Size = new Size(124, 35);
        cmdEliminar.TabIndex = 4;
        cmdEliminar.Text = "Eliminar";
        cmdEliminar.UseVisualStyleBackColor = true;
        cmdEliminar.Click += cmdEliminar_Click;
        // 
        // cmdModificar
        // 
        cmdModificar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdModificar.Location = new Point(131, 1);
        cmdModificar.Name = "cmdModificar";
        cmdModificar.Size = new Size(124, 35);
        cmdModificar.TabIndex = 3;
        cmdModificar.Text = "Modificar";
        cmdModificar.UseVisualStyleBackColor = true;
        cmdModificar.Click += cmdModificar_Click;
        // 
        // cmdAgregar
        // 
        cmdAgregar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdAgregar.DialogResult = DialogResult.Cancel;
        cmdAgregar.Location = new Point(1, 1);
        cmdAgregar.Name = "cmdAgregar";
        cmdAgregar.Size = new Size(124, 35);
        cmdAgregar.TabIndex = 2;
        cmdAgregar.Text = "Agregar";
        cmdAgregar.UseVisualStyleBackColor = true;
        cmdAgregar.Click += cmdAgregar_Click;
        // 
        // tabProcedures
        // 
        tabProcedures.BackColor = Color.FromArgb(227, 237, 239);
        tabProcedures.Controls.Add(gridProcedures);
        tabProcedures.Controls.Add(pnlBotonesProcs);
        tabProcedures.Location = new Point(4, 34);
        tabProcedures.Name = "tabProcedures";
        tabProcedures.Padding = new Padding(3);
        tabProcedures.Size = new Size(1362, 581);
        tabProcedures.TabIndex = 3;
        tabProcedures.Text = "Procedures";
        // 
        // gridProcedures
        // 
        gridProcedures.AllowUserToAddRows = false;
        gridProcedures.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridProcedures.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridProcedures.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridProcedures.Dock = DockStyle.Fill;
        gridProcedures.Location = new Point(3, 3);
        gridProcedures.Name = "gridProcedures";
        gridProcedures.ReadOnly = true;
        gridProcedures.RowHeadersVisible = false;
        gridProcedures.RowHeadersWidth = 51;
        gridProcedures.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridProcedures.Size = new Size(1356, 535);
        gridProcedures.TabIndex = 3;
        gridProcedures.DoubleClick += gridProcedures_DoubleClick;
        // 
        // pnlBotonesProcs
        // 
        pnlBotonesProcs.Controls.Add(cmdEliminarProc);
        pnlBotonesProcs.Controls.Add(cmdModificarProc);
        pnlBotonesProcs.Controls.Add(cmdAgregarProc);
        pnlBotonesProcs.Dock = DockStyle.Bottom;
        pnlBotonesProcs.Location = new Point(3, 538);
        pnlBotonesProcs.Name = "pnlBotonesProcs";
        pnlBotonesProcs.Size = new Size(1356, 40);
        pnlBotonesProcs.TabIndex = 10;
        // 
        // cmdEliminarProc
        // 
        cmdEliminarProc.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdEliminarProc.Location = new Point(261, 1);
        cmdEliminarProc.Name = "cmdEliminarProc";
        cmdEliminarProc.Size = new Size(124, 35);
        cmdEliminarProc.TabIndex = 12;
        cmdEliminarProc.Text = "Eliminar";
        cmdEliminarProc.UseVisualStyleBackColor = true;
        cmdEliminarProc.Click += cmdEliminarProc_Click;
        // 
        // cmdModificarProc
        // 
        cmdModificarProc.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdModificarProc.Location = new Point(131, 1);
        cmdModificarProc.Name = "cmdModificarProc";
        cmdModificarProc.Size = new Size(124, 35);
        cmdModificarProc.TabIndex = 11;
        cmdModificarProc.Text = "Modificar";
        cmdModificarProc.UseVisualStyleBackColor = true;
        cmdModificarProc.Click += cmdModificarProc_Click;
        // 
        // cmdAgregarProc
        // 
        cmdAgregarProc.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdAgregarProc.Location = new Point(1, 1);
        cmdAgregarProc.Name = "cmdAgregarProc";
        cmdAgregarProc.Size = new Size(124, 35);
        cmdAgregarProc.TabIndex = 10;
        cmdAgregarProc.Text = "Agregar";
        cmdAgregarProc.UseVisualStyleBackColor = true;
        cmdAgregarProc.Click += cmdAgregarProc_Click;
        // 
        // tabOnDemand
        // 
        tabOnDemand.BackColor = Color.FromArgb(227, 237, 239);
        tabOnDemand.Controls.Add(gridOnDemand);
        tabOnDemand.Controls.Add(Panel1);
        tabOnDemand.Location = new Point(4, 34);
        tabOnDemand.Name = "tabOnDemand";
        tabOnDemand.Padding = new Padding(3);
        tabOnDemand.Size = new Size(1362, 581);
        tabOnDemand.TabIndex = 6;
        tabOnDemand.Text = "Ejecución Inmediata";
        tabOnDemand.UseVisualStyleBackColor = true;
        // 
        // gridOnDemand
        // 
        gridOnDemand.AllowUserToAddRows = false;
        gridOnDemand.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridOnDemand.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridOnDemand.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridOnDemand.Dock = DockStyle.Fill;
        gridOnDemand.Location = new Point(3, 3);
        gridOnDemand.Name = "gridOnDemand";
        gridOnDemand.ReadOnly = true;
        gridOnDemand.RowHeadersVisible = false;
        gridOnDemand.RowHeadersWidth = 51;
        gridOnDemand.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridOnDemand.Size = new Size(1356, 535);
        gridOnDemand.TabIndex = 3;
        gridOnDemand.DoubleClick += gridOnDemand_DoubleClick;
        // 
        // Panel1
        // 
        Panel1.Controls.Add(cmdEliminarOnDemand);
        Panel1.Controls.Add(cmdModificarOnDemand);
        Panel1.Controls.Add(cmdAgregarOnDemand);
        Panel1.Dock = DockStyle.Bottom;
        Panel1.Location = new Point(3, 538);
        Panel1.Name = "Panel1";
        Panel1.Size = new Size(1356, 40);
        Panel1.TabIndex = 12;
        // 
        // cmdEliminarOnDemand
        // 
        cmdEliminarOnDemand.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdEliminarOnDemand.Location = new Point(261, 1);
        cmdEliminarOnDemand.Name = "cmdEliminarOnDemand";
        cmdEliminarOnDemand.Size = new Size(124, 35);
        cmdEliminarOnDemand.TabIndex = 12;
        cmdEliminarOnDemand.Text = "Eliminar";
        cmdEliminarOnDemand.UseVisualStyleBackColor = true;
        cmdEliminarOnDemand.Click += cmdEliminarOnDemand_Click;
        // 
        // cmdModificarOnDemand
        // 
        cmdModificarOnDemand.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdModificarOnDemand.Location = new Point(131, 1);
        cmdModificarOnDemand.Name = "cmdModificarOnDemand";
        cmdModificarOnDemand.Size = new Size(124, 35);
        cmdModificarOnDemand.TabIndex = 11;
        cmdModificarOnDemand.Text = "Modificar";
        cmdModificarOnDemand.UseVisualStyleBackColor = true;
        cmdModificarOnDemand.Click += cmdModificarOnDemand_Click;
        // 
        // cmdAgregarOnDemand
        // 
        cmdAgregarOnDemand.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        cmdAgregarOnDemand.DialogResult = DialogResult.Cancel;
        cmdAgregarOnDemand.Location = new Point(1, 1);
        cmdAgregarOnDemand.Name = "cmdAgregarOnDemand";
        cmdAgregarOnDemand.Size = new Size(124, 35);
        cmdAgregarOnDemand.TabIndex = 10;
        cmdAgregarOnDemand.Text = "Agregar";
        cmdAgregarOnDemand.UseVisualStyleBackColor = true;
        cmdAgregarOnDemand.Click += cmdAgregarOnDemand_Click;
        // 
        // tabOrderProcess
        // 
        tabOrderProcess.Controls.Add(gridOrderProcess);
        tabOrderProcess.Controls.Add(Panel3);
        tabOrderProcess.Location = new Point(4, 34);
        tabOrderProcess.Name = "tabOrderProcess";
        tabOrderProcess.Padding = new Padding(3);
        tabOrderProcess.Size = new Size(1362, 581);
        tabOrderProcess.TabIndex = 8;
        tabOrderProcess.Text = "Prioridad de Procesamiento";
        tabOrderProcess.UseVisualStyleBackColor = true;
        // 
        // gridOrderProcess
        // 
        gridOrderProcess.AllowUserToAddRows = false;
        gridOrderProcess.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        gridOrderProcess.BackgroundColor = Color.FromArgb(227, 237, 239);
        gridOrderProcess.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        gridOrderProcess.Dock = DockStyle.Fill;
        gridOrderProcess.Location = new Point(3, 3);
        gridOrderProcess.Name = "gridOrderProcess";
        gridOrderProcess.ReadOnly = true;
        gridOrderProcess.RowHeadersVisible = false;
        gridOrderProcess.RowHeadersWidth = 51;
        gridOrderProcess.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        gridOrderProcess.Size = new Size(1356, 535);
        gridOrderProcess.TabIndex = 13;
        // 
        // Panel3
        // 
        Panel3.BackColor = Color.FromArgb(227, 237, 239);
        Panel3.Controls.Add(btnDeleteOrderProcess);
        Panel3.Controls.Add(btnUpdateOrderProcess);
        Panel3.Controls.Add(btnAddOrderProcess);
        Panel3.Dock = DockStyle.Bottom;
        Panel3.Location = new Point(3, 538);
        Panel3.Name = "Panel3";
        Panel3.Size = new Size(1356, 40);
        Panel3.TabIndex = 14;
        // 
        // btnDeleteOrderProcess
        // 
        btnDeleteOrderProcess.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnDeleteOrderProcess.Location = new Point(261, 1);
        btnDeleteOrderProcess.Name = "btnDeleteOrderProcess";
        btnDeleteOrderProcess.Size = new Size(124, 35);
        btnDeleteOrderProcess.TabIndex = 12;
        btnDeleteOrderProcess.Text = "Eliminar";
        btnDeleteOrderProcess.UseVisualStyleBackColor = true;
        btnDeleteOrderProcess.Click += btnDeleteOrderProcess_Click;
        // 
        // btnUpdateOrderProcess
        // 
        btnUpdateOrderProcess.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnUpdateOrderProcess.Location = new Point(131, 1);
        btnUpdateOrderProcess.Name = "btnUpdateOrderProcess";
        btnUpdateOrderProcess.Size = new Size(124, 35);
        btnUpdateOrderProcess.TabIndex = 11;
        btnUpdateOrderProcess.Text = "Modificar";
        btnUpdateOrderProcess.UseVisualStyleBackColor = true;
        btnUpdateOrderProcess.Click += btnUpdateOrderProcess_Click;
        // 
        // btnAddOrderProcess
        // 
        btnAddOrderProcess.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnAddOrderProcess.DialogResult = DialogResult.Cancel;
        btnAddOrderProcess.Location = new Point(1, 1);
        btnAddOrderProcess.Name = "btnAddOrderProcess";
        btnAddOrderProcess.Size = new Size(124, 35);
        btnAddOrderProcess.TabIndex = 10;
        btnAddOrderProcess.Text = "Agregar";
        btnAddOrderProcess.UseVisualStyleBackColor = true;
        btnAddOrderProcess.Click += btnAddOrderProcess_Click;
        // 
        // tabTalentDB
        // 
        tabTalentDB.BackColor = Color.FromArgb(227, 237, 239);
        tabTalentDB.Controls.Add(btnSaveTalentDB);
        tabTalentDB.Controls.Add(chkEnableTalentDB);
        tabTalentDB.Controls.Add(grpTalentDBConnection);
        tabTalentDB.Location = new Point(4, 32);
        tabTalentDB.Name = "tabTalentDB";
        tabTalentDB.Padding = new Padding(3);
        tabTalentDB.Size = new Size(1362, 583);
        tabTalentDB.TabIndex = 9;
        tabTalentDB.Text = "Talent DB";
        // 
        // btnSaveTalentDB
        // 
        btnSaveTalentDB.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnSaveTalentDB.DialogResult = DialogResult.Cancel;
        btnSaveTalentDB.Location = new Point(1292, 737);
        btnSaveTalentDB.Name = "btnSaveTalentDB";
        btnSaveTalentDB.Size = new Size(75, 23);
        btnSaveTalentDB.TabIndex = 46;
        btnSaveTalentDB.Text = "Guardar";
        btnSaveTalentDB.UseVisualStyleBackColor = true;
        btnSaveTalentDB.Click += btnSaveTalentDB_Click;
        // 
        // chkEnableTalentDB
        // 
        chkEnableTalentDB.AutoSize = true;
        chkEnableTalentDB.Location = new Point(22, 15);
        chkEnableTalentDB.Name = "chkEnableTalentDB";
        chkEnableTalentDB.Size = new Size(170, 27);
        chkEnableTalentDB.TabIndex = 0;
        chkEnableTalentDB.Text = "Enable Talent DB";
        chkEnableTalentDB.UseVisualStyleBackColor = true;
        chkEnableTalentDB.CheckedChanged += chkEnableTalentDB_CheckedChanged;
        // 
        // grpTalentDBConnection
        // 
        grpTalentDBConnection.Anchor = AnchorStyles.None;
        grpTalentDBConnection.Controls.Add(cboConnectionType);
        grpTalentDBConnection.Controls.Add(Label1);
        grpTalentDBConnection.Controls.Add(txtDatabaseTalent);
        grpTalentDBConnection.Controls.Add(txtServerTalent);
        grpTalentDBConnection.Controls.Add(lblBase);
        grpTalentDBConnection.Controls.Add(Label3);
        grpTalentDBConnection.Controls.Add(btnTestConnection);
        grpTalentDBConnection.Controls.Add(txtPasswordTalent);
        grpTalentDBConnection.Controls.Add(lblPassword);
        grpTalentDBConnection.Controls.Add(txtUserTalent);
        grpTalentDBConnection.Controls.Add(Label4);
        grpTalentDBConnection.Controls.Add(lblConnectionString);
        grpTalentDBConnection.Enabled = false;
        grpTalentDBConnection.Location = new Point(22, 29);
        grpTalentDBConnection.Name = "grpTalentDBConnection";
        grpTalentDBConnection.Size = new Size(523, 230);
        grpTalentDBConnection.TabIndex = 40;
        grpTalentDBConnection.TabStop = false;
        // 
        // cboConnectionType
        // 
        cboConnectionType.FormattingEnabled = true;
        cboConnectionType.Location = new Point(154, 113);
        cboConnectionType.Name = "cboConnectionType";
        cboConnectionType.Size = new Size(200, 31);
        cboConnectionType.TabIndex = 51;
        // 
        // Label1
        // 
        Label1.AutoSize = true;
        Label1.Location = new Point(14, 113);
        Label1.Name = "Label1";
        Label1.Size = new Size(131, 23);
        Label1.TabIndex = 50;
        Label1.Text = "Tipo Conexión:";
        // 
        // txtDatabaseTalent
        // 
        txtDatabaseTalent.Location = new Point(154, 179);
        txtDatabaseTalent.MaxLength = 200;
        txtDatabaseTalent.Name = "txtDatabaseTalent";
        txtDatabaseTalent.Size = new Size(250, 28);
        txtDatabaseTalent.TabIndex = 48;
        // 
        // txtServerTalent
        // 
        txtServerTalent.Location = new Point(154, 149);
        txtServerTalent.MaxLength = 200;
        txtServerTalent.Name = "txtServerTalent";
        txtServerTalent.Size = new Size(250, 28);
        txtServerTalent.TabIndex = 46;
        // 
        // lblBase
        // 
        lblBase.AutoSize = true;
        lblBase.Location = new Point(15, 179);
        lblBase.Name = "lblBase";
        lblBase.Size = new Size(127, 23);
        lblBase.TabIndex = 47;
        lblBase.Text = "Base de Datos:";
        // 
        // Label3
        // 
        Label3.AutoSize = true;
        Label3.Location = new Point(14, 149);
        Label3.Name = "Label3";
        Label3.Size = new Size(84, 23);
        Label3.TabIndex = 45;
        Label3.Text = "Servidor:";
        // 
        // btnTestConnection
        // 
        btnTestConnection.Anchor = AnchorStyles.None;
        btnTestConnection.DialogResult = DialogResult.Cancel;
        btnTestConnection.Location = new Point(415, 149);
        btnTestConnection.Name = "btnTestConnection";
        btnTestConnection.Size = new Size(100, 60);
        btnTestConnection.TabIndex = 49;
        btnTestConnection.Text = "Probar Conexion";
        btnTestConnection.UseVisualStyleBackColor = true;
        btnTestConnection.Click += btnTestConnection_Click;
        // 
        // txtPasswordTalent
        // 
        txtPasswordTalent.Location = new Point(154, 83);
        txtPasswordTalent.MaxLength = 200;
        txtPasswordTalent.Name = "txtPasswordTalent";
        txtPasswordTalent.Size = new Size(250, 28);
        txtPasswordTalent.TabIndex = 44;
        txtPasswordTalent.UseSystemPasswordChar = true;
        // 
        // lblPassword
        // 
        lblPassword.AutoSize = true;
        lblPassword.Location = new Point(14, 83);
        lblPassword.Name = "lblPassword";
        lblPassword.Size = new Size(89, 23);
        lblPassword.TabIndex = 43;
        lblPassword.Text = "Password:";
        // 
        // txtUserTalent
        // 
        txtUserTalent.Location = new Point(154, 53);
        txtUserTalent.MaxLength = 200;
        txtUserTalent.Name = "txtUserTalent";
        txtUserTalent.Size = new Size(250, 28);
        txtUserTalent.TabIndex = 42;
        // 
        // Label4
        // 
        Label4.AutoSize = true;
        Label4.Location = new Point(14, 53);
        Label4.Name = "Label4";
        Label4.Size = new Size(77, 23);
        Label4.TabIndex = 41;
        Label4.Text = "Usuario:";
        // 
        // lblConnectionString
        // 
        lblConnectionString.AutoSize = true;
        lblConnectionString.Font = new Font("Trebuchet MS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblConnectionString.Location = new Point(15, 28);
        lblConnectionString.Name = "lblConnectionString";
        lblConnectionString.Size = new Size(197, 23);
        lblConnectionString.TabIndex = 40;
        lblConnectionString.Text = "Talent DB Connection:";
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.Location = new Point(1235, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cerrar";
        cmdCancelar.UseVisualStyleBackColor = true;
        cmdCancelar.Click += cmdCancelar_Click;
        // 
        // pnlEstado
        // 
        pnlEstado.Dock = DockStyle.Top;
        pnlEstado.Location = new Point(0, 30);
        pnlEstado.Name = "pnlEstado";
        pnlEstado.Size = new Size(1370, 60);
        pnlEstado.TabIndex = 7;
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 709);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(1370, 40);
        pnlBotones.TabIndex = 8;
        // 
        // scMIIA
        // 
        scMIIA.MachineName = ".";
        // 
        // timerEventos
        // 
        timerEventos.Interval = 10000;
        timerEventos.Tick += timerEventos_Tick;
        // 
        // EventLogADAM
        // 
        EventLogADAM.SynchronizingObject = this;
        // 
        // frmConfiguracion
        // 
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        ClientSize = new Size(1370, 749);
        Controls.Add(pnlPrincipal);
        Controls.Add(pnlEstado);
        Controls.Add(pnlSuperior);
        Controls.Add(pnlBotones);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        Icon = (Icon)resources.GetObject("$this.Icon");
        Name = "frmConfiguracion";
        Text = "Configuración MIIA";
        WindowState = FormWindowState.Maximized;
        Load += frmConfiguracion_Load;
        Resize += frmConfiguracion_Resize;
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        pnlPrincipal.ResumeLayout(false);
        tabParametros.ResumeLayout(false);
        tabServicio.ResumeLayout(false);
        pnlEventosServicio.ResumeLayout(false);
        Panel2.ResumeLayout(false);
        Panel2.PerformLayout();
        pnlServicio.ResumeLayout(false);
        pnlServicio.PerformLayout();
        tabGeneral.ResumeLayout(false);
        pnlGenerales.ResumeLayout(false);
        pnlGenerales.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)nupdTimeConnectionRetries).EndInit();
        ((System.ComponentModel.ISupportInitialize)nupdConnectionRetries).EndInit();
        tabCorreo.ResumeLayout(false);
        pnlCorreo.ResumeLayout(false);
        pnlCorreo.PerformLayout();
        tabClientes.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridParametrosCliente).EndInit();
        pnlBotonesClientes.ResumeLayout(false);
        tabProcedures.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridProcedures).EndInit();
        pnlBotonesProcs.ResumeLayout(false);
        tabOnDemand.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridOnDemand).EndInit();
        Panel1.ResumeLayout(false);
        tabOrderProcess.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)gridOrderProcess).EndInit();
        Panel3.ResumeLayout(false);
        tabTalentDB.ResumeLayout(false);
        tabTalentDB.PerformLayout();
        grpTalentDBConnection.ResumeLayout(false);
        grpTalentDBConnection.PerformLayout();
        pnlBotones.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)EventLogADAM).EndInit();
        ResumeLayout(false);
    }

    #endregion

    private System.Windows.Forms.Button cmdProbar;
    private System.Windows.Forms.Button cmdGuardaCorreo;
    private System.Windows.Forms.TextBox txtTimeOut;
    private System.Windows.Forms.Panel pnlSuperior;
    private System.Windows.Forms.Label lblTitulo;
    private System.Windows.Forms.Label lblTimeOut;
    private System.Windows.Forms.TextBox txtPassword;
    private System.Windows.Forms.Panel pnlCorreo;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtUsuario;
    private System.Windows.Forms.Label lblUsuario;
    private System.Windows.Forms.ComboBox cboSSL;
    private System.Windows.Forms.Label lblSsl;
    private System.Windows.Forms.TextBox txtPuerto;
    private System.Windows.Forms.Label lblPuerto;
    private System.Windows.Forms.TextBox txtServidorCorreo;
    private System.Windows.Forms.Label lblServidor;
    private System.Windows.Forms.ComboBox cboPrioridad;
    private System.Windows.Forms.Label lblPrioridad;
    private System.Windows.Forms.ComboBox cboHtml;
    private System.Windows.Forms.Label lblHtml;
    private System.Windows.Forms.TextBox txtMensaje;
    private System.Windows.Forms.Label lblMensaje;
    private System.Windows.Forms.TextBox txtMail;
    private System.Windows.Forms.Label lblCorreoDe;
    private System.Windows.Forms.TextBox txtTitulo;
    private System.Windows.Forms.Label lblTituloCorreo;
    private System.Windows.Forms.TextBox txtNombre;
    private System.Windows.Forms.Label lblDeCorreo;
    private System.Windows.Forms.TabPage tabGeneral;
    private System.Windows.Forms.Panel pnlGenerales;
    private System.Windows.Forms.TextBox txtCarpetas;
    private System.Windows.Forms.Label lblCarpetas;
    private System.Windows.Forms.Label lblUsarControl;
    private System.Windows.Forms.Label lblVecesEjecutar;
    private System.Windows.Forms.Button cmdRutaOrigen;
    private System.Windows.Forms.Button cmdAceptar;
    private System.Windows.Forms.TextBox txtNombresArchivosCtrl;
    private System.Windows.Forms.TextBox txtRutaDestino;
    private System.Windows.Forms.TextBox txtRutaOrigen;
    private System.Windows.Forms.Label lblNombresArchivosCtrl;
    private System.Windows.Forms.Label lblRutaDestino;
    private System.Windows.Forms.Label lblRutaOrigen;
    private System.Windows.Forms.TabPage tabCorreo;
    private System.Windows.Forms.Panel pnlPrincipal;
    private System.Windows.Forms.TabControl tabParametros;
    private System.Windows.Forms.Button cmdCancelar;
    private System.Windows.Forms.Panel pnlEstado;
    private System.Windows.Forms.Button cmdDetener;
    private System.Windows.Forms.Label lblEstadoServicio;
    private System.Windows.Forms.Button cmdReinicia;
    private System.Windows.Forms.Panel pnlBotones;
    private System.Windows.Forms.FolderBrowserDialog fbdRuta;
    private System.Windows.Forms.Button cmdRutaDestino;
    private System.Windows.Forms.ComboBox cboArchivoControl;
    private System.Windows.Forms.ComboBox cboVeces;
    private System.Windows.Forms.ComboBox cboEjecucionInmediata;
    private System.Windows.Forms.Label lblEjecucionInmediata;
    private System.Windows.Forms.TextBox txtPatron;
    private System.Windows.Forms.Label lblPatron;
    internal System.Windows.Forms.TabPage tabClientes;
    private System.Windows.Forms.DataGridView gridParametrosCliente;
    internal System.Windows.Forms.TabPage tabProcedures;
    private System.Windows.Forms.DataGridView gridProcedures;
    internal System.Windows.Forms.TabPage tabOnDemand;
    private System.Windows.Forms.DataGridView gridOnDemand;
    internal System.Windows.Forms.Panel pnlBotonesClientes;
    private System.Windows.Forms.Button cmdEliminar;
    private System.Windows.Forms.Button cmdModificar;
    private System.Windows.Forms.Button cmdAgregar;
    internal System.Windows.Forms.Panel pnlBotonesProcs;
    private System.Windows.Forms.Button cmdEliminarProc;
    private System.Windows.Forms.Button cmdModificarProc;
    private System.Windows.Forms.Button cmdAgregarProc;
    internal System.Windows.Forms.Panel Panel1;
    private System.Windows.Forms.Button cmdEliminarOnDemand;
    private System.Windows.Forms.Button cmdModificarOnDemand;
    private System.Windows.Forms.Button cmdAgregarOnDemand;
    internal System.ServiceProcess.ServiceController scMIIA;
    private System.Windows.Forms.Label lblNombresArchivosInmediata;
    private System.Windows.Forms.TextBox txtNombresArchivosInmediata;
    internal System.Windows.Forms.TabPage tabServicio;
    internal System.Windows.Forms.Panel pnlEventosServicio;
    internal System.Windows.Forms.Panel pnlServicio;
    internal System.Windows.Forms.Timer timerEventos;
    internal System.Diagnostics.EventLog EventLogADAM;
    internal System.Windows.Forms.ListView lvEventos;
    internal System.Windows.Forms.ImageList ilIconos;
    private System.Windows.Forms.Label lblEventos;
    internal System.Windows.Forms.ColumnHeader ColumnHeader1;
    internal System.Windows.Forms.CheckBox chkActualiza;
    private System.Windows.Forms.Button cmdActualizar;
    private System.Windows.Forms.TextBox txtPasswordGPG;
    private System.Windows.Forms.Label lblContrasenia;
    private System.Windows.Forms.ComboBox cboArchivosEncriptados;
    private System.Windows.Forms.Label lblEncriptados;
    private System.Windows.Forms.ComboBox cboUsarJobsSQL;
    private System.Windows.Forms.Label lblUsarJobsSQL;
    internal System.Windows.Forms.Panel Panel2;
    private System.Windows.Forms.Label lblNotaEventos;
    private System.Windows.Forms.Button cmdEventViewer;
    internal System.Windows.Forms.TabPage tabOrderProcess;
    private System.Windows.Forms.DataGridView gridOrderProcess;
    internal System.Windows.Forms.Panel Panel3;
    private System.Windows.Forms.Button btnDeleteOrderProcess;
    private System.Windows.Forms.Button btnUpdateOrderProcess;
    private System.Windows.Forms.Button btnAddOrderProcess;
    internal System.Windows.Forms.TabPage tabTalentDB;
    internal System.Windows.Forms.CheckBox chkEnableTalentDB;
    internal System.Windows.Forms.GroupBox grpTalentDBConnection;
    internal System.Windows.Forms.ComboBox cboConnectionType;
    private System.Windows.Forms.Label Label1;
    private System.Windows.Forms.TextBox txtDatabaseTalent;
    private System.Windows.Forms.TextBox txtServerTalent;
    private System.Windows.Forms.Label lblBase;
    private System.Windows.Forms.Label Label3;
    private System.Windows.Forms.Button btnTestConnection;
    private System.Windows.Forms.TextBox txtPasswordTalent;
    private System.Windows.Forms.Label lblPassword;
    private System.Windows.Forms.TextBox txtUserTalent;
    private System.Windows.Forms.Label Label4;
    internal System.Windows.Forms.Label lblConnectionString;
    private System.Windows.Forms.Button btnSaveTalentDB;
    private System.Windows.Forms.TextBox txtRutaResumenEnExcel;
    private System.Windows.Forms.Label Label5;
    private System.Windows.Forms.Button cmdRutaResumenEnExcel;
    private System.Windows.Forms.Label Label6;
    internal System.Windows.Forms.NumericUpDown nupdTimeConnectionRetries;
    private System.Windows.Forms.Label lblTimeConnectionRetries;
    internal System.Windows.Forms.NumericUpDown nupdConnectionRetries;
    private System.Windows.Forms.Label lblConnectionRetries;
}

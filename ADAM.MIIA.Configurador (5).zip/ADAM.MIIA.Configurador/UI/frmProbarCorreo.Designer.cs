#nullable enable
namespace ADAM.MIIA.Configurador.UI;

partial class FrmProbarCorreo
{
    private System.ComponentModel.IContainer? components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProbarCorreo));
        cmdAceptar = new Button();
        pnlBotones = new Panel();
        cmdCancelar = new Button();
        txtCorreoElectronico = new TextBox();
        lblTitulo = new Label();
        pnlSuperior = new Panel();
        lblClavePais = new Label();
        pnlBotones.SuspendLayout();
        pnlSuperior.SuspendLayout();
        SuspendLayout();
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdAceptar.DialogResult = DialogResult.Cancel;
        cmdAceptar.FlatStyle = FlatStyle.Popup;
        cmdAceptar.Location = new Point(197, 2);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 2;
        cmdAceptar.Text = "Enviar";
        cmdAceptar.UseVisualStyleBackColor = true;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdAceptar);
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 220);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(459, 46);
        pnlBotones.TabIndex = 15;
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.FlatStyle = FlatStyle.Popup;
        cmdCancelar.Location = new Point(327, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cancelar";
        cmdCancelar.UseVisualStyleBackColor = true;
        cmdCancelar.Click += cmdCancelar_Click;
        // 
        // txtCorreoElectronico
        // 
        txtCorreoElectronico.BorderStyle = BorderStyle.FixedSingle;
        txtCorreoElectronico.Location = new Point(188, 50);
        txtCorreoElectronico.MaxLength = 50;
        txtCorreoElectronico.Name = "txtCorreoElectronico";
        txtCorreoElectronico.Size = new Size(250, 28);
        txtCorreoElectronico.TabIndex = 14;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 10.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(10, 5);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(183, 27);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Prueba de Correo";
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(92, 145, 163);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(459, 30);
        pnlSuperior.TabIndex = 12;
        // 
        // lblClavePais
        // 
        lblClavePais.AutoSize = true;
        lblClavePais.Location = new Point(10, 50);
        lblClavePais.Name = "lblClavePais";
        lblClavePais.Size = new Size(169, 23);
        lblClavePais.TabIndex = 13;
        lblClavePais.Text = "Correo Electrónico:";
        // 
        // FrmProbarCorreo
        // 
        AcceptButton = cmdAceptar;
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        CancelButton = cmdCancelar;
        ClientSize = new Size(459, 266);
        Controls.Add(pnlBotones);
        Controls.Add(txtCorreoElectronico);
        Controls.Add(pnlSuperior);
        Controls.Add(lblClavePais);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        Icon = (Icon)resources.GetObject("$this.Icon");
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "FrmProbarCorreo";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "FrmProbarCorreo";
        Load += FrmProbarCorreo_Load;
        pnlBotones.ResumeLayout(false);
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.Button cmdAceptar;
    private System.Windows.Forms.Panel pnlBotones;
    private System.Windows.Forms.Button cmdCancelar;
    private System.Windows.Forms.TextBox txtCorreoElectronico;
    private System.Windows.Forms.Label lblTitulo;
    private System.Windows.Forms.Panel pnlSuperior;
    private System.Windows.Forms.Label lblClavePais;
}

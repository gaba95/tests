﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public enum ManejoNomina
    {
        periodica = 1,
        interactiva = 2
    }
}

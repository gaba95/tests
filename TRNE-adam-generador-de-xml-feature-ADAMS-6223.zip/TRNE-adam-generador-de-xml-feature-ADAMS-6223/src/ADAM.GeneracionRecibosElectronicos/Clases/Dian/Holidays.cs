﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("vacaciones", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Holidays
    {
        public bool vacacionesCompensadas { get; set; }

        [JsonProperty("fechaInicio")]
        public string FechaInicio { get; set; }

        [JsonProperty("fechaFin")]
        public string FechaFin { get; set; }

        [JsonProperty("numeroDias")]
        public int PagoCantidad { get; set; }

        [JsonProperty("valorPago")]
        public decimal Pago { get; set; }
    }
}

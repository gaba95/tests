using System.Data;
using Microsoft.Data.SqlClient;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Datos.Clases.Common;

namespace ADAM.Recibos.Datos.Clases
{
    public class CatalogoDianSql : ICatalogoDian
    {
        private const string TableName = "Table";
        private const string ParamCompany = "@company";
        private const string ParamCompania = "@compania";
        private const string ParamIdCampo = "@id_campo";
        private const string ParamCampo = "@campo";

        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoDianSql(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public DataSet getDatasetInformationDian(string compania, string anio, string mes, string employee, string id_parent_node, string tipo)
        {
            int connectionRetries = 0;

            // AZ-1071: Added connection tries, so if it fails at the fill or timeout, it doesn�t throw
            // the Exception at first error. This helps to maintain consistency when getting multiple
            // years, months, payrolls, etc
            while (connectionRetries < Database.MaxConnectionRetries)
            {
                try
                {
                    using var dbConnection = this._connectionFactory.CreateConnection();

                    if (dbConnection.State == ConnectionState.Closed)
                        dbConnection.Open();

                    var dt = SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_conceptos_json_dian", TableName, cmd =>
                    {
                        SqlHelpers.AddVarCharParam(cmd, ParamCompany, compania);
                        SqlHelpers.AddVarCharParam(cmd, "@year", anio);
                        SqlHelpers.AddVarCharParam(cmd, "@month", mes);
                        SqlHelpers.AddVarCharParam(cmd, "@employee", employee);
                        SqlHelpers.AddVarCharParam(cmd, "@id_parent_node", id_parent_node);
                        SqlHelpers.AddVarCharParam(cmd, "@tipo", tipo);
                    });

                    if (dt.Rows.Count > 0)
                    {
                        var ds = new DataSet();
                        ds.Tables.Add(dt);
                        return ds;
                    }
                    return null;
                }
                catch
                {
                    connectionRetries++;

                    if (connectionRetries == Database.MaxConnectionRetries)
                        throw;
                }
            }

            return null;
        }

        public DataSet getParentIdCatalog()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT id_padre, tipo 
                                        FROM 
                                            ( 
                                              SELECT DISTINCT id_padre, 
                                                     ISNULL(( 
                                                           SELECT CASE tipo_mapeo 
                                                                    WHEN 'query' 
                                                                      THEN tipo_mapeo 
                                                                    ELSE tipo_concepto 
                                                                  END 
                                                             FROM tb_catalogos_doc_xml_campos_mapas_dian tcm 
                                                            WHERE tcm.id_campo = tch.id 
                                                     ),'query') AS tipo 
                                                FROM tb_catalogos_doc_xml_campos_hijo_dian tch 
                                               WHERE habilitar_mapeo = 1 
                                              UNION 
                                              SELECT 'fechasPago' AS id_padre, 'query' AS tipo 
                                              UNION 
                                              SELECT 'numeroSecuenciaXML' AS id_padre, 'query' AS tipo 
                                            ) Result 
                                       WHERE tipo IS NOT NULL 
                                       ORDER BY 
                                               CASE 
                                                 WHEN id_padre = 'Trabajador' THEN 0 
                                                   ELSE 
                                                     CASE 
                                                       WHEN id_padre = 'Deducciones' OR id_padre = 'Devengados' OR id_padre = 'Empleador'  THEN 1 
                                                       ELSE 2 
                                                     END 
                                                 END";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            dsResult = (dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0 ? dsResult : null);
            return dsResult;
        }

        public DataSet getTypeClassification()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT id_padre,tipo,
                                             CASE tipo
                                               WHEN 'query' THEN ''
                                               WHEN 'percepcion'THEN 'devengados'
                                               WHEN 'InformacionNomina' THEN ''
                                               WHEN 'AjusteNomina' THEN ''
                                               ELSE tipo 
                                             END AS Header,
                                             CASE id_padre
                                               WHEN 'Trabajador' THEN 'Informacion del Empleado'
                                               WHEN 'Pago' THEN 'Pago'
                                               WHEN 'FechasPagos' THEN 'FechasPagos'
                                               WHEN 'numeroSecuenciaXML' THEN 'numeroSecuenciaXML'
                                               WHEN 'InformacionNomina' THEN 'Informaci�n Nomina'
                                               WHEN 'AjusteNomina' THEN 'Ajuste Nomina'
                                               WHEN 'HED' THEN 'HeDs'
                                               WHEN 'HEDDF' THEN 'heddFs'
                                               WHEN 'HEN' THEN 'heNs'
                                               WHEN 'HENDF' THEN 'hendFs'
                                               WHEN 'HRDDF' THEN 'hrddFs'
                                               WHEN 'HRN' THEN 'hrNs'
                                               WHEN 'HRNDF' THEN 'hrndFs'
                                               ELSE id_padre 
                                             END AS subHeader
                                            FROM (SELECT DISTINCT id_padre, 
                                                   ISNULL(
                                                    (SELECT CASE tipo_mapeo 
                                                              WHEN 'query' THEN tipo_mapeo 
                                                              ELSE tipo_concepto 
                                                            END 
                                                       FROM tb_catalogos_doc_xml_campos_mapas_dian tcm
                                                      WHERE tcm.id_campo = tch.id),'query') AS tipo
                                            FROM tb_catalogos_doc_xml_campos_hijo_dian tch 
                                           WHERE habilitar_mapeo = 1
                                            UNION SELECT 'numeroSecuenciaXML' AS id_padre, 'query' AS tipo
                                            UNION SELECT 'InformacionNomina' AS id_padre, 'InformacionNomina' AS tipo
                                            UNION SELECT 'AjusteNomina' AS id_padre, 'AjusteNomina' AS tipo
                                           ) Result WHERE tipo IS NOT NULL
                                            AND NOT id_padre IN ('Empleador', 'InformacionGeneral', 'LugarGeneracionXML', 'NominaIndividual', 'Novedad', 'Periodo', 'ProveedorXML')
                                            ORDER BY
                                            CASE id_padre
                                              WHEN 'Trabajador' THEN 0
                                              WHEN 'InformacionNomina' THEN 1
                                              WHEN 'AjusteNomina' THEN 2
                                              WHEN 'numeroSecuenciaXML' THEN 3
                                              WHEN 'Pago' THEN 4
                                              WHEN 'FechasPagos' THEN 5
                                              WHEN 'percepcion' THEN 6
                                              WHEN 'deduccion' THEN 7
                                              ELSE 
                                                CASE WHEN tipo = 'percepcion' THEN 6
                                                ELSE 8 END
                                              END";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            dsResult = (dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0 ? dsResult : null);
            return dsResult;
        }

        public DataSet getDatasetEmployeesReceiptDian(string compania, string anio, string mes)
        {
            int connectionRetries = 0;

            // AZ-1071: Added connection tries, so if it fails at the fill or timeout, it doesn�t throw
            // the Exception at first error. This helps to maintain consistency when getting multiple
            // years, months, payrolls, etc
            while (connectionRetries < Database.MaxConnectionRetries)
            {
                try
                {
                    using var dbConnection = this._connectionFactory.CreateConnection();

                    if (dbConnection.State == ConnectionState.Closed)
                        dbConnection.Open();

                    var dt = SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_trabajadores_recibo_dian", TableName, cmd =>
                    {
                        SqlHelpers.AddVarCharParam(cmd, ParamCompany, compania);
                        SqlHelpers.AddVarCharParam(cmd, "@year", anio);
                        SqlHelpers.AddVarCharParam(cmd, "@month", mes);
                    });

                    if (dt.Rows.Count > 0)
                    {
                        var ds = new DataSet();
                        ds.Tables.Add(dt);
                        return ds;
                    }
                    return null;
                }
                catch
                {
                    connectionRetries++;

                    if (connectionRetries == Database.MaxConnectionRetries)
                        throw;
                }
            }

            return null;
        }

        public DataSet obtenCorrelativoDian(string compania, string trabajador)
        {
            int connectionRetries = 0;

            while (connectionRetries < Database.MaxConnectionRetries)
            {
                try
                {
                    using var dbConnection = this._connectionFactory.CreateConnection();

                    if (dbConnection.State == ConnectionState.Closed)
                        dbConnection.Open();

                    var ds = new DataSet();
                    ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_correlativo_dian", TableName, cmd =>
                    {
                        SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                        SqlHelpers.AddCharParam(cmd, "@trabajador", 10, trabajador);
                        var p = cmd.CreateParameter();
                        p.ParameterName = "@fecha_envio";
                        p.DbType = DbType.DateTime;
                        p.Value = DateTime.Now;
                        cmd.Parameters.Add(p);
                    }));

                    return ds;
                }
                catch
                {
                    connectionRetries++;

                    if (connectionRetries == Database.MaxConnectionRetries)
                        throw;
                }
            }
            return null;
        }

        public Task<bool> ActualizaBitacoraCorrelativosDian(string compania, string numero, string documento_id, string estado_accion)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            var sqlStmt = new SqlCommand(@"UPDATE tb_bitacora_correlativos_dian 
                                              SET documento_id = @documento_id,
                                                  estado_accion = @estado_accion
                                            WHERE compania = @compania
                                              AND numero = @numero", sqlConnection);

            sqlStmt.Parameters.Add("@documento_id", SqlDbType.VarChar, 50).Value = documento_id;
            sqlStmt.Parameters.Add("@estado_accion", SqlDbType.VarChar, 50).Value = estado_accion;
            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = compania;
            sqlStmt.Parameters.Add("@numero", SqlDbType.VarChar, 150).Value = numero;
            sqlStmt.Prepare();

            return Task<bool>.Factory.FromAsync(sqlStmt.BeginExecuteNonQuery(), asyncResult =>
            {
                int nResult = sqlStmt.EndExecuteNonQuery(asyncResult);
                return nResult != 0;
            });
        }

        public bool AltaResultadoValidacion(string numero, string codigo_error, string mensaje)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"INSERT INTO tb_bitacora_correlativos_dian_resultado_validacion 
                                       VALUES(@numero,@codigo_error,@mensaje)";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Parameters.Add("@numero", SqlDbType.VarChar, 150).Value = numero;
            sqlStmt.Parameters.Add("@codigo_error", SqlDbType.VarChar, 10).Value = codigo_error;
            sqlStmt.Parameters.Add("@mensaje", SqlDbType.VarChar, 1024).Value = mensaje;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public DataSet obtenDatasetBitacoraCorrelativosDianEmpleado(string compania, string trabajador, bool correctos = true)
        {
            SqlCommand sqlStmt;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            if (correctos)
            {
                const string sqlQuery01 = @"SELECT b.compania, b.trabajador, b.fecha_envio, b.prefijo, 
                                                   b.correlativo, b.numero,  b.documento_id, b.estado_accion
                                              FROM tb_bitacora_correlativos_dian AS b
                                             WHERE b.compania = @compania
                                               AND b.trabajador = @trabajador
                                               AND b.documento_id IS NOT NULL
                                             ORDER BY b.fecha_envio";
                sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
            }
            else
            {
                const string sqlQuery02 = @"SELECT b.compania, b.trabajador, b.fecha_envio, b.prefijo, 
                                                   b.correlativo, b.numero,  b.documento_id, b.estado_accion
                                              FROM tb_bitacora_correlativos_dian AS b
                                             WHERE b.compania = @compania
                                               AND b.trabajador = @trabajador
                                             ORDER BY b.fecha_envio";
                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);
            }

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = compania.Trim();
            sqlStmt.Parameters.Add("@trabajador", SqlDbType.Char, 10).Value = trabajador;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet dsListaSeccionesDIAN(string szTipo, string szTipoConcepto = "")
        {
            SqlCommand sqlStmt;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            if (string.IsNullOrEmpty(szTipoConcepto))
            {
                const string sqlQuery01 = @"SELECT tbp.id_campo AS clave,
                                                   RTRIM(tbp.id_campo) AS descripcion
                                              FROM tb_catalogos_doc_xml_campos_padre_dian AS tbp
                                             WHERE (SELECT COUNT(*)
                                                      FROM tb_catalogos_doc_xml_campos_hijo_dian AS tbh
                                                       INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                               AND tbm.tipo_mapeo = @tipoMapeo
                                                     WHERE tbh.id_padre = tbp.id_campo
                                                       AND tbh.habilitar_mapeo = 1) > 0
                                                     ORDER BY tbp.id_campo";
                sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);

                sqlStmt.Parameters.Add("@tipoMapeo", SqlDbType.VarChar, 10).Value = szTipo;
                sqlStmt.Prepare();
            }
            else
            {
                const string sqlQuery02 = @"SELECT tbp.id_campo AS clave,
                                                   RTRIM(tbp.id_campo) AS descripcion
                                              FROM tb_catalogos_doc_xml_campos_padre_dian AS tbp
                                             WHERE (SELECT COUNT(*)
                                                      FROM tb_catalogos_doc_xml_campos_hijo_dian AS tbh
                                                        INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                                AND tbm.tipo_mapeo = @tipoMapeo
                                                                                                                AND tbm.tipo_concepto = @tipoConcepto
                                                     WHERE tbh.id_padre = tbp.id_campo
                                                       AND tbh.habilitar_mapeo = 1) > 0
                                             ORDER BY tbp.id_campo";
                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);

                sqlStmt.Parameters.Add("@tipoMapeo", SqlDbType.VarChar, 10).Value = szTipo;
                sqlStmt.Parameters.Add("@tipoConcepto", SqlDbType.VarChar, 20).Value = szTipoConcepto;
                sqlStmt.Prepare();
            }

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet dsListaCamposDIAN(string szIdPadre, string szTipoMapeo, string szTipoConcepto = "")
        {
            SqlCommand sqlStmt;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            if (string.IsNullOrEmpty(szTipoConcepto))
            {
                const string sqlQuery01 = @"SELECT tbh.id AS 'clave',
                                                   CASE 
                                                     WHEN tbm.tipo_mapeo='query' THEN tbh.id + ' - ' + tbh.id_campo
                                                     ELSE tbh.id_campo
                                                   END AS 'descripcion'
                                              FROM tb_catalogos_doc_xml_campos_hijo_dian tbh
                                                INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                        AND tbm.tipo_mapeo = @tipo_mapeo
                                             WHERE tbh.id_padre = @id_padre 
                                               AND tbh.habilitar_mapeo = 1 
                                             ORDER BY tbh.id";

                sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
                sqlStmt.Parameters.Add("@tipo_mapeo", SqlDbType.VarChar, 10).Value = szTipoMapeo;
                sqlStmt.Parameters.Add("@id_padre", SqlDbType.VarChar, 50).Value = szIdPadre;
            }
            else
            {
                const string sqlQuery02 = @"SELECT tbh.id AS 'clave',
                                                   CASE 
                                                     WHEN tbm.tipo_mapeo='query' THEN tbh.id + ' - ' + tbh.id_campo
                                                     ELSE tbh.id_campo
                                                   END AS 'descripcion'
                                              FROM tb_catalogos_doc_xml_campos_hijo_dian tbh
                                                INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                        AND tbm.tipo_mapeo = @tipo_mapeo
                                               AND tbm.tipo_concepto = CASE 
                                                                         WHEN tbm.tipo_mapeo ='query' THEN tbm.tipo_concepto
                                                                         ELSE @tipo_concepto
                                                                       END 
                                             WHERE tbh.id_padre = @id_padre 
                                               AND tbh.habilitar_mapeo = 1 
                                             ORDER BY tbh.id";

                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);
                sqlStmt.Parameters.Add("@tipo_mapeo", SqlDbType.VarChar, 10).Value = szTipoMapeo;
                sqlStmt.Parameters.Add("@tipo_concepto", SqlDbType.VarChar, 20).Value = szTipoConcepto;
                sqlStmt.Parameters.Add("@id_padre", SqlDbType.VarChar, 50).Value = szIdPadre;
            }

            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDataSetConceptosAux()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tbh.id AS 'clave', tbh.id_padre,
                                             CASE 
                                               WHEN tbm.tipo_mapeo='query' THEN tbh.id + ' - ' + tbh.id_campo
                                               ELSE tbh.id_campo
                                             END AS 'descripcion',
                                             tbm.tipo_concepto
                                        FROM tb_catalogos_doc_xml_campos_hijo_dian tbh
                                          INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                  AND tbm.tipo_mapeo = 'concepto'
                                       WHERE tbh.habilitar_mapeo = 1
                                       ORDER BY tbh.id";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDataSetCatalogosAux()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tbh.id AS clave,
                                             CASE tbm.tipo_mapeo
                                               WHEN 'query' THEN tbh.id + ' - ' + tbh.id_campo
                                               ELSE tbh.id_campo
                                             END AS descripcion,
                                             tbh.id_padre
                                        FROM tb_catalogos_doc_xml_campos_hijo_dian tbh
                                          INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian tbm ON tbh.id = tbm.id_campo
                                                                                               AND tbm.tipo_mapeo = 'query'
                                       WHERE tbh.habilitar_mapeo = 1
                                       ORDER BY tbh.id";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetTablaDIAN(string szIdCampo)
        {
            string table;
            SqlCommand sqlStmt;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            try
            {
                sqlStmt = new SqlCommand(@"SELECT tabla_dian 
                                             FROM tb_catalogos_doc_xml_campos_mapas_dian 
                                            WHERE id_campo=@id_campo", sqlConnection);

                sqlStmt.Parameters.Add(ParamIdCampo, SqlDbType.VarChar, 10).Value = szIdCampo;
                sqlStmt.Prepare();

                table = (string)sqlStmt.ExecuteScalar();
            }
            catch 
            { 
                return null; 
            }

            sqlStmt = null;

            switch (table)
            {
                case "tb_catalogo_paises_dian":
                    const string sqlQuery01 = @"SELECT 'Pais' AS tipo, 
                                                       codigo_alfa2 AS clave, 
                                                       nombre_comun AS descripcion 
                                                  FROM tb_catalogo_paises_dian 
                                                 ORDER BY codigo_alfa2";
                    sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
                    break;
                case "tb_catalogo_departamentos_dian":
                    const string sqlQuery02 = @"SELECT 'Departamento' AS tipo, 
                                                       codigo_departamento AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_departamentos_dian 
                                                 ORDER BY codigo_alfa2, codigo_departamento";
                    sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);
                    break;
                case "tb_catalogo_municipios_dian":
                    const string sqlQuery03 = @"SELECT 'Municipio' AS tipo, 
                                                       codigo_municipio AS clave, 
                                                       nombre_municipio AS descripcion 
                                                  FROM tb_catalogo_municipios_dian 
                                                 ORDER BY codigo_alfa2, codigo_municipio";
                    sqlStmt = new SqlCommand(sqlQuery03, sqlConnection);
                    break;
                case "tb_catalogo_monedas_dian":
                    const string sqlQuery04 = @"SELECT 'Moneda' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_monedas_dian 
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery04, sqlConnection);
                    break;
                case "tb_catalogo_tipo_contrato_dian":
                    const string sqlQuery05 = @"SELECT 'Tipo Contrato' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_tipo_contrato_dian 
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery05, sqlConnection);
                    break;
                case "tb_catalogo_tipo_doc_identidad_dian":
                    const string sqlQuery06 = @"SELECT 'Tipo Identificaci�n' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_tipo_doc_identidad_dian
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery06, sqlConnection);
                    break;
                case "tb_catalogo_medios_pago_dian":
                    const string sqlQuery07 = @"SELECT 'Medio de Pago' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_medios_pago_dian 
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery07, sqlConnection);
                    break;
                case "tb_catalogo_periodo_nomina_dian":
                    const string sqlQuery08 = @"SELECT 'Frecuencia de Pago' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_periodo_nomina_dian 
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery08, sqlConnection);
                    break;
                case "tb_catalogo_tipo_trabajador_dian":
                    const string sqlQuery09 = @"SELECT 'Tipo Trabajador' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_tipo_trabajador_dian 
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery09, sqlConnection);
                    break;
                case "tb_catalogo_tipos_incapacidad_dian":
                    const string sqlQuery10 = @"SELECT 'Tipo Incapacidad' AS tipo, 
                                                       codigo AS clave, 
                                                       descripcion AS descripcion 
                                                  FROM tb_catalogo_tipos_incapacidad_dian
                                                 ORDER BY codigo";
                    sqlStmt = new SqlCommand(sqlQuery10, sqlConnection);
                    break;
            }

            if (sqlStmt != null)
            { 
                sqlStmt.Prepare();
                return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            }
            else
            {
                return null;
            }
        }
        
        public DataSet obtenCatalogoAdamDIAN(string id_campo, string param1 = "")
        {
            int connectionRetries = 0;

            while (connectionRetries < Database.MaxConnectionRetries)
            {
                try
                {
                    using var dbConnection = this._connectionFactory.CreateConnection();

                    if (dbConnection.State == ConnectionState.Closed)
                        dbConnection.Open();

                    var dt = SqlHelpers.ExecuteSpToDataTable(dbConnection, "usp_obtiene_catalogo_adam_dian", TableName, cmd =>
                    {
                        SqlHelpers.AddVarCharParam(cmd, ParamIdCampo, id_campo);
                        SqlHelpers.AddVarCharParam(cmd, ParamCompania, param1);
                    });

                    if (dt.Rows.Count > 0)
                    {
                        var ds = new DataSet();
                        ds.Tables.Add(dt);
                        return ds;
                    }
                    return null;
                }
                catch
                {
                    connectionRetries++;

                    if (connectionRetries == Database.MaxConnectionRetries)
                        throw;
                }
            }

            return null;
        }

        public bool altaRelacionDatoCatalogoDIAN(string szCompania, string szCampo, string szClaveDian, string szClaveAdam)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"INSERT INTO tb_rel_catalogos_dian_adam (compania, id_campo, clave_dian, clave_adam) 
                                       VALUES (@Compania, @Campo, @ClaveDian, @ClaveAdam)";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add("@Compania", SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add("@Campo", SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Parameters.Add("@ClaveDian", SqlDbType.VarChar, 10).Value = szClaveDian;
            sqlStmt.Parameters.Add("@ClaveAdam", SqlDbType.VarChar, 20).Value = szClaveAdam;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public bool bajaRelacionDatoCatalogoDIAN(string szCompania, string szCampo, string szClaveDian, string szClaveAdam)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"DELETE FROM tb_rel_catalogos_dian_adam 
                                       WHERE compania = @compania 
                                         AND id_campo = @id_campo 
                                         AND clave_dian = @clave_dian 
                                         AND clave_adam = @clave_adam";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add(ParamIdCampo, SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Parameters.Add("@clave_dian", SqlDbType.VarChar, 10).Value = szClaveDian;
            sqlStmt.Parameters.Add("@clave_adam", SqlDbType.VarChar, 10).Value = szClaveAdam;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public DataSet obtenDatasetRelacionCatalogosDIAN(string szCompania, string szCampo, string szClaveDian)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT compania, id_campo, clave_dian, clave_adam
                                        FROM tb_rel_catalogos_dian_adam
                                       WHERE compania = @compania
                                         AND id_campo = @id_campo
                                         AND clave_dian = @clave_dian
                                       ORDER BY compania, id_campo, clave_dian";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add(ParamIdCampo, SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Parameters.Add("@clave_dian", SqlDbType.VarChar, 10).Value = szClaveDian;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetTreeViewCatalogosDIAN()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT rel.compania, c.nombre_cia, id_campo, clave_dian, clave_adam
                                        FROM tb_rel_catalogos_dian_adam as rel
                                         INNER JOIN companias as c ON rel.compania = c.compania
                                       ORDER BY rel.compania, c.nombre_cia, id_campo, clave_dian";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetTreeViewCatalogosDIANByCompany(string company)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT rel.compania, c.nombre_cia, id_campo, clave_dian, clave_adam
                                        FROM tb_rel_catalogos_dian_adam as rel
                                          INNER JOIN companias as c ON rel.compania = c.compania
                                       WHERE rel.compania = @company
                                       ORDER BY rel.compania, c.nombre_cia, id_campo, clave_dian";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Parameters.Add(ParamCompany, SqlDbType.Char, 4).Value = company;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetTreeViewConceptosDIAN()
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tbrel.compania,
                                             tbrel.id_campo,
                                             tbrel.concepto_adam,
                                             cn.descripcion
                                        FROM tb_rel_conceptos_dian_adam tbrel
                                          INNER JOIN conceptos cn ON cn.concepto = tbrel.concepto_adam
                                       ORDER BY tbrel.id_campo, tbrel.concepto_adam";
            var sqlStmt= new SqlCommand(sqlQuery, sqlConnection);
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetTreeViewConceptosDIANByCompany(string company)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tbrel.compania, c.nombre_cia, tbrel.id_campo, 
                                             tbrel.concepto_adam, cn.descripcion
                                        FROM tb_rel_conceptos_dian_adam tbrel
                                          INNER JOIN conceptos cn ON cn.concepto = tbrel.concepto_adam
                                          INNER JOIN companias c ON tbrel.compania = c.compania
                                       WHERE tbrel.compania = @company
                                       ORDER BY tbrel.id_campo, tbrel.concepto_adam";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompany, SqlDbType.Char, 4).Value = company;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public DataSet obtenDatasetConceptosRelacionarDIAN(string tipoConcepto)
        {
            SqlCommand sqlStmt;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            if (tipoConcepto.Equals("deduccion"))
            {
                const string sqlQuery01 = @"SELECT concepto, 
                                                  RTRIM(concepto) + '--' + RTRIM(descripcion) AS descripcion 
                                             FROM conceptos 
                                            WHERE tipo_transaccion IN (2,3,5)
                                            ORDER BY concepto";
                sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
            }
            else
            {
                const string sqlQuery02 = @"SELECT concepto, 
                                                   RTRIM(concepto) + '--' + RTRIM(descripcion) AS descripcion 
                                              FROM conceptos 
                                             WHERE tipo_transaccion IN (1,2,3,4,5)
                                             ORDER BY concepto";
                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);
            }

            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public bool getDatasetConceptosADAM(string tipoConcepto, string szConcepto)
        {
            SqlCommand sqlStmt;

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            if (tipoConcepto.Equals("deduccion"))
            {
                const string sqlQuery01 = @"SELECT concepto 
                                             FROM conceptos 
                                            WHERE concepto = @concept
                                              AND tipo_transaccion IN (2,3,5)
                                            ORDER BY concepto";
                sqlStmt = new SqlCommand(sqlQuery01, sqlConnection);
            }
            else
            {
                const string sqlQuery02 = @"SELECT concepto 
                                             FROM conceptos 
                                            WHERE concepto = @concept
                                              AND tipo_transaccion IN (1,2,3,4,5)
                                            ORDER BY concepto";
                sqlStmt = new SqlCommand(sqlQuery02, sqlConnection);
            }

            sqlStmt.Parameters.Add("@concept", SqlDbType.SmallInt).Value = szConcepto;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            return (dsResult != null && dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0);
        }

        public bool altaRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"INSERT INTO tb_rel_conceptos_dian_adam 
                                       VALUES (@compania, @campo, @concepto)";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add(ParamCampo, SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Parameters.Add("@concepto", SqlDbType.VarChar, 10).Value = szConcepto;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }

        public bool existRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT COUNT(*) 
                                        FROM tb_rel_conceptos_dian_adam 
                                       WHERE compania = @compania 
                                         AND id_campo = @campo 
                                         AND concepto_adam = @concepto";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add(ParamCampo, SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Parameters.Add("@concepto", SqlDbType.VarChar, 10).Value = szConcepto;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, true);
        }

        public DataSet obtenDatasetRelacionConceptosDIAN(string szCompania, string szCampo)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"SELECT tbrel.id_campo, tbrel.concepto_adam, cn.descripcion
                                        FROM tb_rel_conceptos_dian_adam tbrel
                                          INNER JOIN conceptos cn ON cn.concepto = tbrel.concepto_adam
                                       WHERE tbrel.compania = @compania
                                         AND tbrel.id_campo = @campo
                                       ORDER BY tbrel.id_campo, tbrel.concepto_adam";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add(ParamCampo, SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
        }

        public bool bajaRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = @"DELETE FROM tb_rel_conceptos_dian_adam 
                                       WHERE compania = @compania 
                                         AND id_campo = @campo 
                                         AND concepto_adam = @concepto";
            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection);

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = szCompania;
            sqlStmt.Parameters.Add(ParamCampo, SqlDbType.VarChar, 10).Value = szCampo;
            sqlStmt.Parameters.Add("@concepto", SqlDbType.VarChar, 10).Value = szConcepto;
            sqlStmt.Prepare();

            return SqlCommandExecutor.Request(sqlStmt, false);
        }
    }
}

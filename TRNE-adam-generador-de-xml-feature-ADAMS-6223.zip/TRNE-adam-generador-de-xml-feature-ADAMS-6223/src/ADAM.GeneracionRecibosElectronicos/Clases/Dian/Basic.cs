﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("basico", ItemNullValueHandling = NullValueHandling.Include)]
    public class Basic
    {
        [JsonProperty("diasTrabajados")]
        public int SueldoTrabajadoCantidad { get; set; } = 0;

        [JsonProperty("sueldoTrabajado")]
        public decimal SueldoTrabajado { get; set; } = 0.0M;
    }
}

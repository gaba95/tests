﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Principal.Test.Helpers
{
    public class WhiteListAssertions
    {
        public static void AssertContainsExpectedKeysAndSameValues(
            IReadOnlyDictionary<string, string> whitelist,
            string whitelistName,
            IEnumerable<string> expectedKeys)
        {
            Assert.IsNotNull(whitelist, $"El Diccionario {whitelistName} no debe ser null");
            Assert.IsTrue(whitelist.Count>0, $"El diccionario {whitelistName} debe contener al menos una entrada");

            var expectedKeyList = expectedKeys?.ToList() ?? new List<string>();
            Assert.IsTrue(expectedKeyList.Count > 0, $"No se proporcionaron llaves esperadas para {whitelistName}");

            foreach (var key in expectedKeyList)
            {
                Assert.IsTrue(whitelist.ContainsKey(key), $"Falta la clave esperada en {whitelistName}: {key}");
            }

            foreach(var key in expectedKeyList)
            {
                Assert.AreEqual(key, whitelist[key], $"El valor para {key} en {whitelistName} debería ser {key}. ");
            }

            var duplicates = whitelist.Keys
                .GroupBy(k => k, StringComparer.OrdinalIgnoreCase)
                .Where(g=>g.Count()>1)
                .Select(g => g.Key)
                .ToList();

            Assert.AreEqual(0, duplicates.Count, $"No deberian haber llaves duplucadas en {whitelistName}");
        }

        public static void AssertNoEmptyOrWhitespaceKeyAndValues(IReadOnlyDictionary<string, string> whitelist, string whitelistName)
        {
            Assert.IsNotNull(whitelist, $"El Diccionario {whitelistName} no debe ser null");

            foreach(var kvp in whitelist)
            {
                Assert.IsFalse(string.IsNullOrEmpty(kvp.Key), $"{whitelistName} contiene una clave vacía o nula");
                Assert.IsFalse(string.IsNullOrEmpty(kvp.Value), $"{whitelistName} contiene un valor vacío o nulo");

                Assert.AreEqual(kvp.Key.Trim(),kvp.Key, $"{whitelistName} contiene una clave con espacios");
                Assert.AreEqual(kvp.Value.Trim(), kvp.Value, $"{whitelistName} contiene un valor con espacios");
            }
        }
    }
}

using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics.CodeAnalysis;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmCambiaRegimen : Form
    {
        #region Properties

        private ICatalogoAdicional _catalogoAdicional;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FrmRegimenContratacion FrmRegimen { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataGridView gridTrabajadores { get; set; }

        #endregion

        #region Events

        private void FrmCambiaRegimen_Load(object sender, EventArgs e)
        {
            inicializaClase();
        }
     
        private void cmdCambiar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            foreach (DataGridViewRow renglon in gridTrabajadores.SelectedRows)
            {
                GuardaCambio(renglon.Cells["compania"].Value.ToString(), renglon.Cells["trabajador"].Value.ToString());
            }

            this.FrmRegimen.LlenaGridTrabajadores();
            this.Cursor = Cursors.Default;
            this.Close();
        }

        #endregion

        #region Methods

        public FrmCambiaRegimen()
        {
            InitializeComponent();
        }

        private void inicializaClase()
        {
            if (gridTrabajadores.SelectedRows.Count == 1)
            {
                lblTrabajador.Text = "Empleado: " + gridTrabajadores.SelectedRows[0].Cells["trabajador"].Value.ToString();
                lblNombreTrabajador.Text = gridTrabajadores.SelectedRows[0].Cells["nombre"].Value.ToString();
            }
            else
            {
                lblTrabajador.Text = "Total de Empleados seleccionados: " + gridTrabajadores.SelectedRows.Count.ToString();
                lblNombreTrabajador.Text = "";
            }

            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            LlenaComboRegimen();
        }

        private void LlenaComboRegimen()
        {
            try
            {
                cboRegimen.ValueMember = "clave";
                cboRegimen.DisplayMember = "descripcion";

                cboRegimen.DataSource = _catalogoAdicional.obtenDatasetRegimen().Tables[0];

                if (gridTrabajadores.SelectedRows.Count == 1
                    && int.Parse(gridTrabajadores.SelectedRows[0].Cells["regimen"].Value.ToString()) != 0) 
                        cboRegimen.SelectedValue = int.Parse(gridTrabajadores.SelectedRows[0].Cells["regimen"].Value.ToString());

            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }

        }

        private void GuardaCambio(string compania, string trabajador)
        {
            try
            {
                _catalogoAdicional.AltaRelacionRegimen(compania, trabajador, cboRegimen.SelectedValue.ToString());
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al guardar el registro, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }

        }

        #endregion
    
    }
}

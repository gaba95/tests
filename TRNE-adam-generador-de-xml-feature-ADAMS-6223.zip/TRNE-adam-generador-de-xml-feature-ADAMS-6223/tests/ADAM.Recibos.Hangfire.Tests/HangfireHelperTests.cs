﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ADAM.Recibos.Hangfire;
using ADAM.Recibos.Hangfire.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Hangfire.Tests
{
    [TestClass]
    public class HangfireHelperTests
    {
        private EmployeeRequest GetEmployees()
        {
            return new EmployeeRequest
            {
                Culture = "es-GT",
                Country = "GT",
                ProcessId = Guid.NewGuid().ToString(),
                TotalEmployees = "1",
                Employees = new List<EmployeeInfo>
                 {
                 new EmployeeInfo
                     {
                     Compania = "01",
                     TipoNomina = "TP",
                     ClaseNomina = "CN",
                     Anio = "2026",
                     Periodo = "1",
                     Trabajador = "12345",
                     NumeroLiquidacion = "1",
                     ManejoNomina = "2"
                     }
                 }
            };
        }

        [TestMethod]
        [DataRow(null)]
        [DataRow("")]
        [DataRow("url-invalida")]
        public async Task CreateEmployeeRequestAsync_ThrowsArgumentException(string url)
        {
            var request = GetEmployees();

            await Assert.ThrowsAsync<ArgumentException>(() => HangfireHelper.CreateEmployeeRequestAsync(url, "/resultado/prueba", request));
        }

        [TestMethod]
        public async Task CreateEmployeeRequestAsync_CaptureException()
        {
            var request = GetEmployees();
            string urlValida = "https://api.adam-pruebas.com";
            string endpoint = "/recibos/crear";
            Exception exception = null;

            try
            {
                await HangfireHelper.CreateEmployeeRequestAsync(urlValida, endpoint, request);
            }
            catch (Exception ex)
            {
                exception = ex;
            }

            Assert.IsNotNull(exception, "Se esperaba una excepción");
        }

        [TestMethod]
        public async Task CreateEmployeeRequestAsync_RequestNull()
        {
            Exception exception = null;

            try
            {
                await HangfireHelper.CreateEmployeeRequestAsync("https://api.test.com", "/api", null);
            }
            catch (Exception ex)
            {
                exception = ex;
            }

            Assert.IsNotNull(exception, "El envío de un request nulo falla");
        }

        [TestMethod]
        [DataRow("ftp://server.com")]
        [DataRow("file:///path")]
        public async Task CreateEmployeeRequestAsync_NonHttpScheme_ThrowsArgumentException(string url)
        {
            var request = GetEmployees();

            await Assert.ThrowsAsync<ArgumentException>(
                () => HangfireHelper.CreateEmployeeRequestAsync(url, "/endpoint", request));
        }

        [TestMethod]
        public async Task CreateEmployeeRequestAsync_EmptyEndpoint_WrapsException()
        {
            var request = GetEmployees();
            string urlValida = "https://api.adam-pruebas.com";

            Exception exception = null;
            try
            {
                await HangfireHelper.CreateEmployeeRequestAsync(urlValida, "", request);
            }
            catch (Exception ex)
            {
                exception = ex;
            }

            Assert.IsNotNull(exception);
        }

        [TestMethod]
        public async Task CreateEmployeeRequestAsync_WithValidUrl_ThrowsException()
        {
            var request = GetEmployees();
            string urlValida = "https://api.adam-pruebas-inexistente.com";
            string endpoint = "/recibos/crear";

            Exception exception = null;
            try
            {
                await HangfireHelper.CreateEmployeeRequestAsync(urlValida, endpoint, request);
            }
            catch (Exception ex)
            {
                exception = ex;
            }

            Assert.IsNotNull(exception, "Debe lanzar una excepción");
        }

        [TestMethod]
        public async Task CreateEmployeeRequestAsync_WithEmptyEmployeeList_StillThrows()
        {
            var request = new EmployeeRequest
            {
                Culture = "es-MX",
                Country = "MX",
                ProcessId = Guid.NewGuid().ToString(),
                TotalEmployees = "0",
                Employees = new List<EmployeeInfo>()
            };

            Exception exception = null;
            try
            {
                await HangfireHelper.CreateEmployeeRequestAsync("https://api.adam-pruebas.com", "/api", request);
            }
            catch (Exception ex)
            {
                exception = ex;
            }

            Assert.IsNotNull(exception);
        }
    }
}
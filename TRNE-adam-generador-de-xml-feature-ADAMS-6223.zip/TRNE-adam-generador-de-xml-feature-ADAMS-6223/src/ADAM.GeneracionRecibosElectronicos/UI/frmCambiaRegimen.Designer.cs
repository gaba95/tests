namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmCambiaRegimen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCambiaRegimen));
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdCambiar = new System.Windows.Forms.Button();
            this.cboRegimen = new System.Windows.Forms.ComboBox();
            this.lblRegimen = new System.Windows.Forms.Label();
            this.lblNombreTrabajador = new System.Windows.Forms.Label();
            this.lblTrabajador = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(346, 200);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 13;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // cmdCambiar
            // 
            this.cmdCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCambiar.Location = new System.Drawing.Point(200, 200);
            this.cmdCambiar.Name = "cmdCambiar";
            this.cmdCambiar.Size = new System.Drawing.Size(110, 50);
            this.cmdCambiar.TabIndex = 12;
            this.cmdCambiar.Text = "Cambiar &Régimen";
            this.cmdCambiar.UseVisualStyleBackColor = true;
            this.cmdCambiar.Click += new System.EventHandler(this.cmdCambiar_Click);
            // 
            // cboRegimen
            // 
            this.cboRegimen.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboRegimen.DropDownWidth = 350;
            this.cboRegimen.FormattingEnabled = true;
            this.cboRegimen.Location = new System.Drawing.Point(206, 110);
            this.cboRegimen.Name = "cboRegimen";
            this.cboRegimen.Size = new System.Drawing.Size(250, 26);
            this.cboRegimen.TabIndex = 11;
            // 
            // lblRegimen
            // 
            this.lblRegimen.AutoSize = true;
            this.lblRegimen.Location = new System.Drawing.Point(200, 80);
            this.lblRegimen.Name = "lblRegimen";
            this.lblRegimen.Size = new System.Drawing.Size(54, 18);
            this.lblRegimen.TabIndex = 10;
            this.lblRegimen.Text = "Régimen";
            // 
            // lblNombreTrabajador
            // 
            this.lblNombreTrabajador.Location = new System.Drawing.Point(10, 130);
            this.lblNombreTrabajador.Name = "lblNombreTrabajador";
            this.lblNombreTrabajador.Size = new System.Drawing.Size(180, 100);
            this.lblNombreTrabajador.TabIndex = 9;
            this.lblNombreTrabajador.Text = "----";
            // 
            // lblTrabajador
            // 
            this.lblTrabajador.Location = new System.Drawing.Point(10, 80);
            this.lblTrabajador.Name = "lblTrabajador";
            this.lblTrabajador.Size = new System.Drawing.Size(180, 50);
            this.lblTrabajador.TabIndex = 8;
            this.lblTrabajador.Text = "Empleado:";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.Location = new System.Drawing.Point(10, 20);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(146, 60);
            this.lblDescripcion.TabIndex = 7;
            this.lblDescripcion.Text = "Modificar el Régimen de Contratación del Empleado Seleccionado";
            // 
            // FrmCambiaRegimen
            // 
            this.AcceptButton = this.cmdCambiar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(484, 262);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdCambiar);
            this.Controls.Add(this.cboRegimen);
            this.Controls.Add(this.lblRegimen);
            this.Controls.Add(this.lblNombreTrabajador);
            this.Controls.Add(this.lblTrabajador);
            this.Controls.Add(this.lblDescripcion);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCambiaRegimen";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cambio de Régimen";
            this.Load += new System.EventHandler(this.FrmCambiaRegimen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Button cmdCambiar;
        private System.Windows.Forms.ComboBox cboRegimen;
        private System.Windows.Forms.Label lblRegimen;
        private System.Windows.Forms.Label lblNombreTrabajador;
        private System.Windows.Forms.Label lblTrabajador;
        private System.Windows.Forms.Label lblDescripcion;
    }
}
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.Recibos.Datos.Clases.CatalogoAdicional
{
    public class CatalogoAdicionalOracle : ICatalogoAdicional
    {
        private const string ParamTipoConcepto = "@tipoConcepto";

        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoAdicionalOracle(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public bool CheckDbConnection()
        {
            return _connectionFactory.CheckConnection();
        }

        public DataSet obtenDatasetTrabajadoresRecibo(string compania, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_trabajadores_recibo_sat";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.CommandType = CommandType.StoredProcedure;
            oracleStmt.Parameters.Add("i_compania", OracleDbType.Char).Value = compania;
            oracleStmt.Parameters.Add("i_tipo_nomina", OracleDbType.Char).Value = tipoNomina;
            oracleStmt.Parameters.Add("i_clase_nomina", OracleDbType.Char).Value = claseNomina;
            oracleStmt.Parameters.Add("i_anio", OracleDbType.Int16).Value = anio;
            oracleStmt.Parameters.Add("i_periodo", OracleDbType.Int32).Value = periodo;
            oracleStmt.Parameters.Add("i_manejo_nomina", OracleDbType.Int16).Value = manejoNomina;
            oracleStmt.Parameters.Add(new OracleParameter("i_return_value", OracleDbType.RefCursor, 0, ParameterDirection.Output, false, 0, 0, "", DataRowVersion.Current, null));
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public string obtenCompaniasIdiomas()
        {
            return "";
        }

        public DataSet obtenDatasetCompanias(string szLangCode)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            // AZ-1061: Add registro_fiscal, to obtain company id sent to stamping system
            const string oracleQuery = @"SELECT c.compania, c.nombre_cia, c.registro_fiscal 
                                           FROM companias c
                                            INNER JOIN aut_companias at ON at.compania = c.compania
                                          WHERE at.usuario = @user";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@user", OracleDbType.Varchar2).Value = this._connectionFactory.ApplicationUser;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetClasesNomina(string compania)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT cn.clase_nomina, cn.descripcion
                                           FROM clases_nomina cn
                                            INNER JOIN rel_usu_clase_nom rucn ON rucn.clase_nomina = cn.clase_nomina
                                            INNER JOIN rel_tipo_clase_nomina rel ON rel.clase_nomina = cn.clase_nomina
                                          WHERE rucn.usuario = @user
                                            AND rel.compania = @company";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@user", OracleDbType.Varchar2).Value = this._connectionFactory.ApplicationUser;
            oracleStmt.Parameters.Add("@company", OracleDbType.Varchar2).Value = compania;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetTiposNomina(string compania)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT t.tipo_nomina, 
                                                RTRIM(t.descripcion) AS descripcion, 
                                                t.manejo
                                           FROM tipos_nomina t
                                            INNER JOIN rel_tipo_clase_nomina rel ON rel.tipo_nomina = t.tipo_nomina 
                                          WHERE rel.compania = @company";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@company", OracleDbType.Varchar2).Value = compania;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenBasesDisponibles()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT name 
                                           FROM sysdatabases 
                                          WHERE UPPER(name)<>'FILESYSTEMSQL'";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenListaPeriodosMes(string compania, string tipoNomina, int anio, int mesAcumular)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT cp.periodo
                                           FROM calendario_procesos cp 
                                             INNER JOIN cal_proc_cias cpc ON cpc.id_calendario = cp.id_calendario
                                          WHERE cp.tipo_nomina = @tipoNomina
                                            AND cp.anio = @anio
                                            AND cp.mes_acumular @mesAcumular
                                            AND cpc.compania = @compania";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@tipoNomina", OracleDbType.Varchar2).Value = tipoNomina;
            oracleStmt.Parameters.Add("@anio", OracleDbType.Int16).Value = anio;
            oracleStmt.Parameters.Add("@mesAcumular", OracleDbType.Varchar2).Value = mesAcumular;
            oracleStmt.Parameters.Add("@compania", OracleDbType.Varchar2).Value = mesAcumular;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        #region Metodos Tipos Percepcion

        public DataSet obtenDatasetTiposPercepcionDeduccion(int tipo)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT clave, descripcion 
                                           FROM tipos_percepcion_deduccion
                                          WHERE tipo_concepto_sat = @tipo
                                          ORDER BY clave";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@tipo", OracleDbType.Varchar2).Value = tipo;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetDescripcionTipos()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT item, RTRIM(descripcion) AS descripcion 
                                           FROM criterios_valores 
                                          WHERE campo = 'tipo_concepto_sat'";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetRelacionConceptos(int tipoConcepto, string claveTipo)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT rct.tipo_concepto_sat, rct.clave, rct.concepto, c.descripcion
                                           FROM rel_conceptos_tipos_sat12 rct
                                             INNER JOIN conceptos c ON c.concepto = rct.concepto
                                          WHERE rct.tipo_concepto_sat = @tipoConcepto
                                            AND rct.clave = @claveTipo 
                                          ORDER BY rct.concepto";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add(ParamTipoConcepto, OracleDbType.Int16).Value = tipoConcepto;
            oracleStmt.Parameters.Add("@claveTipo", OracleDbType.Varchar2).Value = claveTipo.Trim();
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetConceptosRelacionar(int tipoConcepto, string claveTipo)
        {
            switch (tipoConcepto)
            {
                case 2: // Deduccion
                    return FetchConceptosRelacionarDeducciones(tipoConcepto);

                case 4: // Incapacidad
                    return FetchConceptosRelacionarIncapacidad(tipoConcepto);

                default: // Percepciones / Otros Pagos
                    return FetchConceptosRelacionarDefault(tipoConcepto);
            }
        }

        internal virtual DataSet FetchConceptosRelacionarDeducciones(int tipoConcepto)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string sqlQuery01 = @"SELECT concepto, RTRIM(concepto) || '--' || RTRIM(descripcion) AS descripcion 
                                                  FROM conceptos
                                                 WHERE concepto NOT IN (SELECT concepto
                                                                          FROM rel_conceptos_tipos_sat12
                                                                         WHERE tipo_concepto_sat = @tipoConcepto)
                                                   AND tipo_transaccion IN (2,3,5)
                                                 ORDER BY concepto";

            var oracleStmt01 = new OracleCommand(sqlQuery01, oracleConnection);
            oracleStmt01.Parameters.Add(ParamTipoConcepto, OracleDbType.Int16).Value = tipoConcepto;
            oracleStmt01.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt01));
        }

        internal virtual DataSet FetchConceptosRelacionarIncapacidad(int tipoConcepto)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string sqlQuery02 = @"SELECT concepto, RTRIM(concepto) || '--' || RTRIM(descripcion) AS descripcion 
                                                  FROM conceptos
                                                 WHERE concepto NOT IN (SELECT concepto 
                                                                          FROM rel_conceptos_tipos_sat12 
                                                                         WHERE tipo_concepto_sat = @tipoConcepto)
                                                   AND tipo_transaccion IN (1,2,3,5)
                                                 ORDER BY concepto";

            var oracleStmt02 = new OracleCommand(sqlQuery02, oracleConnection);
            oracleStmt02.Parameters.Add(ParamTipoConcepto, OracleDbType.Int16).Value = tipoConcepto;
            oracleStmt02.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt02));
        }

        internal virtual DataSet FetchConceptosRelacionarDefault(int tipoConcepto)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string sqlQuery03 = @"SELECT concepto, RTRIM(concepto) || '--' || RTRIM(descripcion) AS descripcion 
                                                  FROM conceptos
                                                 WHERE concepto NOT IN (SELECT concepto
                                                                          FROM rel_conceptos_tipos_sat12
                                                                         WHERE tipo_concepto_sat = @tipoConcepto)
                                                   AND tipo_transaccion IN (1,3,4,5)
                                                 ORDER BY concepto";

            var oracleStmt03 = new OracleCommand(sqlQuery03, oracleConnection);
            oracleStmt03.Parameters.Add(ParamTipoConcepto, OracleDbType.Int16).Value = tipoConcepto;
            oracleStmt03.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt03));
        }

        public bool AltaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            int resultadoEjecucion = ExecuteAltaRelacionConcepto(tipo, claveTipo, concepto);
            return resultadoEjecucion != 0;
        }

        internal virtual int ExecuteAltaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_alta_rel_con_tipos_sat12";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add("i_tipo_concepto_sat", OracleDbType.Int16).Value = tipo;
            oracleStmt.Parameters.Add("i_clave", OracleDbType.Char).Value = claveTipo;
            oracleStmt.Parameters.Add("i_concepto", OracleDbType.Int16).Value = concepto;
            oracleStmt.Prepare();

            return oracleStmt.ExecuteNonQuery();
        }

        public bool BajaRelacionConcepto(int tipo, string claveTipo, int concepto)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_baja_rel_con_tipos_sat12";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            oracleStmt.Parameters.Add("i_tipo_concepto_sat", OracleDbType.Int16).Value = tipo;
            oracleStmt.Parameters.Add("i_clave", OracleDbType.Char).Value = claveTipo;
            oracleStmt.Parameters.Add("i_concepto", OracleDbType.Int16).Value = concepto;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(oracleStmt, false);
        }

        #endregion

        #region Metodos Regimen Contratacion

        public DataSet obtenDatasetTrabajadoresRegimen(string compania)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT tg.compania, t.trabajador, 
                                                REPLACE(t.nombre,'/', ' ') AS nombre, 
                                                NVL(rtr.clave_regimen,0) AS regimen,
                                                NVL(cv.descripcion_sat,'---') AS descripcion
                                           FROM trabajadores t 
                                            INNER JOIN trabajadores_grales tg ON tg.trabajador = t.trabajador
                                            LEFT OUTER JOIN rel_trab_regimen rtr ON rtr.trabajador = tg.trabajador 
                                                                                AND rtr.compania = tg.compania
                                            LEFT OUTER JOIN catalogos_valores_sat_adam cv ON cv.clave_sat = rtr.clave_regimen 
                                                                                         AND cv.tipo = 3
                                          WHERE tg.compania = @company
                                          ORDER BY tg.trabajador";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Parameters.Add("@company", OracleDbType.Varchar2).Value = compania.Trim();
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet obtenDatasetRegimen()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT clave_sat AS clave,
                                                clave_sat || '--' || RTRIM(descripcion_sat) AS descripcion 
                                           FROM catalogos_valores_sat_adam 
                                          WHERE tipo = 3
                                          ORDER BY clave_sat";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public bool AltaRelacionRegimen(string compania, string trabajador, string regimen)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_alta_rel_trab_regimen";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add("i_compania", OracleDbType.Char).Value = compania;
            oracleStmt.Parameters.Add("i_trabajador", OracleDbType.Char).Value = trabajador;
            oracleStmt.Parameters.Add("i_clave_regimen", OracleDbType.Char).Value = regimen;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(oracleStmt, false);
        }

        #endregion

        public DataSet obtenDatasetFormaPago()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT clave_sat metodo_pago_sat, 
                                                clave_sat || '--' || descripcion_sat descripcion
                                           FROM catalogos_valores_sat_adam
                                          WHERE tipo = 10
                                          ORDER BY clave_sat";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public bool existeTablaConfiguracion()
        {
            return false;
        }

        public bool DeletePayslipsData(string companyId, string payrollType, string payrollClass, int payrollYear, int payrollPeriod, string employee)
        {
            return false;
        }

        public DataSet obtenConfiguracionCompania(string compania)
        {
            return null;
        }

        public void GuardaConfiguracionCompania(string company, ConfigurationTypes parameterId, string description, string alphanumeric, decimal num_decimal = 0, int num_int = 0)
        {
            throw new NotImplementedException();
        }

        DataSet ICatalogoAdicional.ReadCSD()
        {
            throw new NotImplementedException();
        }

        bool ICatalogoAdicional.DeleteCSD(string client)
        {
            throw new NotImplementedException();
        }

        bool ICatalogoAdicional.CreateReplaceCSD(byte[] certBytes, byte[] keyBytes, string client, string key_pass)
        {
            throw new NotImplementedException();
        }

        DataSet ICatalogoAdicional.obtenParametrosCompania(string compania)
        {
            throw new NotImplementedException();
        }
    }
}

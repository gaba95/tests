using Moq;
using System;
using System.Data;
using System.Data.Odbc;
using System.Reflection;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Datos.Clases.Common;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoSAT
{
    [TestClass]
    public class CatalogoSatOdbcTests
    {
        #region Helpers

        private static CatalogoSatOdbc CreateServiceWithNullConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            return new CatalogoSatOdbc(mockFactory.Object);
        }

        private static CatalogoSatOdbc CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            return new CatalogoSatOdbc(mockFactory.Object);
        }

        private static (CatalogoSatOdbc service, Mock<IDbConnectionFactory> mockFactory) CreateServiceWithRealOdbcConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            var callCount = 0;
            mockFactory.Setup(f => f.CreateConnection()).Returns(() =>
            {
                callCount++;
                if (callCount == 1)
                    return Mock.Of<IDbConnection>();
                return new OdbcConnection("DSN=FakeNonExistentDSN_12345;");
            });

            var service = new CatalogoSatOdbc(mockFactory.Object);
            return (service, mockFactory);
        }

        #endregion

        #region Constructor Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            // Act
            var service = new CatalogoSatOdbc(mockFactory.Object);

            // Assert
            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        [TestMethod]
        public void Constructor_WithNullFactory_ShouldThrowNullReferenceException()
        {
            Assert.Throws<NullReferenceException>(() =>
            {
                new CatalogoSatOdbc(null!);
            });
        }

        #endregion

        #region Structure / Reflection Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoSat()
        {
            Assert.IsTrue(typeof(ICatalogoSat).IsAssignableFrom(typeof(CatalogoSatOdbc)));
        }

        [TestMethod]
        [DataRow("dsListaCatalogosSAT")]
        [DataRow("obtenDatasetCatalogosSAT")]
        [DataRow("obtenDatasetCatalogos")]
        [DataRow("obtenCatalogoADAM")]
        [DataRow("obtenDatasetRelacionCatalogosSATADAM")]
        [DataRow("AltaRelacionDatoCatalogoADAM")]
        [DataRow("BajaRelacionDatoCatalogoADAM")]
        public void ShouldContainMethod(string methodName)
        {
            var method = typeof(CatalogoSatOdbc).GetMethod(methodName,
                BindingFlags.Public | BindingFlags.Instance);
            Assert.IsNotNull(method, $"Method {methodName} should exist");
        }

        [TestMethod]
        public void ShouldContainPrivateField_connectionFactory()
        {
            var field = typeof(CatalogoSatOdbc).GetField("_connectionFactory",
                BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(field, "Debe existir el campo privado _connectionFactory");
            Assert.AreEqual(typeof(IDbConnectionFactory), field.FieldType);
        }

        #endregion

        #region dsListaCatalogosSAT Tests

        [TestMethod]
        public void DsListaCatalogosSAT_ShouldReturnDataSetWithOneTable()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("listaCatalogos", result.Tables[0].TableName);
        }

        [TestMethod]
        public void DsListaCatalogosSAT_ShouldReturnTableWithTwoColumns()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.AreEqual(2, result.Tables[0].Columns.Count);
            Assert.IsTrue(result.Tables[0].Columns.Contains("id"));
            Assert.IsTrue(result.Tables[0].Columns.Contains("descripcion"));
        }

        [TestMethod]
        public void DsListaCatalogosSAT_ShouldReturnFourRows()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.AreEqual(4, result.Tables[0].Rows.Count);
        }

        [TestMethod]
        public void DsListaCatalogosSAT_FirstRow_ShouldBeBancos()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.AreEqual("1", result.Tables[0].Rows[0]["id"].ToString());
            Assert.AreEqual("Bancos", result.Tables[0].Rows[0]["descripcion"]);
        }

        [TestMethod]
        public void DsListaCatalogosSAT_SecondRow_ShouldBeTipoContrato()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.AreEqual("2", result.Tables[0].Rows[1]["id"].ToString());
            Assert.AreEqual("Tipo Contrato", result.Tables[0].Rows[1]["descripcion"]);
        }

        [TestMethod]
        public void DsListaCatalogosSAT_ThirdRow_ShouldBeTipoRegimen()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.AreEqual("3", result.Tables[0].Rows[2]["id"].ToString());
            Assert.AreEqual("Tipo Regimen", result.Tables[0].Rows[2]["descripcion"]);
        }

        [TestMethod]
        public void DsListaCatalogosSAT_FourthRow_ShouldBeClavesEntidadFederativa()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.dsListaCatalogosSAT();

            // Assert
            Assert.AreEqual("4", result.Tables[0].Rows[3]["id"].ToString());
            Assert.AreEqual("Claves Entidad Federativa", result.Tables[0].Rows[3]["descripcion"]);
        }

        #endregion

        #region obtenDatasetCatalogosSAT Tests

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_ShouldReturnDataSetWithOneTable()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetCatalogosSAT("1");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_ShouldReturnTableWithTwoColumns()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetCatalogosSAT("1");

            // Assert
            Assert.AreEqual(2, result.Tables[0].Columns.Count);
            Assert.IsTrue(result.Tables[0].Columns.Contains("metodo_pago_sat"));
            Assert.IsTrue(result.Tables[0].Columns.Contains("descripcion"));
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_ShouldReturnZeroRows()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetCatalogosSAT("1");

            // Assert
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_WithNullTipo_ShouldReturnEmptyDataSet()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetCatalogosSAT(null!);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_WithEmptyTipo_ShouldReturnEmptyDataSet()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetCatalogosSAT(string.Empty);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        #endregion

        #region obtenCatalogoADAM Tests

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldReturnDataSetWithOneTable()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenCatalogoADAM("1", "COMP");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldReturnTableWithTwoColumns()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenCatalogoADAM("1", "COMP");

            // Assert
            Assert.AreEqual(2, result.Tables[0].Columns.Count);
            Assert.IsTrue(result.Tables[0].Columns.Contains("clave"));
            Assert.IsTrue(result.Tables[0].Columns.Contains("descripcion"));
        }

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldReturnZeroRows()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenCatalogoADAM("1", "COMP");

            // Assert
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        [TestMethod]
        public void ObtenCatalogoADAM_WithNullParams_ShouldReturnEmptyDataSet()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenCatalogoADAM(null!, null!);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        #endregion

        #region obtenDatasetRelacionCatalogosSATADAM Tests

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldReturnDataSetWithOneTable()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldReturnTableWithTwoColumns()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP");

            // Assert
            Assert.AreEqual(2, result.Tables[0].Columns.Count);
            Assert.IsTrue(result.Tables[0].Columns.Contains("clave"));
            Assert.IsTrue(result.Tables[0].Columns.Contains("descripcion"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldReturnZeroRows()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP");

            // Assert
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_WithNullParams_ShouldReturnEmptyDataSet()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.obtenDatasetRelacionCatalogosSATADAM(null!, null!, null!);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables[0].Rows.Count);
        }

        #endregion

        #region AltaRelacionDatoCatalogoADAM Tests

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.AltaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01");

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_WithNullParams_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.AltaRelacionDatoCatalogoADAM(null!, null!, null!, null!);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_WithEmptyParams_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.AltaRelacionDatoCatalogoADAM(string.Empty, string.Empty, string.Empty, string.Empty);

            // Assert
            Assert.IsTrue(result);
        }

        #endregion

        #region BajaRelacionDatoCatalogoADAM Tests

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.BajaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01");

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_WithNullParams_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.BajaRelacionDatoCatalogoADAM(null!, null!, null!, null!);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_WithEmptyParams_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act
            var result = service.BajaRelacionDatoCatalogoADAM(string.Empty, string.Empty, string.Empty, string.Empty);

            // Assert
            Assert.IsTrue(result);
        }

        #endregion

        #region obtenDatasetCatalogos Tests

        [TestMethod]
        public void ObtenDatasetCatalogos_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.obtenDatasetCatalogos("table1");
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_NonOdbcConnection_ShouldThrowInvalidCastException()
        {
            // Arrange
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() =>
            {
                service.obtenDatasetCatalogos("table1");
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_RealOdbcConnection_ShouldThrowOdbcException()
        {
            // Arrange
            var (service, _) = CreateServiceWithRealOdbcConnection();

            // Act & Assert
            Assert.Throws<OdbcException>(() =>
            {
                service.obtenDatasetCatalogos("table1");
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_NullTabla_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.obtenDatasetCatalogos(null!);
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_EmptyTabla_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.obtenDatasetCatalogos(string.Empty);
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_NullTabla_RealOdbcConnection_ShouldThrowOdbcException()
        {
            // Arrange
            var (service, _) = CreateServiceWithRealOdbcConnection();

            // Act & Assert
            Assert.Throws<OdbcException>(() =>
            {
                service.obtenDatasetCatalogos(null!);
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_EmptyTabla_RealOdbcConnection_ShouldThrowOdbcException()
        {
            // Arrange
            var (service, _) = CreateServiceWithRealOdbcConnection();

            // Act & Assert
            Assert.Throws<OdbcException>(() =>
            {
                service.obtenDatasetCatalogos(string.Empty);
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_WhitespaceTabla_NullConnection_ShouldThrowNullReferenceException()
        {
            // Arrange
            var service = CreateServiceWithNullConnection();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.obtenDatasetCatalogos("   ");
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_ShouldCallCreateConnection()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoSatOdbc(mockFactory.Object);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.obtenDatasetCatalogos("table1");
            });

            // CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_NonOdbcConnection_WithNullTabla_ShouldThrowInvalidCastException()
        {
            // Arrange
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() =>
            {
                service.obtenDatasetCatalogos(null!);
            });
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_WhitespaceTabla_RealOdbcConnection_ShouldThrowOdbcException()
        {
            // Arrange
            var (service, _) = CreateServiceWithRealOdbcConnection();

            // Act & Assert
            Assert.Throws<OdbcException>(() =>
            {
                service.obtenDatasetCatalogos("   ");
            });
        }

        #endregion
    }
}

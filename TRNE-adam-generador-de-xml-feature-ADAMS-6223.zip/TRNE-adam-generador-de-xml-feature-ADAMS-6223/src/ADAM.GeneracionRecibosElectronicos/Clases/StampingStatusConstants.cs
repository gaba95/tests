﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases
{
    class StampingStatusConstants
    {
        public const int SIN_TIMBRAR = 0;
        public const int POR_TIMBRAR_VALUE = 1;
        public const int EN_PROCESO_VALUE = 2;
        public const int FINALIZADO_VALUE = 3;
        public const int ERROR_VALUE = 4;
        public const int ELIMINADO_VALUE = 5;
        public const int EN_PROCESO_CANCELACION_VALUE = 6;
        public const int CANCELADO_VALUE = 7;
        public const int ERROR_CANCELACION_VALUE = 8;

        Dictionary<int, String> estadoTexts = new Dictionary<int, string>();

        /// <summary>
        /// Set constant status.
        /// </summary>
        public StampingStatusConstants()
        {
            estadoTexts.Add(SIN_TIMBRAR, "Sin Timbrar");
            estadoTexts.Add(POR_TIMBRAR_VALUE, "En proceso");
            estadoTexts.Add(EN_PROCESO_VALUE, "En proceso");
            estadoTexts.Add(FINALIZADO_VALUE, "Finalizado");
            estadoTexts.Add(ERROR_VALUE, "Con Error");
            estadoTexts.Add(ELIMINADO_VALUE, "Eliminado");
            estadoTexts.Add(EN_PROCESO_CANCELACION_VALUE, "En proceso");
            estadoTexts.Add(CANCELADO_VALUE, "Cancelado");
            estadoTexts.Add(ERROR_CANCELACION_VALUE, "Con Error");
        }

        public String getStatusText(int? status)
        {
            if(status == null)
            {
                return estadoTexts[0];
            }
            else
            {
                return estadoTexts[status.Value];
            }
        }

        public bool canProcessStamp(int? status)
        {
            if(status == null)
            {
                return true;
            }
            else
            {
                int statusValue = status.Value;
                if(statusValue == SIN_TIMBRAR || statusValue == CANCELADO_VALUE || statusValue == ELIMINADO_VALUE)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}

using ADAM.Recibos.Datos.Utils;
using System.Data;
using System.Data.Common;
using Microsoft.Data.SqlClient;

namespace ADAM.Recibos.Datos.Tests.Utils
{
    [TestClass]
    public class SqlCommandExecutorTests
    {
        #region Fakes

        private class FakeDbConnection : DbConnection
        {
            private ConnectionState _state;
            public FakeDbConnection(ConnectionState state) => _state = state;
            public override string ConnectionString { get; set; } = "";
            public override string Database => "";
            public override string DataSource => "";
            public override string ServerVersion => "";
            public override ConnectionState State => _state;
            public override void ChangeDatabase(string databaseName) { }
            public override void Close() => _state = ConnectionState.Closed;
            public override void Open() => _state = ConnectionState.Open;
            protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) => null!;
            protected override DbCommand CreateDbCommand() => null!;
        }

        private class FakeDbCommand : DbCommand
        {
            private DbConnection? _connection;
            public Func<object?> _onExecuteScalar = () => null;
            public Func<int> _onExecuteNonQuery = () => 0;

            public override string CommandText { get; set; } = "";
            public override int CommandTimeout { get; set; }
            public override CommandType CommandType { get; set; }
            public override bool DesignTimeVisible { get; set; }
            public override UpdateRowSource UpdatedRowSource { get; set; }
            protected override DbConnection? DbConnection { get => _connection; set => _connection = value; }
            protected override DbParameterCollection DbParameterCollection => null!;
            protected override DbTransaction? DbTransaction { get; set; }

            public override void Cancel() { }
            public override int ExecuteNonQuery() => _onExecuteNonQuery();
            public override object? ExecuteScalar() => _onExecuteScalar();
            public override void Prepare() { }
            protected override DbParameter CreateDbParameter() => null!;
            protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior) => null!;
        }

        private class FakeDbDataAdapter : DbDataAdapter
        {
            private readonly int _fillResult;
            private readonly Exception? _fillException;

            public FakeDbDataAdapter(int fillResult = 1) => _fillResult = fillResult;
            public FakeDbDataAdapter(Exception fillException) => _fillException = fillException;

            public override int Fill(DataSet dataSet)
            {
                if (_fillException != null) throw _fillException;
                return _fillResult;
            }
        }

        #endregion

        #region Request(DbDataAdapter) tests

        [TestMethod]
        public void Request_Adapter_NullSelectCommand_ReturnsNull()
        {
            var adapter = new FakeDbDataAdapter();
            adapter.SelectCommand = null;

            var result = SqlCommandExecutor.Request(adapter);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void Request_Adapter_ClosedConnection_OpensAndFills()
        {
            var conn = new FakeDbConnection(ConnectionState.Closed);
            var cmd = new FakeDbCommand { Connection = conn };
            var adapter = new FakeDbDataAdapter();
            adapter.SelectCommand = cmd;

            var result = SqlCommandExecutor.Request(adapter);

            Assert.IsNotNull(result);
            Assert.AreEqual(ConnectionState.Open, conn.State);
        }

        [TestMethod]
        public void Request_Adapter_OpenConnection_DoesNotCallClose()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            var adapter = new FakeDbDataAdapter();
            adapter.SelectCommand = cmd;

            var result = SqlCommandExecutor.Request(adapter);

            Assert.IsNotNull(result);
            Assert.AreEqual(ConnectionState.Open, conn.State);
        }

        [TestMethod]
        public void Request_Adapter_SqlException_ReturnsNull()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            var adapter = new FakeDbDataAdapter(CreateSqlException());
            adapter.SelectCommand = cmd;

            var result = SqlCommandExecutor.Request(adapter);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void Request_Adapter_GeneralException_ReturnsNull()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            var adapter = new FakeDbDataAdapter(new InvalidOperationException("test error"));
            adapter.SelectCommand = cmd;

            var result = SqlCommandExecutor.Request(adapter);

            Assert.IsNull(result);
        }

        #endregion

        #region Request(DbCommand, bool) tests

        [TestMethod]
        public void Request_CommandBool_ClosedConnection_OpensConnection()
        {
            var conn = new FakeDbConnection(ConnectionState.Closed);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteNonQuery = () => 1;

            var result = SqlCommandExecutor.Request(cmd, false);

            Assert.IsTrue(result);
            Assert.AreEqual(ConnectionState.Open, conn.State);
        }

        [TestMethod]
        public void Request_CommandBool_ExecuteScalarTrue_ReturnsTrue()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteScalar = () => 5;

            var result = SqlCommandExecutor.Request(cmd, true);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Request_CommandBool_ExecuteScalarZero_ReturnsFalse()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteScalar = () => 0;

            var result = SqlCommandExecutor.Request(cmd, true);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Request_CommandBool_ExecuteNonQuery_PositiveResult_ReturnsTrue()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteNonQuery = () => 1;

            var result = SqlCommandExecutor.Request(cmd, false);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Request_CommandBool_ExecuteNonQuery_ZeroResult_ReturnsFalse()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteNonQuery = () => 0;

            var result = SqlCommandExecutor.Request(cmd, false);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Request_CommandBool_SqlException_ReturnsFalse()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteNonQuery = () => throw CreateSqlException();

            var result = SqlCommandExecutor.Request(cmd, false);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Request_CommandBool_GeneralException_ReturnsFalse()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteNonQuery = () => throw new InvalidOperationException("test");

            var result = SqlCommandExecutor.Request(cmd, false);

            Assert.IsFalse(result);
        }

        #endregion

        #region Request(DbCommand) tests - string overload

        [TestMethod]
        public void Request_CommandString_ClosedConnection_OpensAndReturnsResult()
        {
            var conn = new FakeDbConnection(ConnectionState.Closed);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteScalar = () => "hello";

            var result = SqlCommandExecutor.Request(cmd);

            Assert.AreEqual("hello", result);
            Assert.AreEqual(ConnectionState.Open, conn.State);
        }

        [TestMethod]
        public void Request_CommandString_OpenConnection_ReturnsResult()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteScalar = () => "result";

            var result = SqlCommandExecutor.Request(cmd);

            Assert.AreEqual("result", result);
        }

        [TestMethod]
        public void Request_CommandString_SqlException_ReturnsEmpty()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteScalar = () => throw CreateSqlException();

            var result = SqlCommandExecutor.Request(cmd);

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void Request_CommandString_GeneralException_ReturnsEmpty()
        {
            var conn = new FakeDbConnection(ConnectionState.Open);
            var cmd = new FakeDbCommand { Connection = conn };
            cmd._onExecuteScalar = () => throw new InvalidOperationException("test");

            var result = SqlCommandExecutor.Request(cmd);

            Assert.AreEqual(string.Empty, result);
        }

        #endregion

        private static SqlException CreateSqlException()
        {
            try
            {
                using var conn = new SqlConnection("Data Source=.;Database=nonexistent;Trusted_Connection=True;TrustServerCertificate=True;Connect Timeout=1");
                conn.Open();
            }
            catch (SqlException ex)
            {
                return ex;
            }

            throw new InvalidOperationException("Could not create SqlException");
        }
    }
}

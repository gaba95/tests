using Moq;
using System;
using System.Data;
using System.Data.Common;
using System.Reflection;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoSAT
{
    [TestClass]
    public class CatalogoSatSqlTests
    {
        #region Constructor Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            // Act
            var service = new CatalogoSatSql(mockFactory.Object);

            // Assert
            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        #endregion

        #region Interface & Structure Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoSat()
        {
            var serviceType = typeof(CatalogoSatSql);
            Assert.IsTrue(typeof(ICatalogoSat).IsAssignableFrom(serviceType), "Debe implementar ICatalogoSat");
        }

        [TestMethod]
        public void ShouldContainMethod_dsListaCatalogosSAT()
        {
            var method = typeof(CatalogoSatSql).GetMethod("dsListaCatalogosSAT");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(0, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetCatalogosSAT()
        {
            var method = typeof(CatalogoSatSql).GetMethod("obtenDatasetCatalogosSAT");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenCatalogoADAM()
        {
            var method = typeof(CatalogoSatSql).GetMethod("obtenCatalogoADAM");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetRelacionCatalogosSATADAM()
        {
            var method = typeof(CatalogoSatSql).GetMethod("obtenDatasetRelacionCatalogosSATADAM");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_AltaRelacionDatoCatalogoADAM()
        {
            var method = typeof(CatalogoSatSql).GetMethod("AltaRelacionDatoCatalogoADAM");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_BajaRelacionDatoCatalogoADAM()
        {
            var method = typeof(CatalogoSatSql).GetMethod("BajaRelacionDatoCatalogoADAM");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetCatalogos()
        {
            var method = typeof(CatalogoSatSql).GetMethod("obtenDatasetCatalogos");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        #endregion

        #region obtenCatalogoADAM Tests (SqlHelpers-based)

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldReturnDataSet_WithEmptyTable()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB();

            // Act
            var result = service.obtenCatalogoADAM("1", "COMP");

            // Assert – 0 rows but always returns DataSet with table
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("Table", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldConfigureTwoCharParams()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.obtenCatalogoADAM("1", "COMP");

            // Assert – 2 Char params: tipo, compania
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(2));
            Assert.AreEqual("sp_consulta_catalogos_adam", mockCommand.Object.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, mockCommand.Object.CommandType);
        }

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldReturnDataSet_WhenRowsExist()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true);

            // Act
            var result = service.obtenCatalogoADAM("1", "COMP");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.IsTrue(result.Tables[0].Rows.Count > 0);
        }

        [TestMethod]
        public void ObtenCatalogoADAM_ShouldThrow_WhenConnectionFails()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoSatSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert – try/catch rethrows
            Assert.Throws<Exception>(() =>
                service.obtenCatalogoADAM("1", "COMP"));
        }

        #endregion

        #region obtenDatasetRelacionCatalogosSATADAM Tests (SqlHelpers-based)

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldReturnDataSet_WithEmptyTable()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB();

            // Act
            var result = service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("Table", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldConfigureThreeCharParams()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP");

            // Assert – 3 Char params: tipo, clave_sat, compania
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(3));
            Assert.AreEqual("sp_consulta_rel_datos_sat_adam", mockCommand.Object.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, mockCommand.Object.CommandType);
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldReturnDataSet_WhenRowsExist()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true);

            // Act
            var result = service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP");

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Tables[0].Rows.Count > 0);
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosSATADAM_ShouldThrow_WhenConnectionFails()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoSatSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert
            Assert.Throws<Exception>(() =>
                service.obtenDatasetRelacionCatalogosSATADAM("1", "SAT01", "COMP"));
        }

        #endregion

        #region SqlConnection-cast methods – InvalidCastException Tests

        [TestMethod]
        public void DsListaCatalogosSAT_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.dsListaCatalogosSAT());
        }

        [TestMethod]
        public void ObtenDatasetCatalogosSAT_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetCatalogosSAT("1"));
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoADAM_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.AltaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01"));
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoADAM_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.BajaRelacionDatoCatalogoADAM("1", "COMP", "SAT01", "ADAM01"));
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_WithWhitelistedTable_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            // "tb_catalogos_dian" is in SafeTables.WhiteList, so it enters the SqlConnection cast path
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetCatalogos("tb_catalogos_dian"));
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_WithNonWhitelistedTable_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            // A table not in the whitelist should return null without touching DB
            var result = service.obtenDatasetCatalogos("tabla_no_existente");
            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenDatasetCatalogos_WithEmptyString_ShouldReturnNull()
        {
            var service = CreateServiceWithMockDB();
            var result = service.obtenDatasetCatalogos("");
            Assert.IsNull(result);
        }

        #endregion

        #region Helpers

        /// <summary>
        /// Creates a CatalogoSatSql with a mock IDbConnection (non-SqlConnection).
        /// Methods that cast to SqlConnection will throw InvalidCastException.
        /// </summary>
        private CatalogoSatSql CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            return new CatalogoSatSql(mockFactory.Object);
        }

        /// <summary>
        /// Creates a CatalogoSatSql with full IDbCommand mock chain (for SqlHelpers-based methods).
        /// When hasRows=true, the DataTable will contain one row.
        /// </summary>
        private (CatalogoSatSql service, Mock<IDbCommand> mockCommand) CreateServiceWithFullMockDB(bool hasRows = false)
        {
            var schemaTable = new DataTable();
            schemaTable.Columns.Add("ColumnName", typeof(string));
            schemaTable.Columns.Add("ColumnOrdinal", typeof(int));
            schemaTable.Columns.Add("ColumnSize", typeof(int));
            schemaTable.Columns.Add("DataType", typeof(Type));
            schemaTable.Columns.Add("AllowDBNull", typeof(bool));
            schemaTable.Columns.Add("IsKey", typeof(bool));
            schemaTable.Columns.Add("IsUnique", typeof(bool));

            var mockReader = new Mock<IDataReader>();
            if (hasRows)
            {
                var schemaRow = schemaTable.NewRow();
                schemaRow["ColumnName"] = "col1";
                schemaRow["ColumnOrdinal"] = 0;
                schemaRow["ColumnSize"] = 255;
                schemaRow["DataType"] = typeof(string);
                schemaRow["AllowDBNull"] = true;
                schemaRow["IsKey"] = false;
                schemaRow["IsUnique"] = false;
                schemaTable.Rows.Add(schemaRow);

                var readSequence = mockReader.SetupSequence(r => r.Read());
                readSequence.Returns(true);
                readSequence.Returns(false);
                mockReader.Setup(r => r.FieldCount).Returns(1);
                mockReader.Setup(r => r.GetName(0)).Returns("col1");
                mockReader.Setup(r => r.GetFieldType(0)).Returns(typeof(string));
                mockReader.Setup(r => r.GetValue(0)).Returns("value1");
                mockReader.Setup(r => r.IsDBNull(0)).Returns(false);
            }
            else
            {
                mockReader.Setup(r => r.Read()).Returns(false);
            }
            mockReader.Setup(r => r.GetSchemaTable()).Returns(schemaTable);

            var mockCommand = CreateMockCommand(mockReader);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new CatalogoSatSql(mockFactory.Object);
            return (service, mockCommand);
        }

        private Mock<IDbCommand> CreateMockCommand(Mock<IDataReader> mockReader)
        {
            var mockCommand = new Mock<IDbCommand>();
            mockCommand.SetupProperty(c => c.CommandText);
            mockCommand.SetupProperty(c => c.CommandType);
            mockCommand.SetupProperty(c => c.CommandTimeout);

            var mockParams = new Mock<IDataParameterCollection>();
            mockCommand.Setup(c => c.Parameters).Returns(mockParams.Object);
            mockCommand.Setup(c => c.CreateParameter()).Returns(() => new Mock<IDbDataParameter>().Object);
            mockCommand.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            return mockCommand;
        }

        #endregion
    }
}

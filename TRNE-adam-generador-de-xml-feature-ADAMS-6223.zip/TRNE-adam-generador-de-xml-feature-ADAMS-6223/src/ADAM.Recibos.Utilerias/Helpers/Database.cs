﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public static class Database
    {
        public const int MaxConnectionRetries = 5;
    }
}

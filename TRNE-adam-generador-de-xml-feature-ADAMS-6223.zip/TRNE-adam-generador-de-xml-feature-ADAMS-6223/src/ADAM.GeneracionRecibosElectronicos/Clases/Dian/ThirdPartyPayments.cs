﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("pagosTerceros", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class ThirdPartyPayments
    {
        [JsonProperty("descripcion")]
        public string PagoTerceroDescripcion { get; set; } = "";

        [JsonProperty("pagoTercero")]
        public decimal PagoTercero { get; set; }        
    }
}


namespace ADAM.GeneracionRecibosElectronicos.UI
{
    partial class FrmFilterSortDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFilterSortDialog));
            this.lblColumnName = new System.Windows.Forms.Label();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.pnlValues = new System.Windows.Forms.Panel();
            this.chkUniqueValues = new System.Windows.Forms.CheckedListBox();
            this.cmdOk = new System.Windows.Forms.Button();
            this.cmdClose = new System.Windows.Forms.Button();
            this.lnkDeleteFilter = new System.Windows.Forms.LinkLabel();
            this.lnkMoreFilters = new System.Windows.Forms.LinkLabel();
            this.lnkDesc = new System.Windows.Forms.LinkLabel();
            this.lnkAsc = new System.Windows.Forms.LinkLabel();
            this.cmdAddToFilter = new System.Windows.Forms.Button();
            this.pnlValues.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblColumnName
            // 
            this.lblColumnName.AutoSize = true;
            this.lblColumnName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColumnName.Location = new System.Drawing.Point(8, 3);
            this.lblColumnName.Name = "lblColumnName";
            this.lblColumnName.Size = new System.Drawing.Size(39, 13);
            this.lblColumnName.TabIndex = 7;
            this.lblColumnName.Text = "TTTT";
            // 
            // txtFilter
            // 
            this.txtFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFilter.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.txtFilter.Location = new System.Drawing.Point(6, 120);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(139, 20);
            this.txtFilter.TabIndex = 8;
            this.txtFilter.TextChanged += new System.EventHandler(this.txtFilter_TextChanged);
            // 
            // pnlValues
            // 
            this.pnlValues.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlValues.Controls.Add(this.chkUniqueValues);
            this.pnlValues.Location = new System.Drawing.Point(5, 146);
            this.pnlValues.Name = "pnlValues";
            this.pnlValues.Size = new System.Drawing.Size(140, 149);
            this.pnlValues.TabIndex = 10;
            // 
            // chkUniqueValues
            // 
            this.chkUniqueValues.CheckOnClick = true;
            this.chkUniqueValues.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkUniqueValues.FormattingEnabled = true;
            this.chkUniqueValues.HorizontalScrollbar = true;
            this.chkUniqueValues.Location = new System.Drawing.Point(0, 0);
            this.chkUniqueValues.Name = "chkUniqueValues";
            this.chkUniqueValues.Size = new System.Drawing.Size(140, 149);
            this.chkUniqueValues.TabIndex = 5;
            this.chkUniqueValues.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chkUniqueValues_ItemCheck);
            // 
            // cmdOk
            // 
            this.cmdOk.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdOk.Location = new System.Drawing.Point(5, 327);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(140, 23);
            this.cmdOk.TabIndex = 11;
            this.cmdOk.Text = "Aceptar";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // cmdClose
            // 
            this.cmdClose.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdClose.Location = new System.Drawing.Point(5, 353);
            this.cmdClose.Name = "cmdClose";
            this.cmdClose.Size = new System.Drawing.Size(140, 23);
            this.cmdClose.TabIndex = 12;
            this.cmdClose.Text = "Cancelar";
            this.cmdClose.UseVisualStyleBackColor = true;
            this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
            // 
            // lnkDeleteFilter
            // 
            this.lnkDeleteFilter.AutoSize = true;
            this.lnkDeleteFilter.Enabled = false;
            this.lnkDeleteFilter.Location = new System.Drawing.Point(8, 74);
            this.lnkDeleteFilter.Name = "lnkDeleteFilter";
            this.lnkDeleteFilter.Size = new System.Drawing.Size(68, 13);
            this.lnkDeleteFilter.TabIndex = 14;
            this.lnkDeleteFilter.TabStop = true;
            this.lnkDeleteFilter.Text = "Eliminar Filtro";
            this.lnkDeleteFilter.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkDeleteFilter_LinkClicked);
            // 
            // lnkMoreFilters
            // 
            this.lnkMoreFilters.AutoSize = true;
            this.lnkMoreFilters.Location = new System.Drawing.Point(8, 104);
            this.lnkMoreFilters.Name = "lnkMoreFilters";
            this.lnkMoreFilters.Size = new System.Drawing.Size(57, 13);
            this.lnkMoreFilters.TabIndex = 15;
            this.lnkMoreFilters.TabStop = true;
            this.lnkMoreFilters.Text = "Mas Filtros";
            this.lnkMoreFilters.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkMoreFilters_LinkClicked);
            // 
            // lnkDesc
            // 
            this.lnkDesc.AutoSize = true;
            this.lnkDesc.Location = new System.Drawing.Point(8, 25);
            this.lnkDesc.Name = "lnkDesc";
            this.lnkDesc.Size = new System.Drawing.Size(112, 13);
            this.lnkDesc.TabIndex = 16;
            this.lnkDesc.TabStop = true;
            this.lnkDesc.Text = "Ordenar Descencente";
            this.lnkDesc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkDesc_LinkClicked);
            // 
            // lnkAsc
            // 
            this.lnkAsc.AutoSize = true;
            this.lnkAsc.Location = new System.Drawing.Point(8, 50);
            this.lnkAsc.Name = "lnkAsc";
            this.lnkAsc.Size = new System.Drawing.Size(105, 13);
            this.lnkAsc.TabIndex = 17;
            this.lnkAsc.TabStop = true;
            this.lnkAsc.Text = "Ordenar Ascendente";
            this.lnkAsc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAsc_LinkClicked);
            // 
            // cmdAddToFilter
            // 
            this.cmdAddToFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAddToFilter.Enabled = false;
            this.cmdAddToFilter.Location = new System.Drawing.Point(5, 301);
            this.cmdAddToFilter.Name = "cmdAddToFilter";
            this.cmdAddToFilter.Size = new System.Drawing.Size(140, 23);
            this.cmdAddToFilter.TabIndex = 18;
            this.cmdAddToFilter.TabStop = false;
            this.cmdAddToFilter.Text = "Agregar al Filtro";
            this.cmdAddToFilter.UseVisualStyleBackColor = true;
            this.cmdAddToFilter.Click += new System.EventHandler(this.cmdAddToFilter_Click);
            // 
            // FrmFilterSortDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(152, 384);
            this.Controls.Add(this.cmdAddToFilter);
            this.Controls.Add(this.lnkAsc);
            this.Controls.Add(this.lnkDesc);
            this.Controls.Add(this.lnkMoreFilters);
            this.Controls.Add(this.lnkDeleteFilter);
            this.Controls.Add(this.cmdClose);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.pnlValues);
            this.Controls.Add(this.txtFilter);
            this.Controls.Add(this.lblColumnName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFilterSortDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Opciones";
            this.Load += new System.EventHandler(this.FrmFilterSortDialog_Load);
            this.pnlValues.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblColumnName;
        private System.Windows.Forms.TextBox txtFilter;
        private System.Windows.Forms.Panel pnlValues;
        private System.Windows.Forms.CheckedListBox chkUniqueValues;
        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.Button cmdClose;
        private System.Windows.Forms.LinkLabel lnkDeleteFilter;
        private System.Windows.Forms.LinkLabel lnkMoreFilters;
        private System.Windows.Forms.LinkLabel lnkDesc;
        private System.Windows.Forms.LinkLabel lnkAsc;
        private System.Windows.Forms.Button cmdAddToFilter;
    }
}
using Moq;
using System.Data;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.DatosTests
{
    [TestClass]
    public class BRReciboElectronicoOracleDataMethodTests
    {
        #region Test Subclass — overrides Fetch* methods, keeps business logic in originals

        private class FetchLevelTestable : BRReciboElectronicoOracle
        {
            public DataSet FetchPrincipalResult { get; set; }
            public DataSet FetchHorasExtraResult { get; set; }
            public DataSet FetchIncapacidadesResult { get; set; }
            public DataSet FetchOtrosPagosResult { get; set; }
            public DataSet FetchAccionesTitulosResult { get; set; }
            public DataSet FetchJubilacionPensionRetiroResult { get; set; }
            public DataSet FetchSeparacionIndemnizacionResult { get; set; }

            public FetchLevelTestable(IDbConnectionFactory factory) : base(factory) { }

            internal override DataSet FetchPrincipalRaw(Nomina nomina) => FetchPrincipalResult;
            internal override DataSet FetchHorasExtraRaw(Nomina nomina) => FetchHorasExtraResult;
            internal override DataSet FetchIncapacidadesRaw(Nomina nomina) => FetchIncapacidadesResult;
            internal override DataSet FetchOtrosPagosRaw(Nomina nomina) => FetchOtrosPagosResult;
            internal override DataSet FetchAccionesTitulosRaw(Nomina nomina) => FetchAccionesTitulosResult;
            internal override DataSet FetchJubilacionPensionRetiroRaw(Nomina nomina) => FetchJubilacionPensionRetiroResult;
            internal override DataSet FetchSeparacionIndemnizacionRaw(Nomina nomina) => FetchSeparacionIndemnizacionResult;
        }

        #endregion

        #region Helpers

        private static FetchLevelTestable CreateService()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            return new FetchLevelTestable(mockFactory.Object);
        }

        private static Nomina CreateNomina(
            ManejoNomina manejoNomina = ManejoNomina.periodica,
            string conceptoFactura = "1000")
        {
            return new Nomina("0001", "  90901010", "01", "01", 2026, 1,
                manejoNomina, 0, conceptoFactura, "EFEC");
        }

        private static DataSet MakeDataSetWithTable(string tableName = "Table")
        {
            var ds = new DataSet();
            var dt = new DataTable(tableName);
            dt.Columns.Add("Col1", typeof(string));
            dt.Rows.Add("val1");
            ds.Tables.Add(dt);
            return ds;
        }

        private static DataSet MakeEmptyDataSet()
        {
            return new DataSet();
        }

        #endregion

        #region ObtenDatasetPrincipal — null+count check + rename

        [TestMethod]
        public void ObtenDatasetPrincipal_WithTableData_ShouldRenameToTablePrincipal()
        {
            var service = CreateService();
            service.FetchPrincipalResult = MakeDataSetWithTable("RawTable");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetPrincipal(nomina);

            Assert.AreEqual("TablePrincipal", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_WithNullResult_ShouldReturnNull()
        {
            var service = CreateService();
            service.FetchPrincipalResult = null;
            var nomina = CreateNomina();

            var result = service.ObtenDatasetPrincipal(nomina);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_WithEmptyDataSet_ShouldReturnWithoutRename()
        {
            var service = CreateService();
            service.FetchPrincipalResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            var result = service.ObtenDatasetPrincipal(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_ShouldPreserveRowData()
        {
            var service = CreateService();
            var ds = MakeDataSetWithTable("Raw");
            ds.Tables[0].Rows.Add("val2");
            service.FetchPrincipalResult = ds;
            var nomina = CreateNomina();

            var result = service.ObtenDatasetPrincipal(nomina);

            Assert.AreEqual(2, result.Tables["TablePrincipal"].Rows.Count);
            Assert.AreEqual("val1", result.Tables["TablePrincipal"].Rows[0]["Col1"]);
            Assert.AreEqual("val2", result.Tables["TablePrincipal"].Rows[1]["Col1"]);
        }

        #endregion

        #region ObtenDatasetHorasExtra — null+count check + rename

        [TestMethod]
        public void ObtenDatasetHorasExtra_WithTableData_ShouldRenameToTableHorasExtra()
        {
            var service = CreateService();
            service.FetchHorasExtraResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetHorasExtra(nomina);

            Assert.AreEqual("TableHorasExtra", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_WithNullResult_ShouldReturnNull()
        {
            var service = CreateService();
            service.FetchHorasExtraResult = null;
            var nomina = CreateNomina();

            var result = service.ObtenDatasetHorasExtra(nomina);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_WithEmptyDataSet_ShouldReturnWithoutRename()
        {
            var service = CreateService();
            service.FetchHorasExtraResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            var result = service.ObtenDatasetHorasExtra(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables.Count);
        }

        #endregion

        #region ObtenDatasetIncapacidades — direct rename (NO null check)

        [TestMethod]
        public void ObtenDatasetIncapacidades_WithTableData_ShouldRenameToTableIncapacidades()
        {
            var service = CreateService();
            service.FetchIncapacidadesResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetIncapacidades(nomina);

            Assert.AreEqual("TableIncapacidades", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_WithEmptyDataSet_ShouldThrowIndexOutOfRange()
        {
            // This method does NOT have a null/count check — it directly accesses Tables[0]
            var service = CreateService();
            service.FetchIncapacidadesResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            Assert.Throws<IndexOutOfRangeException>(() =>
                service.ObtenDatasetIncapacidades(nomina));
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_ShouldPreserveRowData()
        {
            var service = CreateService();
            service.FetchIncapacidadesResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetIncapacidades(nomina);

            Assert.AreEqual(1, result.Tables[0].Rows.Count);
        }

        #endregion

        #region ObtenDatasetOtrosPagos — count check (no null check) + rename

        [TestMethod]
        public void ObtenDatasetOtrosPagos_WithTableData_ShouldRenameToTableOtrosPagos()
        {
            var service = CreateService();
            service.FetchOtrosPagosResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetOtrosPagos(nomina);

            Assert.AreEqual("TableOtrosPagos", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_WithEmptyDataSet_ShouldReturnWithoutRename()
        {
            var service = CreateService();
            service.FetchOtrosPagosResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            var result = service.ObtenDatasetOtrosPagos(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables.Count);
        }

        #endregion

        #region ObtenDatasetAccionesTitulos — count check + rename

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_WithTableData_ShouldRenameToTableAccionesTitulos()
        {
            var service = CreateService();
            service.FetchAccionesTitulosResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetAccionesTitulos(nomina);

            Assert.AreEqual("TableAccionesTitulos", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_WithEmptyDataSet_ShouldReturnWithoutRename()
        {
            var service = CreateService();
            service.FetchAccionesTitulosResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            var result = service.ObtenDatasetAccionesTitulos(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables.Count);
        }

        #endregion

        #region ObtenDatasetJubilacionPensionRetiro — count check + rename

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_WithTableData_ShouldRename()
        {
            var service = CreateService();
            service.FetchJubilacionPensionRetiroResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetJubilacionPensionRetiro(nomina);

            Assert.AreEqual("TableJubilacionPensionRetiro", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_WithEmptyDataSet_ShouldReturnWithoutRename()
        {
            var service = CreateService();
            service.FetchJubilacionPensionRetiroResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            var result = service.ObtenDatasetJubilacionPensionRetiro(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables.Count);
        }

        #endregion

        #region ObtenDatasetSeparacionIndemnizacion — count check + rename

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_WithTableData_ShouldRename()
        {
            var service = CreateService();
            service.FetchSeparacionIndemnizacionResult = MakeDataSetWithTable("Raw");
            var nomina = CreateNomina();

            var result = service.ObtenDatasetSeparacionIndemnizacion(nomina);

            Assert.AreEqual("TableSeparacionIndemnizacion", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_WithEmptyDataSet_ShouldReturnWithoutRename()
        {
            var service = CreateService();
            service.FetchSeparacionIndemnizacionResult = MakeEmptyDataSet();
            var nomina = CreateNomina();

            var result = service.ObtenDatasetSeparacionIndemnizacion(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Tables.Count);
        }

        #endregion

        #region Cross-method consistency tests

        [TestMethod]
        public void AllMethodsWithCountCheck_ShouldHandleEmptyDataSetGracefully()
        {
            // Methods with count > 0 check: OtrosPagos, AccionesTitulos, JubilacionPensionRetiro, SeparacionIndemnizacion
            var service = CreateService();
            var empty = MakeEmptyDataSet();
            service.FetchOtrosPagosResult = empty;
            service.FetchAccionesTitulosResult = new DataSet();
            service.FetchJubilacionPensionRetiroResult = new DataSet();
            service.FetchSeparacionIndemnizacionResult = new DataSet();
            var nomina = CreateNomina();

            Assert.AreEqual(0, service.ObtenDatasetOtrosPagos(nomina).Tables.Count);
            Assert.AreEqual(0, service.ObtenDatasetAccionesTitulos(nomina).Tables.Count);
            Assert.AreEqual(0, service.ObtenDatasetJubilacionPensionRetiro(nomina).Tables.Count);
            Assert.AreEqual(0, service.ObtenDatasetSeparacionIndemnizacion(nomina).Tables.Count);
        }

        [TestMethod]
        public void AllMethodsWithNullCheck_ShouldReturnNull_WhenFetchReturnsNull()
        {
            // Methods with null check: Principal, HorasExtra
            var service = CreateService();
            service.FetchPrincipalResult = null;
            service.FetchHorasExtraResult = null;
            var nomina = CreateNomina();

            Assert.IsNull(service.ObtenDatasetPrincipal(nomina));
            Assert.IsNull(service.ObtenDatasetHorasExtra(nomina));
        }

        [TestMethod]
        public void AllMethods_WithValidData_ShouldRenameTableCorrectly()
        {
            var service = CreateService();
            service.FetchPrincipalResult = MakeDataSetWithTable("A");
            service.FetchHorasExtraResult = MakeDataSetWithTable("B");
            service.FetchIncapacidadesResult = MakeDataSetWithTable("C");
            service.FetchOtrosPagosResult = MakeDataSetWithTable("D");
            service.FetchAccionesTitulosResult = MakeDataSetWithTable("E");
            service.FetchJubilacionPensionRetiroResult = MakeDataSetWithTable("F");
            service.FetchSeparacionIndemnizacionResult = MakeDataSetWithTable("G");
            var nomina = CreateNomina();

            Assert.AreEqual("TablePrincipal", service.ObtenDatasetPrincipal(nomina).Tables[0].TableName);
            Assert.AreEqual("TableHorasExtra", service.ObtenDatasetHorasExtra(nomina).Tables[0].TableName);
            Assert.AreEqual("TableIncapacidades", service.ObtenDatasetIncapacidades(nomina).Tables[0].TableName);
            Assert.AreEqual("TableOtrosPagos", service.ObtenDatasetOtrosPagos(nomina).Tables[0].TableName);
            Assert.AreEqual("TableAccionesTitulos", service.ObtenDatasetAccionesTitulos(nomina).Tables[0].TableName);
            Assert.AreEqual("TableJubilacionPensionRetiro", service.ObtenDatasetJubilacionPensionRetiro(nomina).Tables[0].TableName);
            Assert.AreEqual("TableSeparacionIndemnizacion", service.ObtenDatasetSeparacionIndemnizacion(nomina).Tables[0].TableName);
        }

        #endregion
    }
}

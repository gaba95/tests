namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmRegimenContratacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRegimenContratacion));
            this.cmdCambiar = new System.Windows.Forms.Button();
            this.lblRegimen = new System.Windows.Forms.Label();
            this.gridTrabajadoresRegimen = new System.Windows.Forms.DataGridView();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.cboCompania = new System.Windows.Forms.ComboBox();
            this.lblCompania = new System.Windows.Forms.Label();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.gridTrabajadoresRegimen)).BeginInit();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            this.pnlHerramientas.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdCambiar
            // 
            this.cmdCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCambiar.Location = new System.Drawing.Point(3, 40);
            this.cmdCambiar.Name = "cmdCambiar";
            this.cmdCambiar.Size = new System.Drawing.Size(110, 50);
            this.cmdCambiar.TabIndex = 3;
            this.cmdCambiar.Text = "Cambiar &Régimen";
            this.cmdCambiar.UseVisualStyleBackColor = true;
            this.cmdCambiar.Click += new System.EventHandler(this.cmdCambiar_Click);
            // 
            // lblRegimen
            // 
            this.lblRegimen.AutoSize = true;
            this.lblRegimen.Location = new System.Drawing.Point(0, -40);
            this.lblRegimen.Name = "lblRegimen";
            this.lblRegimen.Size = new System.Drawing.Size(143, 18);
            this.lblRegimen.TabIndex = 0;
            this.lblRegimen.Text = "Regimen de Contatación";
            // 
            // gridTrabajadoresRegimen
            // 
            this.gridTrabajadoresRegimen.AllowUserToAddRows = false;
            this.gridTrabajadoresRegimen.AllowUserToDeleteRows = false;
            this.gridTrabajadoresRegimen.AllowUserToResizeRows = false;
            this.gridTrabajadoresRegimen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridTrabajadoresRegimen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridTrabajadoresRegimen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridTrabajadoresRegimen.Location = new System.Drawing.Point(10, 40);
            this.gridTrabajadoresRegimen.Name = "gridTrabajadoresRegimen";
            this.gridTrabajadoresRegimen.ReadOnly = true;
            this.gridTrabajadoresRegimen.RowHeadersVisible = false;
            this.gridTrabajadoresRegimen.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridTrabajadoresRegimen.Size = new System.Drawing.Size(476, 244);
            this.gridTrabajadoresRegimen.TabIndex = 2;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(3, 234);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 4;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(616, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(252, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Régimen Contratación";
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.cboCompania);
            this.pnlPrincipal.Controls.Add(this.lblCompania);
            this.pnlPrincipal.Controls.Add(this.gridTrabajadoresRegimen);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 50);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(10, 40, 10, 10);
            this.pnlPrincipal.Size = new System.Drawing.Size(496, 294);
            this.pnlPrincipal.TabIndex = 16;
            // 
            // cboCompania
            // 
            this.cboCompania.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompania.FormattingEnabled = true;
            this.cboCompania.Location = new System.Drawing.Point(84, 6);
            this.cboCompania.Name = "cboCompania";
            this.cboCompania.Size = new System.Drawing.Size(300, 26);
            this.cboCompania.TabIndex = 1;
            this.cboCompania.SelectedIndexChanged += new System.EventHandler(this.cboCompania_SelectedIndexChanged);
            // 
            // lblCompania
            // 
            this.lblCompania.AutoSize = true;
            this.lblCompania.Location = new System.Drawing.Point(14, 9);
            this.lblCompania.Name = "lblCompania";
            this.lblCompania.Size = new System.Drawing.Size(64, 18);
            this.lblCompania.TabIndex = 13;
            this.lblCompania.Text = "Compañia:";
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.cmdCerrar);
            this.pnlHerramientas.Controls.Add(this.cmdCambiar);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlHerramientas.Location = new System.Drawing.Point(496, 50);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Size = new System.Drawing.Size(120, 294);
            this.pnlHerramientas.TabIndex = 17;
            // 
            // FrmRegimenContratacion
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(616, 344);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.lblRegimen);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FrmRegimenContratacion";
            this.ShowInTaskbar = false;
            this.Text = "Régimen Contratación";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmRegimenContratacion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridTrabajadoresRegimen)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.pnlHerramientas.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCambiar;
        private System.Windows.Forms.Label lblRegimen;
        private System.Windows.Forms.DataGridView gridTrabajadoresRegimen;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.ComboBox cboCompania;
        private System.Windows.Forms.Label lblCompania;
    }
}
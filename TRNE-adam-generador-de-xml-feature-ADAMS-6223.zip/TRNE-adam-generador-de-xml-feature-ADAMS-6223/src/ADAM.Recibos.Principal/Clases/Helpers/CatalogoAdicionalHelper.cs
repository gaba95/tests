﻿using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.Recibos.Principal.Clases.Helpers
{
    [ExcludeFromCodeCoverage]
    public static class CatalogoAdicionalHelper
    {
        public static ICatalogoAdicional CreateInstance(TipoPlataforma tipoPlataforma,
                                                        ApplicationSettingsBase appSettings)
        {
            switch (tipoPlataforma)
            {
                case TipoPlataforma.SQLServer:
                    return new CatalogoAdicionalSql(new SqlConnectionFactory(appSettings));

                case TipoPlataforma.ORACLE:
                    return new CatalogoAdicionalOracle(new OracleConnectionFactory(appSettings));

                case TipoPlataforma.ODBC:
                    return new CatalogoAdicionalOdbc(new OdbcConnectionFactory(appSettings));

                default:
                    return new CatalogoAdicionalSql(new SqlConnectionFactory(appSettings));
            }
        }
    }
}

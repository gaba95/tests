namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmTiposPercepcionDeduccionDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTiposPercepcionDeduccionDIAN));
            this.gridDatosDIAN = new System.Windows.Forms.DataGridView();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.lblCompania = new System.Windows.Forms.Label();
            this.cboCompania = new System.Windows.Forms.ComboBox();
            this.lblTipoConcepto = new System.Windows.Forms.Label();
            this.cboTipoConcepto = new System.Windows.Forms.ComboBox();
            this.lblSeccion = new System.Windows.Forms.Label();
            this.cboSeccion = new System.Windows.Forms.ComboBox();
            this.lblCatalogoADAM = new System.Windows.Forms.Label();
            this.lblArbol = new System.Windows.Forms.Label();
            this.gridDatosADAM = new System.Windows.Forms.DataGridView();
            this.pnlRelleno = new System.Windows.Forms.Panel();
            this.pnlSeparador = new System.Windows.Forms.Panel();
            this.lblDatosDIAN = new System.Windows.Forms.Label();
            this.pnlArbol = new System.Windows.Forms.Panel();
            this.arbolConceptos = new System.Windows.Forms.TreeView();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.cmdCargar = new System.Windows.Forms.Button();
            this.cmdAgregar = new System.Windows.Forms.Button();
            this.cmdQuitar = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosDIAN)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosADAM)).BeginInit();
            this.pnlArbol.SuspendLayout();
            this.pnlHerramientas.SuspendLayout();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // gridDatosDIAN
            // 
            this.gridDatosDIAN.AllowUserToAddRows = false;
            this.gridDatosDIAN.AllowUserToDeleteRows = false;
            this.gridDatosDIAN.AllowUserToResizeRows = false;
            this.gridDatosDIAN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosDIAN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosDIAN.Dock = System.Windows.Forms.DockStyle.Left;
            this.gridDatosDIAN.Location = new System.Drawing.Point(10, 130);
            this.gridDatosDIAN.MultiSelect = false;
            this.gridDatosDIAN.Name = "gridDatosDIAN";
            this.gridDatosDIAN.ReadOnly = true;
            this.gridDatosDIAN.RowHeadersVisible = false;
            this.gridDatosDIAN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosDIAN.Size = new System.Drawing.Size(400, 484);
            this.gridDatosDIAN.TabIndex = 2;
            this.gridDatosDIAN.SelectionChanged += new System.EventHandler(this.gridDatosDIAN_SelectionChanged);
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.lblCompania);
            this.pnlPrincipal.Controls.Add(this.cboCompania);
            this.pnlPrincipal.Controls.Add(this.lblTipoConcepto);
            this.pnlPrincipal.Controls.Add(this.cboTipoConcepto);
            this.pnlPrincipal.Controls.Add(this.lblSeccion);
            this.pnlPrincipal.Controls.Add(this.cboSeccion);
            this.pnlPrincipal.Controls.Add(this.lblCatalogoADAM);
            this.pnlPrincipal.Controls.Add(this.lblArbol);
            this.pnlPrincipal.Controls.Add(this.gridDatosADAM);
            this.pnlPrincipal.Controls.Add(this.pnlRelleno);
            this.pnlPrincipal.Controls.Add(this.pnlSeparador);
            this.pnlPrincipal.Controls.Add(this.lblDatosDIAN);
            this.pnlPrincipal.Controls.Add(this.gridDatosDIAN);
            this.pnlPrincipal.Controls.Add(this.pnlArbol);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 50);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(10, 130, 10, 10);
            this.pnlPrincipal.Size = new System.Drawing.Size(1243, 624);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // lblCompania
            // 
            this.lblCompania.AutoSize = true;
            this.lblCompania.Location = new System.Drawing.Point(13, 7);
            this.lblCompania.Name = "lblCompania";
            this.lblCompania.Size = new System.Drawing.Size(64, 18);
            this.lblCompania.TabIndex = 13;
            this.lblCompania.Text = "Compañia:";
            // 
            // cboCompania
            // 
            this.cboCompania.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompania.FormattingEnabled = true;
            this.cboCompania.Location = new System.Drawing.Point(160, 6);
            this.cboCompania.Name = "cboCompania";
            this.cboCompania.Size = new System.Drawing.Size(300, 26);
            this.cboCompania.TabIndex = 12;
            this.cboCompania.SelectedIndexChanged += new System.EventHandler(this.cboCompania_SelectedIndexChanged);
            // 
            // lblTipoConcepto
            // 
            this.lblTipoConcepto.AutoSize = true;
            this.lblTipoConcepto.Location = new System.Drawing.Point(13, 39);
            this.lblTipoConcepto.Name = "lblTipoConcepto";
            this.lblTipoConcepto.Size = new System.Drawing.Size(94, 18);
            this.lblTipoConcepto.TabIndex = 4;
            this.lblTipoConcepto.Text = "Tipo Concepto:";
            // 
            // cboTipoConcepto
            // 
            this.cboTipoConcepto.FormattingEnabled = true;
            this.cboTipoConcepto.Location = new System.Drawing.Point(160, 38);
            this.cboTipoConcepto.Name = "cboTipoConcepto";
            this.cboTipoConcepto.Size = new System.Drawing.Size(300, 26);
            this.cboTipoConcepto.TabIndex = 5;
            this.cboTipoConcepto.SelectedIndexChanged += new System.EventHandler(this.cboTipoConcepto_SelectedIndexChanged);
            // 
            // lblSeccion
            // 
            this.lblSeccion.AutoSize = true;
            this.lblSeccion.Location = new System.Drawing.Point(13, 71);
            this.lblSeccion.Name = "lblSeccion";
            this.lblSeccion.Size = new System.Drawing.Size(56, 18);
            this.lblSeccion.TabIndex = 0;
            this.lblSeccion.Text = "Sección:";
            // 
            // cboSeccion
            // 
            this.cboSeccion.FormattingEnabled = true;
            this.cboSeccion.Location = new System.Drawing.Point(160, 70);
            this.cboSeccion.Name = "cboSeccion";
            this.cboSeccion.Size = new System.Drawing.Size(300, 26);
            this.cboSeccion.TabIndex = 1;
            this.cboSeccion.SelectedIndexChanged += new System.EventHandler(this.cboSeccion_SelectedIndexChanged);
            // 
            // lblCatalogoADAM
            // 
            this.lblCatalogoADAM.AutoSize = true;
            this.lblCatalogoADAM.Location = new System.Drawing.Point(419, 104);
            this.lblCatalogoADAM.Name = "lblCatalogoADAM";
            this.lblCatalogoADAM.Size = new System.Drawing.Size(109, 18);
            this.lblCatalogoADAM.TabIndex = 15;
            this.lblCatalogoADAM.Text = "Equivalencia ADAM";
            // 
            // lblArbol
            // 
            this.lblArbol.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblArbol.Location = new System.Drawing.Point(833, 104);
            this.lblArbol.Name = "lblArbol";
            this.lblArbol.Size = new System.Drawing.Size(400, 18);
            this.lblArbol.TabIndex = 10;
            this.lblArbol.Text = "Vista de elementos mapeados";
            // 
            // gridDatosADAM
            // 
            this.gridDatosADAM.AllowUserToAddRows = false;
            this.gridDatosADAM.AllowUserToDeleteRows = false;
            this.gridDatosADAM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosADAM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosADAM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDatosADAM.Location = new System.Drawing.Point(420, 130);
            this.gridDatosADAM.MultiSelect = false;
            this.gridDatosADAM.Name = "gridDatosADAM";
            this.gridDatosADAM.ReadOnly = true;
            this.gridDatosADAM.RowHeadersVisible = false;
            this.gridDatosADAM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosADAM.Size = new System.Drawing.Size(408, 484);
            this.gridDatosADAM.TabIndex = 7;
            // 
            // pnlRelleno
            // 
            this.pnlRelleno.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlRelleno.Location = new System.Drawing.Point(410, 130);
            this.pnlRelleno.Name = "pnlRelleno";
            this.pnlRelleno.Size = new System.Drawing.Size(10, 484);
            this.pnlRelleno.TabIndex = 8;
            // 
            // pnlSeparador
            // 
            this.pnlSeparador.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlSeparador.Location = new System.Drawing.Point(828, 130);
            this.pnlSeparador.Name = "pnlSeparador";
            this.pnlSeparador.Size = new System.Drawing.Size(5, 484);
            this.pnlSeparador.TabIndex = 8;
            // 
            // lblDatosDIAN
            // 
            this.lblDatosDIAN.AutoSize = true;
            this.lblDatosDIAN.Location = new System.Drawing.Point(10, 104);
            this.lblDatosDIAN.Name = "lblDatosDIAN";
            this.lblDatosDIAN.Size = new System.Drawing.Size(65, 18);
            this.lblDatosDIAN.TabIndex = 14;
            this.lblDatosDIAN.Text = "Tabla DIAN";
            // 
            // pnlArbol
            // 
            this.pnlArbol.Controls.Add(this.arbolConceptos);
            this.pnlArbol.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlArbol.Location = new System.Drawing.Point(833, 130);
            this.pnlArbol.Name = "pnlArbol";
            this.pnlArbol.Padding = new System.Windows.Forms.Padding(5, 0, 0, 10);
            this.pnlArbol.Size = new System.Drawing.Size(400, 484);
            this.pnlArbol.TabIndex = 10;
            // 
            // arbolConceptos
            // 
            this.arbolConceptos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arbolConceptos.Location = new System.Drawing.Point(5, 0);
            this.arbolConceptos.Name = "arbolConceptos";
            this.arbolConceptos.Size = new System.Drawing.Size(395, 474);
            this.arbolConceptos.TabIndex = 9;
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.cmdCerrar);
            this.pnlHerramientas.Controls.Add(this.cmdCargar);
            this.pnlHerramientas.Controls.Add(this.cmdAgregar);
            this.pnlHerramientas.Controls.Add(this.cmdQuitar);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlHerramientas.Location = new System.Drawing.Point(1243, 50);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Padding = new System.Windows.Forms.Padding(10, 110, 10, 60);
            this.pnlHerramientas.Size = new System.Drawing.Size(120, 624);
            this.pnlHerramientas.TabIndex = 1;
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(0, 563);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 8;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // cmdCargar
            // 
            this.cmdCargar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCargar.Location = new System.Drawing.Point(0, 234);
            this.cmdCargar.Name = "cmdCargar";
            this.cmdCargar.Size = new System.Drawing.Size(110, 50);
            this.cmdCargar.TabIndex = 7;
            this.cmdCargar.Text = "&Carga Masiva Conceptos";
            this.cmdCargar.UseVisualStyleBackColor = true;
            this.cmdCargar.Click += new System.EventHandler(this.cmdCargar_Click);
            // 
            // cmdAgregar
            // 
            this.cmdAgregar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAgregar.Location = new System.Drawing.Point(0, 130);
            this.cmdAgregar.Name = "cmdAgregar";
            this.cmdAgregar.Size = new System.Drawing.Size(110, 50);
            this.cmdAgregar.TabIndex = 4;
            this.cmdAgregar.Text = "&Agregar Concepto";
            this.cmdAgregar.UseVisualStyleBackColor = true;
            this.cmdAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // cmdQuitar
            // 
            this.cmdQuitar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdQuitar.Location = new System.Drawing.Point(0, 182);
            this.cmdQuitar.Name = "cmdQuitar";
            this.cmdQuitar.Size = new System.Drawing.Size(110, 50);
            this.cmdQuitar.TabIndex = 1;
            this.cmdQuitar.Text = "&Eliminar Concepto";
            this.cmdQuitar.UseVisualStyleBackColor = true;
            this.cmdQuitar.Click += new System.EventHandler(this.cmdQuitar_Click);
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(1363, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(365, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Configuracion Tipo de Conceptos";
            // 
            // FrmTiposPercepcionDeduccionDIAN
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1363, 674);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmTiposPercepcionDeduccionDIAN";
            this.ShowInTaskbar = false;
            this.Text = "FrmTiposPercepcion";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmTiposPercepcion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosDIAN)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosADAM)).EndInit();
            this.pnlArbol.ResumeLayout(false);
            this.pnlHerramientas.ResumeLayout(false);
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridDatosDIAN;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.ComboBox cboSeccion;
        private System.Windows.Forms.Label lblSeccion;
        private System.Windows.Forms.Panel pnlRelleno;
        private System.Windows.Forms.Panel pnlSeparador;
        private System.Windows.Forms.Button cmdQuitar;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.ComboBox cboTipoConcepto;
        private System.Windows.Forms.Label lblTipoConcepto;
        private System.Windows.Forms.Button cmdCargar;
        private System.Windows.Forms.Button cmdAgregar;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.ComboBox cboCompania;
        private System.Windows.Forms.Label lblCompania;
        private System.Windows.Forms.Label lblCatalogoADAM;
        private System.Windows.Forms.Label lblArbol;
        private System.Windows.Forms.Label lblDatosDIAN;
        private System.Windows.Forms.DataGridView gridDatosADAM;
        private System.Windows.Forms.Panel pnlArbol;
        private System.Windows.Forms.TreeView arbolConceptos;
    }
}
﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("devengados", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Perceptions
    {
        public Basic basico { get; set; } = new Basic();
        public Transport transporte { get; set; }
        public List<HeDs> heDs { get; set; }
        public List<HeNs> heNs { get; set; }
        public List<HrNs> hrNs { get; set; }
        public List<HrddFs> hrddFs { get; set; }
        public List<HendFs> hendFs { get; set; }
        public List<HrndFs> hrndFs { get; set; }
        public List<HeddFs> heddFs { get; set; }
        public List<Holidays> vacaciones { get; set; }
        public Premiums primas { get; set; }
        public Layoffs cesantias { get; set; }
        public List<Disabilities> incapacidades { get; set; }
        public List<Licenses> licencias { get; set; }
        public List<Bonus> bonificacion { get; set; }
        public List<Attendances> auxilios { get; set; }
        public List<Strikes> huelgas { get; set; }
        public List<OtherConcepts> otrosConceptos { get; set; }
        public List<Compensations> compensaciones { get; set; }
        public List<EPCTVBonds> bonosEPCTV { get; set; }
        public List<Commissions> comisiones { get; set; }
        public List<ThirdPartyPayments> pagosTerceros { get; set; }
        public List<Advances> anticipos { get; set; }

        [JsonProperty("dotacion")]
        public decimal Dotacion { get; set; }

        [JsonProperty("apoyoSost")]
        public decimal ApoyoSost { get; set; }

        [JsonProperty("teletrabajo")]
        public decimal Teletrabajo { get; set; }

        [JsonProperty("bonifRetiro")]
        public decimal BonifRetiro { get; set; }

        [JsonProperty("indemnizacion")]
        public decimal Indemnizacion { get; set; }

        [JsonProperty("reintegro")]
        public decimal Reintegro { get; set; }
    }
}

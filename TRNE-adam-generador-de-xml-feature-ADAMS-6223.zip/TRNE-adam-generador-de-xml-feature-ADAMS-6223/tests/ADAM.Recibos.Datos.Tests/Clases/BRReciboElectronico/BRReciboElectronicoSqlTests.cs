using Moq;
using System;
using System.Data;
using System.Data.Common;
using System.Reflection;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Utilerias.Enums;
using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests
{
    [TestClass]
    public class BRReciboElectronicoSqlTests
    {

        #region Tests B�sicos de Construcci�n

        [TestMethod]
        public void ApplicationUser_ShouldReturnValueFromConnectionFactory()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new BRReciboElectronicoSql(mockFactory.Object);

            // Act
            var result = service.ApplicationUser;

            // Assert
            Assert.AreEqual("TestUser", result);
        }

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            // Act
            var service = new BRReciboElectronicoSql(mockFactory.Object);

            // Assert
            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        [TestMethod]
        public void CheckDbConnection_ShouldReturnValueFromConnectionFactory()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            var service = new BRReciboElectronicoSql(mockFactory.Object);

            // Act
            var result = service.CheckDbConnection();

            // Assert
            Assert.IsTrue(result);
            mockFactory.Verify(f => f.CheckConnection(), Times.Once());
        }

        #endregion

        #region Tests de Validaci�n de Par�metros

        [TestMethod]
        public void GetDatasetReceipt_WithNullPayroll_ShouldThrowException()
        {
            // Arrange
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                service.ObtenDatasetRecibo(null);
            });
        }

        #endregion

        #region Tests de Estructura (Reflection)

        [TestMethod]
        public void ClassShouldImplementInterface_IBRReciboElectronico()
        {
            // Arrange
            var service = typeof(BRReciboElectronicoSql);

            // Act
            var implementaInterfaz = typeof(IBRReciboElectronico).IsAssignableFrom(service);

            // Assert
            Assert.IsTrue(implementaInterfaz, "Debe implementar IBRReciboElectronico");
        }

        [TestMethod]
        public void ShouldContainMethod_GetReceiptDataset()
        {
            // Arrange
            var type = typeof(BRReciboElectronicoSql);

            // Act
            var metodo = type.GetMethod("ObtenDatasetRecibo");

            // Assert
            Assert.IsNotNull(metodo, "Debe existir el m�todo ObtenDatasetRecibo");
            Assert.AreEqual(typeof(DataSet), metodo.ReturnType, "Debe retornar DataSet");
        }

        [TestMethod]
        public void ShouldContainMethod_GetFullReceiptDataset()
        {
            // Arrange
            var type = typeof(BRReciboElectronicoSql);

            // Act
            var metodo = type.GetMethod("ObtenDatasetReciboFull");

            // Assert
            Assert.IsNotNull(metodo, "Debe existir el m�todo ObtenDatasetReciboFull");
            Assert.AreEqual(typeof(DataSet), metodo.ReturnType, "Debe retornar DataSet");
        }

        [TestMethod]
        public void ShouldContainMethod_GetAdditionalDatasets()
        {
            // Arrange
            var type = typeof(BRReciboElectronicoSql);

            // Act
            var metodo = type.GetMethod("ObtenDatasetAdicionales");

            // Assert
            Assert.IsNotNull(metodo, "Debe existir el m�todo ObtenDatasetAdicionales");
            Assert.AreEqual(typeof(DataSet), metodo.ReturnType, "Debe retornar DataSet");

            var parametros = metodo.GetParameters();
            Assert.AreEqual(2, parametros.Length, "Debe tener 2 par�metros");
        }

        #endregion

        #region Tests de Enum ManejoNomina

        [TestMethod]
        public void PayrollManagement_ShouldContainPeriodicValue()
        {
            // Arrange & Act
            var value = ManejoNomina.periodica;

            // Assert
            Assert.IsTrue(Enum.IsDefined<ManejoNomina>(value));
        }

        [TestMethod]
        public void PayrollManagement_ShouldContainInteractiveValue()
        {
            // Arrange & Act
            var value = ManejoNomina.interactiva;

            // Assert
            Assert.IsTrue(Enum.IsDefined<ManejoNomina>(value));
        }

        #endregion

        #region Tests de SqlCommandExecutor (clase est�tica existente)

        [TestMethod]
        public void SqlCommandExecutor_ShouldBePublicClass()
        {
            // Arrange
            var type = typeof(SqlCommandExecutor);

            // Assert
            Assert.IsTrue(type.IsPublic, "SqlCommandExecutor debe ser p�blico");
            Assert.IsTrue(type.IsClass, "SqlCommandExecutor debe ser una clase");
        }

        [TestMethod]
        public void SqlCommandExecutor_ShouldContainRequestMethodWithDataAdapter()
        {
            // Arrange
            var type = typeof(SqlCommandExecutor);

            // Act
            var method = type.GetMethod("Request",
                BindingFlags.Public | BindingFlags.Static,
                null,
                new[] { typeof(DbDataAdapter) },
                null);

            // Assert
            Assert.IsNotNull(method, "Debe existir el m�todo Request(DbDataAdapter)");
            Assert.IsTrue(method.IsStatic, "Debe ser est�tico");
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        #endregion

        #region Tests de ObtenDatasetReciboFull

        [TestMethod]
        public void ObtenDatasetReciboFull_ShouldConfigureCommandAndParameters()
        {
            // Arrange
            var mockReader = new Mock<IDataReader>();
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.GetSchemaTable()).Returns(new DataTable());

            var mockCommand = new Mock<IDbCommand>();
            mockCommand.SetupProperty(c => c.CommandText);
            mockCommand.SetupProperty(c => c.CommandType);
            mockCommand.SetupProperty(c => c.CommandTimeout);
            mockCommand.Setup(c => c.Parameters).Returns(new DataTableMapping().ColumnMappings is null
                ? new Mock<IDataParameterCollection>().Object
                : new Mock<IDataParameterCollection>().Object);

            var mockParams = new Mock<IDataParameterCollection>();
            mockCommand.Setup(c => c.Parameters).Returns(mockParams.Object);
            mockCommand.Setup(c => c.CreateParameter()).Returns(() => new Mock<IDbDataParameter>().Object);
            mockCommand.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoSql(mockFactory.Object);

            // Act
            var result = service.ObtenDatasetReciboFull("COMP", "TRAB000001", "TN", "CN",
                                                        2026, 1, ManejoNomina.periodica, 1, "CF", "01");

            // Assert
            Assert.IsNotNull(result);
            // 8 SP calls: Principal, HorasExtra, Incapacidades, OtrosPagos, AccionesTitulos,
            // JubilacionPensionRetiro, SeparacionIndemnizacion, Subcontratacion
            Assert.AreEqual(8, result.Tables.Count);
            Assert.AreEqual("TablePrincipal", result.Tables[0].TableName);
            Assert.AreEqual("TableHorasExtra", result.Tables[1].TableName);
            Assert.AreEqual("TableIncapacidades", result.Tables[2].TableName);
            Assert.AreEqual("TableOtrosPagos", result.Tables[3].TableName);
            Assert.AreEqual("TableAccionesTitulos", result.Tables[4].TableName);
            Assert.AreEqual("TableJubilacionPensionRetiro", result.Tables[5].TableName);
            Assert.AreEqual("TableSeparacionIndemnizacion", result.Tables[6].TableName);
            Assert.AreEqual("TableSubcontratacion", result.Tables[7].TableName);
            // 8 SP calls = 8 ExecuteReader calls
            mockCommand.Verify(c => c.ExecuteReader(), Times.Exactly(8));
            // Total parameters across all 8 SPs
            mockCommand.Verify(c => c.CreateParameter(), Times.AtLeast(50));
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_ShouldAddConceptosSeparacionAndSwapTables()
        {
            // Arrange
            var mockReader = new Mock<IDataReader>();
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.GetSchemaTable()).Returns(new DataTable());

            var mockCommand = new Mock<IDbCommand>();
            mockCommand.SetupProperty(c => c.CommandText);
            mockCommand.SetupProperty(c => c.CommandType);
            mockCommand.SetupProperty(c => c.CommandTimeout);

            var mockParams = new Mock<IDataParameterCollection>();
            mockCommand.Setup(c => c.Parameters).Returns(mockParams.Object);
            mockCommand.Setup(c => c.CreateParameter()).Returns(() => new Mock<IDbDataParameter>().Object);
            mockCommand.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoSql(mockFactory.Object);

            // Act � ManejoNomina.interactiva triggers the Conceptos Separaci�n block
            var result = service.ObtenDatasetReciboFull("COMP", "TRAB000001", "TN", "CN",
                                                        2026, 1, ManejoNomina.interactiva, 1, "CF", "01");

            // Assert
            Assert.IsNotNull(result);
            // 8 base SPs + 1 ConceptosSeparacion = 9 tables
            Assert.AreEqual(9, result.Tables.Count);
            // 9 ExecuteReader calls
            mockCommand.Verify(c => c.ExecuteReader(), Times.Exactly(9));
            // Since all tables have 0 rows, the table name swap should have occurred:
            // Original TablePrincipal renamed to TableConceptosSeparacionZero
            Assert.AreEqual("TableConceptosSeparacionZero", result.Tables[0].TableName);
            // Original TableConceptosSeparacion renamed to TablePrincipal
            Assert.AreEqual("TablePrincipal", result.Tables[8].TableName);
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_ClosedConnection_ShouldOpenAndReturn()
        {
            // Arrange — connection starts Closed to cover the Open() branch (line 44)
            var mockReader = new Mock<IDataReader>();
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.GetSchemaTable()).Returns(new DataTable());

            var mockCommand = new Mock<IDbCommand>();
            mockCommand.SetupProperty(c => c.CommandText);
            mockCommand.SetupProperty(c => c.CommandType);
            mockCommand.SetupProperty(c => c.CommandTimeout);

            var mockParams = new Mock<IDataParameterCollection>();
            mockCommand.Setup(c => c.Parameters).Returns(mockParams.Object);
            mockCommand.Setup(c => c.CreateParameter()).Returns(() => new Mock<IDbDataParameter>().Object);
            mockCommand.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new BRReciboElectronicoSql(mockFactory.Object);

            // Act
            var result = service.ObtenDatasetReciboFull("COMP", "TRAB000001", "TN", "CN",
                                                        2026, 1, ManejoNomina.periodica, 1, "CF", "01");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(8, result.Tables.Count);
            mockConnection.Verify(c => c.Open(), Times.Once());
        }

        #endregion

        #region RealSqlConnection Tests - ObtenDatasetRecibo

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetRecibo_Periodica_RealSqlConnection_ShouldThrowAfterRetries()
        {
            var service = CreateServiceWithRealSqlConnection();
            var nomina = CreateTestNomina(ManejoNomina.periodica);

            var ex = Assert.Throws<AggregateException>(() => service.ObtenDatasetRecibo(nomina));
            Assert.IsTrue(ex.InnerExceptions.Count > 0);
        }

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetRecibo_Interactiva_RealSqlConnection_ShouldThrowAfterRetries()
        {
            var service = CreateServiceWithRealSqlConnection();
            var nomina = CreateTestNomina(ManejoNomina.interactiva);

            var ex = Assert.Throws<AggregateException>(() => service.ObtenDatasetRecibo(nomina));
            Assert.IsTrue(ex.InnerExceptions.Count > 0);
        }

        #endregion

        #region RealSqlConnection Tests - ObtenDatasetAdicionales

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetAdicionales_ValidProc_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            var nomina = CreateTestNomina(ManejoNomina.periodica);

            Assert.Throws<SqlException>(() => service.ObtenDatasetAdicionales(nomina, "sp_acumulados_recibo"));
        }

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetAdicionales_InvalidProc_ShouldReturnNull()
        {
            var service = CreateServiceWithRealSqlConnection();
            var nomina = CreateTestNomina(ManejoNomina.periodica);

            var result = service.ObtenDatasetAdicionales(nomina, "invalid_proc_not_in_whitelist");
            Assert.IsNull(result);
        }

        #endregion

        #region Helper

        private BRReciboElectronicoSql CreateServiceWithRealSqlConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection("Server=localhost;Database=FakeDB;Connection Timeout=1;Encrypt=false;"));

            return new BRReciboElectronicoSql(mockFactory.Object);
        }

        private Nomina CreateTestNomina(ManejoNomina manejoNomina)
        {
            return new Nomina("COMP", "TRAB000001", "TN", "CN", 2026, 1, manejoNomina, 1, "CF", "01");
        }

        private BRReciboElectronicoSql CreateServiceWithMockDB()
        {
            try
            {
                var mockFactory = new Mock<IDbConnectionFactory>();
                mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
                mockFactory.Setup(f => f.CheckConnection()).Returns(true);
                return new BRReciboElectronicoSql(mockFactory.Object);
            }
            catch
            {
                return null;
            }
        }

        #endregion
    }
}

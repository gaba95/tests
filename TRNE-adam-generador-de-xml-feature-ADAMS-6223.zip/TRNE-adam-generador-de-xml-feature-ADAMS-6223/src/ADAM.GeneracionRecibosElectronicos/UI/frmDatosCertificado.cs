﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Security;
using System.Windows.Forms;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmDatosCertificado : Form
    {

        #region Properties

        SecureString _keyPwd;

        public string certPath { get; private set; } = "";

        public string keyPath { get; private set; } = string.Empty;

        public string keyPwd
        {
            get
            {
                return new NetworkCredential(string.Empty, _keyPwd).Password;
            }
        }

        #endregion

        #region Methods

        public FrmDatosCertificado()
        {
            InitializeComponent();
        }

        private void cmdBuscarArchivo_Click(object sender, EventArgs e)
        {
            ofArchivoCertificado.Filter = "Certificados|*.cer";
            ofArchivoCertificado.ShowDialog();
            txtRuta.Text = ofArchivoCertificado.FileName;
        }

        private void cmdBuscarArchivoKey_Click(object sender, EventArgs e)
        {
            ofArchivoCertificado.Filter = "Archivos Llave|*.key";
            ofArchivoCertificado.ShowDialog();
            txtRutaLlave.Text = ofArchivoCertificado.FileName;
        }

        private void cmdAceptar_Click(object sender, EventArgs e)
        {
            certPath = txtRuta.Text;

            keyPath = txtRutaLlave.Text;
            _keyPwd = new NetworkCredential(string.Empty, txtPasswordLlave.Text).SecurePassword;

            this.Close();
        }

        #endregion

    }
}

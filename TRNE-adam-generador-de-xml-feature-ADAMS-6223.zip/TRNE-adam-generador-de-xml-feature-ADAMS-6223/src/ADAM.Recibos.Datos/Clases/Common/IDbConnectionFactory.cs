﻿using System.Data;

namespace ADAM.Recibos.Datos.Clases.Common
{
    public interface IDbConnectionFactory
    {
        string ApplicationUser { get; }

        bool CheckConnection();

        IDbConnection CreateConnection();
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    /// <summary>
    /// Period Class
    /// </summary>
    [JsonObject("periodo", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Period
    {        
        [JsonProperty("fechaLiquidacionInicio")]
        public string FechaPagoInicio { get; set; }

        [JsonProperty("fechaLiquidacionFinal")]
        public string FechaPagoFin { get; set; }

        [JsonProperty("fechaGeneracion")]
        public string FechaGen { get; set; }
    }
}

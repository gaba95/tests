﻿using ADAM.Recibos.Controls;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Test.Helpers;
using System.Data;
using System.Xml;

namespace ADAM.Recibos.Principal.Test.Classes.Helpers
{
    [TestClass]
    public class XmlHelperTest
    {
        [TestInitialize]
        public void TestInit()
        {
            CustomMessageBox.SuppressUI = true;
        }

        [TestCleanup]
        public void TestCleanup()
        {
            CustomMessageBox.SuppressUI = false;
        }

        #region ConvierteDatasetXml

        [TestMethod]
        public void ConvierteDatasetXml_SingleTable_ReturnsNonEmptyXml()
        {
            var ds = new DataSet("TestDS");
            var table = new DataTable("Empleado");
            table.Columns.Add("Nombre", typeof(string));
            table.Rows.Add("Juan");
            ds.Tables.Add(table);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "Juan");
        }

        [TestMethod]
        public void ConvierteDatasetXml_SingleTable_ContainsUtf8Encoding()
        {
            var ds = new DataSet("TestDS");
            var table = new DataTable("Item");
            table.Columns.Add("Value", typeof(string));
            table.Rows.Add("Test");
            ds.Tables.Add(table);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            StringAssert.Contains(result, "utf-8");
        }

        [TestMethod]
        public void ConvierteDatasetXml_SingleTable_MultipleRows_ContainsAllData()
        {
            var ds = new DataSet("TestDS");
            var table = new DataTable("Registro");
            table.Columns.Add("Id", typeof(int));
            table.Columns.Add("Nombre", typeof(string));
            table.Rows.Add(1, "Ana");
            table.Rows.Add(2, "Pedro");
            table.Rows.Add(3, "Maria");
            ds.Tables.Add(table);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            StringAssert.Contains(result, "Ana");
            StringAssert.Contains(result, "Pedro");
            StringAssert.Contains(result, "Maria");
        }

        [TestMethod]
        public void ConvierteDatasetXml_SingleTable_MultipleColumns_ContainsAllColumns()
        {
            var ds = new DataSet("TestDS");
            var table = new DataTable("Empleado");
            table.Columns.Add("Nombre", typeof(string));
            table.Columns.Add("Puesto", typeof(string));
            table.Columns.Add("Salario", typeof(decimal));
            table.Rows.Add("Carlos", "Ingeniero", 50000m);
            ds.Tables.Add(table);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            StringAssert.Contains(result, "Carlos");
            StringAssert.Contains(result, "Ingeniero");
            StringAssert.Contains(result, "50000");
        }

        [TestMethod]
        public void ConvierteDatasetXml_MultipleTables_ReturnsNonEmptyXml()
        {
            var ds = new DataSet("TestDS");
            var t1 = new DataTable("Table1");
            t1.Columns.Add("Col1", typeof(string));
            t1.Rows.Add("ValueA");
            var t2 = new DataTable("Table2");
            t2.Columns.Add("Col2", typeof(string));
            t2.Rows.Add("ValueB");
            ds.Tables.Add(t1);
            ds.Tables.Add(t2);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "ValueA");
            StringAssert.Contains(result, "ValueB");
        }

        [TestMethod]
        public void ConvierteDatasetXml_NoTables_ReturnsNonNullXml()
        {
            var ds = new DataSet("Empty");

            var result = XmlHelper.ConvierteDatasetXml(ds);

            // 0 tables → Tables.Count != 1 → else branch (MemoryStream path)
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ConvierteDatasetXml_MultipleTables_ContainsDataSetName()
        {
            var ds = new DataSet("MiDataSet");
            var t1 = new DataTable("T1");
            t1.Columns.Add("A", typeof(string));
            t1.Rows.Add("X");
            var t2 = new DataTable("T2");
            t2.Columns.Add("B", typeof(string));
            t2.Rows.Add("Y");
            ds.Tables.Add(t1);
            ds.Tables.Add(t2);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            StringAssert.Contains(result, "MiDataSet");
        }

        #endregion

        #region DepuraNodosNomina

        [TestMethod]
        public void DepuraNodosNomina_InvalidXml_ReturnsOriginal()
        {
            var invalidXml = "this is not xml at all";

            var result = XmlHelper.DepuraNodosNomina(invalidXml);

            Assert.AreEqual(invalidXml, result);
        }

        [TestMethod]
        public void DepuraNodosNomina_EmptyString_ReturnsEmptyString()
        {
            var result = XmlHelper.DepuraNodosNomina(string.Empty);

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void DepuraNodosNomina_NullInput_ReturnsNull()
        {
            var result = XmlHelper.DepuraNodosNomina(null!);

            Assert.IsNull(result);
        }

        [TestMethod]
        public void DepuraNodosNomina_NoNominaElement_ReturnsOuterXml()
        {
            var xml = "<root><child>value</child></root>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            StringAssert.Contains(result, "<root>");
            StringAssert.Contains(result, "value");
        }

        [TestMethod]
        public void DepuraNodosNomina_XmlWithDifferentNamespace_ReturnsUnmodified()
        {
            var xml = @"<Nomina xmlns=""http://www.example.com/other""><Emisor/></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            // Different namespace → GetElementsByTagName returns empty → elemento is null
            StringAssert.Contains(result, "Emisor");
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaWithSingleChildlessNode_RemovesIt()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina""><Emisor/></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            Assert.IsFalse(result.Contains("Emisor"), "Childless Emisor node should be removed");
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaAllChildrenWithSubChildren_PreservesAll()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina""><Percepciones><Percepcion/></Percepciones><Deducciones><Deduccion/></Deducciones></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            StringAssert.Contains(result, "Percepciones");
            StringAssert.Contains(result, "Deducciones");
        }

        [TestMethod]
        public void DepuraNodosNomina_EmptyNomina_ReturnsXml()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina""/>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "Nomina");
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaWithMixedChildren_ResultIsWellFormedXml()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina""><Receptor><SubContratacion/></Receptor><Emisor/></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            // Verify the result is well-formed XML regardless of which nodes were removed
            var doc = new XmlDocument();
            doc.LoadXml(result);
            StringAssert.Contains(result, "Receptor");
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaInsideComprobante_ProcessesCorrectly()
        {
            var xml = @"<cfdi:Comprobante xmlns:cfdi=""http://www.sat.gob.mx/cfd/4"" xmlns:nomina=""http://www.sat.gob.mx/nomina""><nomina:Nomina><nomina:Emisor/><nomina:Receptor><nomina:SubContratacion/></nomina:Receptor></nomina:Nomina></cfdi:Comprobante>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "Comprobante");
        }

        #endregion

        #region LoadAllSchemas

        [TestMethod]
        public void LoadAllSchemas_FileNameContains12_ReturnsSchemaSet()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xsdPath = Path.Combine(tempDir.PathValue, "test_nomina12.xsd");
            File.WriteAllText(xsdPath, MinimalXsd("http://www.sat.gob.mx/nomina12"));

            var result = XmlHelper.LoadAllSchemas(xsdPath);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count > 0);
        }

        [TestMethod]
        public void LoadAllSchemas_FileNameNotContains12_ReturnsSchemaSet()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xsdPath = Path.Combine(tempDir.PathValue, "test_nomina.xsd");
            File.WriteAllText(xsdPath, MinimalXsd("http://www.sat.gob.mx/nomina"));

            var result = XmlHelper.LoadAllSchemas(xsdPath);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count > 0);
        }

        [TestMethod]
        public void LoadAllSchemas_NonExistentFile_ThrowsFileNotFoundException()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var fakePath = Path.Combine(tempDir.PathValue, "nonexistent_nomina12.xsd");

            Assert.Throws<FileNotFoundException>(() =>
                XmlHelper.LoadAllSchemas(fakePath));
        }

        [TestMethod]
        public void LoadAllSchemas_ReturnsCompiledSchemaSet()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xsdPath = Path.Combine(tempDir.PathValue, "nomina12_compiled.xsd");
            File.WriteAllText(xsdPath, MinimalXsd("http://www.sat.gob.mx/nomina12"));

            var schemaSet = XmlHelper.LoadAllSchemas(xsdPath);

            Assert.IsTrue(schemaSet.IsCompiled);
        }

        #endregion

        #region TransformaXml

        [TestMethod]
        public void TransformaXml_ExtValidationsTrue_FileNotExists_ReturnsEmpty()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");

            var result = XmlHelper.TransformaXml(
                tempDir.PathValue + Path.DirectorySeparatorChar,
                "<root/>",
                "template.xslt",
                false,
                new XmlWriterSettings(),
                extValidations: true);

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void TransformaXml_ExtValidationsTrue_FileExists_ContinuesToTransform()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            // Create ext validation file at appPath + extTemplate for File.Exists check
            File.WriteAllText(
                Path.Combine(tempDir.PathValue, "nomina12_40ADAM_ext.xsd"),
                "existence marker");

            // Create XSLT file at xml/ subdirectory for actual loading
            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12_40ADAM_ext.xsd"),
                MinimalXslt());

            var settings = new XmlWriterSettings { OmitXmlDeclaration = true };
            var result = XmlHelper.TransformaXml(
                tempDir.PathValue + Path.DirectorySeparatorChar,
                "<root><data>ExtValue</data></root>",
                "nomina12_40ADAM.xslt",
                false,
                settings,
                extValidations: true);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "ExtValue");
        }

        [TestMethod]
        public void TransformaXml_WhiteListHit_XsltExists_ReturnsTransformedXml()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12_40ADAM.xslt"),
                MinimalXslt());

            var settings = new XmlWriterSettings { OmitXmlDeclaration = true };
            var result = XmlHelper.TransformaXml(
                tempDir.PathValue,
                "<root><data>TestValue</data></root>",
                "nomina12_40ADAM.xslt",
                false,
                settings,
                extValidations: false);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "TestValue");
        }

        [TestMethod]
        public void TransformaXml_WhiteListHit_XsltNotExists_ReturnsNonNull()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);
            // Don't create the XSLT file

            var settings = new XmlWriterSettings { OmitXmlDeclaration = true };
            var result = XmlHelper.TransformaXml(
                tempDir.PathValue,
                "<root><data>Test</data></root>",
                "nomina12_40ADAM.xslt",
                false,
                settings,
                extValidations: false);

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TransformaXml_WhiteListHit_DebugTrue_ReturnsTransformedXml()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12_40ADAM.xslt"),
                MinimalXslt());

            var settings = new XmlWriterSettings { OmitXmlDeclaration = true };
            var result = XmlHelper.TransformaXml(
                tempDir.PathValue,
                "<root><data>DebugValue</data></root>",
                "nomina12_40ADAM.xslt",
                true,
                settings,
                extValidations: false);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "DebugValue");
        }

        #endregion

        #region ValidaXmlvsXsd

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_ValidXml_ReturnsTrue()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12.xsd"),
                MinimalXsd("http://www.sat.gob.mx/nomina12"));

            var validXml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina12"">Test</Nomina>";

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                validXml,
                "nomina12.xsd",
                "TRAB001",
                null!);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_InvalidXml_ReturnsFalse()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            // Schema requires Emisor child element
            var xsdContent = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<xs:schema xmlns:xs=""http://www.w3.org/2001/XMLSchema""
           targetNamespace=""http://www.sat.gob.mx/nomina12""
           xmlns:tns=""http://www.sat.gob.mx/nomina12""
           elementFormDefault=""qualified"">
  <xs:element name=""Nomina"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Emisor"" type=""xs:string""/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";

            File.WriteAllText(Path.Combine(xmlDir, "nomina12.xsd"), xsdContent);

            // XML with unexpected element (Invalid instead of required Emisor)
            var invalidXml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina12""><Invalid>Test</Invalid></Nomina>";

            // CallBackThread with null Control so UpdateUI is a no-op
            CallBackDelegate noOpCallback = (s, r) => { };
            var callback = new CallBackThread(null!, () => Task.CompletedTask, noOpCallback);

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                invalidXml,
                "nomina12.xsd",
                "TRAB001",
                callback);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_ValidComplexXml_ReturnsTrue()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            var xsdContent = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<xs:schema xmlns:xs=""http://www.w3.org/2001/XMLSchema""
           targetNamespace=""http://www.sat.gob.mx/nomina12""
           xmlns:tns=""http://www.sat.gob.mx/nomina12""
           elementFormDefault=""qualified"">
  <xs:element name=""Nomina"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Emisor"" type=""xs:string""/>
        <xs:element name=""Receptor"" type=""xs:string"" minOccurs=""0""/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";

            File.WriteAllText(Path.Combine(xmlDir, "nomina12.xsd"), xsdContent);

            var validXml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina12""><Emisor>RFC123</Emisor><Receptor>RFC456</Receptor></Nomina>";

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                validXml,
                "nomina12.xsd",
                "TRAB002",
                null!);

            Assert.IsTrue(result);
        }

        #endregion

        #region ConvierteDatasetXml – additional coverage

        [TestMethod]
        public void ConvierteDatasetXml_SingleTable_EmptyRows_ReturnsXml()
        {
            var ds = new DataSet("TestDS");
            var table = new DataTable("Empty");
            table.Columns.Add("Col1", typeof(string));
            // No rows added
            ds.Tables.Add(table);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            Assert.IsFalse(string.IsNullOrEmpty(result));
        }

        [TestMethod]
        public void ConvierteDatasetXml_MultipleTables_WithRelations_ReturnsAllData()
        {
            var ds = new DataSet("RelDS");
            var parent = new DataTable("Parent");
            parent.Columns.Add("Id", typeof(int));
            parent.Columns.Add("Name", typeof(string));
            parent.Rows.Add(1, "ParentRow");

            var child = new DataTable("Child");
            child.Columns.Add("ParentId", typeof(int));
            child.Columns.Add("Detail", typeof(string));
            child.Rows.Add(1, "ChildRow");

            ds.Tables.Add(parent);
            ds.Tables.Add(child);

            var result = XmlHelper.ConvierteDatasetXml(ds);

            StringAssert.Contains(result, "ParentRow");
            StringAssert.Contains(result, "ChildRow");
        }

        [TestMethod]
        public void ConvierteDatasetXml_ThreeTables_UsesMemoryStreamPath()
        {
            var ds = new DataSet("ThreeTableDS");
            for (int i = 0; i < 3; i++)
            {
                var t = new DataTable($"Table{i}");
                t.Columns.Add("Val", typeof(string));
                t.Rows.Add($"Value{i}");
                ds.Tables.Add(t);
            }

            var result = XmlHelper.ConvierteDatasetXml(ds);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "Value0");
            StringAssert.Contains(result, "Value1");
            StringAssert.Contains(result, "Value2");
        }

        #endregion

        #region DepuraNodosNomina – additional coverage

        [TestMethod]
        public void DepuraNodosNomina_NominaWithMultipleChildlessNodes_RemovesAll()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina""><Emisor/><Receptor/><OtroDato/></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            // ForEach over ChildNodes while removing — tests iteration behavior
            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "Nomina");
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaWithTextNode_PreservesText()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina"">SomeTextContent</Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            Assert.IsFalse(string.IsNullOrEmpty(result));
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaWithChildContainingText_PreservesChild()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina""><Percepciones>Datos</Percepciones></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            StringAssert.Contains(result, "Percepciones");
            StringAssert.Contains(result, "Datos");
        }

        [TestMethod]
        public void DepuraNodosNomina_NominaWithAttributes_PreservesAttributes()
        {
            var xml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina"" Version=""1.2""><Emisor/></Nomina>";

            var result = XmlHelper.DepuraNodosNomina(xml);

            StringAssert.Contains(result, "Version");
        }

        #endregion

        #region TransformaXml – additional coverage

        [TestMethod]
        public void TransformaXml_WhiteListMiss_ReturnsEmpty()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");

            var result = XmlHelper.TransformaXml(
                tempDir.PathValue,
                "<root/>",
                "not_in_whitelist.xslt",
                false,
                new XmlWriterSettings(),
                extValidations: false);

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void TransformaXml_WhiteListHit_MalformedXml_ReturnsEmpty()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12_40ADAM.xslt"),
                MinimalXslt());

            var result = XmlHelper.TransformaXml(
                tempDir.PathValue,
                "<<<not valid xml>>>",
                "nomina12_40ADAM.xslt",
                false,
                new XmlWriterSettings(),
                extValidations: false);

            // Malformed XML triggers exception → catch → returns empty
            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void TransformaXml_ExtValidationsTrue_ExtFileExists_WhiteListMiss_ReturnsEmpty()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");

            // Create the ext file so File.Exists passes
            File.WriteAllText(
                Path.Combine(tempDir.PathValue, "unknown_ext.xsd"),
                "marker");

            var result = XmlHelper.TransformaXml(
                tempDir.PathValue + Path.DirectorySeparatorChar,
                "<root/>",
                "unknown.xslt",
                false,
                new XmlWriterSettings(),
                extValidations: true);

            // ext file exists → template becomes unknown_ext.xsd → whitelist miss → returns empty
            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void TransformaXml_ExtValidationsFalse_MultipleWhiteListTemplates_TransformsCorrectly()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12_40ADAMEle.xslt"),
                MinimalXslt());

            var settings = new XmlWriterSettings { OmitXmlDeclaration = true };
            var result = XmlHelper.TransformaXml(
                tempDir.PathValue,
                "<root><data>EleValue</data></root>",
                "nomina12_40ADAMEle.xslt",
                false,
                settings,
                extValidations: false);

            Assert.IsFalse(string.IsNullOrEmpty(result));
            StringAssert.Contains(result, "EleValue");
        }

        #endregion

        #region ValidaXmlvsXsd – additional coverage

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListMiss_ReturnsFalse()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                "<root/>",
                "not_in_whitelist.xsd",
                "TRAB001",
                null!);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_NonExistentXsd_ReturnsFalse()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);
            // Don't create the actual XSD file → FileNotFoundException → catch → returns false

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                "<root/>",
                "nomina12.xsd",
                "TRAB001",
                null!);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_WarningOnly_ReturnsTrue()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            // Schema that accepts any content (xs:anyType)
            var xsdContent = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<xs:schema xmlns:xs=""http://www.w3.org/2001/XMLSchema""
           targetNamespace=""http://www.sat.gob.mx/nomina12""
           xmlns:tns=""http://www.sat.gob.mx/nomina12""
           elementFormDefault=""qualified"">
  <xs:element name=""Nomina"">
    <xs:complexType mixed=""true"">
      <xs:sequence>
        <xs:any minOccurs=""0"" maxOccurs=""unbounded"" processContents=""lax""/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";

            File.WriteAllText(Path.Combine(xmlDir, "nomina12.xsd"), xsdContent);

            var validXml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina12""><Unknown>data</Unknown></Nomina>";

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                validXml,
                "nomina12.xsd",
                "TRAB003",
                null!);

            // No errors (warnings only or none) → returns true
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_MultipleErrors_AllReported()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            // Strict schema requiring specific structure
            var xsdContent = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<xs:schema xmlns:xs=""http://www.w3.org/2001/XMLSchema""
           targetNamespace=""http://www.sat.gob.mx/nomina12""
           xmlns:tns=""http://www.sat.gob.mx/nomina12""
           elementFormDefault=""qualified"">
  <xs:element name=""Nomina"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Emisor"" type=""xs:string""/>
        <xs:element name=""Receptor"" type=""xs:string""/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";

            File.WriteAllText(Path.Combine(xmlDir, "nomina12.xsd"), xsdContent);

            // XML missing both required elements
            var invalidXml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina12""><Bad1/><Bad2/></Nomina>";

            var messages = new System.Collections.Generic.List<string>();
            CallBackDelegate captureCallback = (s, r) => { messages.Add(s); };
            var callback = new CallBackThread(null!, () => Task.CompletedTask, captureCallback);

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                invalidXml,
                "nomina12.xsd",
                "TRAB004",
                callback);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidaXmlvsXsd_WhiteListHit_DifferentXsdTemplate_ReturnsTrue()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xmlDir = Path.Combine(tempDir.PathValue, "xml");
            Directory.CreateDirectory(xmlDir);

            File.WriteAllText(
                Path.Combine(xmlDir, "nomina12_40ADAM.xsd"),
                MinimalXsd("http://www.sat.gob.mx/nomina12"));

            var validXml = @"<Nomina xmlns=""http://www.sat.gob.mx/nomina12"">Test</Nomina>";

            var result = XmlHelper.ValidaXmlvsXsd(
                tempDir.PathValue,
                validXml,
                "nomina12_40ADAM.xsd",
                "TRAB005",
                null!);

            Assert.IsTrue(result);
        }

        #endregion

        #region LoadAllSchemas – additional coverage

        [TestMethod]
        public void LoadAllSchemas_MalformedXsd_ThrowsXmlSchemaException()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xsdPath = Path.Combine(tempDir.PathValue, "bad_nomina12.xsd");
            File.WriteAllText(xsdPath, "this is not valid xsd");

            Assert.Throws<XmlException>(() =>
                XmlHelper.LoadAllSchemas(xsdPath));
        }

        [TestMethod]
        public void LoadAllSchemas_EmptyXsd_ThrowsException()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xsdPath = Path.Combine(tempDir.PathValue, "empty_nomina.xsd");
            File.WriteAllText(xsdPath, string.Empty);

            Assert.Throws<XmlException>(() =>
                XmlHelper.LoadAllSchemas(xsdPath));
        }

        [TestMethod]
        public void LoadAllSchemas_ComplexXsd_WithMultipleElements_ReturnsCompiledSet()
        {
            using var tempDir = new TestTempDirectory("XmlHelperTest");
            var xsdPath = Path.Combine(tempDir.PathValue, "complex_nomina12.xsd");
            var xsdContent = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<xs:schema xmlns:xs=""http://www.w3.org/2001/XMLSchema""
           targetNamespace=""http://www.sat.gob.mx/nomina12""
           xmlns:tns=""http://www.sat.gob.mx/nomina12""
           elementFormDefault=""qualified"">
  <xs:element name=""Nomina"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Emisor"" type=""xs:string""/>
        <xs:element name=""Receptor"" type=""xs:string"" minOccurs=""0""/>
      </xs:sequence>
      <xs:attribute name=""Version"" type=""xs:string""/>
    </xs:complexType>
  </xs:element>
</xs:schema>";
            File.WriteAllText(xsdPath, xsdContent);

            var result = XmlHelper.LoadAllSchemas(xsdPath);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCompiled);
            Assert.IsTrue(result.Count > 0);
        }

        #endregion

        #region Helpers

        private static string MinimalXsd(string targetNamespace) =>
            $@"<?xml version=""1.0"" encoding=""UTF-8""?>
<xs:schema xmlns:xs=""http://www.w3.org/2001/XMLSchema""
           targetNamespace=""{targetNamespace}""
           xmlns:tns=""{targetNamespace}""
           elementFormDefault=""qualified"">
  <xs:element name=""Nomina"" type=""xs:string""/>
</xs:schema>";

        private static string MinimalXslt() =>
            @"<?xml version=""1.0"" encoding=""UTF-8""?>
<xsl:stylesheet version=""1.0"" xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"">
  <xsl:output method=""xml"" indent=""no""/>
  <xsl:template match=""/"">
    <result><xsl:value-of select=""//data""/></result>
  </xsl:template>
</xsl:stylesheet>";

        #endregion
    }
}

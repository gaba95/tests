using System.Data;
using ADAM.Recibos.Datos.Utils;
using Oracle.ManagedDataAccess.Client;
using ADAM.Recibos.Datos.Clases.Common;

namespace ADAM.Recibos.Datos.Clases.CatalogoDIAN
{
    public class CatalogoDianOracle : ICatalogoDian
    {
        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoDianOracle(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public DataSet dsListaSeccionesDIAN(string szTipo, string szTipoConcepto = "")
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT id_campo AS clave,
                                                descripcion
                                           FROM tb_catalogos_doc_xml_campos_padre_dian tb1
                                          WHERE (SELECT COUNT(*)
                                                   FROM tb_catalogos_doc_xml_campos_hijo_dian tb2
                                                  WHERE tb2.id_padre = tb1.id_campo
                                                    AND tb2.habilitar_mapeo = 1) > 0";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet dsListaCamposDIAN(string szIdPadre, string szTipoMapeo, string szTipoConcepto = "")
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            OracleCommand oracleStmt;
            if (!string.IsNullOrEmpty(szTipoConcepto))
            {
                const string oracleQuery01 = @"SELECT tbh.id AS 'clave',
                                                        CASE 
                                                          WHEN tbm.tipo_mapeo='query' THEN tbh.id + ' - ' + tbh.id_campo
                                                          ELSE tbh.id_campo
                                                        END AS 'descripcion'
                                                 FROM tb_catalogos_doc_xml_campos_hijo_dian tbh
                                                  INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                          AND tbm.tipo_mapeo = @TipoMapeo
                                                                                                          AND tbm.tipo_concepto = CASE 
                                                                                                                                      WHEN tbm.tipo_mapeo = 'query' THEN tbm.tipo_concepto 
                                                                                                                                      ELSE @TipoConcepto
                                                                                                                                    END
                                                WHERE tbh.id_padre = @IdPadre
                                                  AND tbh.habilitar_mapeo = 1
                                                ORDER BY tbh.id";
                oracleStmt = new OracleCommand(oracleQuery01, oracleConnection);
            }
            else
            {
                const string oracleQuery2 = @"SELECT tbh.id AS 'clave',
                                                     CASE 
                                                       WHEN tbm.tipo_mapeo='query' THEN tbh.id + ' - ' + tbh.id_campo
                                                       ELSE tbh.id_campo
                                                     END AS 'descripcion'
                                                FROM tb_catalogos_doc_xml_campos_hijo_dian tbh
                                                 INNER JOIN tb_catalogos_doc_xml_campos_mapas_dian AS tbm ON tbh.id = tbm.id_campo 
                                                                                                         AND tbm.tipo_mapeo = @TipoMapeo
                                               WHERE tbh.id_padre = @IdPadre
                                                 AND tbh.habilitar_mapeo = 1 
                                               ORDER BY tbh.id";
                oracleStmt = new OracleCommand(oracleQuery2, oracleConnection);
            }
            oracleStmt.Parameters.Add("@TipoMapeo", SqlDbType.VarChar).Value = szTipoMapeo;
            oracleStmt.Parameters.Add("@TipoConcepto", SqlDbType.VarChar).Value = szTipoConcepto;
            oracleStmt.Parameters.Add("@IdPadre", SqlDbType.VarChar).Value = szIdPadre;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        public DataSet getDatasetEmployeesReceiptDian(string compania, string anio, string mes)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_trabajadores_recibo_dian";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add("@company", SqlDbType.Char).Value = compania;
            oracleStmt.Parameters.Add("@year", SqlDbType.Char).Value = anio;
            oracleStmt.Parameters.Add("@month", SqlDbType.Int).Value = mes;
            oracleStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
            dsResult = (dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0 ? dsResult : null);
            return dsResult;
        }

        public DataSet getDatasetInformationDian(string compania, string anio, string mes, string employee, string id_parent_node, string tipo)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = "sp_conceptos_json_dian";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection)
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add("@company", SqlDbType.VarChar).Value = compania;
            oracleStmt.Parameters.Add("@year", SqlDbType.VarChar).Value = anio;
            oracleStmt.Parameters.Add("@month", SqlDbType.VarChar).Value = mes;
            oracleStmt.Parameters.Add("@employee", SqlDbType.VarChar).Value = employee;
            oracleStmt.Parameters.Add("@id_parent_node", SqlDbType.VarChar).Value = id_parent_node;
            oracleStmt.Parameters.Add("@tipo", SqlDbType.VarChar).Value = tipo;
            oracleStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
            dsResult = (dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0 ? dsResult : null);
            return dsResult;
        }

        public DataSet getParentIdCatalog()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT id_padre, tipo 
                                           FROM (
                                                 SELECT DISTINCT id_padre, 
                                                        (
                                                          SELECT CASE tipo_mapeo 
                                                                   WHEN 'query' THEN tipo_mapeo 
                                                                   ELSE tipo_concepto 
                                                                 END 
                                                            FROM tb_catalogos_doc_xml_campos_mapas_dian tcm 
                                                           WHERE tcm.id_campo = tch.id 
                                                         ) AS tipo 
                                                   FROM tb_catalogos_doc_xml_campos_hijo_dian tch 
                                                  WHERE habilitar_mapeo = 1
                                                ) Result 
                                          WHERE tipo IS NOT NULL 
                                          ORDER BY CASE 
                                                     WHEN id_padre = 'Trabajador' THEN 0 
                                                     ELSE 
                                                        CASE 
                                                          WHEN id_padre = 'Deducciones' OR id_padre = 'Devengados' OR id_padre = 'Empleador' THEN 1 
                                                          ELSE 2 
                                                         END 
                                                     END";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
            dsResult = (dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0 ? dsResult : null);
            return dsResult;
        }

        public DataSet getTypeClassification()
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            const string oracleQuery = @"SELECT id_padre,
                                                tipo,
                                                CASE tipo
                                                  WHEN 'query' THEN ''
                                                  WHEN 'percepcion' THEN 'devengados'
                                                  WHEN 'InformacionNomina' THEN ''
                                                  WHEN 'AjusteNomina' THEN ''
                                                  ELSE tipo
                                                END AS Header,
                                                CASE id_padre
                                                  WHEN 'Trabajador' THEN 'Informacion del Empleado'
                                                  WHEN 'Pago' THEN 'Pago'
                                                  WHEN 'FechasPagos' THEN 'FechasPagos'
                                                  WHEN 'numeroSecuenciaXML' THEN 'numeroSecuenciaXML'
                                                  WHEN 'InformacionNomina' THEN 'Información Nomina'
                                                  WHEN 'AjusteNomina' THEN 'Ajuste Nomina'
                                                  WHEN 'HED' THEN 'HeDs'
                                                  WHEN 'HEDDF' THEN 'heddFs'
                                                  WHEN 'HEN' THEN 'heNs'
                                                  WHEN 'HENDF' THEN 'hendFs'
                                                  WHEN 'HRDDF' THEN 'hrddFs'
                                                  WHEN 'HRN' THEN 'hrNs'
                                                  WHEN 'HRNDF' THEN 'hrndFs'
                                                  ELSE id_padre
                                              END AS subHeader
                                              FROM
                                                (
                                                  SELECT DISTINCT id_padre,
                                                                  ISNULL(
                                                                         (
                                                                            SELECT 
                                                                               CASE tipo_mapeo
                                                                                 WHEN 'query' THEN tipo_mapeo
                                                                                 ELSE tipo_concepto
                                                                               END
                                                                             FROM tb_catalogos_doc_xml_campos_mapas_dian tcm
                                                                            WHERE tcm.id_campo = tch.id
                                                                         ),
                                                                         'query'
                                                                        ) AS tipo
                                                    FROM tb_catalogos_doc_xml_campos_hijo_dian tch
                                                   WHERE habilitar_mapeo = 1
                                                 UNION
                                                   SELECT 'numeroSecuenciaXML' AS id_padre,
                                                          'query' AS tipo
                                                 UNION
                                                   SELECT 'InformacionNomina' AS id_padre,
                                                          'InformacionNomina' AS tipo
                                                 UNION
                                                   SELECT 'AjusteNomina' AS id_padre,
                                                          'AjusteNomina' AS tipo
                                                ) Result
                                              WHERE tipo IS NOT NULL
                                                AND NOT id_padre IN ('Empleador', 'InformacionGeneral', 'LugarGeneracionXML', 'NominaIndividual', 'Novedad', 'Periodo', 'ProveedorXML')
                                              ORDER BY CASE id_padre
                                                         WHEN 'Trabajador' THEN 0
                                                         WHEN 'InformacionNomina' THEN 1
                                                         WHEN 'AjusteNomina' THEN 2
                                                         WHEN 'numeroSecuenciaXML' THEN 3
                                                         WHEN 'Pago' THEN 4
                                                         WHEN 'FechasPagos' THEN 5
                                                         WHEN 'percepcion' THEN 6
                                                         WHEN 'deduccion' THEN 7
                                                         ELSE
                                                            CASE
                                                                WHEN tipo = 'percepcion' THEN 6
                                                                ELSE 8
                                                            END
                                                       END";
            var oracleStmt = new OracleCommand(oracleQuery, oracleConnection);
            oracleStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
            dsResult = (dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0 ? dsResult : null);
            return dsResult;
        }

        #region Not in use, part of the interface implementation

        public DataSet obtenDatasetTablaDIAN(string szIdCampo)
        {
            return null;
        }

        public DataSet obtenCatalogoAdamDIAN(string id_campo, string param1 = "")
        {
            return null;
        }

        public bool altaRelacionDatoCatalogoDIAN(string szCompania, string szCampo, string szClaveDian, string szClaveAdam)
        {
            return false;
        }

        public bool existRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto)
        {
            return false;
        }

        public bool bajaRelacionDatoCatalogoDIAN(string szCompania, string szCampo, string szClaveDian, string szClaveAdam)
        {
            return false;
        }

        public DataSet obtenDatasetRelacionCatalogosDIAN(string szCompania, string szCampo, string szClaveDian)
        {
            return null;
        }

        public DataSet obtenDatasetConceptosRelacionarDIAN(string tipoConcepto)
        {
            return null;
        }

        public bool getDatasetConceptosADAM(string tipoConcepto, string szConcepto)
        {
            return true;
        }

        public bool altaRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto)
        {
            return false;
        }

        public DataSet obtenDatasetRelacionConceptosDIAN(string szCompania, string szCampo)
        {
            return null;
        }

        public bool bajaRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto)
        {
            return false;
        }
        
        public static DataSet obtenConfiguracionActualAdicional(string selectedValue)
        {
            throw new NotImplementedException();
        }
        
        public static void guardaConfiguracionActualAdicional(string selectedValue, string ruta_temp, string url_api, string usuario, string contrasenia)
        {
            throw new NotImplementedException();
        }
        
        public DataSet obtenDatasetTreeViewCatalogosDIAN()
        {
            throw new NotImplementedException();
        }
        
        public DataSet obtenDatasetTreeViewCatalogosDIANByCompany(string company)
        {
            throw new NotImplementedException();
        }
        
        public DataSet obtenDatasetTreeViewConceptosDIAN()
        {
            throw new NotImplementedException();
        }
        
        public DataSet obtenDatasetTreeViewConceptosDIANByCompany(string company)
        {
            throw new NotImplementedException();
        }
        
        public DataSet obtenDataSetConceptosAux()
        {
            throw new NotImplementedException();
        }
        
        public DataSet obtenDataSetCatalogosAux()
        {
            throw new NotImplementedException();
        }
        
        public Task<bool> ActualizaBitacoraCorrelativosDian(string compania, string numero, string documento_id, string estado_accion)
        {
            return Task.FromResult(false);
        }
        
        public bool AltaResultadoValidacion(string numero, string codigo_error, string mensaje)
        {
            return false;
        }
        
        public DataSet obtenDatasetBitacoraCorrelativosDianEmpleado(string compania, string trabajador, bool correctos = true)
        {
            return null;
        }
        
        public static DataSet obtenConfiguracionActualAdicionalMx(string compania)
        {
            return null;
        }
        
        public static void guardaConfiguracionActualAdicionalMx(string compania, string sitio_timbrado, string nombre_xslt, string nombre_xsd, short tipo_generacion, string ruta_temp, string url_api, bool genera_adicionales, string procedimiento_adicional)
        {
            throw new NotImplementedException();
        }

        public DataSet obtenCorrelativoDian(string compania, string trabajador)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            string textoComando = "sp_correlativo_dian";
            var comando = new OracleCommand(textoComando, oracleConnection);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.Add("compania", OracleDbType.Char, 4).Value = compania;
            comando.Parameters.Add("trabajador", OracleDbType.Char, 10).Value = trabajador;
            comando.Parameters.Add("fecha_envio", OracleDbType.Char, 2).Value = DateTime.Now;

            DataSet ds = new DataSet();
            var adapter = new OracleDataAdapter(comando);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();
                // Cambiar el formato de fecha
                OracleCommand cmdFormatoFecha = new OracleCommand("ALTER SESSION SET nls_date_format = 'YYYYMMDD'", oracleConnection);
                cmdFormatoFecha.CommandType = CommandType.Text;
                cmdFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(ds);
            return ds;
        }

        #endregion  Not in use, part of the interface implementation
    }
}

using Moq;
using System;
using System.Data;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Datos.Clases.Common;
using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoDIAN
{
    [TestClass]
    [TestCategory("LocalDB")]
    public class CatalogoDianSqlLocalDbTests
    {
        private const string LocalDbConnectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=tempdb;Integrated Security=true;Connection Timeout=5;Encrypt=false";

        private static bool _localDbAvailable;

        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            _localDbAvailable = IsLocalDbAvailable();
            if (!_localDbAvailable) return;

            using var conn = new SqlConnection(LocalDbConnectionString);
            conn.Open();

            var sql = @"
                IF OBJECT_ID('dbo.tb_catalogos_doc_xml_campos_padre_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogos_doc_xml_campos_padre_dian;
                IF OBJECT_ID('dbo.tb_catalogos_doc_xml_campos_mapas_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogos_doc_xml_campos_mapas_dian;
                IF OBJECT_ID('dbo.tb_catalogos_doc_xml_campos_hijo_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogos_doc_xml_campos_hijo_dian;
                IF OBJECT_ID('dbo.tb_catalogo_paises_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_paises_dian;
                IF OBJECT_ID('dbo.tb_catalogo_departamentos_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_departamentos_dian;
                IF OBJECT_ID('dbo.tb_catalogo_municipios_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_municipios_dian;
                IF OBJECT_ID('dbo.tb_catalogo_monedas_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_monedas_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipo_contrato_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipo_contrato_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipo_doc_identidad_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipo_doc_identidad_dian;
                IF OBJECT_ID('dbo.tb_catalogo_medios_pago_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_medios_pago_dian;
                IF OBJECT_ID('dbo.tb_catalogo_periodo_nomina_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_periodo_nomina_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipo_trabajador_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipo_trabajador_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipos_incapacidad_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipos_incapacidad_dian;
                IF OBJECT_ID('dbo.tb_bitacora_correlativos_dian','U') IS NOT NULL DROP TABLE dbo.tb_bitacora_correlativos_dian;
                IF OBJECT_ID('dbo.tb_bitacora_correlativos_dian_resultado_validacion','U') IS NOT NULL DROP TABLE dbo.tb_bitacora_correlativos_dian_resultado_validacion;
                IF OBJECT_ID('dbo.tb_rel_catalogos_dian_adam','U') IS NOT NULL DROP TABLE dbo.tb_rel_catalogos_dian_adam;
                IF OBJECT_ID('dbo.tb_rel_conceptos_dian_adam','U') IS NOT NULL DROP TABLE dbo.tb_rel_conceptos_dian_adam;
                IF OBJECT_ID('dbo.companias','U') IS NOT NULL DROP TABLE dbo.companias;
                IF OBJECT_ID('dbo.conceptos','U') IS NOT NULL DROP TABLE dbo.conceptos;

                CREATE TABLE dbo.tb_catalogos_doc_xml_campos_padre_dian (
                    id_campo VARCHAR(50) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogos_doc_xml_campos_hijo_dian (
                    id VARCHAR(50) NOT NULL,
                    id_padre VARCHAR(50) NOT NULL,
                    id_campo VARCHAR(50) NOT NULL,
                    habilitar_mapeo BIT NOT NULL DEFAULT 0
                );

                CREATE TABLE dbo.tb_catalogos_doc_xml_campos_mapas_dian (
                    id_campo VARCHAR(50) NOT NULL,
                    tipo_mapeo VARCHAR(20) NOT NULL,
                    tipo_concepto VARCHAR(20) NULL,
                    tabla_dian VARCHAR(100) NULL
                );

                CREATE TABLE dbo.tb_catalogo_paises_dian (
                    codigo_alfa2 VARCHAR(10) NOT NULL,
                    nombre_comun VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_departamentos_dian (
                    codigo_departamento VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL,
                    codigo_alfa2 VARCHAR(10) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_municipios_dian (
                    codigo_municipio VARCHAR(10) NOT NULL,
                    nombre_municipio VARCHAR(100) NOT NULL,
                    codigo_alfa2 VARCHAR(10) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_monedas_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_tipo_contrato_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_tipo_doc_identidad_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_medios_pago_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_periodo_nomina_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_tipo_trabajador_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_catalogo_tipos_incapacidad_dian (
                    codigo VARCHAR(10) NOT NULL,
                    descripcion VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.tb_bitacora_correlativos_dian (
                    compania CHAR(4) NOT NULL,
                    trabajador CHAR(10) NOT NULL,
                    fecha_envio DATETIME NOT NULL,
                    prefijo VARCHAR(50) NULL,
                    correlativo VARCHAR(50) NULL,
                    numero VARCHAR(150) NOT NULL,
                    documento_id VARCHAR(50) NULL,
                    estado_accion VARCHAR(50) NULL
                );

                CREATE TABLE dbo.tb_bitacora_correlativos_dian_resultado_validacion (
                    numero VARCHAR(150) NOT NULL,
                    codigo_error VARCHAR(10) NOT NULL,
                    mensaje VARCHAR(1024) NOT NULL
                );

                CREATE TABLE dbo.tb_rel_catalogos_dian_adam (
                    compania CHAR(4) NOT NULL,
                    id_campo VARCHAR(10) NOT NULL,
                    clave_dian VARCHAR(10) NOT NULL,
                    clave_adam VARCHAR(20) NOT NULL
                );

                CREATE TABLE dbo.tb_rel_conceptos_dian_adam (
                    compania CHAR(4) NOT NULL,
                    id_campo VARCHAR(10) NOT NULL,
                    concepto_adam VARCHAR(10) NOT NULL
                );

                CREATE TABLE dbo.companias (
                    compania CHAR(4) NOT NULL,
                    nombre_cia VARCHAR(100) NOT NULL
                );

                CREATE TABLE dbo.conceptos (
                    concepto SMALLINT NOT NULL,
                    descripcion VARCHAR(100) NOT NULL,
                    tipo_transaccion INT NOT NULL
                );
            ";
            new SqlCommand(sql, conn).ExecuteNonQuery();

            // Seed data for coverage of specific branches
            var seedSql = @"
                -- Data for getParentIdCatalog / getTypeClassification
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_padre_dian VALUES ('Trabajador');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_padre_dian VALUES ('Deducciones');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_hijo_dian VALUES ('H001', 'Trabajador', 'TipoDocumento', 1);
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('H001', 'query', NULL, 'tb_catalogo_tipo_doc_identidad_dian');

                -- Data for dsListaSeccionesDIAN / dsListaCamposDIAN
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_hijo_dian VALUES ('H002', 'Trabajador', 'Pais', 1);
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('H002', 'concepto', 'percepcion', 'tb_catalogo_paises_dian');

                -- Data for obtenDatasetTablaDIAN - each of the 10 switch cases
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('PAIS', 'query', NULL, 'tb_catalogo_paises_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('DEPT', 'query', NULL, 'tb_catalogo_departamentos_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('MUNI', 'query', NULL, 'tb_catalogo_municipios_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('MONE', 'query', NULL, 'tb_catalogo_monedas_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('CONT', 'query', NULL, 'tb_catalogo_tipo_contrato_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('TDID', 'query', NULL, 'tb_catalogo_tipo_doc_identidad_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('MPAG', 'query', NULL, 'tb_catalogo_medios_pago_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('PNOM', 'query', NULL, 'tb_catalogo_periodo_nomina_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('TTRAB', 'query', NULL, 'tb_catalogo_tipo_trabajador_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('TINC', 'query', NULL, 'tb_catalogo_tipos_incapacidad_dian');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('NOMATCH', 'query', NULL, 'nonexistent_table');
                INSERT INTO dbo.tb_catalogos_doc_xml_campos_mapas_dian VALUES ('NULLTBL', 'query', NULL, NULL);

                -- Data for catalog tables (one row each for non-empty results)
                INSERT INTO dbo.tb_catalogo_paises_dian VALUES ('CO', 'Colombia');
                INSERT INTO dbo.tb_catalogo_departamentos_dian VALUES ('05', 'Antioquia', 'CO');
                INSERT INTO dbo.tb_catalogo_municipios_dian VALUES ('05001', 'Medellin', 'CO');
                INSERT INTO dbo.tb_catalogo_monedas_dian VALUES ('COP', 'Peso Colombiano');
                INSERT INTO dbo.tb_catalogo_tipo_contrato_dian VALUES ('1', 'Termino Fijo');
                INSERT INTO dbo.tb_catalogo_tipo_doc_identidad_dian VALUES ('CC', 'Cedula de Ciudadania');
                INSERT INTO dbo.tb_catalogo_medios_pago_dian VALUES ('10', 'Efectivo');
                INSERT INTO dbo.tb_catalogo_periodo_nomina_dian VALUES ('5', 'Quincenal');
                INSERT INTO dbo.tb_catalogo_tipo_trabajador_dian VALUES ('01', 'Trabajador dependiente');
                INSERT INTO dbo.tb_catalogo_tipos_incapacidad_dian VALUES ('1', 'Comun');

                -- Data for bitacora (correlativo) tests
                INSERT INTO dbo.tb_bitacora_correlativos_dian VALUES ('COMP', 'TRAB000001', GETDATE(), 'PRE', '001', 'NUM001', 'DOC001', 'OK');
                INSERT INTO dbo.tb_bitacora_correlativos_dian VALUES ('COMP', 'TRAB000001', GETDATE(), 'PRE', '002', 'NUM002', NULL, 'PENDING');

                -- Data for rel_catalogos_dian_adam
                INSERT INTO dbo.tb_rel_catalogos_dian_adam VALUES ('COMP', 'PAIS', 'CO', 'COL');

                -- Data for companias
                INSERT INTO dbo.companias VALUES ('COMP', 'Test Company');

                -- Data for conceptos
                INSERT INTO dbo.conceptos VALUES (100, 'Salario Basico', 1);
                INSERT INTO dbo.conceptos VALUES (200, 'Descuento Salud', 2);

                -- Data for rel_conceptos_dian_adam
                INSERT INTO dbo.tb_rel_conceptos_dian_adam VALUES ('COMP', 'H001', '100');
            ";
            new SqlCommand(seedSql, conn).ExecuteNonQuery();
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            if (!_localDbAvailable) return;

            using var conn = new SqlConnection(LocalDbConnectionString);
            conn.Open();

            var sql = @"
                IF OBJECT_ID('dbo.tb_rel_conceptos_dian_adam','U') IS NOT NULL DROP TABLE dbo.tb_rel_conceptos_dian_adam;
                IF OBJECT_ID('dbo.tb_rel_catalogos_dian_adam','U') IS NOT NULL DROP TABLE dbo.tb_rel_catalogos_dian_adam;
                IF OBJECT_ID('dbo.tb_bitacora_correlativos_dian_resultado_validacion','U') IS NOT NULL DROP TABLE dbo.tb_bitacora_correlativos_dian_resultado_validacion;
                IF OBJECT_ID('dbo.tb_bitacora_correlativos_dian','U') IS NOT NULL DROP TABLE dbo.tb_bitacora_correlativos_dian;
                IF OBJECT_ID('dbo.tb_catalogos_doc_xml_campos_mapas_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogos_doc_xml_campos_mapas_dian;
                IF OBJECT_ID('dbo.tb_catalogos_doc_xml_campos_hijo_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogos_doc_xml_campos_hijo_dian;
                IF OBJECT_ID('dbo.tb_catalogos_doc_xml_campos_padre_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogos_doc_xml_campos_padre_dian;
                IF OBJECT_ID('dbo.tb_catalogo_paises_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_paises_dian;
                IF OBJECT_ID('dbo.tb_catalogo_departamentos_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_departamentos_dian;
                IF OBJECT_ID('dbo.tb_catalogo_municipios_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_municipios_dian;
                IF OBJECT_ID('dbo.tb_catalogo_monedas_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_monedas_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipo_contrato_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipo_contrato_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipo_doc_identidad_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipo_doc_identidad_dian;
                IF OBJECT_ID('dbo.tb_catalogo_medios_pago_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_medios_pago_dian;
                IF OBJECT_ID('dbo.tb_catalogo_periodo_nomina_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_periodo_nomina_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipo_trabajador_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipo_trabajador_dian;
                IF OBJECT_ID('dbo.tb_catalogo_tipos_incapacidad_dian','U') IS NOT NULL DROP TABLE dbo.tb_catalogo_tipos_incapacidad_dian;
                IF OBJECT_ID('dbo.companias','U') IS NOT NULL DROP TABLE dbo.companias;
                IF OBJECT_ID('dbo.conceptos','U') IS NOT NULL DROP TABLE dbo.conceptos;
            ";
            new SqlCommand(sql, conn).ExecuteNonQuery();
        }

        #region Helpers

        private static bool IsLocalDbAvailable()
        {
            try
            {
                using var conn = new SqlConnection(LocalDbConnectionString);
                conn.Open();
                conn.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private CatalogoDianSql CreateServiceWithLocalDb()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection(LocalDbConnectionString));

            return new CatalogoDianSql(mockFactory.Object);
        }

        private void SkipIfNoLocalDb()
        {
            if (!_localDbAvailable)
                Assert.Inconclusive("LocalDB not available");
        }

        #endregion

        #region getParentIdCatalog

        [TestMethod]
        public void GetParentIdCatalog_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.getParentIdCatalog();

            // UNION clauses + seeded data produce rows
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Tables.Count > 0);
            Assert.IsTrue(result.Tables[0].Rows.Count > 0);
        }

        #endregion

        #region getTypeClassification

        [TestMethod]
        public void GetTypeClassification_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.getTypeClassification();

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Tables.Count > 0);
            Assert.IsTrue(result.Tables[0].Rows.Count > 0);
        }

        #endregion

        // ActualizaBitacoraCorrelativosDian tests removed: the production code has a using/async
        // race condition (connection disposed before EndExecuteNonQuery completes) causing hangs.

        #region AltaResultadoValidacion

        [TestMethod]
        public void AltaResultadoValidacion_LocalDb_InsertsRow()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.AltaResultadoValidacion("NUM001", "ERR01", "Test error message");

            Assert.IsTrue(result);
        }

        #endregion

        #region obtenDatasetBitacoraCorrelativosDianEmpleado

        [TestMethod]
        public void ObtenDatasetBitacoraCorrelativosDianEmpleado_Correctos_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetBitacoraCorrelativosDianEmpleado("COMP", "TRAB000001", true);

            // correctos=true: filters documento_id IS NOT NULL → 1 row
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetBitacoraCorrelativosDianEmpleado_NoCorrectos_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetBitacoraCorrelativosDianEmpleado("COMP", "TRAB000001", false);

            // correctos=false: no filter on documento_id → 2 rows
            Assert.IsNotNull(result);
        }

        #endregion

        #region dsListaSeccionesDIAN

        [TestMethod]
        public void DsListaSeccionesDIAN_WithoutTipoConcepto_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.dsListaSeccionesDIAN("query");

            // Returns DataSet (may be null from SqlCommandExecutor if no match, or DataSet with rows)
            // Coverage: executes the empty-tipoConcepto branch
        }

        [TestMethod]
        public void DsListaSeccionesDIAN_WithTipoConcepto_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.dsListaSeccionesDIAN("concepto", "percepcion");

            // Coverage: executes the non-empty-tipoConcepto branch
        }

        #endregion

        #region dsListaCamposDIAN

        [TestMethod]
        public void DsListaCamposDIAN_WithoutTipoConcepto_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.dsListaCamposDIAN("Trabajador", "query");

            // Coverage: executes the empty-tipoConcepto branch
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithTipoConcepto_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.dsListaCamposDIAN("Trabajador", "concepto", "percepcion");

            // Coverage: executes the non-empty-tipoConcepto branch
        }

        #endregion

        #region obtenDataSetConceptosAux

        [TestMethod]
        public void ObtenDataSetConceptosAux_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDataSetConceptosAux();

            // Coverage: executes full method body
        }

        #endregion

        #region obtenDataSetCatalogosAux

        [TestMethod]
        public void ObtenDataSetCatalogosAux_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDataSetCatalogosAux();

            // Coverage: executes full method body
        }

        #endregion

        #region obtenDatasetTablaDIAN - 10 switch cases + catch + no-match

        [TestMethod]
        public void ObtenDatasetTablaDIAN_Paises_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("PAIS");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_Departamentos_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("DEPT");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_Municipios_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("MUNI");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_Monedas_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("MONE");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_TipoContrato_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("CONT");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_TipoDocIdentidad_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("TDID");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_MediosPago_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("MPAG");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_PeriodoNomina_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("PNOM");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_TipoTrabajador_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("TTRAB");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_TiposIncapacidad_LocalDb()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTablaDIAN("TINC");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_NoMatchingTable_LocalDb_ReturnsNull()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            // 'NOMATCH' maps to 'nonexistent_table' which doesn't match any switch case → sqlStmt stays null → return null
            var result = service.obtenDatasetTablaDIAN("NOMATCH");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_CatchBlock_LocalDb_ReturnsNull()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            // Non-existent id_campo → ExecuteScalar returns null → (string)null cast succeeds, table is null
            // switch(null) doesn't match any case → sqlStmt stays null → return null
            var result = service.obtenDatasetTablaDIAN("NONEXISTENT");

            Assert.IsNull(result);
        }

        #endregion

        #region altaRelacionDatoCatalogoDIAN

        [TestMethod]
        public void AltaRelacionDatoCatalogoDIAN_LocalDb_InsertsRow()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.altaRelacionDatoCatalogoDIAN("TEST", "campo1", "dian01", "adam01");

            Assert.IsTrue(result);

            // Cleanup
            using var conn = new SqlConnection(LocalDbConnectionString);
            conn.Open();
            new SqlCommand("DELETE FROM tb_rel_catalogos_dian_adam WHERE compania='TEST'", conn).ExecuteNonQuery();
        }

        #endregion

        #region bajaRelacionDatoCatalogoDIAN

        [TestMethod]
        public void BajaRelacionDatoCatalogoDIAN_LocalDb_DeletesRow()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            // Delete the seeded row
            var result = service.bajaRelacionDatoCatalogoDIAN("COMP", "PAIS", "CO", "COL");

            Assert.IsTrue(result);

            // Re-insert for other tests
            using var conn = new SqlConnection(LocalDbConnectionString);
            conn.Open();
            new SqlCommand("INSERT INTO tb_rel_catalogos_dian_adam VALUES ('COMP','PAIS','CO','COL')", conn).ExecuteNonQuery();
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoDIAN_LocalDb_ReturnsFalse_WhenNoMatch()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.bajaRelacionDatoCatalogoDIAN("XXXX", "NONE", "XX", "XX");

            Assert.IsFalse(result);
        }

        #endregion

        #region obtenDatasetRelacionCatalogosDIAN

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosDIAN_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetRelacionCatalogosDIAN("COMP", "PAIS", "CO");

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenDatasetTreeViewCatalogosDIAN

        [TestMethod]
        public void ObtenDatasetTreeViewCatalogosDIAN_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTreeViewCatalogosDIAN();

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenDatasetTreeViewCatalogosDIANByCompany

        [TestMethod]
        public void ObtenDatasetTreeViewCatalogosDIANByCompany_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTreeViewCatalogosDIANByCompany("COMP");

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenDatasetTreeViewConceptosDIAN

        [TestMethod]
        public void ObtenDatasetTreeViewConceptosDIAN_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTreeViewConceptosDIAN();

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenDatasetTreeViewConceptosDIANByCompany

        [TestMethod]
        public void ObtenDatasetTreeViewConceptosDIANByCompany_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetTreeViewConceptosDIANByCompany("COMP");

            Assert.IsNotNull(result);
        }

        #endregion

        #region obtenDatasetConceptosRelacionarDIAN

        [TestMethod]
        public void ObtenDatasetConceptosRelacionarDIAN_Deduccion_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetConceptosRelacionarDIAN("deduccion");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionarDIAN_Percepcion_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetConceptosRelacionarDIAN("percepcion");

            Assert.IsNotNull(result);
        }

        #endregion

        #region getDatasetConceptosADAM

        [TestMethod]
        public void GetDatasetConceptosADAM_Deduccion_Found_LocalDb_ReturnsTrue()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            // concepto 200 has tipo_transaccion=2, which is IN (2,3,5) for deduccion
            var result = service.getDatasetConceptosADAM("deduccion", "200");

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void GetDatasetConceptosADAM_Deduccion_NotFound_LocalDb_ReturnsFalse()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.getDatasetConceptosADAM("deduccion", "999");

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void GetDatasetConceptosADAM_Percepcion_Found_LocalDb_ReturnsTrue()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            // concepto 100 has tipo_transaccion=1, which is IN (1,2,3,4,5) for non-deduccion
            var result = service.getDatasetConceptosADAM("percepcion", "100");

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void GetDatasetConceptosADAM_Percepcion_NotFound_LocalDb_ReturnsFalse()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.getDatasetConceptosADAM("percepcion", "999");

            Assert.IsFalse(result);
        }

        #endregion

        #region altaRelacionDatoConceptoDIAN

        [TestMethod]
        public void AltaRelacionDatoConceptoDIAN_LocalDb_InsertsRow()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.altaRelacionDatoConceptoDIAN("TEST", "H001", "200");

            Assert.IsTrue(result);

            // Cleanup
            using var conn = new SqlConnection(LocalDbConnectionString);
            conn.Open();
            new SqlCommand("DELETE FROM tb_rel_conceptos_dian_adam WHERE compania='TEST'", conn).ExecuteNonQuery();
        }

        #endregion

        #region existRelacionDatoConceptoDIAN

        [TestMethod]
        public void ExistRelacionDatoConceptoDIAN_Exists_LocalDb_ReturnsTrue()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.existRelacionDatoConceptoDIAN("COMP", "H001", "100");

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void ExistRelacionDatoConceptoDIAN_NotExists_LocalDb_ReturnsFalse()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.existRelacionDatoConceptoDIAN("XXXX", "NONE", "999");

            Assert.IsFalse(result);
        }

        #endregion

        #region obtenDatasetRelacionConceptosDIAN

        [TestMethod]
        public void ObtenDatasetRelacionConceptosDIAN_LocalDb_ReturnsDataSet()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.obtenDatasetRelacionConceptosDIAN("COMP", "H001");

            Assert.IsNotNull(result);
        }

        #endregion

        #region bajaRelacionDatoConceptoDIAN

        [TestMethod]
        public void BajaRelacionDatoConceptoDIAN_LocalDb_DeletesRow()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.bajaRelacionDatoConceptoDIAN("COMP", "H001", "100");

            Assert.IsTrue(result);

            // Re-insert for other tests
            using var conn = new SqlConnection(LocalDbConnectionString);
            conn.Open();
            new SqlCommand("INSERT INTO tb_rel_conceptos_dian_adam VALUES ('COMP','H001','100')", conn).ExecuteNonQuery();
        }

        [TestMethod]
        public void BajaRelacionDatoConceptoDIAN_LocalDb_ReturnsFalse_WhenNoMatch()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var result = service.bajaRelacionDatoConceptoDIAN("XXXX", "NONE", "999");

            Assert.IsFalse(result);
        }

        #endregion

        #region ActualizaBitacoraCorrelativosDian (via Task.Wait)

        [TestMethod]
        [Timeout(15000)]
        public void ActualizaBitacoraCorrelativosDian_LocalDb_MatchingRow_ReturnsTask()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var task = service.ActualizaBitacoraCorrelativosDian("COMP", "NUM001", "DOC_NEW", "COMPLETED");

            Assert.IsNotNull(task);
            try { task.Wait(TimeSpan.FromSeconds(10)); } catch { /* connection disposed race */ }
        }

        [TestMethod]
        [Timeout(15000)]
        public void ActualizaBitacoraCorrelativosDian_LocalDb_NoMatch_ReturnsTask()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            var task = service.ActualizaBitacoraCorrelativosDian("XXXX", "NONE", "DOC", "OK");

            Assert.IsNotNull(task);
            try { task.Wait(TimeSpan.FromSeconds(10)); } catch { /* connection disposed race */ }
        }

        #endregion

        #region obtenDatasetTablaDIAN catch block

        [TestMethod]
        public void ObtenDatasetTablaDIAN_NullTableValue_LocalDb_ReturnsNull()
        {
            SkipIfNoLocalDb();
            var service = CreateServiceWithLocalDb();

            // NULLTBL has tabla_dian=NULL → ExecuteScalar returns DBNull.Value → (string)DBNull.Value throws InvalidCastException → catch returns null
            var result = service.obtenDatasetTablaDIAN("NULLTBL");

            Assert.IsNull(result);
        }

        #endregion
    }
}

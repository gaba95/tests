﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("fondoPensionSP", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PensionfundSP
    {
        [JsonProperty("porcentaje")]
        public decimal DeduccionSPPorcentaje { get; set; }

        [JsonProperty("deduccionSP")]
        public decimal DeduccionSP { get; set; }

        [JsonProperty("porcentajeSub")]
        public decimal DeduccionSubPorcentaje { get; set; }

        [JsonProperty("deduccionSub")]
        public decimal DeduccionSub { get; set; }
    }
}

﻿<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
   xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:user="urn:my-scripts">
  
  <xsl:output method="xml"/>
  <xsl:template match="/NewDataSet">
    <nomina>
        <ADAM
            instancia = "{TablePrincipal[1]/Instancia}"
            Compania = "{TablePrincipal[1]/Compania}"
            TipoNomina = "{TablePrincipal[1]/TipoNomina}"
            ClaseNomina = "{TablePrincipal[1]/ClaseNomina}"
            Anio = "{TablePrincipal[1]/Anio}"
            Periodo = "{TablePrincipal[1]/Periodo}"
            correoEmpleado = "{TablePrincipal[1]/correoEmpleado}"
            netoPagar = "{TablePrincipal[1]/netoPagar}"
            netoPagarLetra = "{TablePrincipal[1]/netoPagarLetra}"
            netoAnterior = "{TablePrincipal[1]/netoAnterior}"
            sueldo = "{format-number(TablePrincipal[1]/Sueldo,'#0.00')}"
            folio="{TablePrincipal[1]/Compania}-{TablePrincipal[1]/NumEmpleado}-{TablePrincipal[1]/TipoNomina}{TablePrincipal[1]/Periodo}"
        />

        <cfdi:Comprobante
            xmlns:cfdi="http://www.sat.gob.mx/cfd/4"
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xsi:schemaLocation="http://www.sat.gob.mx/cfd/4 http://www.sat.gob.mx/sitio_internet/cfd/4/cfdv40.xsd"
            Version="4.0"
            Fecha="{TablePrincipal[1]/Fecha}"
            TipoDeComprobante="N"
            FormaPago="{TablePrincipal[1]/FormaPago}"
            Exportacion="01"
            MetodoPago="PUE"
            NoCertificado=""
            Moneda="MXN"
            Total="{format-number(TablePrincipal[1]/netoPagar,'#0.00')}"
            LugarExpedicion="{TablePrincipal[1]/LugarExpedicion}"
            Certificado=""
            Sello=""
        >
        
        <!-- PTF-2091: SubTotal will be calculated different if TableConceptosSeparacion exists -->
        <xsl:choose>
          <xsl:when test="TableConceptosSeparacion">
            <xsl:attribute name="SubTotal">
              <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
            </xsl:attribute>
          </xsl:when>
          <xsl:otherwise>
            <xsl:attribute name="SubTotal">
              <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
            </xsl:attribute>
          </xsl:otherwise>
        </xsl:choose>

        <!-- PTF-2091: if varTotalPercepciones is 1, then first node will have perceptions, else it won't have and then we will only need one nomina node, even if it's a separation -->
        <xsl:variable name="varTotalPercepciones">
          <xsl:choose>
            <xsl:when test="TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro>0">
              <xsl:value-of select="1" />
            </xsl:when>
            <xsl:otherwise>
              <xsl:value-of select="0" />
            </xsl:otherwise>
          </xsl:choose>
        </xsl:variable>

        <xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
          <xsl:attribute name="Descuento">
            <xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/>
          </xsl:attribute>
        </xsl:if>
        
        <xsl:variable name="tipoContratoFinal">
          <!-- PTF-2091: Add check for TableConceptosSeparacion, if it exists TipoContrato should be calculated base on the information on TableConceptosSeparacion-->
          <xsl:choose>
            <xsl:when test="TableConceptosSeparacion and $varTotalPercepciones = 0">
              <xsl:variable name="tipoContrato" select="TableConceptosSeparacion[1]/TipoContrato"/>
              <xsl:choose>
                <xsl:when test="contains('0102030405060708',$tipoContrato) and (count(/NewDataSet/TableConceptosSeparacion[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                  <xsl:value-of select="09" />
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$tipoContrato" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
              <xsl:variable name="tipoContrato" select="TablePrincipal[1]/TipoContrato"/>
              <xsl:choose>
                <xsl:when test="contains('0102030405060708',$tipoContrato) and (count(/NewDataSet/TablePrincipal[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                  <xsl:value-of select="09" />
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$tipoContrato" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:variable>

        <xsl:variable name="tipoContratoFinalNodo2">
          <!-- PTF-2091: Add check for TableConceptosSeparacion, if it exists TipoContrato should be calculated base on the information on TableConceptosSeparacion-->
          <xsl:choose>
            <xsl:when test="TableConceptosSeparacion">
              <xsl:variable name="tipoContrato" select="TableConceptosSeparacion[1]/TipoContrato"/>
              <xsl:choose>
                <xsl:when test="contains('0102030405060708',$tipoContrato) and (count(/NewDataSet/TableConceptosSeparacion[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                  <xsl:value-of select="09" />
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$tipoContrato" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
              <xsl:variable name="tipoContrato" select="TablePrincipal[1]/TipoContrato"/>
              <xsl:choose>
                <xsl:when test="contains('0102030405060708',$tipoContrato) and (count(/NewDataSet/TablePrincipal[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                  <xsl:value-of select="09" />
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="$tipoContrato" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:variable>

        <!-- PTF-2091: Set tipoRegimenFinal variable for further validations of tipoRegimen, otherwise it's always 02-->
        <xsl:variable name="tipoRegimenFinal">
          <xsl:choose>
            <!-- PTF-2091: Validate if TableConceptosSeparacion exists, if it exists then test TipoRegimen 13-->
            <xsl:when test="TableConceptosSeparacion">
              <xsl:choose>
                <!-- JGE 201809 To show Regimen Type 13 when it is an extraordinary payroll and has a concept with Keys 022, 023, 025.-->
                <!-- PTF-1337 - Change to avoid setting the TypeRegimen to 13, when it is Nomina Finiquitos (it must have the one configured in the catalog).-->
                <xsl:when test="count(/NewDataSet/TableConceptosSeparacion[TipoNominaSat='E' and TipoTransaccion=1 and (contains('022023025',TipoSAT)) and TipoNomina != 'NF'])">
                  <xsl:choose>
                    <xsl:when test="$varTotalPercepciones = 1">
                      <xsl:value-of select="string(format-number(TablePrincipal[1]/TipoRegimen,'00'))" />
                    </xsl:when>
                    <xsl:otherwise>
                      <xsl:value-of select="13" />
                    </xsl:otherwise>
                  </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="string(format-number(TableConceptosSeparacion[1]/TipoRegimen,'00'))" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
              <xsl:choose>
                <!-- JGE 201809 To show Regimen Type 13 when it is an extraordinary payroll and has a concept with Keys 022, 023, 025.-->
                <!-- PTF-1337 - Change to avoid setting the TypeRegimen to 13, when it is Nomina Finiquitos (it must have the one configured in the catalog).-->
                <xsl:when test="count(/NewDataSet/TablePrincipal[TipoNominaSat='E' and TipoTransaccion=1 and (contains('022023025',TipoSAT)) and TipoNomina != 'NF'])">
                  <xsl:value-of select="13" />
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="string(format-number(TablePrincipal[1]/TipoRegimen,'00'))" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:variable>
        
        <xsl:variable name="trabajador" select="TablePrincipal[1]/NumEmpleado"/>
        <cfdi:Emisor
            RegimenFiscal="{TablePrincipal[1]/emisorRegimen}"
            Nombre="{TablePrincipal[1]/emisorNombre}"
            Rfc="{TablePrincipal[1]/emisorRfc}"
        >
        </cfdi:Emisor>
        <cfdi:Receptor
            UsoCFDI="CN01"
            ResidenciaFiscal="MEX" 
            Nombre="{TablePrincipal[1]/receptorNombre}"
            Rfc="{TablePrincipal[1]/receptorRfc}"
            DomicilioFiscalReceptor="{TablePrincipal[1]/receptorCodigoPostal}"
            RegimenFiscalReceptor="605" 
        >
        </cfdi:Receptor>
        <cfdi:Conceptos>
          <cfdi:Concepto
              ObjetoImp="01"
              Descripcion="Pago de nómina"
              ClaveUnidad="ACT"
              Cantidad="1"
              ClaveProdServ="84111505"
          >
            <!-- PTF-2091: Importe and ValorUnitario will be calculated different if TableConceptosSeparacion exists -->
            <xsl:choose>
              <xsl:when test="TableConceptosSeparacion">
                <xsl:attribute name="Importe">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
                </xsl:attribute>
                <xsl:attribute name="ValorUnitario">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
                </xsl:attribute>
              </xsl:when>
              <xsl:otherwise>
                <xsl:attribute name="Importe">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
                </xsl:attribute>
                <xsl:attribute name="ValorUnitario">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
                </xsl:attribute>
              </xsl:otherwise>
            </xsl:choose>

            <xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
              <xsl:attribute name="Descuento">
                <xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/>
              </xsl:attribute>
            </xsl:if>
          </cfdi:Concepto>
        </cfdi:Conceptos>
        
        <cfdi:Complemento>
          <nomina:Nomina
              xmlns:nomina="http://www.sat.gob.mx/nomina12"
              xsi:schemaLocation="http://www.sat.gob.mx/informacion_fiscal/factura_electronica/Documents/Complementoscfdi/nomina12.xsd"
              Version="{TablePrincipal[1]/Version}"
              FechaPago="{TablePrincipal[1]/FechaPago}"
              FechaInicialPago="{TablePrincipal[1]/FechaInicialPago}"
              FechaFinalPago="{TablePrincipal[1]/FechaFinalPago}"
              NumDiasPagados="{format-number(TablePrincipal[1]/NumDiasPagados,'#0.000')}"
          >
            <xsl:attribute name="TipoNomina">
              <xsl:choose>
                <!-- PTF-2916: If there is liquidation info and there's a second node, then tipoNomina will be O-->
                <xsl:when test="TableConceptosSeparacion and $varTotalPercepciones = 1">
                  <xsl:value-of select="'O'" />
                </xsl:when>
                <xsl:otherwise>
                  <xsl:value-of select="TablePrincipal[1]/TipoNominaSat" />
                </xsl:otherwise>
              </xsl:choose>
            </xsl:attribute>

            <xsl:if test="TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
              <xsl:attribute name="TotalPercepciones">
                <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro,'#0.00')"/>
              </xsl:attribute>
            </xsl:if>

            <xsl:if test="TableConceptosSeparacion and $varTotalPercepciones = 0">
              <xsl:if test="TableConceptosSeparacion[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro!=0">
                <xsl:attribute name="TotalPercepciones">
                  <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro,'#0.00')"/>
                </xsl:attribute>
              </xsl:if>
            </xsl:if>

            <xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
              <xsl:attribute name="TotalDeducciones">
                <xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/>
              </xsl:attribute>
            </xsl:if>

            <xsl:if test="TablePrincipal[1]/TotalOtrosPagos!=0 or $tipoRegimenFinal='02'">
              <xsl:attribute name="TotalOtrosPagos">
                <xsl:value-of select="format-number(TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/>
              </xsl:attribute>
            </xsl:if>

            <xsl:choose>
              <xsl:when test="TablePrincipal[1]/longitudRegistroPatronal &lt;= 12">
                <xsl:if test="contains('0102030405060708',$tipoContratoFinal)">
                  <xsl:element name="nomina:Emisor">
                    <xsl:attribute name="RegistroPatronal">
                      <xsl:value-of select="TablePrincipal[1]/RegistroPatronal"/>
                    </xsl:attribute>
                    <xsl:if test="TablePrincipal[1]/EmpresaSNCF!=0">
                      <xsl:element name="nomina:EntidadSNCF">
                        <xsl:attribute name="OrigenRecurso">
                          <xsl:value-of select="TablePrincipal[1]/OrigenRecurso"/>
                        </xsl:attribute>
                        <xsl:attribute name="MontoRecursoPropio">
                          <xsl:value-of select="TablePrincipal[1]/MontoRecursoPropio"/>
                        </xsl:attribute>
                      </xsl:element>
                    </xsl:if>
                  </xsl:element>
                </xsl:if>
              </xsl:when>
              <xsl:otherwise>
                <nomina:Emisor
                    Curp="{TablePrincipal[1]/CURPEmisor}"
                    RfcPatronOrigen="{TablePrincipal[1]/RFCPatronOrigen}"
                > 
                  <xsl:if test="contains('0102030405060708',$tipoContratoFinal)">
                    <xsl:attribute name="RegistroPatronal">
                      <xsl:value-of select="TablePrincipal[1]/RegistroPatronal"/>
                    </xsl:attribute>
                  </xsl:if>
                  <xsl:if test="TablePrincipal[1]/EmpresaSNCF!=0">
                    <nomina:EntidadSNCF
                        OrigenRecurso="{TablePrincipal[1]/OrigenRecurso}"
                        MontoRecursoPropio="{TablePrincipal[1]/MontoRecursoPropio}"
                    />
                  </xsl:if>
                </nomina:Emisor>
              </xsl:otherwise>
            </xsl:choose>

            <xsl:element name="nomina:Receptor">
              <xsl:attribute name="Curp">
                <xsl:value-of select="TablePrincipal[1]/CURP"/>
              </xsl:attribute>
              <!-- The following fields are not displayed for contract types greater than 08-->
              <xsl:if test="contains('0102030405060708',$tipoContratoFinal)">
                <xsl:attribute name="NumSeguridadSocial">
                  <xsl:value-of select="TablePrincipal[1]/NumSeguridadSocial"/>
                </xsl:attribute>
                <xsl:attribute name="FechaInicioRelLaboral">
                  <xsl:value-of select="TablePrincipal[1]/FechaInicioRelLaboral"/>
                </xsl:attribute>
                <xsl:attribute name="Antigüedad">
                  <xsl:value-of select="TablePrincipal[1]/Antiguedad"/>
                </xsl:attribute>
                <xsl:attribute name="RiesgoPuesto">
                  <xsl:value-of select="TablePrincipal[1]/RiesgoPuesto"/>
                </xsl:attribute>
                <xsl:attribute name="SalarioDiarioIntegrado">
                  <xsl:value-of select="format-number(TablePrincipal[1]/SalarioDiarioIntegrado,'#0.00')"/>
                </xsl:attribute>
              </xsl:if>
              <xsl:attribute name="TipoContrato">
                <xsl:value-of select="format-number($tipoContratoFinal,'00')"/>
              </xsl:attribute>
              <xsl:attribute name="Sindicalizado">
                <xsl:value-of select="TablePrincipal[1]/Sindicalizado"/>
              </xsl:attribute>
              <xsl:attribute name="TipoJornada">
                <xsl:value-of select="TablePrincipal[1]/TipoJornada"/>
              </xsl:attribute>
              <!-- PTF-2091: Change to use only TipoRegimenFinal variable-->
              <xsl:attribute name="TipoRegimen">
                <xsl:value-of select="string(format-number($tipoRegimenFinal,'00'))"/>
              </xsl:attribute>
              <xsl:attribute name="NumEmpleado">
                <xsl:value-of select="TablePrincipal[1]/NumEmpleado"/>
              </xsl:attribute>
              <xsl:attribute name="Departamento">
                <xsl:value-of select="TablePrincipal[1]/Departamento"/>
              </xsl:attribute>
              <xsl:attribute name="Puesto">
                <xsl:value-of select="TablePrincipal[1]/Puesto"/>
              </xsl:attribute>
              <xsl:attribute name="PeriodicidadPago">
                <xsl:choose>     
                  <!-- PTF-2916: If there is liquidation info and there's a second node, then periodicidadPago will be the one configured for Liquidation-->
                  <xsl:when test="TableConceptosSeparacion and $varTotalPercepciones = 1">
                    <xsl:value-of select="TablePrincipal[1]/PeriodicidadPagoLiquidation" />
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:value-of select="TablePrincipal[1]/PeriodicidadPago" />
                  </xsl:otherwise>
                </xsl:choose>
              </xsl:attribute>
              
              <!-- CU-863gfxd1h: PTF-3211: Validate Banco attribute given CLABE and CuentaBancaria-->
              <xsl:choose>
                <xsl:when test="TablePrincipal[1]/Banco!='' and TablePrincipal[1]/CuentaBancaria!='' and TablePrincipal[1]/CuentaBancaria!='0'">
                  <xsl:attribute name="Banco">
                    <xsl:value-of select="TablePrincipal[1]/Banco"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="TablePrincipal[1]/Banco!='' and TablePrincipal[1]/CuentaBancaria!='' and TablePrincipal[1]/CuentaBancaria='0' and string-length(TablePrincipal[1]/CLABE)>2">
                </xsl:when>
                <xsl:when test="TablePrincipal[1]/Banco!='' and TablePrincipal[1]/CuentaBancaria!='' and TablePrincipal[1]/CuentaBancaria='0' and string-length(TablePrincipal[1]/CLABE)&lt;3">
                  <xsl:attribute name="Banco">
                    <xsl:value-of select="TablePrincipal[1]/CLABE"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:if test="TablePrincipal[1]/Banco!=''">
                    <xsl:attribute name="Banco">
                      <xsl:value-of select="TablePrincipal[1]/Banco"/>
                    </xsl:attribute>
                  </xsl:if>
                </xsl:otherwise>
              </xsl:choose>
              
              <!-- CU-863gfxd1h: PTF-3211: If CuentaBancaria is != 0, then show that field, otherwise use CLABE because it's an interbank account -->
              <xsl:choose>
                <xsl:when test="TablePrincipal[1]/CuentaBancaria!='' and TablePrincipal[1]/CuentaBancaria!='0'">
                  <xsl:attribute name="CuentaBancaria">
                    <xsl:value-of select="TablePrincipal[1]/CuentaBancaria"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="TablePrincipal[1]/CuentaBancaria!='' and TablePrincipal[1]/CuentaBancaria='0'">
                  <xsl:attribute name="CuentaBancaria">
                    <xsl:value-of select="TablePrincipal[1]/CLABE"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:attribute name="CuentaBancaria">
                    <xsl:value-of select="TablePrincipal[1]/CuentaBancaria"/>
                  </xsl:attribute>
                </xsl:otherwise>
              </xsl:choose>
              <xsl:attribute name="SalarioBaseCotApor">
                <xsl:value-of select="format-number(TablePrincipal[1]/SalarioBaseCotApor,'#0.00')"/>
              </xsl:attribute>
              <xsl:attribute name="ClaveEntFed">
                <xsl:value-of select="TablePrincipal[1]/ClaveEntFed"/>
              </xsl:attribute>

              <xsl:if test="count(/NewDataSet/TableSubcontratacion)>0">
                <xsl:for-each select = "TableSubcontratacion">
                  <nomina:SubContratacion>
                    <xsl:attribute name="RfcLabora">
                      <xsl:value-of select="RfcLabora" />
                    </xsl:attribute>
                    <xsl:attribute name="PorcentajeTiempo">
                      <xsl:value-of select="PorcentajeTiempo" />
                    </xsl:attribute>
                  </nomina:SubContratacion>
                </xsl:for-each>
              </xsl:if>
            </xsl:element>

            <xsl:if test="TablePrincipal[1]/TotalSueldos!=0 or TablePrincipal[1]/TotalSeparacionIndemnizacion!=0 or TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
              <nomina:Percepciones>
                <xsl:attribute name="TotalExento">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalExento,'#0.00')"/>
                </xsl:attribute>
                <xsl:attribute name="TotalGravado">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalGravado,'#0.00')"/>
                </xsl:attribute>

                <xsl:if test="TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
                  <xsl:attribute name="TotalJubilacionPensionRetiro">
                    <xsl:value-of select="format-number(TablePrincipal[1]/TotalJubilacionPensionRetiro,'#0.00')"/>
                  </xsl:attribute>
                </xsl:if>

                <xsl:if test="TablePrincipal[1]/TotalSeparacionIndemnizacion!=0">
                  <xsl:attribute name="TotalSeparacionIndemnizacion">
                    <xsl:value-of select="format-number(TablePrincipal[1]/TotalSeparacionIndemnizacion,'#0.00')"/>
                  </xsl:attribute>
                </xsl:if>

                <xsl:if test="TablePrincipal[1]/TotalSueldos!=0">
                  <xsl:attribute name="TotalSueldos">
                    <xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos,'#0.00')"/>
                  </xsl:attribute>
                </xsl:if>

                <xsl:for-each select = "TablePrincipal[TipoTransaccion=1]">
                  <nomina:Percepcion>
                    <xsl:attribute name="TipoPercepcion">
                      <xsl:value-of select="TipoSAT" />
                    </xsl:attribute>
                    <xsl:attribute name="Clave">
                      <xsl:value-of select="Clave" />
                    </xsl:attribute>
                    <xsl:attribute name="Concepto">
                      <xsl:value-of select="Concepto" />
                    </xsl:attribute>
                    <xsl:attribute name="ImporteGravado">
                      <xsl:value-of select="format-number(ImporteGravado,'#0.00')" />
                    </xsl:attribute>
                    <xsl:attribute name="ImporteExento">
                      <xsl:value-of select="format-number(ImporteExento,'#0.00')" />
                    </xsl:attribute>
                    <xsl:attribute name="Tiempo">
                      <xsl:value-of select="format-number(tiempo,'#0.00')" />
                    </xsl:attribute>
                    
                    <xsl:if test="TipoSAT='019'">
                      <xsl:variable name="claveConcepto" select="Clave"/>
                      <xsl:for-each select = "/NewDataSet/TableHorasExtra[Clave=$claveConcepto[1]]">
                        <nomina:HorasExtra>
                          <xsl:choose>
                            <xsl:when test="Dias=0">
                              <xsl:attribute name="Dias">1</xsl:attribute>
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:attribute name="Dias">
                                <xsl:value-of select="Dias"/>
                              </xsl:attribute>
                            </xsl:otherwise>
                          </xsl:choose>
                          <xsl:attribute name="TipoHoras">
                            <xsl:value-of select="TipoHoras" />
                          </xsl:attribute>
                          <xsl:choose>
                            <xsl:when test="HorasExtra=0">
                              <xsl:attribute name="HorasExtra">1</xsl:attribute>
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:attribute name="HorasExtra">
                                <xsl:value-of select="HorasExtra" />
                              </xsl:attribute>
                            </xsl:otherwise>
                          </xsl:choose>
                          <xsl:attribute name="ImportePagado">
                            <xsl:value-of select="format-number(ImportePagado,'#0.00')" />
                          </xsl:attribute>
                        </nomina:HorasExtra>
                      </xsl:for-each>
                    </xsl:if>
                    
                    <xsl:if test="TipoSAT='045'">
                      <xsl:for-each select = "/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]]">
                        <nomina:AccionesOTitulos>
                          <xsl:attribute name="ValorMercado">
                            <xsl:value-of select="format-number(ValorMercadoAcciones,'#0.00')" />
                          </xsl:attribute>
                          <xsl:attribute name="PrecioAlOtorgarse">
                            <xsl:value-of select="format-number(PrecioEstTitulosVal,'#0.00')" />
                          </xsl:attribute>
                        </nomina:AccionesOTitulos>
                      </xsl:for-each>
                    </xsl:if>
                  </nomina:Percepcion>
                </xsl:for-each>
                
                <!-- Initial the additional tables of perceptions-->
                <!-- If there is data for RetirementPensionRetirement-->
                <xsl:if test="count(/NewDataSet/TableJubilacionPensionRetiro)>0">
                  <!-- You can only have one type JubilacionPensionRetiro 039 (in one payment) or 044 (in installments).-->
                  <xsl:if test="/NewDataSet/TablePrincipal[TipoSAT='039']">
                    <nomina:JubilacionPensionRetiro>
                      <xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
                        <xsl:attribute name="IngresoAcumulable">
                          <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="IngresoNoAcumulable">
                          <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="TotalUnaExhibicion">
                          <xsl:value-of select="format-number(TotalUnaExhibicion,'#0.00')"/>
                        </xsl:attribute>
                      </xsl:for-each>
                    </nomina:JubilacionPensionRetiro>
                  </xsl:if>
                  
                  <xsl:if test="/NewDataSet/TablePrincipal[TipoSAT='044']">
                    <nomina:JubilacionPensionRetiro>
                      <xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
                        <xsl:attribute name="IngresoAcumulable">
                          <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="IngresoNoAcumulable">
                          <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="TotalParcialidad">
                          <xsl:value-of select="format-number(TotalParcialidad,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="MontoDiario">
                          <xsl:value-of select="format-number(MontoDiario,'#0.00')"/>
                        </xsl:attribute>
                      </xsl:for-each>
                    </nomina:JubilacionPensionRetiro>
                  </xsl:if>
                </xsl:if>

                <!-- SeparacionIndemnizacion 022(Seniority premium) 023(Separation payments) 025(Severance payments)-->
                <xsl:if test="count(/NewDataSet/TableSeparacionIndemnizacion)>0 and (count(/NewDataSet/TablePrincipal[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                  <xsl:if test="/NewDataSet/TableSeparacionIndemnizacion/TotalPagado!=0">
                    <nomina:SeparacionIndemnizacion>
                      <xsl:for-each select = "/NewDataSet/TableSeparacionIndemnizacion">
                        <xsl:attribute name="TotalPagado">
                          <xsl:value-of select="format-number(TotalPagado,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:choose>
                          <xsl:when test="number(/NewDataSet/TablePrincipal/AntiguedadAnios)>0">
                            <xsl:attribute name="NumAñosServicio">
                              <xsl:value-of select="/NewDataSet/TablePrincipal/AntiguedadAnios"/>
                            </xsl:attribute>
                          </xsl:when>
                          <xsl:otherwise>
                            <xsl:attribute name="NumAñosServicio">0</xsl:attribute>
                          </xsl:otherwise>
                        </xsl:choose>
                        <xsl:attribute name="UltimoSueldoMensOrd">
                          <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="IngresoAcumulable">
                          <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                        <xsl:attribute name="IngresoNoAcumulable">
                          <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                        </xsl:attribute>
                      </xsl:for-each>
                    </nomina:SeparacionIndemnizacion>
                  </xsl:if>
                </xsl:if>
              </nomina:Percepciones>
            </xsl:if>

            <xsl:if test="TableConceptosSeparacion and $varTotalPercepciones = 0">
              <xsl:if test="TableConceptosSeparacion[1]/TotalSueldos!=0 or TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion!=0 or TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro!=0">
                <nomina:Percepciones>
                  <xsl:attribute name="TotalExento">
                    <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalExento,'#0.00')"/>
                  </xsl:attribute>
                  <xsl:attribute name="TotalGravado">
                    <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalGravado,'#0.00')"/>
                  </xsl:attribute>
                  
                  <xsl:if test="TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro!=0">
                    <xsl:attribute name="TotalJubilacionPensionRetiro">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>

                  <xsl:if test="TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion!=0">
                    <xsl:attribute name="TotalSeparacionIndemnizacion">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>

                  <xsl:if test="TableConceptosSeparacion[1]/TotalSueldos!=0">
                    <xsl:attribute name="TotalSueldos">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalSueldos,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>

                  <xsl:for-each select = "TableConceptosSeparacion[TipoTransaccion=1]">
                    <nomina:Percepcion>
                      <xsl:attribute name="TipoPercepcion">
                        <xsl:value-of select="TipoSAT" />
                      </xsl:attribute>
                      <xsl:attribute name="Clave">
                        <xsl:value-of select="Clave" />
                      </xsl:attribute>
                      <xsl:attribute name="Concepto">
                        <xsl:value-of select="Concepto" />
                      </xsl:attribute>
                      <xsl:attribute name="ImporteGravado">
                        <xsl:value-of select="format-number(ImporteGravado,'#0.00')" />
                      </xsl:attribute>
                      <xsl:attribute name="ImporteExento">
                        <xsl:value-of select="format-number(ImporteExento,'#0.00')" />
                      </xsl:attribute>
                      <xsl:attribute name="Tiempo">
                        <xsl:value-of select="format-number(tiempo,'#0.00')" />
                      </xsl:attribute>
                      
                      <xsl:if test="TipoSAT='019'">
                        <xsl:variable name="claveConcepto" select="Clave"/>
                        <xsl:for-each select = "/NewDataSet/TableHorasExtra[Clave=$claveConcepto[1]]">
                          <nomina:HorasExtra>
                            <xsl:choose>
                              <xsl:when test="Dias=0">
                                <xsl:attribute name="Dias">1</xsl:attribute>
                              </xsl:when>
                              <xsl:otherwise>
                                <xsl:attribute name="Dias">
                                  <xsl:value-of select="Dias"/>
                                </xsl:attribute>
                              </xsl:otherwise>
                            </xsl:choose>
                            <xsl:attribute name="TipoHoras">
                              <xsl:value-of select="TipoHoras" />
                            </xsl:attribute>
                            <xsl:choose>
                              <xsl:when test="HorasExtra=0">
                                <xsl:attribute name="HorasExtra">1</xsl:attribute>
                              </xsl:when>
                              <xsl:otherwise>
                                <xsl:attribute name="HorasExtra">
                                  <xsl:value-of select="HorasExtra" />
                                </xsl:attribute>
                              </xsl:otherwise>
                            </xsl:choose>
                            <xsl:attribute name="ImportePagado">
                              <xsl:value-of select="format-number(ImportePagado,'#0.00')" />
                            </xsl:attribute>
                          </nomina:HorasExtra>
                        </xsl:for-each>
                      </xsl:if>
                      
                      <xsl:if test="TipoSAT='045'">
                        <xsl:for-each select = "/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]]">
                          <nomina:AccionesOTitulos>
                            <xsl:attribute name="ValorMercado">
                              <xsl:value-of select="format-number(ValorMercadoAcciones,'#0.00')" />
                            </xsl:attribute>
                            <xsl:attribute name="PrecioAlOtorgarse">
                              <xsl:value-of select="format-number(PrecioEstTitulosVal,'#0.00')" />
                            </xsl:attribute>
                          </nomina:AccionesOTitulos>
                        </xsl:for-each>
                      </xsl:if>
                    </nomina:Percepcion>
                  </xsl:for-each>

                  <!-- Initial the additional tables of perceptions-->
                  <!-- If there is data for jubilacionPensionRetiro-->
                  <xsl:if test="count(/NewDataSet/TableJubilacionPensionRetiro)>0">
                    <!-- You can only have one type JubilacionPensionRetiro 039 (in one payment) or 044 (in installments).-->
                    <xsl:if test="/NewDataSet/TableConceptosSeparacion[TipoSAT='039']">
                      <nomina:JubilacionPensionRetiro>
                        <xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
                          <xsl:attribute name="IngresoAcumulable">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoNoAcumulable">
                            <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="TotalUnaExhibicion">
                            <xsl:value-of select="format-number(TotalUnaExhibicion,'#0.00')"/>
                          </xsl:attribute>
                        </xsl:for-each>
                      </nomina:JubilacionPensionRetiro>
                    </xsl:if>
                    
                    <xsl:if test="/NewDataSet/TableConceptosSeparacion[TipoSAT='044']">
                      <nomina:JubilacionPensionRetiro>
                        <xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
                          <xsl:attribute name="IngresoAcumulable">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoNoAcumulable">
                            <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="TotalParcialidad">
                            <xsl:value-of select="format-number(TotalParcialidad,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="MontoDiario">
                            <xsl:value-of select="format-number(MontoDiario,'#0.00')"/>
                          </xsl:attribute>
                        </xsl:for-each>
                      </nomina:JubilacionPensionRetiro>
                    </xsl:if>
                  </xsl:if>

                  <!-- SeparacionIndemnizacion 022(Seniority premium) 023(Separation payments) 025(Severance payments)-->
                  <xsl:if test="count(/NewDataSet/TableSeparacionIndemnizacion)>0 and (count(/NewDataSet/TableConceptosSeparacion[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                    <xsl:if test="/NewDataSet/TableSeparacionIndemnizacion/TotalPagado!=0">
                      <nomina:SeparacionIndemnizacion>
                        <xsl:for-each select = "/NewDataSet/TableSeparacionIndemnizacion">
                          <xsl:attribute name="TotalPagado">
                            <xsl:value-of select="format-number(TotalPagado,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:choose>
                            <xsl:when test="number(/NewDataSet/TableConceptosSeparacion/AntiguedadAnios)>0">
                              <xsl:attribute name="NumAñosServicio">
                                <xsl:value-of select="/NewDataSet/TableConceptosSeparacion/AntiguedadAnios"/>
                              </xsl:attribute>
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:attribute name="NumAñosServicio">0</xsl:attribute>
                            </xsl:otherwise>
                          </xsl:choose>
                          <xsl:attribute name="UltimoSueldoMensOrd">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoAcumulable">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoNoAcumulable">
                            <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                        </xsl:for-each>
                      </nomina:SeparacionIndemnizacion>
                    </xsl:if>
                  </xsl:if>
                </nomina:Percepciones>
              </xsl:if>
            </xsl:if>
              
            <xsl:if test="count(TablePrincipal[TipoTransaccion=2])>0">
              <xsl:element name="nomina:Deducciones">
                <xsl:attribute name="TotalOtrasDeducciones">
                  <xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones,'#0.00')"/>
                </xsl:attribute>
                <xsl:if test="TablePrincipal[1]/TotalImpuestosRetenidos>0">
                  <xsl:attribute name="TotalImpuestosRetenidos">
                    <xsl:value-of select="format-number(TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/>
                  </xsl:attribute>
                </xsl:if>
                <xsl:for-each select = "TablePrincipal[TipoTransaccion=2]">
                  <nomina:Deduccion>
                    <xsl:attribute name="TipoDeduccion">
                      <xsl:value-of select="TipoSAT"/>
                    </xsl:attribute>
                    <xsl:attribute name="Clave">
                      <xsl:value-of select="Clave" />
                    </xsl:attribute>
                    <xsl:attribute name="Concepto">
                      <xsl:value-of select="Concepto"/>
                    </xsl:attribute>
                    <xsl:attribute name="Importe">
                      <xsl:value-of select="format-number(Importe,'#0.00')"/>
                    </xsl:attribute>
                    <xsl:attribute name="Tiempo">
                      <xsl:value-of select="format-number(tiempo,'#0.00')"/>
                    </xsl:attribute>
                  </nomina:Deduccion>
                </xsl:for-each>
              </xsl:element>
            </xsl:if>

            <xsl:if test="count(/NewDataSet/TableOtrosPagos)>0">
              <xsl:if test="$tipoRegimenFinal='02' or /NewDataSet/TableOtrosPagos/Importe > 0">
                <nomina:OtrosPagos>
                  <xsl:for-each select = "TableOtrosPagos">
                    <nomina:OtroPago>
                      <xsl:attribute name="TipoOtroPago">
                        <xsl:value-of select="TipoOtroPago"/>
                      </xsl:attribute>
                      <xsl:attribute name="Clave">
                        <xsl:value-of select="Clave"/>
                      </xsl:attribute>
                      <xsl:attribute name="Concepto">
                        <xsl:value-of select="Concepto"/>
                      </xsl:attribute>
                      <xsl:attribute name="Importe">
                        <xsl:value-of select="format-number(Importe,'#0.00')"/>
                      </xsl:attribute>
                      <xsl:if test="TipoOtroPago='002' or TipoOtroPago='007' or TipoOtroPago='008'">
                        <nomina:SubsidioAlEmpleo
                          SubsidioCausado="{format-number(SubsidioCausado,'#0.00')}"
                        >
                        </nomina:SubsidioAlEmpleo>
                      </xsl:if>
                      <xsl:if test="TipoOtroPago='004'">
                        <nomina:CompensacionSaldosAFavor
                          SaldoAFavor="{format-number(SaldoAFavor,'#0.00')}"
                          Año="{Anio}"
                          RemanenteSalFav="{format-number(RemanenteSalFav,'#0.00')}"
                        >
                        </nomina:CompensacionSaldosAFavor>
                      </xsl:if>
                    </nomina:OtroPago>
                  </xsl:for-each>
                </nomina:OtrosPagos>
              </xsl:if>
            </xsl:if>

            <xsl:if test="count(/NewDataSet/TableIncapacidades)>0">
              <nomina:Incapacidades>
                <xsl:for-each select = "/NewDataSet/TableIncapacidades">
                  <nomina:Incapacidad>
                    <xsl:attribute name="DiasIncapacidad">
                      <xsl:value-of select="DiasIncapacidad" />
                    </xsl:attribute>
                    <xsl:attribute name="TipoIncapacidad">
                      <xsl:value-of select="TipoIncapacidad" />
                    </xsl:attribute>
                    <xsl:attribute name="ImporteMonetario">
                      <xsl:value-of select="format-number(Descuento,'#0.00')"/>
                    </xsl:attribute>
                  </nomina:Incapacidad>
                </xsl:for-each>
              </nomina:Incapacidades>
            </xsl:if>
          </nomina:Nomina>

          <!-- PTF-2091: Add second node if separation concepts table exists -->
          <xsl:if test="TableConceptosSeparacion and $varTotalPercepciones = 1">
            <!-- PTF-2916: Second node contains only liquidation data, tipoNomina will always be E-->
            <nomina:Nomina
                xmlns:nomina="http://www.sat.gob.mx/nomina12"
                xsi:schemaLocation="http://www.sat.gob.mx/informacion_fiscal/factura_electronica/Documents/Complementoscfdi/nomina12.xsd"
                Version="{TableConceptosSeparacion[1]/Version}"
                TipoNomina="E"
                FechaPago="{TableConceptosSeparacion[1]/FechaPago}"
                FechaInicialPago="{TableConceptosSeparacion[1]/FechaInicialPago}"
                FechaFinalPago="{TableConceptosSeparacion[1]/FechaFinalPago}"
                NumDiasPagados="{format-number(TableConceptosSeparacion[1]/NumDiasPagados,'#0.000')}"
            >
              <xsl:if test="TableConceptosSeparacion[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro!=0">
                <xsl:attribute name="TotalPercepciones">
                  <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalSueldos+TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion+TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro,'#0.00')"/>
                </xsl:attribute>
              </xsl:if>

              <xsl:if test="TableConceptosSeparacion[1]/TotalDeducciones+TableConceptosSeparacion[1]/TotalImpuestosRetenidos!=0">
                <xsl:attribute name="TotalDeducciones">
                  <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalDeducciones+TableConceptosSeparacion[1]/TotalImpuestosRetenidos,'#0.00')"/>
                </xsl:attribute>
              </xsl:if>

              <xsl:if test="TableConceptosSeparacion[1]/TotalOtrosPagos!=0">
                <xsl:attribute name="TotalOtrosPagos">
                  <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalOtrosPagos,'#0.00')"/>
                </xsl:attribute>
              </xsl:if>

              <xsl:choose>
                <xsl:when test="TableConceptosSeparacion[1]/longitudRegistroPatronal &lt;= 12">
                  <xsl:if test="contains('0102030405060708',$tipoContratoFinalNodo2)">
                    <xsl:element name="nomina:Emisor">
                      <xsl:attribute name="RegistroPatronal">
                        <xsl:value-of select="TableConceptosSeparacion[1]/RegistroPatronal"/>
                      </xsl:attribute>
                      <xsl:if test="TableConceptosSeparacion[1]/EmpresaSNCF!=0">
                        <xsl:element name="nomina:EntidadSNCF">
                          <xsl:attribute name="OrigenRecurso">
                            <xsl:value-of select="TableConceptosSeparacion[1]/OrigenRecurso"/>
                          </xsl:attribute>
                          <xsl:attribute name="MontoRecursoPropio">
                            <xsl:value-of select="TableConceptosSeparacion[1]/MontoRecursoPropio"/>
                          </xsl:attribute>
                        </xsl:element>
                      </xsl:if>
                    </xsl:element>
                  </xsl:if>
                </xsl:when>
                <xsl:otherwise>
                  <nomina:Emisor
                    Curp="{TableConceptosSeparacion[1]/CURPEmisor}"
                    RfcPatronOrigen="{TableConceptosSeparacion[1]/RFCPatronOrigen}"
                  >
                    <xsl:if test="contains('0102030405060708',$tipoContratoFinalNodo2)">
                      <xsl:attribute name="RegistroPatronal">
                        <xsl:value-of select="TableConceptosSeparacion[1]/RegistroPatronal"/>
                      </xsl:attribute>
                    </xsl:if>
                    <xsl:if test="TableConceptosSeparacion[1]/EmpresaSNCF!=0">
                      <nomina:EntidadSNCF
                        OrigenRecurso="{TableConceptosSeparacion[1]/OrigenRecurso}"
                        MontoRecursoPropio="{TableConceptosSeparacion[1]/MontoRecursoPropio}"
                      />
                    </xsl:if>
                  </nomina:Emisor>
                </xsl:otherwise>
              </xsl:choose>
              <xsl:element name="nomina:Receptor">
                <xsl:attribute name="Curp">
                  <xsl:value-of select="TableConceptosSeparacion[1]/CURP"/>
                </xsl:attribute>
                <!-- The following fields are not displayed for contract types greater than 08-->
                <xsl:if test="contains('0102030405060708',$tipoContratoFinalNodo2)">
                  <xsl:attribute name="NumSeguridadSocial">
                    <xsl:value-of select="TableConceptosSeparacion[1]/NumSeguridadSocial"/>
                  </xsl:attribute>
                  <xsl:attribute name="FechaInicioRelLaboral">
                    <xsl:value-of select="TableConceptosSeparacion[1]/FechaInicioRelLaboral"/>
                  </xsl:attribute>
                  <xsl:attribute name="Antigüedad">
                    <xsl:value-of select="TableConceptosSeparacion[1]/Antiguedad"/>
                  </xsl:attribute>
                  <xsl:attribute name="RiesgoPuesto">
                    <xsl:value-of select="TableConceptosSeparacion[1]/RiesgoPuesto"/>
                  </xsl:attribute>
                  <xsl:attribute name="SalarioDiarioIntegrado">
                    <xsl:value-of select="format-number(TableConceptosSeparacion[1]/SalarioDiarioIntegrado,'#0.00')"/>
                  </xsl:attribute>
                </xsl:if>
                <xsl:attribute name="TipoContrato">
                  <xsl:value-of select="format-number($tipoContratoFinalNodo2,'00')"/>
                </xsl:attribute>
                <xsl:attribute name="Sindicalizado">
                  <xsl:value-of select="TableConceptosSeparacion[1]/Sindicalizado"/>
                </xsl:attribute>
                <xsl:attribute name="TipoJornada">
                  <xsl:value-of select="TableConceptosSeparacion[1]/TipoJornada"/>
                </xsl:attribute>

                <!-- PTF-2916: Second node will have only separation info, so tipoRegimen will always be 13-->
                <xsl:attribute name="TipoRegimen">
                  <xsl:value-of select="13"/>
                </xsl:attribute>
                <xsl:attribute name="NumEmpleado">
                  <xsl:value-of select="TableConceptosSeparacion[1]/NumEmpleado"/>
                </xsl:attribute>
                <xsl:attribute name="Departamento">
                  <xsl:value-of select="TableConceptosSeparacion[1]/Departamento"/>
                </xsl:attribute>
                <xsl:attribute name="Puesto">
                  <xsl:value-of select="TableConceptosSeparacion[1]/Puesto"/>
                </xsl:attribute>
                <xsl:attribute name="PeriodicidadPago">
                  <xsl:value-of select="TableConceptosSeparacion[1]/PeriodicidadPago"/>
                </xsl:attribute>
                <xsl:if test="TableConceptosSeparacion[1]/Banco!=''">
                  <xsl:attribute name="Banco">
                    <xsl:value-of select="TableConceptosSeparacion[1]/Banco"/>
                  </xsl:attribute>
                </xsl:if>
                
              <!-- CU-863gfxd1h PTF-3211: Validate Banco attribute given CLABE and CuentaBancaria-->
              <xsl:choose>
                <xsl:when test="TableConceptosSeparacion[1]/Banco!='' and TableConceptosSeparacion[1]/CuentaBancaria!='' and TableConceptosSeparacion[1]/CuentaBancaria!='0'">
                  <xsl:attribute name="Banco">
                    <xsl:value-of select="TableConceptosSeparacion[1]/Banco"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="TableConceptosSeparacion[1]/Banco!='' and TableConceptosSeparacion[1]/CuentaBancaria!='' and TableConceptosSeparacion[1]/CuentaBancaria='0' and string-length(TableConceptosSeparacion[1]/CLABE)>2">
                </xsl:when>
                <xsl:when test="TableConceptosSeparacion[1]/Banco!='' and TableConceptosSeparacion[1]/CuentaBancaria!='' and TableConceptosSeparacion[1]/CuentaBancaria='0' and string-length(TableConceptosSeparacion[1]/CLABE)&lt;3">
                  <xsl:attribute name="Banco">
                    <xsl:value-of select="TableConceptosSeparacion[1]/CLABE"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:if test="TableConceptosSeparacion[1]/Banco!=''">
                    <xsl:attribute name="Banco">
                      <xsl:value-of select="TableConceptosSeparacion[1]/Banco"/>
                    </xsl:attribute>
                  </xsl:if>
                </xsl:otherwise>
              </xsl:choose>

              <!-- CU-863gfxd1h PTF-3211: If CuentaBancaria is != 0, then show that field, otherwise use CLABE because it's an interbank account -->
              <xsl:choose>
                <xsl:when test="TableConceptosSeparacion[1]/CuentaBancaria!='' and TableConceptosSeparacion[1]/CuentaBancaria!='0'">
                  <xsl:attribute name="CuentaBancaria">
                    <xsl:value-of select="TableConceptosSeparacion[1]/CuentaBancaria"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="TableConceptosSeparacion[1]/CuentaBancaria!='' and TableConceptosSeparacion[1]/CuentaBancaria='0'">
                  <xsl:attribute name="CuentaBancaria">
                    <xsl:value-of select="TableConceptosSeparacion[1]/CLABE"/>
                  </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:attribute name="CuentaBancaria">
                    <xsl:value-of select="TableConceptosSeparacion[1]/CuentaBancaria"/>
                  </xsl:attribute>
                </xsl:otherwise>
              </xsl:choose>
                <xsl:attribute name="SalarioBaseCotApor">
                  <xsl:value-of select="format-number(TableConceptosSeparacion[1]/SalarioBaseCotApor,'#0.00')"/>
                </xsl:attribute>
                <xsl:attribute name="ClaveEntFed">
                  <xsl:value-of select="TableConceptosSeparacion[1]/ClaveEntFed"/>
                </xsl:attribute>

                <xsl:if test="count(/NewDataSet/TableSubcontratacion)>0">
                  <xsl:for-each select = "TableSubcontratacion">
                    <nomina:SubContratacion>
                      <xsl:attribute name="RfcLabora">
                        <xsl:value-of select="RfcLabora" />
                      </xsl:attribute>
                      <xsl:attribute name="PorcentajeTiempo">
                        <xsl:value-of select="PorcentajeTiempo" />
                      </xsl:attribute>
                    </nomina:SubContratacion>
                  </xsl:for-each>
                </xsl:if>
              </xsl:element>

              <xsl:if test="TableConceptosSeparacion[1]/TotalSueldos!=0 or TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion!=0 or TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro!=0">
                <nomina:Percepciones>
                  <xsl:attribute name="TotalExento">
                    <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalExento,'#0.00')"/>
                  </xsl:attribute>
                  <xsl:attribute name="TotalGravado">
                    <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalGravado,'#0.00')"/>
                  </xsl:attribute>

                  <xsl:if test="TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro!=0">
                    <xsl:attribute name="TotalJubilacionPensionRetiro">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalJubilacionPensionRetiro,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>

                  <xsl:if test="TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion!=0">
                    <xsl:attribute name="TotalSeparacionIndemnizacion">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalSeparacionIndemnizacion,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>

                  <xsl:if test="TableConceptosSeparacion[1]/TotalSueldos!=0">
                    <xsl:attribute name="TotalSueldos">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalSueldos,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>

                  <xsl:for-each select = "TableConceptosSeparacion[TipoTransaccion=1]">
                    <nomina:Percepcion>
                      <xsl:attribute name="TipoPercepcion">
                        <xsl:value-of select="TipoSAT" />
                      </xsl:attribute>
                      <xsl:attribute name="Clave">
                        <xsl:value-of select="Clave" />
                      </xsl:attribute>
                      <xsl:attribute name="Concepto">
                        <xsl:value-of select="Concepto" />
                      </xsl:attribute>
                      <xsl:attribute name="ImporteGravado">
                        <xsl:value-of select="format-number(ImporteGravado,'#0.00')" />
                      </xsl:attribute>
                      <xsl:attribute name="ImporteExento">
                        <xsl:value-of select="format-number(ImporteExento,'#0.00')" />
                      </xsl:attribute>
                      <xsl:attribute name="Tiempo">
                        <xsl:value-of select="format-number(tiempo,'#0.00')" />
                      </xsl:attribute>

                      <xsl:if test="TipoSAT='019'">
                        <xsl:variable name="claveConcepto" select="Clave"/>
                        <xsl:for-each select = "/NewDataSet/TableHorasExtra[Clave=$claveConcepto[1]]">
                          <nomina:HorasExtra>
                            <xsl:choose>
                              <xsl:when test="Dias=0">
                                <xsl:attribute name="Dias">1</xsl:attribute>
                              </xsl:when>
                              <xsl:otherwise>
                                <xsl:attribute name="Dias">
                                  <xsl:value-of select="Dias"/>
                                </xsl:attribute>
                              </xsl:otherwise>
                            </xsl:choose>
                            <xsl:attribute name="TipoHoras">
                              <xsl:value-of select="TipoHoras" />
                            </xsl:attribute>
                            <xsl:choose>
                              <xsl:when test="HorasExtra=0">
                                <xsl:attribute name="HorasExtra">1</xsl:attribute>
                              </xsl:when>
                              <xsl:otherwise>
                                <xsl:attribute name="HorasExtra">
                                  <xsl:value-of select="HorasExtra" />
                                </xsl:attribute>
                              </xsl:otherwise>
                            </xsl:choose>
                            <xsl:attribute name="ImportePagado">
                              <xsl:value-of select="format-number(ImportePagado,'#0.00')" />
                            </xsl:attribute>
                          </nomina:HorasExtra>
                        </xsl:for-each>
                      </xsl:if>

                      <xsl:if test="TipoSAT='045'">
                        <xsl:for-each select = "/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]]">
                          <nomina:AccionesOTitulos>
                            <xsl:attribute name="ValorMercado">
                              <xsl:value-of select="format-number(ValorMercadoAcciones,'#0.00')" />
                            </xsl:attribute>
                            <xsl:attribute name="PrecioAlOtorgarse">
                              <xsl:value-of select="format-number(PrecioEstTitulosVal,'#0.00')" />
                            </xsl:attribute>
                          </nomina:AccionesOTitulos>
                        </xsl:for-each>
                      </xsl:if>
                    </nomina:Percepcion>
                  </xsl:for-each>

                  <!-- Initial the additional tables of perceptions-->
                  <!-- If there is data for jubilacionPensionRetiro-->
                  <xsl:if test="count(/NewDataSet/TableJubilacionPensionRetiro)>0">
                    <!-- You can only have one type JubilacionPensionRetiro 039 (in one payment) or 044 (in installments).-->
                    <xsl:if test="/NewDataSet/TableConceptosSeparacion[TipoSAT='039']">
                      <nomina:JubilacionPensionRetiro>
                        <xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
                          <xsl:attribute name="IngresoAcumulable">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoNoAcumulable">
                            <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="TotalUnaExhibicion">
                            <xsl:value-of select="format-number(TotalUnaExhibicion,'#0.00')"/>
                          </xsl:attribute>
                        </xsl:for-each>
                      </nomina:JubilacionPensionRetiro>
                    </xsl:if>

                    <xsl:if test="/NewDataSet/TableConceptosSeparacion[TipoSAT='044']">
                      <nomina:JubilacionPensionRetiro>
                        <xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
                          <xsl:attribute name="IngresoAcumulable">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoNoAcumulable">
                            <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="TotalParcialidad">
                            <xsl:value-of select="format-number(TotalParcialidad,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="MontoDiario">
                            <xsl:value-of select="format-number(MontoDiario,'#0.00')"/>
                          </xsl:attribute>
                        </xsl:for-each>
                      </nomina:JubilacionPensionRetiro>
                    </xsl:if>
                  </xsl:if>

                  <!-- SeparacionIndemnizacion 022(Seniority premium) 023(severance payments) 025(Severance payments)-->
                  <xsl:if test="count(/NewDataSet/TableSeparacionIndemnizacion)>0 and (count(/NewDataSet/TableConceptosSeparacion[TipoNominaSat='E' and TipoTransaccion=1 and (TipoSAT='022' or TipoSAT='023' or TipoSAT='025')])>0)">
                    <xsl:if test="/NewDataSet/TableSeparacionIndemnizacion/TotalPagado!=0">
                      <nomina:SeparacionIndemnizacion>
                        <xsl:for-each select = "/NewDataSet/TableSeparacionIndemnizacion">
                          <xsl:attribute name="TotalPagado">
                            <xsl:value-of select="format-number(TotalPagado,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:choose>
                            <xsl:when test="number(/NewDataSet/TableConceptosSeparacion/AntiguedadAnios)>0">
                              <xsl:attribute name="NumAñosServicio">
                                <xsl:value-of select="/NewDataSet/TableConceptosSeparacion/AntiguedadAnios"/>
                              </xsl:attribute>
                            </xsl:when>
                            <xsl:otherwise>
                              <xsl:attribute name="NumAñosServicio">0</xsl:attribute>
                            </xsl:otherwise>
                          </xsl:choose>
                          <xsl:attribute name="UltimoSueldoMensOrd">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoAcumulable">
                            <xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                          <xsl:attribute name="IngresoNoAcumulable">
                            <xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/>
                          </xsl:attribute>
                        </xsl:for-each>
                      </nomina:SeparacionIndemnizacion>
                    </xsl:if>
                  </xsl:if>
                </nomina:Percepciones>
              </xsl:if>

              <xsl:if test="count(TableConceptosSeparacion[TipoTransaccion=2])>0">
                <xsl:element name="nomina:Deducciones">
                  <xsl:attribute name="TotalOtrasDeducciones">
                    <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalDeducciones,'#0.00')"/>
                  </xsl:attribute>
                  <xsl:if test="TableConceptosSeparacion[1]/TotalImpuestosRetenidos>0">
                    <xsl:attribute name="TotalImpuestosRetenidos">
                      <xsl:value-of select="format-number(TableConceptosSeparacion[1]/TotalImpuestosRetenidos,'#0.00')"/>
                    </xsl:attribute>
                  </xsl:if>
                  <xsl:for-each select = "TableConceptosSeparacion[TipoTransaccion=2]">
                    <nomina:Deduccion>
                      <xsl:attribute name="TipoDeduccion">
                        <xsl:value-of select="TipoSAT"/>
                      </xsl:attribute>
                      <xsl:attribute name="Clave">
                        <xsl:value-of select="Clave" />
                      </xsl:attribute>
                      <xsl:attribute name="Concepto">
                        <xsl:value-of select="Concepto"/>
                      </xsl:attribute>
                      <xsl:attribute name="Importe">
                        <xsl:value-of select="format-number(Importe,'#0.00')"/>
                      </xsl:attribute>
                      <xsl:attribute name="Tiempo">
                        <xsl:value-of select="format-number(tiempo,'#0.00')"/>
                      </xsl:attribute>
                    </nomina:Deduccion>
                  </xsl:for-each>
                </xsl:element>
              </xsl:if>
            </nomina:Nomina>
          </xsl:if>
        </cfdi:Complemento>
      </cfdi:Comprobante>
    </nomina>
  </xsl:template>
</xsl:stylesheet>
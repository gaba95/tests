﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    /// <summary>
    /// Valid Comparation Operators for DgFilter
    /// </summary>
    public enum ComparationOperator
    {
        Equal = 1,
        NotEqual = 2,
        Contain = 3,
        NoContain = 4,
        Greater = 5,
        GreaterOrEqual = 6,
        Less = 7,
        LessOrEqual = 8,
        In = 9,
        NotIn = 10
    }
}

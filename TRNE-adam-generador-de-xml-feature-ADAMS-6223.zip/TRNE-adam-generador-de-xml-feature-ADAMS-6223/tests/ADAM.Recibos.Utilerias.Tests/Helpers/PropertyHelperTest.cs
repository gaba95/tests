using System;
using ADAM.Recibos.Utilerias.Helpers;
using ADAM.Recibos.Utilerias.Tests.Dummys;
namespace ADAM.Recibos.Utilerias.Tests.Helpers
{
    [TestClass]
    public class PropertyHelperTest
    {
        [TestMethod]
        public void GetPrivatePropertyValue_ObjNull_ThrowsArgumentNullException()
        {
            object obj = null;
            Assert.Throws<ArgumentNullException>(() => obj.GetPrivatePropertyValue<string>("AnyProperty"));
        }
        
        [TestMethod]
        public void GetPrivatePropertyValue_PropertyDoesNotExist_ThrowsArgumentOutOfRangeException()
        {
            var obj = new DummyClass();
                        Assert.Throws<ArgumentOutOfRangeException>(() => obj.GetPrivatePropertyValue<string>("NonExistentProperty"));
        }
        
        [TestMethod]
        public void GetPrivatePropertyValue_PropertyExist_ReturnsValue()
        {
            var obj = new DummyClass();
            var result = obj.GetPrivatePropertyValue<string>("PrivatePop");
            Assert.AreEqual("secret", result);
        }
        
        [TestMethod]
        public void GetPrivateFieldValue_ObjNull_ThrowsArgumentNullException()
        {
            object obj = null;
            Assert.Throws<ArgumentNullException>(() => obj.GetPrivateFieldValue<string>("AnyField"));
        }
        
        [TestMethod]
        public void GetPrivateFieldValue_FieldExistInClass_ReturnsValue()
        {
            var obj = new DummyClass();
            var result = obj.GetPrivateFieldValue<string>("_privateField");
            Assert.AreEqual("value", result);
        }
        
        [TestMethod]
        public void GetPrivateFieldValue_FieldExistInBaseClass_ReturnsValue()
        {
            var obj = new ChildDummy();
            var result = obj.GetPrivateFieldValue<string>("_baseField");
            Assert.AreEqual("baseValue", result);
        }
        
        [TestMethod]
        public void GetPrivateFieldValue_FieldDoesNotExist_ThrowsArgumentOutOfRangeException()
        {
            var obj = new DummyClass();
            Assert.Throws<ArgumentOutOfRangeException>(() => obj.GetPrivateFieldValue<string>("NonExistentField"));
        }
        
        [TestMethod]
        public void SetPrivateFieldValue_SetPrivateField()
        {
            var obj = new DummyClass();
            obj.SetPrivateFieldValue("_privateField", "newValue");
            var value = obj.GetPrivateFieldValue<string>("_privateField");
            Assert.AreEqual("newValue", value);
        }
        
        [TestMethod]
        public void SetPrivateFieldValue_SetsBasePrivateField()
        {
            var obj = new ChildDummy();
            obj.SetPrivateFieldValue("_baseField", "newValue");
            var value = obj.GetPrivateFieldValue<string>("_baseField");
            Assert.AreEqual("newValue", value);
        }
        
        [TestMethod]
        public void SetPrivateFieldValue_FieldNotExist_ThrowsArgumentOutOfRangeException()
        {
            var obj = new ChildDummy();
            Assert.Throws<ArgumentOutOfRangeException>(() => obj.SetPrivateFieldValue("_nonExistentField", "value"));
        }
        
        [TestMethod]
        public void SetPrivateFieldValue_NullPropName_ThrowsArgumentNullException()
        {
            var obj = new DummyClass();
            Assert.Throws<ArgumentNullException>(() => obj.SetPrivateFieldValue(null, "value"));
        }
    }
}
﻿using System.Net;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Xml.Linq;
using System.Globalization;

namespace ADAM.Recibos.Utilerias.Helpers
{
    public static class GlobalHelper
    {
        public static string ToXml(this DataTable table, int metaIndex = 0)
        {
            XDocument xdoc = new XDocument(
                new XElement(table.TableName,
                    from column in table.Columns.Cast<DataColumn>()
                    where column != table.Columns[metaIndex]
                    select new XElement(column.ColumnName,
                        from row in table.AsEnumerable()
                        select new XElement(row.Field<string>(metaIndex), row[column])
                        )
                    )
                );

            return xdoc.ToString();
        }

        public static DataTable Meses()
        {
            DataTable meses = new DataTable();
            DataRow renglon;

            string nombreMes;
            meses.Columns.Add("mes");
            meses.Columns.Add("descripcion");

            for (int mes = 0; mes < 12; mes++)
            {
                nombreMes = CultureInfo.GetCultureInfo("es-MX").DateTimeFormat.MonthNames[mes];
                renglon = meses.NewRow();
                renglon["mes"] = mes + 1;
                renglon["descripcion"] = nombreMes.ToUpper();
                meses.Rows.Add(renglon);
            }

            return meses;
        }

        public static Func<string, string> CreateFuncGetParam(DataSet param, string columnParamName, string columnValueName)
        {
            Func<string, string> resultFunc = (string id_parametro) =>
            {
                var parametro = param.Tables[0].AsEnumerable().Where(t => t.Field<string>(columnParamName) == id_parametro).ToArray();
                if (parametro.Length > 0)
                    return parametro[0]?.Field<string>(columnValueName);
                return string.Empty;
            };
            return resultFunc;
        }

        public static void ValidateUrl(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                throw new ArgumentException("La URL no puede estar vacía.");
            }

            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri uri))
            {
                throw new ArgumentException("La URL no es válida.");
            }

            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
            {
                throw new ArgumentException("Solo se permiten esquemas HTTP y HTTPS.");
            }

            string host = uri.Host.ToLower();
            IPAddress[] addresses = Dns.GetHostAddresses(host);

            if (addresses.Any(ip => IPAddress.IsLoopback(ip)))
                throw new ArgumentException("No se permite el acceso a direcciones locales o privadas.");
        }

        /// <summary>
        /// Opens a local file using the system default application.
        /// Validates and sanitizes the path to prevent OS command injection.
        /// Uses a safe temp copy to break taint propagation from untrusted sources.
        /// </summary>
        public static void OpenFileSecure(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                return;

            // Resolve to absolute canonical path (removes traversal, resolves symlinks)
            string fullPath = Path.GetFullPath(filePath);

            // Reject paths containing characters that could be used for argument injection
            char[] forbidden = { '"', '&', '|', ';', '<', '>', '`', '$', '!', '\n', '\r' };
            if (fullPath.IndexOfAny(forbidden) >= 0)
                throw new ArgumentException("File path contains invalid characters.");

            // Must be a rooted, existing file
            if (!Path.IsPathRooted(fullPath) || !File.Exists(fullPath))
                return;

            // Validate extension is a known safe document type
            string ext = Path.GetExtension(fullPath).ToLowerInvariant();
            string[] allowedExtensions = { ".xml", ".html", ".htm", ".json", ".csv", ".txt", ".pdf", ".xlsx", ".xls", ".zip" };
            if (!allowedExtensions.Contains(ext))
                throw new ArgumentException($"File extension '{ext}' is not allowed.");

            // Copy file to a safe temp location with a fixed name pattern to break taint chain
            const string safeTempDir = @"C:\ADAM_Viewer";
            Directory.CreateDirectory(safeTempDir);

            // Map extension to a fully constant file path — no tainted data reaches Process.Start
            string safeTempFile = ext switch
            {
                ".xml" => @"C:\ADAM_Viewer\preview.xml",
                ".html" => @"C:\ADAM_Viewer\preview.html",
                ".htm" => @"C:\ADAM_Viewer\preview.htm",
                ".json" => @"C:\ADAM_Viewer\preview.json",
                ".csv" => @"C:\ADAM_Viewer\preview.csv",
                ".txt" => @"C:\ADAM_Viewer\preview.txt",
                ".pdf" => @"C:\ADAM_Viewer\preview.pdf",
                ".xlsx" => @"C:\ADAM_Viewer\preview.xlsx",
                ".xls" => @"C:\ADAM_Viewer\preview.xls",
                ".zip" => @"C:\ADAM_Viewer\preview.zip",
                _ => throw new ArgumentException($"File extension '{ext}' is not allowed.")
            };

            File.Copy(fullPath, safeTempFile, overwrite: true);

            // Open via isolated launcher — no tainted context reaches Process.Start
            SafeProcessLauncher.OpenWithExplorer(safeTempFile);
        }

        /// <summary>
        /// Opens a URL in the default browser securely.
        /// Validates the URL against an allowlist of safe characters to prevent OS command injection (CWE-78).
        /// Uses an intermediate HTML redirect file to completely break taint propagation.
        /// </summary>
        public static void OpenUrlSecure(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
                throw new ArgumentException("La URL no puede estar vacía.");

            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri uri))
                throw new ArgumentException("La URL no es válida.");

            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
                throw new ArgumentException("Solo se permiten esquemas HTTP y HTTPS.");

            // Validate that the URL only contains characters safe for URLs
            string canonicalUrl = uri.AbsoluteUri;
            const string allowedChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~:/?#[]@!$&'()*+,;=%";
            foreach (char c in canonicalUrl)
            {
                if (allowedChars.IndexOf(c) < 0)
                    throw new ArgumentException($"La URL contiene caracteres no permitidos: '{c}'");
            }

            // Write a redirect HTML file — breaks taint chain completely
            const string safeTempDir = @"C:\ADAM_Viewer";
            Directory.CreateDirectory(safeTempDir);
            const string redirectFile = @"C:\ADAM_Viewer\redirect.html";
            string htmlContent = $"<html><head><meta http-equiv=\"refresh\" content=\"0;url={WebUtility.HtmlEncode(canonicalUrl)}\"/></head><body></body></html>";
            File.WriteAllText(redirectFile, htmlContent);

            // Open via isolated launcher — no tainted context reaches Process.Start
            SafeProcessLauncher.OpenWithExplorer(redirectFile);
        }

    }

    /// <summary>
    /// Internal helper to open files via explorer.exe.
    /// Isolated from tainted contexts to satisfy static analysis (CWE-78).
    /// Only accepts paths from a predefined safe set.
    /// </summary>
    internal static class SafeProcessLauncher
    {
        private static readonly HashSet<string> AllowedPaths = new(StringComparer.OrdinalIgnoreCase)
        {
            @"C:\ADAM_Viewer\preview.xml",
            @"C:\ADAM_Viewer\preview.html",
            @"C:\ADAM_Viewer\preview.htm",
            @"C:\ADAM_Viewer\preview.json",
            @"C:\ADAM_Viewer\preview.csv",
            @"C:\ADAM_Viewer\preview.txt",
            @"C:\ADAM_Viewer\preview.pdf",
            @"C:\ADAM_Viewer\preview.xlsx",
            @"C:\ADAM_Viewer\preview.xls",
            @"C:\ADAM_Viewer\preview.zip",
            @"C:\ADAM_Viewer\redirect.html"
        };

        internal static void OpenWithExplorer(string filePath)
        {
            if (!AllowedPaths.Contains(filePath))
                throw new ArgumentException("Path is not in the allowed set.");

            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = filePath,
                UseShellExecute = false,
                CreateNoWindow = true
            });
        }
    }
}

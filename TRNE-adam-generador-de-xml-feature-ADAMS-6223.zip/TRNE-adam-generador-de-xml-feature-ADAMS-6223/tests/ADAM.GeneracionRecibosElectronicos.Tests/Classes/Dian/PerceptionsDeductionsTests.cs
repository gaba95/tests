using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class PerceptionsDeductionsTests
    {
        #region Perceptions

        [TestMethod]
        public void Perceptions_Basico_HasDefaultValue()
        {
            var perceptions = new Perceptions();
            Assert.IsNotNull(perceptions.basico);
            Assert.AreEqual(0, perceptions.basico.SueldoTrabajadoCantidad);
            Assert.AreEqual(0.0M, perceptions.basico.SueldoTrabajado);
        }

        [TestMethod]
        public void Perceptions_AllCollectionProperties_DefaultToNull()
        {
            var perceptions = new Perceptions();

            Assert.IsNull(perceptions.transporte);
            Assert.IsNull(perceptions.heDs);
            Assert.IsNull(perceptions.heNs);
            Assert.IsNull(perceptions.hrNs);
            Assert.IsNull(perceptions.hrddFs);
            Assert.IsNull(perceptions.hendFs);
            Assert.IsNull(perceptions.hrndFs);
            Assert.IsNull(perceptions.heddFs);
            Assert.IsNull(perceptions.vacaciones);
            Assert.IsNull(perceptions.primas);
            Assert.IsNull(perceptions.cesantias);
            Assert.IsNull(perceptions.incapacidades);
            Assert.IsNull(perceptions.licencias);
            Assert.IsNull(perceptions.bonificacion);
            Assert.IsNull(perceptions.auxilios);
            Assert.IsNull(perceptions.huelgas);
            Assert.IsNull(perceptions.otrosConceptos);
            Assert.IsNull(perceptions.compensaciones);
            Assert.IsNull(perceptions.bonosEPCTV);
            Assert.IsNull(perceptions.comisiones);
            Assert.IsNull(perceptions.pagosTerceros);
            Assert.IsNull(perceptions.anticipos);
        }

        [TestMethod]
        public void Perceptions_DecimalProperties_SetAndGet()
        {
            var p = new Perceptions
            {
                Dotacion = 100000m,
                ApoyoSost = 50000m,
                Teletrabajo = 75000m,
                BonifRetiro = 3000000m,
                Indemnizacion = 10000000m,
                Reintegro = 200000m
            };

            Assert.AreEqual(100000m, p.Dotacion);
            Assert.AreEqual(50000m, p.ApoyoSost);
            Assert.AreEqual(75000m, p.Teletrabajo);
            Assert.AreEqual(3000000m, p.BonifRetiro);
            Assert.AreEqual(10000000m, p.Indemnizacion);
            Assert.AreEqual(200000m, p.Reintegro);
        }

        [TestMethod]
        public void Perceptions_JsonPropertyNames_AreCorrect()
        {
            var p = new Perceptions
            {
                Dotacion = 1m,
                ApoyoSost = 2m,
                Teletrabajo = 3m,
                BonifRetiro = 4m,
                Indemnizacion = 5m,
                Reintegro = 6m
            };
            var json = JsonConvert.SerializeObject(p);

            Assert.IsTrue(json.Contains("\"dotacion\""));
            Assert.IsTrue(json.Contains("\"apoyoSost\""));
            Assert.IsTrue(json.Contains("\"teletrabajo\""));
            Assert.IsTrue(json.Contains("\"bonifRetiro\""));
            Assert.IsTrue(json.Contains("\"indemnizacion\""));
            Assert.IsTrue(json.Contains("\"reintegro\""));
        }

        [TestMethod]
        public void Perceptions_WithCollections_SetAndGet()
        {
            var p = new Perceptions
            {
                heDs = new List<HeDs> { new HeDs { Pago = 50000m } },
                vacaciones = new List<Holidays> { new Holidays { Pago = 1000000m } },
                bonificacion = new List<Bonus> { new Bonus { valor = 200000m } },
                compensaciones = new List<Compensations> { new Compensations { valor = 300000m } },
                transporte = new Transport { AuxilioTransporte = 140606m },
                primas = new Premiums { Pago = 1250000m },
                cesantias = new Layoffs { Pago = 2500000m }
            };

            Assert.AreEqual(1, p.heDs.Count);
            Assert.AreEqual(50000m, p.heDs[0].Pago);
            Assert.AreEqual(1, p.vacaciones.Count);
            Assert.AreEqual(140606m, p.transporte.AuxilioTransporte);
        }

        #endregion

        #region Deductions

        [TestMethod]
        public void Deductions_AllDecimalProperties_SetAndGet()
        {
            var d = new Deductions
            {
                PensionVoluntaria = 100000m,
                RetencionFuente = 250000m,
                AFC = 50000m,
                Cooperativa = 30000m,
                EmbargoFiscal = 0m,
                PlanComplementarios = 80000m,
                Educacion = 120000m,
                Reintegro = 15000m,
                Deuda = 500000m
            };

            Assert.AreEqual(100000m, d.PensionVoluntaria);
            Assert.AreEqual(250000m, d.RetencionFuente);
            Assert.AreEqual(50000m, d.AFC);
            Assert.AreEqual(30000m, d.Cooperativa);
            Assert.AreEqual(0m, d.EmbargoFiscal);
            Assert.AreEqual(80000m, d.PlanComplementarios);
            Assert.AreEqual(120000m, d.Educacion);
            Assert.AreEqual(15000m, d.Reintegro);
            Assert.AreEqual(500000m, d.Deuda);
        }

        [TestMethod]
        public void Deductions_ComplexProperties_SetAndGet()
        {
            var d = new Deductions
            {
                salud = new Health { DeduccionPorcentaje = 4.0m, Deduccion = 100000m },
                fondoPension = new PensionFund { DeduccionPorcentaje = 4.0m, Deduccion = 100000m },
                fondoPensionSP = new PensionfundSP { DeduccionSP = 50000m },
                sindicatos = new List<Unions> { new Unions { Deduccion = 37500m } },
                sanciones = new List<Sanctions> { new Sanctions { valorDeduccion = 50000m } },
                libranzas = new List<Orders> { new Orders { Deduccion = 500000m } },
                pagosTerceros = new List<ThirdPartyPayments> { new ThirdPartyPayments { PagoTercero = 200000m } },
                anticipos = new List<Advances> { new Advances { Anticipo = 100000m } },
                otrosDescuentos = new List<OtherDiscounts> { new OtherDiscounts { OtraDeduccion = 75000m } }
            };

            Assert.IsNotNull(d.salud);
            Assert.AreEqual(100000m, d.salud.Deduccion);
            Assert.IsNotNull(d.fondoPension);
            Assert.IsNotNull(d.fondoPensionSP);
            Assert.AreEqual(1, d.sindicatos.Count);
            Assert.AreEqual(1, d.sanciones.Count);
            Assert.AreEqual(1, d.libranzas.Count);
            Assert.AreEqual(1, d.pagosTerceros.Count);
            Assert.AreEqual(1, d.anticipos.Count);
            Assert.AreEqual(1, d.otrosDescuentos.Count);
        }

        [TestMethod]
        public void Deductions_JsonPropertyNames_AreCorrect()
        {
            var d = new Deductions
            {
                PensionVoluntaria = 1m,
                RetencionFuente = 2m,
                AFC = 3m,
                Cooperativa = 4m,
                EmbargoFiscal = 5m,
                PlanComplementarios = 6m,
                Educacion = 7m,
                Reintegro = 8m,
                Deuda = 9m
            };
            var json = JsonConvert.SerializeObject(d);

            Assert.IsTrue(json.Contains("\"pensionVoluntaria\""));
            Assert.IsTrue(json.Contains("\"retencionFuente\""));
            Assert.IsTrue(json.Contains("\"afc\""));
            Assert.IsTrue(json.Contains("\"cooperativa\""));
            Assert.IsTrue(json.Contains("\"embargofiscal\""));
            Assert.IsTrue(json.Contains("\"planComplementarios\""));
            Assert.IsTrue(json.Contains("\"educacion\""));
            Assert.IsTrue(json.Contains("\"reintegro\""));
            Assert.IsTrue(json.Contains("\"deuda\""));
        }

        #endregion
    }
}

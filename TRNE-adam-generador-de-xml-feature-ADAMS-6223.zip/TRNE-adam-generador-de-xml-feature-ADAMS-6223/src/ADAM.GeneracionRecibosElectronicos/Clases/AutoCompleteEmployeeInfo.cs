﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases
{
    class AutoCompleteEmployeeInfo
    {

        public AutoCompleteEmployeeInfo(string text, string value)
        {
            this.DisplayText = text;
            this.Value = value;
        }

        public string DisplayText
        {
            set;
            get;
        }

        public string Value
        {
            set;
            get;
        }

        public override string ToString()
        {
            return DisplayText;
        }


    }
}

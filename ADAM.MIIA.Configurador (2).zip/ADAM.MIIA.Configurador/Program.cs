using ADAM.MIIA.Configurador.UI;
using System.Text;

namespace ADAM.MIIA.Configurador;

static class Program
{
    [STAThread]
    static void Main()
    {
        // Habilita codificaciones legacy (p.ej. 1252) necesarias en algunos entornos
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        ApplicationConfiguration.Initialize();
        Application.Run(new frmConfiguracion());
    }
}

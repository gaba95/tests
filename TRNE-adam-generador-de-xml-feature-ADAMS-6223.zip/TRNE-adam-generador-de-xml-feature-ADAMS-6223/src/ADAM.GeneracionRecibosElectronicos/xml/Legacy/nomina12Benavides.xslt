﻿<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" >
	<xsl:output method="xml"/>
	<xsl:template match="/NewDataSet">
<!--		
			<ADAM 
				instancia = "{TablePrincipal[1]/Instancia}"
				Compania = "{TablePrincipal[1]/Compania}"
				TipoNomina = "{TablePrincipal[1]/TipoNomina}"
				ClaseNomina = "{TablePrincipal[1]/ClaseNomina}"
				Anio = "{TablePrincipal[1]/Anio}"
				Periodo = "{TablePrincipal[1]/Periodo}"
				correoEmpleado = "{TablePrincipal[1]/correoEmpleado}"
				netoPagar = "{TablePrincipal[1]/netoPagar}"
				netoPagarLetra = "{TablePrincipal[1]/netoPagarLetra}"
				netoAnterior = "{TablePrincipal[1]/netoAnterior}"
				sueldo = "{format-number(TablePrincipal[1]/Sueldo,'#0.00')}"
				folio="{TablePrincipal[1]/Compania}-{TablePrincipal[1]/NumEmpleado}-{TablePrincipal[1]/TipoNomina}{TablePrincipal[1]/Periodo}"
			/>
-->			
			<cfdi:Comprobante
				xmlns:cfdi="http://www.sat.gob.mx/cfd/3" 
				xmlns:nomina12="http://www.sat.gob.mx/nomina12" 
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
				xsi:schemaLocation="http://www.sat.gob.mx/cfd/3 http://www.sat.gob.mx/sitio_internet/cfd/3/cfdv32.xsd http://www.sat.gob.mx/nomina12 http://www.sat.gob.mx/sitio_internet/cfd/nomina/nomina12.xsd"
				version="{TablePrincipal[1]/VersionFactura}"
				fecha="{TablePrincipal[1]/Fecha}"
				tipoDeComprobante="egreso" 
				formaDePago="Pago en una sola exhibicion"
				metodoDePago="NA"
				noCertificado="{TablePrincipal[1]/noCertificado}"
				subTotal="{format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')}"
				Moneda="MXN"
				TipoCambio="1"
				total="{format-number(TablePrincipal[1]/netoPagar,'#0.00')}"
				LugarExpedicion="{TablePrincipal[1]/LugarExpedicion}"
				certificado="" 
				sello="" 
			>
			
				<xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
					<xsl:attribute name="descuento"><xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/></xsl:attribute>
				</xsl:if>

				<cfdi:Emisor 
					nombre="{TablePrincipal[1]/emisorNombre}" 
					rfc="{TablePrincipal[1]/emisorRfc}"
				>
					<cfdi:RegimenFiscal Regimen="{TablePrincipal[1]/emisorRegimen}"/>
				</cfdi:Emisor>

				<cfdi:Receptor 
					rfc="{TablePrincipal[1]/receptorRfc}"
					nombre="{TablePrincipal[1]/receptorNombre}"> 
				</cfdi:Receptor>
				
				<cfdi:Conceptos>
					<cfdi:Concepto 
						importe="{format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')}"
						valorUnitario="{format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro+TablePrincipal[1]/TotalOtrosPagos,'#0.00')}"
						descripcion="Pago de nómina"
						unidad="ACT" 
						cantidad="1"
					/>
				</cfdi:Conceptos>

				<cfdi:Impuestos/>

				<cfdi:Complemento>
					<nomina12:Nomina
						Version="{TablePrincipal[1]/Version}"
						TipoNomina="{TablePrincipal[1]/TipoNominaSat}"
						FechaPago="{TablePrincipal[1]/FechaPago}"
						FechaInicialPago="{TablePrincipal[1]/FechaInicialPago}" 
						FechaFinalPago="{TablePrincipal[1]/FechaFinalPago}"
						NumDiasPagados="{format-number(TablePrincipal[1]/NumDiasPagados,'#0.000')}"
					>
						<xsl:if test="TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
							<xsl:attribute name="TotalPercepciones"><xsl:value-of select="format-number(TablePrincipal[1]/TotalSueldos+TablePrincipal[1]/TotalSeparacionIndemnizacion+TablePrincipal[1]/TotalJubilacionPensionRetiro,'#0.00')"/></xsl:attribute>
						</xsl:if>
						<xsl:if test="TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos!=0">
							<xsl:attribute name="TotalDeducciones"><xsl:value-of select="format-number(TablePrincipal[1]/TotalDeducciones+TablePrincipal[1]/TotalImpuestosRetenidos,'#0.00')"/></xsl:attribute>
						</xsl:if>
						<xsl:if test="TablePrincipal[1]/TotalOtrosPagos!=0">
							<xsl:attribute name="TotalOtrosPagos"><xsl:value-of select="format-number(TablePrincipal[1]/TotalOtrosPagos,'#0.00')"/></xsl:attribute>
						</xsl:if>
						
						<xsl:choose>
							<xsl:when test="TablePrincipal[1]/longitudRegistroPatronal &lt;= 12">
								<nomina12:Emisor
									RegistroPatronal="{TablePrincipal[1]/RegistroPatronal}"
								>
									<xsl:if test="TablePrincipal[1]/EmpresaSNCF!=0">
										<nomina12:EntidadSNCF 
											OrigenRecurso="{TablePrincipal[1]/OrigenRecurso}"
											MontoRecursoPropio="{TablePrincipal[1]/MontoRecursoPropio}"
										/>
									</xsl:if>							
								</nomina12:Emisor>
							</xsl:when>
							<xsl:otherwise>
								<nomina12:Emisor
									Curp="{TablePrincipal[1]/CURPEmisor}"
									RegistroPatronal="{TablePrincipal[1]/RegistroPatronal}"
									RfcPatronOrigen="{TablePrincipal[1]/RFCPatronOrigen}"
								>
									<xsl:if test="TablePrincipal[1]/EmpresaSNCF!=0">
										<nomina12:EntidadSNCF 
											OrigenRecurso="{TablePrincipal[1]/OrigenRecurso}"
											MontoRecursoPropio="{TablePrincipal[1]/MontoRecursoPropio}"
										/>
									</xsl:if>
								</nomina12:Emisor>
							</xsl:otherwise>
						</xsl:choose>
						
						<xsl:element name="nomina12:Receptor">
							<xsl:attribute name="Curp"><xsl:value-of select="TablePrincipal[1]/CURP"/></xsl:attribute>
							<!--No se muestran los siguientes campos para tipos de contrato mayor a 08-->							
							<xsl:if test="TablePrincipal[1]/TipoContrato='01' or TablePrincipal[1]/TipoContrato='02' or TablePrincipal[1]/TipoContrato='03' or TablePrincipal[1]/TipoContrato='04' or TablePrincipal[1]/TipoContrato='05' or TablePrincipal[1]/TipoContrato='06' or TablePrincipal[1]/TipoContrato='07' or TablePrincipal[1]/TipoContrato='08'">
							<xsl:attribute name="NumSeguridadSocial"><xsl:value-of select="TablePrincipal[1]/NumSeguridadSocial"/></xsl:attribute>
							<xsl:attribute name="FechaInicioRelLaboral"><xsl:value-of select="TablePrincipal[1]/FechaInicioRelLaboral"/></xsl:attribute>
							<xsl:attribute name="Antigüedad"><xsl:value-of select="TablePrincipal[1]/Antiguedad"/></xsl:attribute>
								<xsl:attribute name="RiesgoPuesto"><xsl:value-of select="TablePrincipal[1]/RiesgoPuesto"/></xsl:attribute>
								<xsl:attribute name="SalarioDiarioIntegrado"><xsl:value-of select="format-number(TablePrincipal[1]/SalarioDiarioIntegrado,'#0.00')"/></xsl:attribute>
							</xsl:if>		
							<xsl:attribute name="TipoContrato"><xsl:value-of select="TablePrincipal[1]/TipoContrato"/></xsl:attribute>
							<xsl:attribute name="Sindicalizado"><xsl:value-of select="TablePrincipal[1]/Sindicalizado"/></xsl:attribute>
							<xsl:attribute name="TipoJornada"><xsl:value-of select="TablePrincipal[1]/TipoJornada"/></xsl:attribute>

							<xsl:variable name="trabajador" select="TablePrincipal[1]/NumEmpleado"/>
							<xsl:choose>
								<xsl:when test="count(/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]])>0">
									<xsl:attribute name="TipoRegimen">10</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="TipoRegimen"><xsl:value-of select="TablePrincipal[1]/TipoRegimen"/></xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
							
							<xsl:attribute name="NumEmpleado"><xsl:value-of select="TablePrincipal[1]/NumEmpleado"/></xsl:attribute>
							<xsl:attribute name="Departamento"><xsl:value-of select="TablePrincipal[1]/Departamento"/></xsl:attribute>
							<xsl:attribute name="Puesto"><xsl:value-of select="TablePrincipal[1]/Puesto"/></xsl:attribute>
							<xsl:attribute name="RiesgoPuesto"><xsl:value-of select="TablePrincipal[1]/RiesgoPuesto"/></xsl:attribute>
							<xsl:attribute name="PeriodicidadPago"><xsl:value-of select="TablePrincipal[1]/PeriodicidadPago"/></xsl:attribute>
							<xsl:if test="TablePrincipal[1]/Banco!=''">
								<xsl:attribute name="Banco"><xsl:value-of select="TablePrincipal[1]/Banco"/></xsl:attribute>
							</xsl:if>
							<xsl:if test="TablePrincipal[1]/CuentaBancaria!=''">
								<xsl:attribute name="CuentaBancaria"><xsl:value-of select="TablePrincipal[1]/CuentaBancaria"/></xsl:attribute>
							</xsl:if>
							<xsl:attribute name="SalarioBaseCotApor"><xsl:value-of select="format-number(TablePrincipal[1]/SalarioBaseCotApor,'#0.00')"/></xsl:attribute>
							<xsl:attribute name="SalarioDiarioIntegrado"><xsl:value-of select="format-number(TablePrincipal[1]/SalarioDiarioIntegrado,'#0.00')"/></xsl:attribute>
							<xsl:attribute name="ClaveEntFed"><xsl:value-of select="TablePrincipal[1]/ClaveEntFed"/></xsl:attribute>

							<xsl:if test="count(/NewDataSet/TableSubcontratacion)>0">
								<xsl:for-each select = "TableSubcontratacion">
									<nomina12:SubContratacion>
										<xsl:attribute name="RfcLabora"><xsl:value-of select="RfcLabora" /></xsl:attribute>
										<xsl:attribute name="PorcentajeTiempo"><xsl:value-of select="PorcentajeTiempo" /></xsl:attribute>
									</nomina12:SubContratacion>
								</xsl:for-each>
							</xsl:if>
							
						</xsl:element>

						<xsl:if test="TablePrincipal[1]/TotalSueldos!=0 or TablePrincipal[1]/TotalSeparacionIndemnizacion!=0 or TablePrincipal[1]/TotalJubilacionPensionRetiro!=0">
							<nomina12:Percepciones
								TotalSueldos="{TablePrincipal[1]/TotalSueldos}"
								TotalSeparacionIndemnizacion="{TablePrincipal[1]/TotalSeparacionIndemnizacion}"
								TotalJubilacionPensionRetiro="{TablePrincipal[1]/TotalJubilacionPensionRetiro}"
								TotalGravado="{TablePrincipal[1]/TotalGravado}"
								TotalExento="{TablePrincipal[1]/TotalExento}"
							>
								<xsl:for-each select = "TablePrincipal[TipoConceptoSAT=1]">
									<nomina12:Percepcion>
											<xsl:attribute name="TipoPercepcion"><xsl:value-of select="TipoSAT" /></xsl:attribute>
											<xsl:attribute name="Clave"><xsl:value-of select="Clave" /></xsl:attribute>
											<xsl:attribute name="Concepto"><xsl:value-of select="Concepto" /></xsl:attribute>
											<xsl:attribute name="ImporteGravado"><xsl:value-of select="ImporteGravado" /></xsl:attribute>
											<xsl:attribute name="ImporteExento"><xsl:value-of select="ImporteExento" /></xsl:attribute>
											<!--<xsl:attribute name="Tiempo"><xsl:value-of select="tiempo" /></xsl:attribute>-->
										<xsl:if test="TipoSAT='019'">
											<xsl:variable name="claveConcepto" select="Clave"/>
											<xsl:for-each select = "/NewDataSet/TableHorasExtra[Clave=$claveConcepto[1]]">
												<nomina12:HorasExtra>
													<xsl:choose>
														<xsl:when test="Dias=0">
															<xsl:attribute name="Dias">1</xsl:attribute>
														</xsl:when>
														<xsl:otherwise>
															<xsl:attribute name="Dias"><xsl:value-of select="Dias"/></xsl:attribute>
														</xsl:otherwise>
													</xsl:choose>
													<xsl:attribute name="TipoHoras"><xsl:value-of select="TipoHoras" /></xsl:attribute>
													<xsl:choose>
														<xsl:when test="HorasExtra=0">
															<xsl:attribute name="HorasExtra">1</xsl:attribute>
														</xsl:when>
														<xsl:otherwise>
															<xsl:attribute name="HorasExtra"><xsl:value-of select="HorasExtra" /></xsl:attribute>
														</xsl:otherwise>
													</xsl:choose>
													<xsl:attribute name="ImportePagado"><xsl:value-of select="ImportePagado" /></xsl:attribute>
												</nomina12:HorasExtra>
											</xsl:for-each>
										</xsl:if>
										<xsl:if test="TipoSAT='045'">
											<xsl:variable name="trabajador" select="NumEmpleado"/>
											<xsl:for-each select = "/NewDataSet/TableAccionesTitulos[trabajador=$trabajador[1]]">
												<nomina12:AccionesOTitulos>
													<xsl:attribute name="ValorMercado"><xsl:value-of select="ValorMercadoAcciones" /></xsl:attribute>
													<xsl:attribute name="PrecioAlOtorgarse"><xsl:value-of select="PrecioEstTitulosVal" /></xsl:attribute>
												</nomina12:AccionesOTitulos>
											</xsl:for-each>
										</xsl:if>
									</nomina12:Percepcion>
								</xsl:for-each>

								<!--Inicial las tablas adicionales de percepciones-->
								<!--Si hay datos para jubilacionPensionRetiro-->
								<xsl:if test="count(/NewDataSet/TableJubilacionPensionRetiro)>0">
									<!--Solo puede tener de un tipo JubilacionPensionRetiro 039(en una exhibicion) o 044(en parcialidades)-->
									<xsl:if test="/NewDataSet/TablePrincipal[TipoSAT='039']">
										<nomina12:JubilacionPensionRetiro>
											<xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
												<xsl:attribute name="IngresoAcumulable"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoNoAcumulable"><xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="TotalUnaExhibicion"><xsl:value-of select="format-number(TotalUnaExhibicion,'#0.00')"/></xsl:attribute>
											</xsl:for-each>
										</nomina12:JubilacionPensionRetiro>
									</xsl:if>
									<xsl:if test="/NewDataSet/TablePrincipal[TipoSAT='044']">
										<nomina12:JubilacionPensionRetiro>
											<xsl:for-each select = "/NewDataSet/TableJubilacionPensionRetiro">
												<xsl:attribute name="IngresoAcumulable"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoNoAcumulable"><xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="TotalParcialidad"><xsl:value-of select="format-number(TotalParcialidad,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="MontoDiario"><xsl:value-of select="format-number(MontoDiario,'#0.00')"/></xsl:attribute>
											</xsl:for-each>
										</nomina12:JubilacionPensionRetiro>
									</xsl:if>
								</xsl:if>
								
								<!--SeparacionIndemnizacion 022(Prima por Antigüedad) 023(pagos separacion) 025(Indemnizaciones) -->
								<xsl:if test="count(/NewDataSet/TableSeparacionIndemnizacion)>0">
									<xsl:if test="/NewDataSet/TableSeparacionIndemnizacion/TotalPagado!=0">
										<nomina12:SeparacionIndemnizacion>
											<xsl:for-each select = "/NewDataSet/TableSeparacionIndemnizacion">
												<xsl:attribute name="TotalPagado"><xsl:value-of select="format-number(TotalPagado,'#0.00')"/></xsl:attribute>
												
												<xsl:choose>
													<xsl:when test="number(/NewDataSet/TablePrincipal/AntiguedadAnios)>0">
												<xsl:attribute name="NumAñosServicio"><xsl:value-of select="/NewDataSet/TablePrincipal/AntiguedadAnios"/></xsl:attribute>
													</xsl:when>
													<xsl:otherwise>
														<xsl:attribute name="NumAñosServicio">0</xsl:attribute>
													</xsl:otherwise>
												</xsl:choose>
												
												<xsl:attribute name="UltimoSueldoMensOrd"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoAcumulable"><xsl:value-of select="format-number(IngresoAcumulable,'#0.00')"/></xsl:attribute>
												<xsl:attribute name="IngresoNoAcumulable"><xsl:value-of select="format-number(IngresoNoAcumulable,'#0.00')"/></xsl:attribute>
											</xsl:for-each>
										</nomina12:SeparacionIndemnizacion>
									</xsl:if>
								</xsl:if>
							</nomina12:Percepciones>
						</xsl:if>
						
						<xsl:if test="count(TablePrincipal[TipoConceptoSAT=2])>0">
							<xsl:element name="nomina12:Deducciones">
								<xsl:attribute name="TotalOtrasDeducciones"><xsl:value-of select="TablePrincipal[1]/TotalDeducciones"/></xsl:attribute>
								<xsl:if test="TablePrincipal[1]/TotalImpuestosRetenidos>0">
									<xsl:attribute name="TotalImpuestosRetenidos"><xsl:value-of select="TablePrincipal[1]/TotalImpuestosRetenidos"/></xsl:attribute>
								</xsl:if>
								<xsl:for-each select = "TablePrincipal[TipoConceptoSAT=2]">
									<nomina12:Deduccion
										>
											<xsl:attribute name="TipoDeduccion"><xsl:value-of select="TipoSAT"/></xsl:attribute>
											<xsl:attribute name="Clave"><xsl:value-of select="Clave" /></xsl:attribute>
											<xsl:attribute name="Concepto"><xsl:value-of select="Concepto"/></xsl:attribute>
											<xsl:attribute name="Importe"><xsl:value-of select="Importe"/></xsl:attribute>
											<!--<xsl:attribute name="Tiempo"><xsl:value-of select="tiempo"/></xsl:attribute>-->
										</nomina12:Deduccion>
								</xsl:for-each>
							</xsl:element>
						</xsl:if>
					
						<xsl:if test="count(/NewDataSet/TableOtrosPagos)>0">
							<nomina12:OtrosPagos>
								<xsl:for-each select = "TableOtrosPagos">
									<nomina12:OtroPago>
										<xsl:attribute name="TipoOtroPago"><xsl:value-of select="TipoOtroPago"/></xsl:attribute>
										<xsl:attribute name="Clave"><xsl:value-of select="Clave"/></xsl:attribute>
										<xsl:attribute name="Concepto"><xsl:value-of select="Concepto"/></xsl:attribute>
										<xsl:attribute name="Importe"><xsl:value-of select="Importe"/></xsl:attribute>
										
										<xsl:if test="TipoOtroPago='002'">
											<nomina12:SubsidioAlEmpleo
												SubsidioCausado="{SubsidioCausado}"
												>
											</nomina12:SubsidioAlEmpleo>
										</xsl:if>
										
										<xsl:if test="TipoOtroPago='004'">
											<nomina12:CompensacionSaldosAFavor
												SaldoAFavor="{factor_01}"
												Año="{factor_02}"
												RemanenteSalFav="{factor_03}"
												>
											</nomina12:CompensacionSaldosAFavor>
										</xsl:if>
									</nomina12:OtroPago>
								</xsl:for-each>
							</nomina12:OtrosPagos>
						</xsl:if>
						
						<xsl:if test="count(/NewDataSet/TableIncapacidades)>0">
							<nomina12:Incapacidades>
								<xsl:for-each select = "/NewDataSet/TableIncapacidades">
									<nomina12:Incapacidad>
										<xsl:attribute name="DiasIncapacidad"><xsl:value-of select="DiasIncapacidad" /></xsl:attribute>
										<xsl:attribute name="TipoIncapacidad"><xsl:value-of select="TipoIncapacidad" /></xsl:attribute>
										<xsl:attribute name="ImporteMonetario"><xsl:value-of select="Descuento" /></xsl:attribute>
									</nomina12:Incapacidad>
								</xsl:for-each>
							</nomina12:Incapacidades>
						</xsl:if>
					
					</nomina12:Nomina>
				</cfdi:Complemento>
			</cfdi:Comprobante>
	</xsl:template>
</xsl:stylesheet>

﻿namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    public static class LanguageCodes
    {
        public const string Mexico = "es-MX";
        public const string Colombia = "es-CO";
    }
}

using System.Data;
using System.Data.Odbc;
using ADAM.Recibos.Datos.Clases.Common;

namespace ADAM.Recibos.Datos.Clases.CatalogoSAT
{
    public class CatalogoSatOdbc : ICatalogoSat
    {
        private const string ListaCatalogos = "listaCatalogos";
        private const string Descripcion = "descripcion";

        private readonly IDbConnectionFactory _connectionFactory;

        public CatalogoSatOdbc(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public DataSet dsListaCatalogosSAT()
        {
            DataSet ds = new();

            ds.Tables.Add(ListaCatalogos);
            ds.Tables[ListaCatalogos].Columns.Add("id");
            ds.Tables[ListaCatalogos].Columns.Add(Descripcion);

            DataRow renglon = ds.Tables[ListaCatalogos].NewRow();
            renglon["id"] = 1;
            renglon[Descripcion] = "Bancos";
            ds.Tables[ListaCatalogos].Rows.Add(renglon);

            renglon = ds.Tables[ListaCatalogos].NewRow();
            renglon["id"] = 2;
            renglon[Descripcion] = "Tipo Contrato";
            ds.Tables[ListaCatalogos].Rows.Add(renglon);

            renglon = ds.Tables[ListaCatalogos].NewRow();
            renglon["id"] = 3;
            renglon[Descripcion] = "Tipo Regimen";
            ds.Tables[ListaCatalogos].Rows.Add(renglon);

            renglon = ds.Tables[ListaCatalogos].NewRow();
            renglon["id"] = 4;
            renglon[Descripcion] = "Claves Entidad Federativa";
            ds.Tables[ListaCatalogos].Rows.Add(renglon);

            return ds;
        }

        public System.Data.DataSet obtenDatasetCatalogosSAT(string tipo)
        {
            DataSet ds = new();
            ds.Tables.Add();
            ds.Tables[0].Columns.Add("metodo_pago_sat");
            ds.Tables[0].Columns.Add(Descripcion);
            return ds;
        }

        public System.Data.DataSet obtenCatalogoADAM(string tipo, string compania)
        {
            DataSet ds = new();

            ds.Tables.Add();
            ds.Tables[0].Columns.Add("clave");
            ds.Tables[0].Columns.Add(Descripcion);

            return ds;
        }

        public System.Data.DataSet obtenDatasetRelacionCatalogosSATADAM(string tipo, string claveSAT, string compania)
        {
            DataSet ds = new();

            ds.Tables.Add();
            ds.Tables[0].Columns.Add("clave");
            ds.Tables[0].Columns.Add(Descripcion);

            return ds;
        }

        public bool AltaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM)
        {
            return true;
        }

        public bool BajaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM)
        {
            return true;
        }

        public DataSet obtenDatasetCatalogos(string tabla)
        {
            using OdbcConnection odbcConnection = (OdbcConnection)this._connectionFactory.CreateConnection();

            if (odbcConnection.State == ConnectionState.Closed)
                odbcConnection.Open();

            OdbcCommand odbcStmt = new OdbcCommand("SELECT * FROM @table", odbcConnection)
            {
                CommandType = CommandType.Text
            };
            odbcStmt.Parameters.AddWithValue("@table", tabla);

            var odbcAdapter = new OdbcDataAdapter(odbcStmt);
            var dsResult = new DataSet();
            odbcAdapter.Fill(dsResult);

            return dsResult;
        }

    }
}

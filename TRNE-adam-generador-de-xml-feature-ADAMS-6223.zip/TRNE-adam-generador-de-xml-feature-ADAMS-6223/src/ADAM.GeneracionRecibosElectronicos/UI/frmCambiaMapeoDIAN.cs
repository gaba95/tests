using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics.CodeAnalysis;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmCambiaMapeoDIAN : Form
    {
        #region Properties

        private ICatalogoDian _catalogosDIAN;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FrmMapeoCatalogosDIAN FrmMapeoCatalogosDIAN { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string tipo { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string seccion { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string campo { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string claveDian { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string descripcion { get; set; }

        #endregion

        #region Events

        private void FrmCambiaMapeo_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }

        private void cmdCambiar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            GuardaCambio();

            // Actualizar la lista de opciones disponibles
            LlenaComboValoresADAM();

            // Actualiza los datos en el grid para mostrar el valor recien creado
            this.FrmMapeoCatalogosDIAN.LlenaGridEquivalenciasDIAN(compania, campo, claveDian);
            this.Cursor = Cursors.Default;
        }

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Methods

        public FrmCambiaMapeoDIAN()
        {
            InitializeComponent();
        }

        private void InicializaClase()
        {
            lblSeccion.Text = "Sección: " + seccion.Trim();
            lblCampo.Text = "Campo: " + campo.Trim();
            lblClave.Text = "Clave: " + claveDian.Trim();
            lblDesc.Text = "Descripción: " + descripcion.Trim();
            _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            LlenaComboValoresADAM();
        }
        
        private void LlenaComboValoresADAM()
        {
            try
            {
                cboDatoADAM.ValueMember = "clave";
                cboDatoADAM.DisplayMember = "descripcion";
                var dsCatalog = _catalogosDIAN.obtenCatalogoAdamDIAN(campo, compania);
                cboDatoADAM.DataSource = (dsCatalog != null && dsCatalog.Tables.Count > 0 ? dsCatalog.Tables[0] : null);
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }

        }

        private void GuardaCambio()
        {
            try
            {
                // Save Relationship
                _catalogosDIAN.altaRelacionDatoCatalogoDIAN(compania, campo, claveDian, cboDatoADAM.SelectedValue.ToString());
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al guardar el registro, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        #endregion
    }
}

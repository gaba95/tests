﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("primas", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Premiums
    {
        [JsonProperty("cantidad")]
        public Int32 CantidadCantidad { get; set; }

        [JsonProperty("pago")]
        public decimal Pago { get; set; }

        [JsonProperty("pagoNS")]
        public decimal PagoNS { get; set; }

        [JsonIgnore]
        public Decimal Cantidad { get; set; }

        [JsonIgnore]
        public Int32 PagoNSCantidad { get; set; }
    }
}

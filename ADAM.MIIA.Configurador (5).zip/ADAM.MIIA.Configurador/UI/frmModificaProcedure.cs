using ADAM.MIIA.Configuration;
using System.Configuration;
using System.Data;

namespace ADAM.MIIA.Configurador.UI;

public partial class frmModificaProcedure : Form
{
    private bool esNuevoRegistro = false;

    public string tabla { get; set; } = "";
    public string procedure { get; set; } = "";
    public string procedure2 { get; set; } = "";
    public MIIAProceduresSection? MIIAProceduresSection { get; set; }
    public System.Configuration.Configuration? config { get; set; }
    public frmConfiguracion? frmPadre { get; set; }

    public frmModificaProcedure()
    {
        InitializeComponent();
    }

    private void frmModificaProcedure_Load(object? sender, EventArgs e)
    {
        if (tabla.Trim() != "")
        {
            CargaValoresActuales();
            esNuevoRegistro = false;
            txtTabla.ReadOnly = true;
        }
        else
        {
            esNuevoRegistro = true;
            txtTabla.ReadOnly = false;
        }
        AplicarEstiloRetro(this);
    }

    private void txtTabla_Leave(object? sender, EventArgs e)
    {
        txtTabla.Text = txtTabla.Text.ToUpper();
    }

    private void cmdAceptar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        if (GuardarProcedure(txtTabla.Text.Trim()))
        {
            DialogResult = DialogResult.OK;
            Close();
        }
        else
        {
            DialogResult = DialogResult.None;
        }
    }

    private void CargaValoresActuales()
    {
        txtTabla.Text = tabla;
        txtProcedure.Text = procedure;
        txtProcedure2.Text = procedure2;
    }

    private bool GuardarProcedure(string tabla)
    {
        try
        {
            if (!Validar())
                return false;

            if (esNuevoRegistro)
            {
                var nuevoProcedure = new ProcedureMIIA();
                nuevoProcedure.ProcedureMIIAProp = txtTabla.Text;
                nuevoProcedure.Procedimiento = txtProcedure.Text;
                nuevoProcedure.Procedimiento2 = txtProcedure2.Text;
                MIIAProceduresSection!.Procedures.Add(nuevoProcedure);
            }
            else
            {
                var existingProc = MIIAProceduresSection!.Procedures[tabla];
                if (existingProc != null)
                {
                    existingProc.Procedimiento = txtProcedure.Text;
                    existingProc.Procedimiento2 = txtProcedure2.Text;
                }
            }

            config!.Save();
            frmPadre!.llenaGridProcedures();
            return true;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    private bool Validar()
    {
        string tablaNueva = txtTabla.Text;

        if (esNuevoRegistro)
        {
            foreach (ProcedureMIIA proc in MIIAProceduresSection!.Procedures)
            {
                if (proc.ProcedureMIIAProp == tablaNueva)
                {
                    UIHelper.ShowMessage("La tabla que esta intentando ingresar ya existe", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtTabla.Focus();
                    return false;
                }
            }
        }

        if (txtTabla.Text.Trim() == string.Empty)
        {
            txtTabla.Focus();
            UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        if (txtProcedure.Text.Trim() == string.Empty)
        {
            txtProcedure.Focus();
            UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        return true;
    }
    private void AplicarEstiloRetro(Control parent)
    {
        foreach (Control ctrl in parent.Controls)
        {
            if (ctrl is Button btn)
            {
                btn.FlatStyle = FlatStyle.Flat;

                btn.BackColor = Color.FromArgb(227, 237, 239);

                btn.ForeColor = Color.Black;

                btn.Font = new Font("Tahoma", 8.25f);

                btn.FlatAppearance.BorderSize = 0;

                btn.Paint += RetroPaint;
            }
            if (ctrl is TextBox txt)
            {
                if (txt.ReadOnly || !txt.Enabled)
                {
                    AplicarEstiloRetroTextBoxBloqueado(txt);
                }
                else
                {
                    AplicarEstiloRetroTextBox(txt);
                }
            }
            if (ctrl is ComboBox cmb)
            {
                if (!cmb.Enabled)
                {
                    AplicarEstiloRetroComboBoxBloqueado(cmb);
                }
                else
                {
                    AplicarEstiloRetroComboBox(cmb);
                }


            }
            if (ctrl is TabControl tab)
            {
                AplicarEstiloRetroTabControl(tab);
            }

            AplicarEstiloRetro(ctrl);
        }
    }
    private void RetroPaint(object? sender, PaintEventArgs e)
    {
        Button btn = (Button)sender!;

        Rectangle rect = btn.ClientRectangle;

        Color light = Color.White;
        Color dark = Color.Gray;

        e.Graphics.FillRectangle(
            new SolidBrush(Color.FromArgb(227, 237, 239)),
            rect);

        e.Graphics.DrawLine(
            new Pen(light),
            0,
            0,
            rect.Width - 1,
            0);

        e.Graphics.DrawLine(
            new Pen(light),
            0,
            0,
            0,
            rect.Height - 1);

        e.Graphics.DrawLine(
            new Pen(dark),
            0,
            rect.Height - 1,
            rect.Width - 1,
            rect.Height - 1);

        e.Graphics.DrawLine(
            new Pen(dark),
            rect.Width - 1,
            0,
            rect.Width - 1,
            rect.Height - 1);

        TextRenderer.DrawText(
            e.Graphics,
            btn.Text,
            btn.Font,
            rect,
            Color.Black,
            TextFormatFlags.HorizontalCenter |
            TextFormatFlags.VerticalCenter |
            TextFormatFlags.WordBreak);
    }
    private void AplicarEstiloRetroTextBox(TextBox txt)
    {
        if (txt.Parent == null)
            return;

        Control parent = txt.Parent;

        Panel panel = new Panel();

        panel.Location = new Point(txt.Left - 2, txt.Top - 2);

        panel.Size = new Size(txt.Width + 4, txt.Height + 4);

        panel.Anchor = txt.Anchor;

        panel.BackColor = Color.White;

        panel.ForeColor = Color.Black;

        panel.Paint += (s, e) =>
        {
            Rectangle r = panel.ClientRectangle;

            // negro exterior
            e.Graphics.DrawLine(Pens.Black, 0, 0, r.Width - 1, 0);
            e.Graphics.DrawLine(Pens.Black, 0, 0, 0, r.Height - 1);

            // gris interior
            e.Graphics.DrawLine(Pens.Gray, 1, 1, r.Width - 2, 1);
            e.Graphics.DrawLine(Pens.Gray, 1, 1, 1, r.Height - 2);

            // línea clara fina abajo
            e.Graphics.DrawLine(
                Pens.White,
                1,
                r.Height - 1,
                r.Width - 1,
                r.Height - 1);

            // línea clara fina derecha
            e.Graphics.DrawLine(
                Pens.White,
                r.Width - 1,
                1,
                r.Width - 1,
                r.Height - 1);
        };

        txt.BorderStyle = BorderStyle.None;

        txt.Location = new Point(3, 3);

        txt.Width = panel.Width - 6;

        txt.BackColor = Color.White;

        txt.Font = new Font("Tahoma", 8.25f);

        parent.Controls.Add(panel);

        panel.Controls.Add(txt);

        panel.BringToFront();
    }
    private void AplicarEstiloRetroTextBoxBloqueado(TextBox txt)
    {
        if (txt.Parent == null)
            return;

        Control parent = txt.Parent;

        Panel panel = new Panel();

        panel.Location = new Point(txt.Left - 2, txt.Top - 2);

        panel.Size = new Size(txt.Width + 4, txt.Height + 4);

        panel.Anchor = txt.Anchor;

        panel.BackColor = Color.FromArgb(212, 208, 200);

        panel.ForeColor = SystemColors.ControlDarkDark;

        panel.Paint += (s, e) =>
        {
            Rectangle r = panel.ClientRectangle;

            // negro exterior
            e.Graphics.DrawLine(Pens.Black, 0, 0, r.Width - 1, 0);
            e.Graphics.DrawLine(Pens.Black, 0, 0, 0, r.Height - 1);

            // gris interior
            e.Graphics.DrawLine(Pens.Gray, 1, 1, r.Width - 2, 1);
            e.Graphics.DrawLine(Pens.Gray, 1, 1, 1, r.Height - 2);

            // línea clara fina abajo
            e.Graphics.DrawLine(
                Pens.White,
                1,
                r.Height - 1,
                r.Width - 1,
                r.Height - 1);

            // línea clara fina derecha
            e.Graphics.DrawLine(
                Pens.White,
                r.Width - 1,
                1,
                r.Width - 1,
                r.Height - 1);
        };

        txt.BorderStyle = BorderStyle.None;

        txt.Location = new Point(3, 3);

        txt.Width = panel.Width - 6;

        txt.Font = new Font("Tahoma", 8.25f);

        parent.Controls.Add(panel);

        panel.Controls.Add(txt);

        panel.BringToFront();
        txt.BorderStyle = BorderStyle.None;

        txt.Multiline = true;

        txt.Location = new Point(3, 4);

        txt.Width = panel.Width - 7;

        txt.Height = panel.Height - 7;

        txt.Font = new Font("Tahoma", 8.25f);
    }
    private void AplicarEstiloRetroComboBox(ComboBox cbo)
    {
        cbo.FlatStyle = FlatStyle.Flat;

        cbo.BackColor = SystemColors.Window;

        cbo.ForeColor = Color.Black;

        cbo.Font = new Font("Tahoma", 8.25f);

        cbo.DrawMode = DrawMode.OwnerDrawFixed;

        cbo.DropDownStyle = ComboBoxStyle.DropDownList;

        cbo.ItemHeight = 18;

        cbo.DrawItem -= RetroComboBox_DrawItem;
        cbo.DrawItem += RetroComboBox_DrawItem;

        CrearPanelRetroCombo(cbo, false);
    }

    private void AplicarEstiloRetroComboBoxBloqueado(ComboBox cbo)
    {
        cbo.FlatStyle = FlatStyle.Flat;

        cbo.BackColor = SystemColors.Control;

        cbo.ForeColor = SystemColors.GrayText;

        cbo.Font = new Font("Tahoma", 8.25f);

        cbo.DrawMode = DrawMode.OwnerDrawFixed;

        cbo.DropDownStyle = ComboBoxStyle.DropDownList;

        cbo.ItemHeight = 18;

        cbo.DrawItem -= RetroComboBox_DrawItem;
        cbo.DrawItem += RetroComboBox_DrawItem;

        CrearPanelRetroCombo(cbo, true);
    }

    private void CrearPanelRetroCombo(ComboBox cbo, bool bloqueado)
    {
        if (cbo.Parent == null)
            return;

        // evitar aplicar dos veces
        if (cbo.Tag?.ToString() == "RETRO")
            return;

        cbo.Tag = "RETRO";

        Control parent = cbo.Parent;

        Panel panel = new Panel();

        panel.Location = new Point(cbo.Left - 2, cbo.Top - 2);

        panel.Size = new Size(cbo.Width + 4, cbo.Height + 4);

        panel.Anchor = cbo.Anchor;

        panel.BackColor = bloqueado
            ? SystemColors.Control
            : SystemColors.Window;

        panel.Paint += (s, e) =>
        {
            Rectangle r = panel.ClientRectangle;

            r.Width -= 1;
            r.Height -= 1;

            // negro arriba
            e.Graphics.DrawLine(
                Pens.Black,
                0,
                0,
                r.Width,
                0);

            // negro izquierda
            e.Graphics.DrawLine(
                Pens.Black,
                0,
                0,
                0,
                r.Height);

            // gris interior arriba
            e.Graphics.DrawLine(
                Pens.Gray,
                1,
                1,
                r.Width - 1,
                1);

            // gris interior izquierda
            e.Graphics.DrawLine(
                Pens.Gray,
                1,
                1,
                1,
                r.Height - 1);

            // línea blanca fina abajo
            e.Graphics.DrawLine(
                Pens.White,
                1,
                r.Height,
                r.Width,
                r.Height);

            // línea blanca fina derecha
            e.Graphics.DrawLine(
                Pens.White,
                r.Width,
                1,
                r.Width,
                r.Height);
        };

        parent.Controls.Add(panel);

        panel.Controls.Add(cbo);

        cbo.Location = new Point(2, 2);

        cbo.Width = panel.Width - 4;

        cbo.Height = panel.Height - 4;

        // IMPORTANTÍSIMO
        cbo.FlatStyle = FlatStyle.Popup;

        panel.BringToFront();
    }

    private void RetroComboBox_DrawItem(object? sender, DrawItemEventArgs e)
    {
        ComboBox cbo = (ComboBox)sender!;

        e.DrawBackground();

        if (e.Index >= 0)
        {
            string text = "";

            object item = cbo.Items[e.Index];

            // soporte para DataTable/DataSource
            if (item is DataRowView rowView)
            {
                text = rowView[cbo.DisplayMember]?.ToString() ?? "";
            }
            else
            {
                text = item?.ToString() ?? "";
            }

            Color backColor;
            Color textColor;

            if (!cbo.Enabled)
            {
                backColor = SystemColors.Control;

                textColor = SystemColors.GrayText;
            }
            else if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                backColor = SystemColors.Highlight;

                textColor = SystemColors.HighlightText;
            }
            else
            {
                backColor = SystemColors.Window;

                textColor = Color.Black;
            }

            using SolidBrush backBrush = new SolidBrush(backColor);

            e.Graphics.FillRectangle(backBrush, e.Bounds);

            TextRenderer.DrawText(
                e.Graphics,
                text,
                cbo.Font,
                e.Bounds,
                textColor,
                TextFormatFlags.Left |
                TextFormatFlags.VerticalCenter);
        }

        e.DrawFocusRectangle();
    }

    private void RefrescarControlesRetro(Control parent)
    {
        foreach (Control ctrl in parent.Controls)
        {
            // COMBOBOX
            if (ctrl is ComboBox cbo)
            {
                if (cbo.Enabled)
                {
                    cbo.BackColor = SystemColors.Window;

                    cbo.ForeColor = Color.Black;
                }
                else
                {
                    cbo.BackColor = SystemColors.Control;

                    cbo.ForeColor = SystemColors.GrayText;
                }

                if (cbo.Parent is Panel pnl)
                {
                    pnl.BackColor = cbo.Enabled
                        ? SystemColors.Window
                        : SystemColors.Control;

                    pnl.Invalidate();

                    pnl.Refresh();
                }

                cbo.Invalidate();

                cbo.Refresh();
            }

            // TEXTBOX
            if (ctrl is TextBox txt)
            {
                if (txt.Enabled && !txt.ReadOnly)
                {
                    txt.BackColor = SystemColors.Window;

                    txt.ForeColor = Color.Black;
                }
                else
                {
                    txt.BackColor = SystemColors.Control;

                    txt.ForeColor = SystemColors.GrayText;
                }

                txt.Invalidate();

                txt.Refresh();

                txt.Parent?.Invalidate();
            }

            RefrescarControlesRetro(ctrl);
        }
    }
    private void AplicarEstiloRetroTabControl(TabControl tab)
    {
        tab.DrawMode = TabDrawMode.OwnerDrawFixed;

        tab.SizeMode = TabSizeMode.Normal;

        tab.Font = new Font("Tahoma", 8.25f);

        tab.Padding = new Point(12, 4);

        tab.Appearance = TabAppearance.Normal;

        tab.DrawItem -= RetroTab_DrawItem;
        tab.DrawItem += RetroTab_DrawItem;

        foreach (TabPage page in tab.TabPages)
        {
            // mismo color del formulario
            page.BackColor = this.BackColor;

            page.ForeColor = Color.Black;
        }
    }

    private void RetroTab_DrawItem(object? sender, DrawItemEventArgs e)
    {
        TabControl tab = (TabControl)sender!;

        Graphics g = e.Graphics;

        TabPage page = tab.TabPages[e.Index];

        Rectangle rect = tab.GetTabRect(e.Index);

        // mismo color para todas
        Color backColor = SystemColors.Control;

        using SolidBrush brush = new SolidBrush(backColor);

        g.FillRectangle(brush, rect);

        // borde claro arriba
        g.DrawLine(
            Pens.White,
            rect.Left,
            rect.Bottom,
            rect.Left,
            rect.Top);

        g.DrawLine(
            Pens.White,
            rect.Left,
            rect.Top,
            rect.Right,
            rect.Top);

        // borde oscuro derecha
        g.DrawLine(
            Pens.Gray,
            rect.Right,
            rect.Top,
            rect.Right,
            rect.Bottom);

        // borde oscuro abajo
        g.DrawLine(
            Pens.Gray,
            rect.Left,
            rect.Bottom,
            rect.Right,
            rect.Bottom);

        // texto
        Rectangle textRect = rect;

        textRect.Y += 2;

        TextRenderer.DrawText(
            g,
            page.Text,
            tab.Font,
            textRect,
            Color.Black,
            TextFormatFlags.HorizontalCenter |
            TextFormatFlags.VerticalCenter);
    }
}

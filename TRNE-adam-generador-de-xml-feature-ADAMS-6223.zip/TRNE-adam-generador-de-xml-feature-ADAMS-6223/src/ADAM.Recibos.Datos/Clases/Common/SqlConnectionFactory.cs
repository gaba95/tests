﻿using System.Data;
using Microsoft.Data.SqlClient;
using System.Configuration;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos.Clases.Common
{
    public class SqlConnectionFactory : IDbConnectionFactory
    {
        #region Members 

        protected ApplicationSettingsBase _appSettings;
        protected string _applicationUser;

        #endregion

        #region Properties 

        public string ApplicationUser
        {
            get
            {
                return _applicationUser.Replace("-", "_");
            }
        }

        #endregion

        #region Methods

        public SqlConnectionFactory(ApplicationSettingsBase appSettings) 
        {
            this._appSettings = appSettings;
        }

        private string BuildConnectionString()
        {
            this._applicationUser = _appSettings[ConfigParameters.applicationUser.ToString()].ToString();

            return _appSettings[ConfigParameters.version.ToString()] switch
            {
                "5" => new SqlConnectionStringBuilder
                {
                    DataSource = _appSettings[ConfigParameters.server.ToString()].ToString(),
                    InitialCatalog = _appSettings[ConfigParameters.database.ToString()].ToString(),
                    UserID = _appSettings[ConfigParameters.user.ToString()].ToString(),
                    Password = _appSettings[ConfigParameters.password.ToString()].ToString(),
                    MultipleActiveResultSets = true,
                    TrustServerCertificate = true,
                    MinPoolSize = 10,
                    MaxPoolSize = (Environment.ProcessorCount - 1) * 60,
                    ConnectTimeout = 600
                }.ConnectionString,
                "3" => new SqlConnectionStringBuilder
                {
                    DataSource = _appSettings[ConfigParameters.server.ToString()].ToString(),
                    InitialCatalog = _appSettings[ConfigParameters.database.ToString()].ToString(),
                    UserID = _appSettings[ConfigParameters.user.ToString()].ToString(),
                    Password = _appSettings[ConfigParameters.password.ToString()].ToString(),
                    MultipleActiveResultSets = true,
                    TrustServerCertificate = true,
                    ConnectTimeout = 600
                }.ConnectionString,
                _ => string.Empty,
            };
        }

        public IDbConnection CreateConnection()
        {
            try
            {
                return _appSettings[ConfigParameters.version.ToString()] switch
                {
                    "5" or "3" => new SqlConnection(BuildConnectionString()),
                    _ => null,
                };
            }
            catch (SqlException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public bool CheckConnection()
        {
            using (SqlConnection sqlConnection = (SqlConnection)CreateConnection())
            {
                try
                {
                    sqlConnection.Open();
                    return true;
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"CheckConnection failed: {ex.Message}");
                    return false;
                }
            }

        }
        #endregion 
    }
}

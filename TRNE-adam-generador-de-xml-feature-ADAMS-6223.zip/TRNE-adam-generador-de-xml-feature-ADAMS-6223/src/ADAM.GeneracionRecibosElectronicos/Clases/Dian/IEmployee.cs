﻿using ADAM.GeneracionRecibosElectronicos.Enums;
using System.Collections.Generic;
using System.Data;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    /// <summary>
    /// contract for any Employee class
    /// </summary>
    public interface IEmployee
    {
        string employeeId { get; set; }

        bool altoRiesgoPension { get; set; }
        decimal comprobanteTotal { get; set; }
        Deductions deducciones { get; set; }
        decimal deduccionesTotal { get; set; }
        Perceptions devengados { get; set; }
        decimal devengadosTotal { get; set; }
        string emailTrabajador { get; set; }
        string fechaIngreso { get; set; }
        string fechaRetiro { get; set; }
        List<PaymentDates> fechasPago { get; set; }
        PredecessorInformation informacionPredecesor { get; set; }
        PlaceGenerationXML lugarGeneracionXML { get; set; }
        string lugarTrabajoDepartamentoEstado { get; set; }
        string lugarTrabajoDireccion { get; set; }
        string lugarTrabajoMunicipioCiudad { get; set; }
        string lugarTrabajoPais { get; set; }
        string notas { get; set; }
        string numeroDocumento { get; set; }
        XMLSequenceNumber numeroSecuenciaXML { get; set; }
        string otrosNombres { get; set; }
        Payment pago { get; set; }
        string primerApellido { get; set; }
        string primerNombre { get; set; }
        decimal redondeo { get; set; }
        bool salarioIntegral { get; set; }
        string segundoApellido { get; set; }
        string subtipoTrabajador { get; set; }
        decimal sueldo { get; set; }
        int tiempoLaborado { get; set; }
        int tipoContrato { get; set; }
        string tipoDocumento { get; set; }
        string tipoMoneda { get; set; }
        string tipoTrabajador { get; set; }
        decimal trm { get; set; }
        string nombreCompleto { get;  }
        string respuestaDianMessage { get;  }
        string codigoMensajeDian { get; }
        string respuestaDianEstatus { get;  }
    }
}
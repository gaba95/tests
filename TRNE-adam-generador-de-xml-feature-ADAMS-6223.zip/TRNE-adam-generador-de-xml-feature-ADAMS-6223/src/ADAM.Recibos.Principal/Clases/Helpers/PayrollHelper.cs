﻿using System;
using System.Data;
using System.Xml;

namespace ADAM.Recibos.Principal.Clases
{
    public  class PayrollHelper
    {
        public static string InsertaIncapacidadesRecibo(string recibo, DataTable incapacidades)
        {
            try
            {
                //Obtiene el XML de la cadena
                XmlDocument docRecibo = new XmlDocument();
                docRecibo.LoadXml(recibo);

                //Establece el elemento a modificar
                XmlElement elemento = (XmlElement)docRecibo.GetElementsByTagName("Nomina", "http://www.sat.gob.mx/nomina")[0];

                //201410 Se agrega el elemento padre
                XmlNode nodoPadreIncapacidad;
                nodoPadreIncapacidad = docRecibo.CreateNode(XmlNodeType.Element, "nomina:Incapacidades", "http://www.sat.gob.mx/nomina");

                //Agrega el nodo Padre de incapacidades al elemento principal
                elemento.AppendChild(nodoPadreIncapacidad);

                //Establece el elemento a modificar
                XmlElement elementoIncapacidades = (XmlElement)docRecibo.GetElementsByTagName("Incapacidades", "http://www.sat.gob.mx/nomina")[0];

                //Por cada registro se agrega el valor correspondiente
                foreach (DataRow renglon in incapacidades.Rows)
                {
                    XmlNode nodo;
                    nodo = docRecibo.CreateNode(XmlNodeType.Element, "nomina:Incapacidad", "http://www.sat.gob.mx/nomina");

                    XmlAttribute DiasIncapacidad = docRecibo.CreateAttribute("DiasIncapacidad");
                    DiasIncapacidad.Value = renglon["DiasIncapacidad"].ToString();

                    XmlAttribute TipoIncapacidad = docRecibo.CreateAttribute("TipoIncapacidad");
                    TipoIncapacidad.Value = renglon["TipoIncapacidad"].ToString();

                    XmlAttribute Descuento = docRecibo.CreateAttribute("Descuento");
                    Descuento.Value = renglon["Descuento"].ToString();

                    nodo.Attributes.Append(DiasIncapacidad);
                    nodo.Attributes.Append(TipoIncapacidad);
                    nodo.Attributes.Append(Descuento);

                    elementoIncapacidades.AppendChild(nodo);
                }

                return docRecibo.OuterXml;
            }
            catch
            {
                return recibo;
            }
        }

        public static string InsertaHorasExtraRecibo(string recibo, DataTable horasExtra)
        {
            try
            {
                // Obtiene el XML de la cadena
                XmlDocument docRecibo = new XmlDocument();
                docRecibo.LoadXml(recibo);

                // Establece el elemento a modificar
                XmlElement elemento = (XmlElement)docRecibo.GetElementsByTagName("Nomina", "http://www.sat.gob.mx/nomina")[0];

                // 201410 Se agrega el elemento padre
                XmlNode nodoPadreHorasExtra;
                nodoPadreHorasExtra = docRecibo.CreateNode(XmlNodeType.Element, "nomina:HorasExtras", "http://www.sat.gob.mx/nomina");

                // Agrega el nodo Padre de incapacidades al elemento principal
                elemento.AppendChild(nodoPadreHorasExtra);

                // Establece el elemento a modificar
                XmlElement elementoHorasExtra = (XmlElement)docRecibo.GetElementsByTagName("HorasExtras", "http://www.sat.gob.mx/nomina")[0];

                // Por cada registro se agrega el valor correspondiente
                foreach (DataRow renglon in horasExtra.Rows)
                {
                    XmlNode nodo;
                    nodo = docRecibo.CreateNode(XmlNodeType.Element, "nomina:HorasExtra", "http://www.sat.gob.mx/nomina");

                    XmlAttribute Dias = docRecibo.CreateAttribute("Dias");
                    Dias.Value = renglon["Dias"].ToString();

                    XmlAttribute TipoHoras = docRecibo.CreateAttribute("TipoHoras");
                    TipoHoras.Value = renglon["TipoHoras"].ToString();

                    XmlAttribute HorasExtra = docRecibo.CreateAttribute("HorasExtra");
                    HorasExtra.Value = renglon["HorasExtra"].ToString();

                    XmlAttribute ImportePagado = docRecibo.CreateAttribute("ImportePagado");
                    ImportePagado.Value = renglon["ImportePagado"].ToString();

                    nodo.Attributes.Append(Dias);
                    nodo.Attributes.Append(TipoHoras);
                    nodo.Attributes.Append(HorasExtra);
                    nodo.Attributes.Append(ImportePagado);

                    elementoHorasExtra.AppendChild(nodo);
                }

                // Default
                return docRecibo.OuterXml;
            }
            catch
            {
                return recibo;
            }
        }

        public static string InsertaAdicionales(string recibo, DataTable tablaAdicionales, string XSDValidacion)
        {
            try
            {
                // Obtiene el Xml de la cadena
                XmlDocument docRecibo = new XmlDocument();
                docRecibo.LoadXml(recibo);

                XmlElement elemento;
                XmlNode nodoPadre;

                // Establece el elemento a modificar
                if (XSDValidacion.Contains("12"))
                {
                    elemento = (XmlElement)docRecibo.GetElementsByTagName("Nomina", "http://www.sat.gob.mx/nomina12")[0];

                    // Agrega el Elemento Padre
                    nodoPadre = docRecibo.CreateNode(XmlNodeType.Element, "nomina:Adicionales", "http://www.sat.gob.mx/nomina12");
                }
                else
                {
                    elemento = (XmlElement)docRecibo.GetElementsByTagName("Nomina", "http://www.sat.gob.mx/nomina")[0];

                    // Agrega el Elemento Padre
                    nodoPadre = docRecibo.CreateNode(XmlNodeType.Element, "nomina:Adicionales", "http://www.sat.gob.mx/nomina");
                }

                elemento.AppendChild(nodoPadre);

                // Valida si existe el campo "tipo_registo"
                var contieneTipoRegistro = false;
                foreach (DataColumn columna in tablaAdicionales.Columns)
                {
                    if (columna.ColumnName.Trim() == "tipo_registro")
                    {
                        contieneTipoRegistro = true;
                        break;
                    }
                }

                // Por cada registro se agrega el valor correspondiente
                foreach (DataRow renglon in tablaAdicionales.Rows)
                {
                    if (contieneTipoRegistro)
                    {
                        XmlNode nodo;

                        string nombreElemento;
                        switch (renglon["tipo_checada"].ToString())
                        {
                            case "1_entradas":
                                nombreElemento = "nomina:Adicional02";
                                break;
                            case "2_salidas":
                                nombreElemento = "nomina:Adicional03";
                                break;
                            case "3_horas":
                                nombreElemento = "nomina:Adicional04";
                                break;
                            case "4_horas_extra":
                                nombreElemento = "nomina:Adicional05";
                                break;
                            case "6_retardos":
                                nombreElemento = "nomina:Adicional06";
                                break;
                            case "7_salidas_temprano":
                                nombreElemento = "nomina:Adicional07";
                                break;
                            default:
                                nombreElemento = "nomina:Adicional01";
                                break;
                        }

                        if (XSDValidacion.Contains("12"))
                        {
                            nodo = docRecibo.CreateNode(XmlNodeType.Element, nombreElemento, "http://www.sat.gob.mx/nomina12");
                        }
                        else
                        {
                            nodo = docRecibo.CreateNode(XmlNodeType.Element, nombreElemento, "http://www.sat.gob.mx/nomina");
                        }

                        // Las columnas se generan de forma dinamica de acuerdo a los datos del dataset
                        foreach (DataColumn columna in tablaAdicionales.Columns)
                        {
                            if (renglon["tipo_checada"].ToString().Trim() == string.Empty)
                            {
                                if (columna.ColumnName != "tipo_registro" && columna.ColumnName != "tipo_checada" && columna.ColumnName != "campo_05" && columna.ColumnName != "campo_06" && columna.ColumnName != "campo_07")
                                {
                                    XmlAttribute atributo = docRecibo.CreateAttribute(columna.ColumnName);
                                    atributo.Value = renglon[columna.ColumnName].ToString();
                                    nodo.Attributes.Append(atributo);
                                }
                            }
                            else
                            {
                                if (columna.ColumnName != "tipo_registro" && columna.ColumnName != "tipo_checada")
                                {
                                    XmlAttribute atributo = docRecibo.CreateAttribute(columna.ColumnName);
                                    atributo.Value = renglon[columna.ColumnName].ToString();
                                    nodo.Attributes.Append(atributo);
                                }
                            }

                        }

                        nodoPadre.AppendChild(nodo);
                    }
                    else
                    {
                        XmlNode nodo;

                        if (XSDValidacion.Contains("12"))
                        {
                            nodo = docRecibo.CreateNode(XmlNodeType.Element, "nomina:Adicional", "http://www.sat.gob.mx/nomina12");
                        }
                        else
                        {
                            nodo = docRecibo.CreateNode(XmlNodeType.Element, "nomina:Adicional", "http://www.sat.gob.mx/nomina");
                        }

                        // Las columnas se generan de forma dinamica de acuerdo a los datos del dataset
                        foreach (DataColumn columna in tablaAdicionales.Columns)
                        {
                            XmlAttribute atributo = docRecibo.CreateAttribute(columna.ColumnName);
                            atributo.Value = renglon[columna.ColumnName].ToString();
                            nodo.Attributes.Append(atributo);
                        }

                        nodoPadre.AppendChild(nodo);
                    }

                }

                return docRecibo.OuterXml;

            }
            catch
            {
                return recibo;
            }
        }

        public static string InsertaNodoTimbradoRelacionado(string recibo)
        {
            try
            {
                // Obtiene el XML de la cadena
                XmlDocument docRecibo = new XmlDocument();
                docRecibo.LoadXml(recibo);

                // Establece el elemento a modificar
                XmlElement elemento = (XmlElement)docRecibo.GetElementsByTagName("Comprobante", "http://www.sat.gob.mx/cfd/3")[0];

                // 201804 Se agrega el elemento padre
                XmlNode nodoCfdiRelacionados;
                nodoCfdiRelacionados = docRecibo.CreateNode(XmlNodeType.Element, "cfdi:CfdiRelacionados", "http://www.sat.gob.mx/cfd/3");

                // Agrega el nodo Padre al elemento principal
                elemento.AppendChild(nodoCfdiRelacionados);

                // Se crea el atributo de tipo relacion
                XmlAttribute atributoTipoRelacion = docRecibo.CreateAttribute("TipoRelacion");
                atributoTipoRelacion.Value = "04";

                nodoCfdiRelacionados.Attributes.Append(atributoTipoRelacion);

                // Nodo hijo
                XmlNode nodoCfdiRelacionado;
                nodoCfdiRelacionado = docRecibo.CreateNode(XmlNodeType.Element, "cfdi:CfdiRelacionado", "http://www.sat.gob.mx/cfd/3");

                // Agregar el nodo al principal
                nodoCfdiRelacionados.AppendChild(nodoCfdiRelacionado);

                // Atributo UUID
                XmlAttribute atributoUUID = docRecibo.CreateAttribute("UUID");
                atributoUUID.Value = "";
                nodoCfdiRelacionado.Attributes.Append(atributoUUID);

                return docRecibo.OuterXml;
            }
            catch
            {
                return recibo;
            }
        }
    }
}

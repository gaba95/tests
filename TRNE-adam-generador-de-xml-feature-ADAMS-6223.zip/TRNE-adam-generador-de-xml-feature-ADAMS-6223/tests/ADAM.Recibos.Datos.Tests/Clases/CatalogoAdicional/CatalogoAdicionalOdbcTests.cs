using System.Data;
using System.Data.Odbc;
using System.Reflection;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;
using Moq;

namespace ADAM.Recibos.Datos.Tests.Clases.CatalogoAdicional;

[TestClass]
public class CatalogoAdicionalOdbcTests
{
    #region Helpers

    private static CatalogoAdicionalOdbc CreateServiceWithMockDB(Mock<IDbConnectionFactory>? mockFactory = null)
    {
        mockFactory ??= new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
        mockFactory.Setup(f => f.CheckConnection()).Returns(true);
        return new CatalogoAdicionalOdbc(mockFactory.Object);
    }

    private static (CatalogoAdicionalOdbc service, Mock<IDbConnectionFactory> mockFactory) CreateServiceWithRealOdbcConnection()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        var callCount = 0;
        mockFactory.Setup(f => f.CreateConnection()).Returns(() =>
        {
            callCount++;
            if (callCount == 1)
                return Mock.Of<IDbConnection>();
            return new OdbcConnection("DSN=FakeNonExistentDSN_12345;");
        });
        mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");

        var service = new CatalogoAdicionalOdbc(mockFactory.Object);
        return (service, mockFactory);
    }

    #endregion

    #region Constructor

    [TestMethod]
    public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());

        var service = new CatalogoAdicionalOdbc(mockFactory.Object);

        Assert.IsNotNull(service);
        mockFactory.Verify(f => f.CreateConnection(), Times.Once);
    }

    #endregion

    #region CheckDbConnection

    [TestMethod]
    public void CheckDbConnection_ShouldReturnTrue_WhenFactoryReturnsTrue()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.CheckConnection()).Returns(true);

        var service = new CatalogoAdicionalOdbc(mockFactory.Object);

        Assert.IsTrue(service.CheckDbConnection());
    }

    [TestMethod]
    public void CheckDbConnection_ShouldReturnFalse_WhenFactoryReturnsFalse()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.CheckConnection()).Returns(false);

        var service = new CatalogoAdicionalOdbc(mockFactory.Object);

        Assert.IsFalse(service.CheckDbConnection());
    }

    #endregion

    #region Structure / Reflection

    [TestMethod]
    public void ClassShouldImplementInterface_ICatalogoAdicional()
    {
        Assert.IsTrue(typeof(ICatalogoAdicional).IsAssignableFrom(typeof(CatalogoAdicionalOdbc)));
    }

    [TestMethod]
    [DataRow("CheckDbConnection")]
    [DataRow("obtenCompaniasIdiomas")]
    [DataRow("obtenDatasetTrabajadoresRecibo")]
    [DataRow("obtenDatasetCompanias")]
    [DataRow("obtenDatasetClasesNomina")]
    [DataRow("obtenDatasetTiposNomina")]
    [DataRow("obtenDatasetFormaPago")]
    [DataRow("obtenBasesDisponibles")]
    [DataRow("obtenListaPeriodosMes")]
    [DataRow("obtenDatasetTiposPercepcionDeduccion")]
    [DataRow("obtenDatasetDescripcionTipos")]
    [DataRow("obtenDatasetRelacionConceptos")]
    [DataRow("obtenDatasetConceptosRelacionar")]
    [DataRow("AltaRelacionConcepto")]
    [DataRow("BajaRelacionConcepto")]
    [DataRow("obtenDatasetTrabajadoresRegimen")]
    [DataRow("obtenDatasetRegimen")]
    [DataRow("AltaRelacionRegimen")]
    [DataRow("existeTablaConfiguracion")]
    [DataRow("DeletePayslipsData")]
    [DataRow("obtenConfiguracionCompania")]
    [DataRow("GuardaConfiguracionCompania")]
    public void ShouldContainPublicMethod(string methodName)
    {
        var method = typeof(CatalogoAdicionalOdbc).GetMethod(methodName,
            BindingFlags.Public | BindingFlags.Instance);
        Assert.IsNotNull(method, $"Public method {methodName} not found");
    }

    #endregion

    #region Stubs - Fixed Return Values

    [TestMethod]
    public void ObtenCompaniasIdiomas_ShouldReturnEmptyString()
    {
        var service = CreateServiceWithMockDB();
        Assert.AreEqual("", service.obtenCompaniasIdiomas());
    }

    [TestMethod]
    public void ObtenBasesDisponibles_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenBasesDisponibles();
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void ObtenListaPeriodosMes_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenListaPeriodosMes("COMP", "TN", 2026, 1);
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void ObtenDatasetTiposPercepcionDeduccion_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenDatasetTiposPercepcionDeduccion(1);
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void ObtenDatasetDescripcionTipos_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenDatasetDescripcionTipos();
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void ObtenDatasetRelacionConceptos_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenDatasetRelacionConceptos(1, "001");
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void ObtenDatasetConceptosRelacionar_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenDatasetConceptosRelacionar(1, "001");
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void AltaRelacionConcepto_ShouldReturnFalse()
    {
        var service = CreateServiceWithMockDB();
        Assert.IsFalse(service.AltaRelacionConcepto(1, "001", 100));
    }

    [TestMethod]
    public void BajaRelacionConcepto_ShouldReturnFalse()
    {
        var service = CreateServiceWithMockDB();
        Assert.IsFalse(service.BajaRelacionConcepto(1, "001", 100));
    }

    [TestMethod]
    public void ObtenDatasetTrabajadoresRegimen_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenDatasetTrabajadoresRegimen("COMP");
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void ObtenDatasetRegimen_ShouldReturnEmptyDataSet()
    {
        var service = CreateServiceWithMockDB();
        var ds = service.obtenDatasetRegimen();
        Assert.IsNotNull(ds);
        Assert.AreEqual(0, ds.Tables.Count);
    }

    [TestMethod]
    public void AltaRelacionRegimen_ShouldReturnFalse()
    {
        var service = CreateServiceWithMockDB();
        Assert.IsFalse(service.AltaRelacionRegimen("COMP", "TRAB", "REG"));
    }

    [TestMethod]
    public void ExisteTablaConfiguracion_ShouldReturnFalse()
    {
        var service = CreateServiceWithMockDB();
        Assert.IsFalse(service.existeTablaConfiguracion());
    }

    [TestMethod]
    public void DeletePayslipsData_ShouldReturnFalse()
    {
        var service = CreateServiceWithMockDB();
        Assert.IsFalse(service.DeletePayslipsData("COMP", "TN", "CN", 2026, 1, "EMP001"));
    }

    [TestMethod]
    public void ObtenConfiguracionCompania_ShouldReturnNull()
    {
        var service = CreateServiceWithMockDB();
        Assert.IsNull(service.obtenConfiguracionCompania("COMP"));
    }

    #endregion

    #region NotImplementedException

    [TestMethod]
    public void GuardaConfiguracionCompania_ShouldThrowNotImplementedException()
    {
        var service = CreateServiceWithMockDB();
        Assert.Throws<NotImplementedException>(() =>
            service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "desc", "alpha", 0, 0));
    }

    [TestMethod]
    public void ReadCSD_ShouldThrowNotImplementedException()
    {
        ICatalogoAdicional service = CreateServiceWithMockDB();
        Assert.Throws<NotImplementedException>(() => service.ReadCSD());
    }

    [TestMethod]
    public void DeleteCSD_ShouldThrowNotImplementedException()
    {
        ICatalogoAdicional service = CreateServiceWithMockDB();
        Assert.Throws<NotImplementedException>(() => service.DeleteCSD("client1"));
    }

    [TestMethod]
    public void CreateReplaceCSD_ShouldThrowNotImplementedException()
    {
        ICatalogoAdicional service = CreateServiceWithMockDB();
        Assert.Throws<NotImplementedException>(() =>
            service.CreateReplaceCSD(new byte[] { 1 }, new byte[] { 2 }, "client1", "pass"));
    }

    [TestMethod]
    public void ObtenParametrosCompania_ShouldThrowNotImplementedException()
    {
        ICatalogoAdicional service = CreateServiceWithMockDB();
        Assert.Throws<NotImplementedException>(() => service.obtenParametrosCompania("COMP"));
    }

    #endregion

    #region InvalidCastException - Mock IDbConnection

    [TestMethod]
    public void ObtenDatasetTrabajadoresRecibo_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        Assert.Throws<InvalidCastException>(() =>
            service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica));
    }

    [TestMethod]
    public void ObtenDatasetCompanias_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        Assert.Throws<InvalidCastException>(() => service.obtenDatasetCompanias("ES"));
    }

    [TestMethod]
    public void ObtenDatasetClasesNomina_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        Assert.Throws<InvalidCastException>(() => service.obtenDatasetClasesNomina("COMP"));
    }

    [TestMethod]
    public void ObtenDatasetTiposNomina_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        Assert.Throws<InvalidCastException>(() => service.obtenDatasetTiposNomina("COMP"));
    }

    [TestMethod]
    public void ObtenDatasetFormaPago_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        Assert.Throws<InvalidCastException>(() => service.obtenDatasetFormaPago());
    }

    #endregion

    #region Real OdbcConnection - OdbcException on Open

    [TestMethod]
    public void ObtenDatasetTrabajadoresRecibo_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        Assert.Throws<OdbcException>(() =>
            service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica));
    }

    [TestMethod]
    public void ObtenDatasetCompanias_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        Assert.Throws<OdbcException>(() => service.obtenDatasetCompanias("ES"));
    }

    [TestMethod]
    public void ObtenDatasetClasesNomina_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        Assert.Throws<OdbcException>(() => service.obtenDatasetClasesNomina("COMP"));
    }

    [TestMethod]
    public void ObtenDatasetTiposNomina_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        Assert.Throws<OdbcException>(() => service.obtenDatasetTiposNomina("COMP"));
    }

    [TestMethod]
    public void ObtenDatasetFormaPago_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        Assert.Throws<OdbcException>(() => service.obtenDatasetFormaPago());
    }

    #endregion
}

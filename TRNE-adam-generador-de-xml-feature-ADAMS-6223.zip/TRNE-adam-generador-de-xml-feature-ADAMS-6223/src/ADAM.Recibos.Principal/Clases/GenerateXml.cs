using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Threading;
using System.Security;
using System.Xml;
using System.Xml.Linq;
using ADAM.Recibos.Controls;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.Recibos.Principal.Clases
{
    public class GenerateXml
    {
        private const string CfdiNamespaceUri = "http://www.sat.gob.mx/cfd/4";

        private TipoPlataforma TipoPlataforma { get; set; }
        private Trabajadores ListaTrabajadores { get; set; }
        private string Compania { get; set; }
        private string ConceptoFactura { get; set; }
        private string MetodoPagoDefault { get; set; }
        private string CertPath { get; set; }
        private string KeyPath { get; set; }
        private SecureString KeyPwd { get; set; }
        private int MaxDegreeOfParallelism { get; set; }

        private readonly ApplicationSettingsBase _appSettings;
        private readonly object _fileLock = new object();

        internal Func<TipoPlataforma, ApplicationSettingsBase, IBRReciboElectronico> CreateBRReciboElectronico { get; set; }
            = BRReciboElectronicoHelper.CreateInstance;

        public GenerateXml(TipoPlataforma tipoPlataforma,
                           ApplicationSettingsBase appSettings,
                           Trabajadores listaTrabajadores,
                           string compania, string conceptoFactura, 
                           string metodoPagoDefault, string rutaCertificado, 
                           string rutaLlave, string passwordLlave)
        {
            if (string.IsNullOrEmpty(compania))
            {
                throw new ArgumentException($"'{nameof(compania)}' no puede ser vacío o nulo", nameof(compania));
            }

            if (string.IsNullOrEmpty(conceptoFactura))
            {
                throw new ArgumentException($"'{nameof(conceptoFactura)}' no puede ser vacío o nulo", nameof(conceptoFactura));
            }

            if (string.IsNullOrEmpty(metodoPagoDefault))
            {
                throw new ArgumentException($"'{nameof(metodoPagoDefault)}' no puede ser vacío o nulo", nameof(metodoPagoDefault));
            }

            this.TipoPlataforma = tipoPlataforma;
            this._appSettings = appSettings ?? throw new ArgumentNullException(nameof(appSettings));
            this.ListaTrabajadores = listaTrabajadores ?? throw new ArgumentNullException(nameof(listaTrabajadores));
            this.Compania = compania;
            this.ConceptoFactura = conceptoFactura;
            this.MetodoPagoDefault = metodoPagoDefault;
            this.CertPath = rutaCertificado;
            this.KeyPath = rutaLlave;
            this.KeyPwd = new NetworkCredential(string.Empty, passwordLlave).SecurePassword;
        }

        public async Task Run(CallBackThread objetoCallBack, 
                              bool generaArchivosPrevio, 
                              string archivoXSLT,
                              string archivoXSD,
                              bool validaXSD,
                              string rutaGenerador,
                              string rutaArchivosSalida, 
                              bool generarMultiplesArchivos, 
                              bool generaDatosAdicionales, 
                              string procedimientoAdicionales,
                              uint fPreviousExecutionState, 
                              uint protectorPantallaActivo,
                              uint nullVar,
                              string defaultEndpoint, 
                              int defaultTimeout)
        {
            int contador = 0;
            int contadorError = 0;
            var stopwatch = Stopwatch.StartNew();
            ConcurrentBag<string> resultfilelist = new ConcurrentBag<string>();

            XmlWriterSettings settings = new XmlWriterSettings { ConformanceLevel = ConformanceLevel.Auto, OmitXmlDeclaration = false };

            // Limit processes per CPU
            MaxDegreeOfParallelism = (Environment.ProcessorCount - 1) * 10;

            Parallel.ForEach(ListaTrabajadores, new ParallelOptions { MaxDegreeOfParallelism = MaxDegreeOfParallelism }, trabajadorProcesar =>
            {
                var xmlGenerado = string.Empty;
                var xmlTransformado = string.Empty;
                string xmlValidacionesExtendidas;
                string resultadoagregarnodotrabajador;
                string nombreArchivo;

                // Receipts dataset contains the manage of extra hours.
                DataSet datosRecibo;
                DataSet dsDatosAdicionales;

                IBRReciboElectronico brRecv = CreateBRReciboElectronico(TipoPlataforma, this._appSettings);

#if DEBUG
                Debug.WriteLine($"Max Degree Of Parallelism: {MaxDegreeOfParallelism}");
                Debug.WriteLine($"Amount of app concurrent threads: {Process.GetCurrentProcess().Threads.Count}");
#endif

                // Generate DataSet including Payroll Receipts
                if (trabajadorProcesar.manejoNomina == ManejoNomina.interactiva) { ConceptoFactura = trabajadorProcesar.pagoSeparacion.ToString(); }

                Nomina nomina = new Nomina(Compania,
                                           trabajadorProcesar.numTrabajador,
                                           trabajadorProcesar.tipoNomina,
                                           trabajadorProcesar.claseNomina,
                                           trabajadorProcesar.anio,
                                           trabajadorProcesar.periodo,
                                           trabajadorProcesar.manejoNomina,
                                           trabajadorProcesar.numeroLiquidacion,
                                           ConceptoFactura,
                                           MetodoPagoDefault);

                datosRecibo = brRecv.ObtenDatasetRecibo(nomina);

                // Convert DataSet to Xml
                xmlGenerado = XmlHelper.ConvierteDatasetXml(datosRecibo);

                // Apply XLST format to Xml
                xmlTransformado = XmlHelper.TransformaXml(rutaGenerador, xmlGenerado, archivoXSLT, false, settings, false);

                // Las horas extra e incapacidades ya estan incluidas en el Dataset Principal
                var xmlResult = xmlTransformado;

                // Check if node apply "Timbrados" relate.
                if (trabajadorProcesar.esTimbradoRelacionado) 
                { 
                    xmlResult = PayrollHelper.InsertaNodoTimbradoRelacionado(xmlResult); 
                }

                // Validate if apply aditional data.
                if (generaDatosAdicionales)
                {
                    dsDatosAdicionales = brRecv.ObtenDatasetAdicionales(nomina, procedimientoAdicionales);

                    if (dsDatosAdicionales != null &&
                        dsDatosAdicionales.Tables.Count > 0 &&
                        dsDatosAdicionales.Tables[0].Rows.Count != 0)
                    {
                        xmlResult = PayrollHelper.InsertaAdicionales(xmlResult, dsDatosAdicionales.Tables[0], archivoXSD);
                    }
                }
                
                // Get parameters to generate multiples files
                if (generarMultiplesArchivos)
                {
                    nombreArchivo = $"{trabajadorProcesar.anio}_{trabajadorProcesar.periodo.ToString().Trim()}_{trabajadorProcesar.claseNomina.Trim()}_{trabajadorProcesar.tipoNomina.Trim()}_{trabajadorProcesar.numTrabajador.Trim()}";

                    if (trabajadorProcesar.manejoNomina == ManejoNomina.interactiva && trabajadorProcesar.pagoSeparacion != 0)
                        nombreArchivo += $"_{trabajadorProcesar.pagoSeparacion}";

                    nombreArchivo += "_ADAM.xml";
                }
                else
                {
                    nombreArchivo = "previo.xml";
                }

                // Debug, deductions and earnings not containing amount. 
                xmlResult = XmlHelper.DepuraNodosNomina(xmlResult);

                // Compare file XML with XSD modified
                bool resultadoValidacionXSD = false;

                if (validaXSD)
                {
                    resultadoValidacionXSD = XmlHelper.ValidaXmlvsXsd(rutaGenerador,
                                                                      xmlResult,
                                                                      archivoXSD,
                                                                      trabajadorProcesar.numTrabajador,
                                                                      objetoCallBack);
                }
                else
                { 
                    resultadoValidacionXSD = true; 
                }

                // Apply extended validations from XSD
                xmlValidacionesExtendidas = XmlHelper.TransformaXml(rutaGenerador,
                                                                    xmlGenerado, 
                                                                    "\\xml\\" + archivoXSLT, 
                                                                    false, 
                                                                    settings, 
                                                                    true);

                if (xmlValidacionesExtendidas.Length > 0)
                {
                    objetoCallBack.UpdateUI($"Trabajador: {trabajadorProcesar.numTrabajador}\t validacion xsd: {xmlValidacionesExtendidas}");
                    resultadoValidacionXSD = false;
                }

                string filepath;
                bool fileWriteSuccess;
                (resultadoagregarnodotrabajador, filepath, fileWriteSuccess) = BuildXmlFile(trabajadorProcesar.numTrabajador, 
                                                                          xmlResult, 
                                                                          rutaArchivosSalida, 
                                                                          nombreArchivo, 
                                                                          generarMultiplesArchivos);

                if (fileWriteSuccess && !string.IsNullOrEmpty(filepath) && !resultfilelist.Contains(filepath)) 
                { 
                    resultfilelist.Add(filepath); 
                }

                // Check XSD Result AND file write success
                if (resultadoValidacionXSD && fileWriteSuccess)
                {
                    // Notify Parent Process/Form
                    objetoCallBack.UpdateUI($"Trabajador: {trabajadorProcesar.numTrabajador}\t Se agregó el trabajador: {trabajadorProcesar.numTrabajador.Trim()} al archivo");
                    Interlocked.Increment(ref contador);
                }
                else 
                {
                    if (!fileWriteSuccess)
                    {
                        objetoCallBack.UpdateUI($"Trabajador: {trabajadorProcesar.numTrabajador}\t Error: {resultadoagregarnodotrabajador}");
                    }
                    Interlocked.Increment(ref contadorError); 
                }
            });

            // Se desactiva el parametro para que se mantenga la configuracion original de suspension
            NativeMethods.SetThreadExecutionState(fPreviousExecutionState);

            // Reactivar el protector de pantalla
            if (protectorPantallaActivo == 1)
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENSAVEACTIVE, 1, ref nullVar, NativeMethods.SPIF_SENDWININICHANGE);

            // Closing Main Node
            if (!generarMultiplesArchivos)
            {
                // File name will be <appuser>_Previo.xml
                var pathToUse = Path.Combine(rutaArchivosSalida,
                                             $"{this._appSettings[ConfigParameters.applicationUser.ToString()]}_Previo.xml");
                await File.AppendAllTextAsync(pathToUse, "</nominas>");
            }

            // Zip Output Folder
            var zipFile = $"{rutaArchivosSalida}.zip";
            await Task.Run(() => ZipFile.CreateFromDirectory(rutaArchivosSalida, zipFile));
            
            // Display Message
            var message = $"Se ha concluido el proceso de {Environment.NewLine}generación de informacion{Environment.NewLine}" +
                          $"{Environment.NewLine}" +
                          $"Total Trabajadores: {ListaTrabajadores.Count}{Environment.NewLine}" +
                          $"{Environment.NewLine}" +
                          $"Generados de forma satisfactoria: {contador}{Environment.NewLine}" +
                          $"Registros con errores: {contadorError}{Environment.NewLine}" +
                          $"{Environment.NewLine}" +
                          $"Tiempo del Proceso: {stopwatch.Elapsed}";

            CustomMessageBox.Show(message, "ADAM",
                                  $"Descargar archivo: {Path.GetFileName(zipFile)}",
                                  zipFile,
                                  MessageBoxIcon.Information);

            // Open File
            if (!generarMultiplesArchivos)
            {
                var pathToUse = Path.Combine(rutaArchivosSalida,
                                             $"{this._appSettings[ConfigParameters.applicationUser.ToString()]}_Previo.xml");

                if (!CustomMessageBox.SuppressUI)
                {
                    Recibos.Utilerias.Helpers.GlobalHelper.OpenFileSecure(pathToUse);
                }
            }
            else
            {
                var outputFolder = rutaArchivosSalida.Replace(rutaGenerador, string.Empty);
                message = $"Los archivos fueron generados en la siguiente ruta:{Environment.NewLine}{Environment.NewLine}"
                        + outputFolder;
                CustomMessageBox.Show(message, "ADAM", MessageBoxIcon.Information);
            }

            if (!generaArchivosPrevio)
            {
                CustomMessageBox.Show($@"Se realizara la etapa de Timbrado", "ADAM", MessageBoxIcon.Information);

                ProcessResultWorkersFile(objetoCallBack, resultfilelist, defaultEndpoint, defaultTimeout);
            }
        }

        private (string message, string filepathresult, bool success) BuildXmlFile(string trabajador, 
                                                                     string xmlEnviar, 
                                                                     string rutaArchivosSalida, 
                                                                     string nombreArchivo, 
                                                                     bool multiplesArchivos)
        {
            try
            {
                var pathToUse = string.Empty;

                if (!multiplesArchivos)
                {
                    var xmlPreview = $"{this._appSettings[ConfigParameters.applicationUser.ToString()]}_Previo.xml";
                    pathToUse = Path.Combine(rutaArchivosSalida, xmlPreview);

                    lock (_fileLock)
                    {
                        using (StreamWriter writerPrevio = File.AppendText(pathToUse))
                        {
                            // Eliminar el encabezado por trabajador para crear un solo archivos
                            writerPrevio.Write(xmlEnviar.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", ""));
                            writerPrevio.Flush();
                        }
                    }

                    return ($"Se agregó el trabajador: {trabajador.Trim()} al archivo", pathToUse, true);
                }
                else
                {
                    xmlEnviar = $"<?xml version=\"1.0\" encoding=\"utf-8\"?>{Environment.NewLine}{xmlEnviar}";
                    pathToUse = Path.Combine(rutaArchivosSalida, nombreArchivo);
                    File.WriteAllText(pathToUse, xmlEnviar);
                    return ($"se creo el archivo {pathToUse} para el trabajador: {trabajador}", pathToUse, true);
                }
            }
            catch (Exception ex)
            {
                return ($"Error al escribir archivo para trabajador {trabajador}: {ex.Message}", string.Empty, false);
            }
        }

        private void ProcessResultWorkersFile(CallBackThread objetoCallBack, ConcurrentBag<string> fileList, string defaultEndpoint, int defaultTimeout)
        {
            var stopwatch = Stopwatch.StartNew();
            ConcurrentBag<string> result = new ConcurrentBag<string>();
            int batchSize = 100;
            objetoCallBack.UpdateUI("", true);
            var validFiles = fileList.Where(f => !string.IsNullOrEmpty(f)).Distinct().ToList();

            Parallel.ForEach(validFiles, filename =>
            {
                List<string> output;
                var xmlDocument = new XmlDocument();
                xmlDocument.Load(filename);

                // Get all 'nomina' nodes from the XML file
                XmlNodeList nominaNodes = xmlDocument.SelectNodes("//nomina");
                output = nominaNodes.Cast<XmlNode>().Select(nodoNomina => nodoNomina.OuterXml).ToList();
                var batches = BatchTasks(output, batchSize);

                foreach (var batch in batches)
                {
                    var tasks = batch.Select(nodoNomina => SendMessageAndUpdateUi(objetoCallBack, defaultEndpoint, defaultTimeout, nodoNomina));
                    var task_results = Task.WhenAll(tasks).GetAwaiter().GetResult();
                    foreach (var r in task_results) { result.Add(r); }
                    Thread.Sleep(1000);
                }
            });

            var szMessage = $"Proceso Concluido{Environment.NewLine}" +
                            $"Tiempo del Proceso: {stopwatch.Elapsed}";
            CustomMessageBox.Show(szMessage, "ADAM", MessageBoxIcon.Information);
        }

        private async Task<string> SendMessageAndUpdateUi(CallBackThread objetoCallBack, string defaultEndpoint, int defaultTimeout, string nodoNomina)
        {
            var message = await EnviaXmlTimbradoAsync(defaultEndpoint, defaultTimeout, nodoNomina);
            objetoCallBack.UpdateUI(message);
            return message;
        }

        private static IEnumerable<IEnumerable<T>> BatchTasks<T>(IEnumerable<T> tasks, int batchSize)
        {
            return tasks.Select((item, index) => new { item, index })
                        .GroupBy(x => x.index / batchSize)
                        .Select(group => group.Select(x => x.item));
        }

        private static XmlNamespaceManager GetXmlNamespaceManager(XmlDocument xmlDoc)
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("cfdi", CfdiNamespaceUri);
            return nsmgr;
        }

        private async Task<string> EnviaXmlTimbradoAsync(string defaultEndpoint, int defaultTimeout, string nodoNomina)
        {
            string rfc = string.Empty;
            string nombre = string.Empty;
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(nodoNomina);
                XmlNode receptorNode = xmlDoc.DocumentElement.SelectSingleNode("//cfdi:Receptor", GetXmlNamespaceManager(xmlDoc));
                rfc = receptorNode.Attributes["Rfc"].Value;
                nombre = receptorNode.Attributes["Nombre"].Value;
            }
            catch
            {
                XNamespace cfdiNamespace = CfdiNamespaceUri;
                XDocument doc = XDocument.Parse(nodoNomina);
                XElement receptorNode = doc.Descendants(cfdiNamespace + "Receptor").FirstOrDefault();
                if (receptorNode != null)
                {
                    XAttribute rfcAttribute = receptorNode.Attribute("Rfc");
                    XAttribute nombreAttribute = receptorNode.Attribute("Nombre");
                    if (rfcAttribute != null) { rfc = rfcAttribute.Value; }
                    if (nombreAttribute != null) { nombre = nombreAttribute.Value; }
                }
            }

            return await Task.Run(() => $"Trabajador: {rfc}-{nombre}\t {WebServiceHelper.EnviaXmlTimbrado(Compania, defaultEndpoint, defaultTimeout, nodoNomina, TipoPlataforma)}");
        }
    }
}

﻿using System.Configuration;


namespace ADAM.Recibos.Datos.Odbc.Tests.Fakes
{
    public class FakeSettings : ApplicationSettingsBase
    {
        public override object this[string propertyName]
        {
            get
            {

                if (propertyName.ToLower().Contains("connection"))
                    return "Driver={SQL Server};Server=localhost;Database=master;Trusted_Connection=yes;";


                return "SELECT 1 AS Dummy";
            }
            set
            {
                _ = value;

            }
        }

    }
}

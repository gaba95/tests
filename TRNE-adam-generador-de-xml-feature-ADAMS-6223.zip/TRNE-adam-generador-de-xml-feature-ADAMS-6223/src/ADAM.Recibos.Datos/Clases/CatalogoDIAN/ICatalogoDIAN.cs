﻿using System.Data;
using System.Threading.Tasks;

namespace ADAM.Recibos.Datos.Clases.CatalogoDIAN
{
    public interface ICatalogoDian
    {
        // PTF-4277
        // Informacion de configuracion de catalgos SAT - DIAN

        DataSet obtenCorrelativoDian(string compania, string trabajador);
        Task<bool> ActualizaBitacoraCorrelativosDian(string compania, string numero, string documento_id, string estado_accion);
        DataSet obtenDatasetBitacoraCorrelativosDianEmpleado(string compania, string trabajador, bool correctos = true);
        DataSet getDatasetEmployeesReceiptDian(string compania, string anio, string mes);
        DataSet getDatasetInformationDian(string compania, string anio, string mes, string employee, string id_parent_node, string tipo);
        DataSet dsListaSeccionesDIAN(string szTipo, string szTipoConcepto = "");
        DataSet dsListaCamposDIAN(string szIdPadre, string szTipoMapeo, string szTipoConcepto = "");
        DataSet obtenDatasetTablaDIAN(string szIdCampo);
        DataSet obtenCatalogoAdamDIAN(string id_campo, string param1 = "");
        DataSet obtenDataSetConceptosAux();
        DataSet obtenDataSetCatalogosAux();
        bool altaRelacionDatoCatalogoDIAN(string szCompania, string szCampo, string szClaveDian, string szClaveAdam);
        bool bajaRelacionDatoCatalogoDIAN(string szCompania, string szCampo, string szClaveDian, string szClaveAdam);
        DataSet obtenDatasetRelacionCatalogosDIAN(string szCompania, string szCampo, string szClaveDian);
        DataSet obtenDatasetTreeViewCatalogosDIAN();
        DataSet obtenDatasetTreeViewCatalogosDIANByCompany(string company);
        DataSet obtenDatasetConceptosRelacionarDIAN(string tipoConcepto);
        DataSet obtenDatasetTreeViewConceptosDIAN();
        DataSet obtenDatasetTreeViewConceptosDIANByCompany(string company);
        bool getDatasetConceptosADAM(string tipoConcepto, string szConcepto);
        bool altaRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto);
        bool existRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto);
        DataSet obtenDatasetRelacionConceptosDIAN(string szCompania, string szCampo);
        bool bajaRelacionDatoConceptoDIAN(string szCompania, string szCampo, string szConcepto);

        DataSet getParentIdCatalog();
        DataSet getTypeClassification();

        bool AltaResultadoValidacion(string numero, string codigo_error, string mensaje);

    }
}

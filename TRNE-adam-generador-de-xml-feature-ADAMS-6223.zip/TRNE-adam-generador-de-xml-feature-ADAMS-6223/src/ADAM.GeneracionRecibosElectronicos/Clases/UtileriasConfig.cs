using System;
using System.Xml;
using System.IO;
using System.Configuration;

namespace ADAM.GeneracionRecibosElectronicos.Clases
{
    public class UtileriasConfig
    {
        public static ApplicationEnvironmentSettings AppSettings { get; set; }

        private static string NodePath = "//system.serviceModel//client//endpoint";
        private UtileriasConfig() { }

        public static string GetEndpointAddress()
        {
            return ConfigurationManager.AppSettings["NominaService"];
        }

        public static void SaveEndpointAddress(string endpointAddress)
        {
            // load config document for current assembly
            XmlDocument doc = loadConfigDocument();

            // retrieve appSettings node
            XmlNode node = doc.SelectSingleNode(NodePath);

            if (node == null)
                throw new InvalidOperationException("Error. Could not find endpoint node in config file.");

            node.Attributes["address"].Value = endpointAddress;

            doc.Save(getConfigFilePath());
        }

        public static XmlDocument loadConfigDocument()
        {
            XmlDocument doc;
            try
            {
                doc = new XmlDocument();
                doc.Load(getConfigFilePath());
                return doc;
            }
            catch (System.IO.FileNotFoundException e)
            {
                throw new System.IO.FileNotFoundException("No configuration file found.", e);
            }
        }

        private static string getConfigFilePath()
        {
            return $"{Environment.ProcessPath.Replace("exe","dll")}.config";
        }
    }
}

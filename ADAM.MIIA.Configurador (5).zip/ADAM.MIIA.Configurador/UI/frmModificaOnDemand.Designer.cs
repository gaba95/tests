#nullable enable
namespace ADAM.MIIA.Configurador.UI;

partial class frmModificaOnDemand
{
    private System.ComponentModel.IContainer? components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmModificaOnDemand));
        cmdAceptar = new Button();
        cmdCancelar = new Button();
        txtProcedure = new TextBox();
        lblProcedimiento = new Label();
        pnlBotones = new Panel();
        txtRegEx = new TextBox();
        pnlSuperior = new Panel();
        lblTitulo = new Label();
        lblPatron = new Label();
        txtClave = new TextBox();
        lblClave = new Label();
        pnlBotones.SuspendLayout();
        pnlSuperior.SuspendLayout();
        SuspendLayout();
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdAceptar.DialogResult = DialogResult.Cancel;
        cmdAceptar.FlatStyle = FlatStyle.Popup;
        cmdAceptar.Location = new Point(230, 2);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 0;
        cmdAceptar.Text = "Guardar";
        cmdAceptar.UseVisualStyleBackColor = true;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.FlatStyle = FlatStyle.Popup;
        cmdCancelar.Location = new Point(360, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cerrar";
        cmdCancelar.UseVisualStyleBackColor = true;
        // 
        // txtProcedure
        // 
        txtProcedure.BorderStyle = BorderStyle.FixedSingle;
        txtProcedure.Location = new Point(150, 120);
        txtProcedure.MaxLength = 200;
        txtProcedure.Name = "txtProcedure";
        txtProcedure.Size = new Size(250, 28);
        txtProcedure.TabIndex = 16;
        // 
        // lblProcedimiento
        // 
        lblProcedimiento.AutoSize = true;
        lblProcedimiento.Location = new Point(10, 120);
        lblProcedimiento.Name = "lblProcedimiento";
        lblProcedimiento.Size = new Size(133, 23);
        lblProcedimiento.TabIndex = 15;
        lblProcedimiento.Text = "Procedimiento:";
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Controls.Add(cmdAceptar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 218);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(494, 50);
        pnlBotones.TabIndex = 17;
        // 
        // txtRegEx
        // 
        txtRegEx.BorderStyle = BorderStyle.FixedSingle;
        txtRegEx.Location = new Point(150, 84);
        txtRegEx.MaxLength = 100;
        txtRegEx.Name = "txtRegEx";
        txtRegEx.Size = new Size(250, 28);
        txtRegEx.TabIndex = 14;
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(92, 145, 163);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(494, 30);
        pnlSuperior.TabIndex = 10;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 10.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(10, 5);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(350, 27);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Configuración Ejecución Inmediata";
        // 
        // lblPatron
        // 
        lblPatron.AutoSize = true;
        lblPatron.Location = new Point(10, 84);
        lblPatron.Name = "lblPatron";
        lblPatron.Size = new Size(69, 23);
        lblPatron.TabIndex = 13;
        lblPatron.Text = "Patrón:";
        // 
        // txtClave
        // 
        txtClave.BorderStyle = BorderStyle.FixedSingle;
        txtClave.Location = new Point(150, 50);
        txtClave.MaxLength = 50;
        txtClave.Name = "txtClave";
        txtClave.Size = new Size(250, 28);
        txtClave.TabIndex = 12;
        // 
        // lblClave
        // 
        lblClave.AutoSize = true;
        lblClave.Location = new Point(10, 50);
        lblClave.Name = "lblClave";
        lblClave.Size = new Size(61, 23);
        lblClave.TabIndex = 11;
        lblClave.Text = "Clave:";
        // 
        // frmModificaOnDemand
        // 
        AcceptButton = cmdAceptar;
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        CancelButton = cmdCancelar;
        ClientSize = new Size(494, 268);
        Controls.Add(txtProcedure);
        Controls.Add(lblProcedimiento);
        Controls.Add(pnlBotones);
        Controls.Add(txtRegEx);
        Controls.Add(pnlSuperior);
        Controls.Add(lblPatron);
        Controls.Add(txtClave);
        Controls.Add(lblClave);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        Icon = (Icon)resources.GetObject("$this.Icon");
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "frmModificaOnDemand";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Modifica Ejecución Inmediata";
        Load += frmModificaOnDemand_Load;
        pnlBotones.ResumeLayout(false);
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    private Button cmdAceptar;
    private Button cmdCancelar;
    private TextBox txtProcedure;
    private Label lblProcedimiento;
    private Panel pnlBotones;
    private TextBox txtRegEx;
    private Panel pnlSuperior;
    private Label lblTitulo;
    private Label lblPatron;
    private TextBox txtClave;
    private Label lblClave;
}

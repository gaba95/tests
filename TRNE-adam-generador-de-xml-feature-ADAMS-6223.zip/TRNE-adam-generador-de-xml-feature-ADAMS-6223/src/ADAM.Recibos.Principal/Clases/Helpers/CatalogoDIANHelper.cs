using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using System.Configuration;

namespace ADAM.Recibos.Principal.Clases.Helpers
{
    public static class CatalogoDianHelper
    {
        public static ICatalogoDian CreateInstance(TipoPlataforma tipoPlataforma,
                                                   ApplicationSettingsBase appSettings)
        {
            switch (tipoPlataforma)
            {
                case TipoPlataforma.SQLServer:
                    return new CatalogoDianSql(new SqlConnectionFactory(appSettings));

                case TipoPlataforma.ORACLE:
                    return new CatalogoDianOracle(new OracleConnectionFactory(appSettings));

                default:
                    return new CatalogoDianSql(new SqlConnectionFactory(appSettings));
            }
        }
    }
}

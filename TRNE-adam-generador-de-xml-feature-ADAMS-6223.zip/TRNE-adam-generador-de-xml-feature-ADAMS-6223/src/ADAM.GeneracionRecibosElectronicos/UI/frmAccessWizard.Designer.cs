
namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmAccessWizard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAccessWizard));
            this.pnlSuperior = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.PictureBox();
            this.panelConexion = new System.Windows.Forms.Panel();
            this.lblInstrucciones = new System.Windows.Forms.Label();
            this.lblPais = new System.Windows.Forms.Label();
            this.cboPaises = new System.Windows.Forms.ComboBox();
            this.pnlBotones = new System.Windows.Forms.Panel();
            this.ctrButtonCancel = new System.Windows.Forms.Button();
            this.ctrButtonOK = new System.Windows.Forms.Button();
            this.pnlSuperior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.panelConexion.SuspendLayout();
            this.pnlBotones.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSuperior
            // 
            this.pnlSuperior.BackColor = System.Drawing.Color.White;
            this.pnlSuperior.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSuperior.Controls.Add(this.logo);
            this.pnlSuperior.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSuperior.Location = new System.Drawing.Point(0, 0);
            this.pnlSuperior.Name = "pnlSuperior";
            this.pnlSuperior.Size = new System.Drawing.Size(428, 80);
            this.pnlSuperior.TabIndex = 131;
            // 
            // logo
            // 
            this.logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.logo.Image = ((System.Drawing.Image)(resources.GetObject("logo.Image")));
            this.logo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.logo.Location = new System.Drawing.Point(0, 0);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(426, 75);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.logo.TabIndex = 0;
            this.logo.TabStop = false;
            // 
            // panelConexion
            // 
            this.panelConexion.Controls.Add(this.lblInstrucciones);
            this.panelConexion.Controls.Add(this.lblPais);
            this.panelConexion.Controls.Add(this.cboPaises);
            this.panelConexion.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelConexion.Location = new System.Drawing.Point(0, 80);
            this.panelConexion.Name = "panelConexion";
            this.panelConexion.Size = new System.Drawing.Size(428, 85);
            this.panelConexion.TabIndex = 132;
            // 
            // lblInstrucciones
            // 
            this.lblInstrucciones.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstrucciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(47)))), ((int)(((byte)(61)))));
            this.lblInstrucciones.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblInstrucciones.Location = new System.Drawing.Point(12, 12);
            this.lblInstrucciones.Name = "lblInstrucciones";
            this.lblInstrucciones.Size = new System.Drawing.Size(410, 16);
            this.lblInstrucciones.TabIndex = 9;
            this.lblInstrucciones.Tag = "In";
            this.lblInstrucciones.Text = "Seleccione el país a utilizar por defecto para la Nómina Electrónica";
            // 
            // lblPais
            // 
            this.lblPais.BackColor = System.Drawing.Color.Transparent;
            this.lblPais.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(47)))), ((int)(((byte)(61)))));
            this.lblPais.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblPais.Location = new System.Drawing.Point(21, 45);
            this.lblPais.Name = "lblPais";
            this.lblPais.Size = new System.Drawing.Size(45, 16);
            this.lblPais.TabIndex = 8;
            this.lblPais.Text = "País  :";
            this.lblPais.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboPaises
            // 
            this.cboPaises.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(247)))), ((int)(((byte)(249)))));
            this.cboPaises.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPaises.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPaises.ItemHeight = 16;
            this.cboPaises.Items.AddRange(new object[] {
            "México",
            "Colombia"});
            this.cboPaises.Location = new System.Drawing.Point(69, 42);
            this.cboPaises.Name = "cboPaises";
            this.cboPaises.Size = new System.Drawing.Size(335, 24);
            this.cboPaises.TabIndex = 2;
            // 
            // pnlBotones
            // 
            this.pnlBotones.Controls.Add(this.ctrButtonCancel);
            this.pnlBotones.Controls.Add(this.ctrButtonOK);
            this.pnlBotones.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBotones.Location = new System.Drawing.Point(0, 165);
            this.pnlBotones.Name = "pnlBotones";
            this.pnlBotones.Size = new System.Drawing.Size(428, 50);
            this.pnlBotones.TabIndex = 133;
            // 
            // ctrButtonCancel
            // 
            this.ctrButtonCancel.BackColor = System.Drawing.Color.Transparent;
            this.ctrButtonCancel.BackgroundImage = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.BT_Base;
            this.ctrButtonCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ctrButtonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ctrButtonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctrButtonCancel.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrButtonCancel.Location = new System.Drawing.Point(232, 12);
            this.ctrButtonCancel.Name = "ctrButtonCancel";
            this.ctrButtonCancel.Size = new System.Drawing.Size(84, 26);
            this.ctrButtonCancel.TabIndex = 1;
            this.ctrButtonCancel.Text = "Cancelar";
            this.ctrButtonCancel.UseVisualStyleBackColor = false;
            this.ctrButtonCancel.Click += new System.EventHandler(this.ctrButtonCancel_Click);
            // 
            // ctrButtonOK
            // 
            this.ctrButtonOK.BackColor = System.Drawing.Color.Transparent;
            this.ctrButtonOK.BackgroundImage = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.BT_Base;
            this.ctrButtonOK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ctrButtonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ctrButtonOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctrButtonOK.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrButtonOK.Location = new System.Drawing.Point(117, 12);
            this.ctrButtonOK.Name = "ctrButtonOK";
            this.ctrButtonOK.Size = new System.Drawing.Size(84, 26);
            this.ctrButtonOK.TabIndex = 0;
            this.ctrButtonOK.Text = "Aceptar";
            this.ctrButtonOK.UseVisualStyleBackColor = false;
            this.ctrButtonOK.Click += new System.EventHandler(this.ctrButtonOK_Click);
            // 
            // FrmAccessWizard
            // 
            this.AcceptButton = this.ctrButtonOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(234)))), ((int)(((byte)(239)))));
            this.CancelButton = this.ctrButtonCancel;
            this.ClientSize = new System.Drawing.Size(428, 216);
            this.Controls.Add(this.pnlBotones);
            this.Controls.Add(this.panelConexion);
            this.Controls.Add(this.pnlSuperior);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAccessWizard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Nómina Electrónica";
            this.pnlSuperior.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.panelConexion.ResumeLayout(false);
            this.pnlBotones.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel pnlSuperior;
        internal System.Windows.Forms.PictureBox logo;
        internal System.Windows.Forms.Panel panelConexion;
        internal System.Windows.Forms.Label lblInstrucciones;
        internal System.Windows.Forms.Label lblPais;
        internal System.Windows.Forms.ComboBox cboPaises;
        internal System.Windows.Forms.Panel pnlBotones;
        private System.Windows.Forms.Button ctrButtonCancel;
        private System.Windows.Forms.Button ctrButtonOK;
    }
}
using ADAM.Recibos.Utilerias.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Utilerias.Tests.Clases
{
    [TestClass]
    public class ManejoNominaTests
    {
        [TestMethod]
        public void ManejoNomina_Periodica_HasValue1()
        {
            Assert.AreEqual(1, (int)ManejoNomina.periodica);
        }

        [TestMethod]
        public void ManejoNomina_Interactiva_HasValue2()
        {
            Assert.AreEqual(2, (int)ManejoNomina.interactiva);
        }

        [TestMethod]
        public void ManejoNomina_ContainsTwoValues()
        {
            var values = Enum.GetValues(typeof(ManejoNomina));
            Assert.AreEqual(2, values.Length);
        }

        [TestMethod]
        [DataRow(ManejoNomina.periodica)]
        [DataRow(ManejoNomina.interactiva)]
        public void ManejoNomina_AllValues_AreDefined(ManejoNomina manejo)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(ManejoNomina), manejo));
        }

        [TestMethod]
        public void ManejoNomina_CastFromInt()
        {
            var periodica = (ManejoNomina)1;
            var interactiva = (ManejoNomina)2;

            Assert.AreEqual(ManejoNomina.periodica, periodica);
            Assert.AreEqual(ManejoNomina.interactiva, interactiva);
        }
    }
}

using ADAM.Recibos.Principal.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Principal.Tests.Classes
{
    [TestClass]
    public class XslTemplatesTests
    {
        [TestMethod]
        public void XslWhiteList_ContainsExpectedEntries()
        {
            Assert.AreEqual(6, XslTemplates.xslWhiteList.Count);
        }

        [TestMethod]
        [DataRow("nomina12_40ADAM.xslt")]
        [DataRow("nomina12_40ADAMEle.xslt")]
        [DataRow("nomina12_40ADAMExp.xslt")]
        [DataRow("nomina12_40ADAM_ext.xsd")]
        [DataRow("remision52ADAM.xslt")]
        [DataRow("nomina12_33Benavides.xslt")]
        public void XslWhiteList_ContainsKey(string key)
        {
            Assert.IsTrue(XslTemplates.xslWhiteList.ContainsKey(key));
        }

        [TestMethod]
        [DataRow("nomina12_40ADAM.xslt", "nomina12_40ADAM.xslt")]
        [DataRow("remision52ADAM.xslt", "remision52ADAM.xslt")]
        public void XslWhiteList_KeyMatchesValue(string key, string expectedValue)
        {
            Assert.AreEqual(expectedValue, XslTemplates.xslWhiteList[key]);
        }

        [TestMethod]
        public void XslWhiteList_DoesNotContainInvalidKey()
        {
            Assert.IsFalse(XslTemplates.xslWhiteList.ContainsKey("nonexistent.xslt"));
        }
    }
}

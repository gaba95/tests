namespace ADAM.Recibos.Datos.Odbc.UI
{
    partial class FrmConfiguracionConsultas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmConfiguracionConsultas));
            this.pnlBotones = new System.Windows.Forms.Panel();
            this.cmdAceptar = new System.Windows.Forms.Button();
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.lblIndicaciones = new System.Windows.Forms.Label();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.txtMetodosPago = new System.Windows.Forms.TextBox();
            this.lblMetodosPago = new System.Windows.Forms.Label();
            this.txtOtrosPagos = new System.Windows.Forms.TextBox();
            this.lblOtrosPagos = new System.Windows.Forms.Label();
            this.txtIncapacidades = new System.Windows.Forms.TextBox();
            this.lblIncapacidades = new System.Windows.Forms.Label();
            this.txtHorasExtra = new System.Windows.Forms.TextBox();
            this.lblHorasExtra = new System.Windows.Forms.Label();
            this.txtNomina = new System.Windows.Forms.TextBox();
            this.lblNomina = new System.Windows.Forms.Label();
            this.txtEmpleados = new System.Windows.Forms.TextBox();
            this.lblEmpleados = new System.Windows.Forms.Label();
            this.txtCompanias = new System.Windows.Forms.TextBox();
            this.lblCompanias = new System.Windows.Forms.Label();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.lblTipo = new System.Windows.Forms.Label();
            this.txtClase = new System.Windows.Forms.TextBox();
            this.lblClase = new System.Windows.Forms.Label();
            this.txtAccionesTitulos = new System.Windows.Forms.TextBox();
            this.lblAccionesTitulos = new System.Windows.Forms.Label();
            this.txtJubilacionPensionRetiro = new System.Windows.Forms.TextBox();
            this.lblJubilacionPensionRetiro = new System.Windows.Forms.Label();
            this.txtSeparacionIndemnizacion = new System.Windows.Forms.TextBox();
            this.lblSeparacionIndemnizacion = new System.Windows.Forms.Label();
            this.pnlBotones.SuspendLayout();
            this.pnlPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBotones
            // 
            this.pnlBotones.Controls.Add(this.cmdAceptar);
            this.pnlBotones.Controls.Add(this.cmdCancelar);
            this.pnlBotones.Controls.Add(this.lblIndicaciones);
            this.pnlBotones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBotones.Location = new System.Drawing.Point(0, 482);
            this.pnlBotones.Name = "pnlBotones";
            this.pnlBotones.Size = new System.Drawing.Size(684, 80);
            this.pnlBotones.TabIndex = 1;
            // 
            // cmdAceptar
            // 
            this.cmdAceptar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAceptar.Location = new System.Drawing.Point(180, 28);
            this.cmdAceptar.Name = "cmdAceptar";
            this.cmdAceptar.Size = new System.Drawing.Size(110, 40);
            this.cmdAceptar.TabIndex = 1;
            this.cmdAceptar.Text = "&Aceptar";
            this.cmdAceptar.UseVisualStyleBackColor = true;
            this.cmdAceptar.Click += new System.EventHandler(this.cmdAceptar_Click);
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancelar.Location = new System.Drawing.Point(377, 27);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(110, 40);
            this.cmdCancelar.TabIndex = 2;
            this.cmdCancelar.Text = "&Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            // 
            // lblIndicaciones
            // 
            this.lblIndicaciones.AutoSize = true;
            this.lblIndicaciones.Location = new System.Drawing.Point(21, 6);
            this.lblIndicaciones.Name = "lblIndicaciones";
            this.lblIndicaciones.Size = new System.Drawing.Size(549, 18);
            this.lblIndicaciones.TabIndex = 0;
            this.lblIndicaciones.Text = "Al terminar la configuración, reinicie la aplicación para que se  consideren los " +
    "cambios realizados";
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.AutoScroll = true;
            this.pnlPrincipal.Controls.Add(this.txtSeparacionIndemnizacion);
            this.pnlPrincipal.Controls.Add(this.lblSeparacionIndemnizacion);
            this.pnlPrincipal.Controls.Add(this.txtJubilacionPensionRetiro);
            this.pnlPrincipal.Controls.Add(this.lblJubilacionPensionRetiro);
            this.pnlPrincipal.Controls.Add(this.txtAccionesTitulos);
            this.pnlPrincipal.Controls.Add(this.lblAccionesTitulos);
            this.pnlPrincipal.Controls.Add(this.txtMetodosPago);
            this.pnlPrincipal.Controls.Add(this.lblMetodosPago);
            this.pnlPrincipal.Controls.Add(this.txtOtrosPagos);
            this.pnlPrincipal.Controls.Add(this.lblOtrosPagos);
            this.pnlPrincipal.Controls.Add(this.txtIncapacidades);
            this.pnlPrincipal.Controls.Add(this.lblIncapacidades);
            this.pnlPrincipal.Controls.Add(this.txtHorasExtra);
            this.pnlPrincipal.Controls.Add(this.lblHorasExtra);
            this.pnlPrincipal.Controls.Add(this.txtNomina);
            this.pnlPrincipal.Controls.Add(this.lblNomina);
            this.pnlPrincipal.Controls.Add(this.txtEmpleados);
            this.pnlPrincipal.Controls.Add(this.lblEmpleados);
            this.pnlPrincipal.Controls.Add(this.txtCompanias);
            this.pnlPrincipal.Controls.Add(this.lblCompanias);
            this.pnlPrincipal.Controls.Add(this.txtTipo);
            this.pnlPrincipal.Controls.Add(this.lblTipo);
            this.pnlPrincipal.Controls.Add(this.txtClase);
            this.pnlPrincipal.Controls.Add(this.lblClase);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 0);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(684, 482);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // txtMetodosPago
            // 
            this.txtMetodosPago.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMetodosPago.Location = new System.Drawing.Point(150, 330);
            this.txtMetodosPago.Multiline = true;
            this.txtMetodosPago.Name = "txtMetodosPago";
            this.txtMetodosPago.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMetodosPago.Size = new System.Drawing.Size(500, 40);
            this.txtMetodosPago.TabIndex = 11;
            // 
            // lblMetodosPago
            // 
            this.lblMetodosPago.AutoSize = true;
            this.lblMetodosPago.Location = new System.Drawing.Point(10, 330);
            this.lblMetodosPago.Name = "lblMetodosPago";
            this.lblMetodosPago.Size = new System.Drawing.Size(104, 18);
            this.lblMetodosPago.TabIndex = 10;
            this.lblMetodosPago.Text = "Metodos de Pago";
            // 
            // txtOtrosPagos
            // 
            this.txtOtrosPagos.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOtrosPagos.Location = new System.Drawing.Point(150, 430);
            this.txtOtrosPagos.Multiline = true;
            this.txtOtrosPagos.Name = "txtOtrosPagos";
            this.txtOtrosPagos.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOtrosPagos.Size = new System.Drawing.Size(500, 40);
            this.txtOtrosPagos.TabIndex = 15;
            // 
            // lblOtrosPagos
            // 
            this.lblOtrosPagos.AutoSize = true;
            this.lblOtrosPagos.Location = new System.Drawing.Point(10, 430);
            this.lblOtrosPagos.Name = "lblOtrosPagos";
            this.lblOtrosPagos.Size = new System.Drawing.Size(74, 18);
            this.lblOtrosPagos.TabIndex = 14;
            this.lblOtrosPagos.Text = "Otros Pagos";
            // 
            // txtIncapacidades
            // 
            this.txtIncapacidades.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIncapacidades.Location = new System.Drawing.Point(150, 380);
            this.txtIncapacidades.Multiline = true;
            this.txtIncapacidades.Name = "txtIncapacidades";
            this.txtIncapacidades.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtIncapacidades.Size = new System.Drawing.Size(500, 40);
            this.txtIncapacidades.TabIndex = 13;
            // 
            // lblIncapacidades
            // 
            this.lblIncapacidades.AutoSize = true;
            this.lblIncapacidades.Location = new System.Drawing.Point(10, 380);
            this.lblIncapacidades.Name = "lblIncapacidades";
            this.lblIncapacidades.Size = new System.Drawing.Size(86, 18);
            this.lblIncapacidades.TabIndex = 12;
            this.lblIncapacidades.Text = "Incapacidades";
            // 
            // txtHorasExtra
            // 
            this.txtHorasExtra.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHorasExtra.Location = new System.Drawing.Point(150, 480);
            this.txtHorasExtra.Multiline = true;
            this.txtHorasExtra.Name = "txtHorasExtra";
            this.txtHorasExtra.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtHorasExtra.Size = new System.Drawing.Size(500, 40);
            this.txtHorasExtra.TabIndex = 17;
            // 
            // lblHorasExtra
            // 
            this.lblHorasExtra.AutoSize = true;
            this.lblHorasExtra.Location = new System.Drawing.Point(12, 480);
            this.lblHorasExtra.Name = "lblHorasExtra";
            this.lblHorasExtra.Size = new System.Drawing.Size(71, 18);
            this.lblHorasExtra.TabIndex = 16;
            this.lblHorasExtra.Text = "Horas Extra";
            // 
            // txtNomina
            // 
            this.txtNomina.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomina.Location = new System.Drawing.Point(150, 220);
            this.txtNomina.Multiline = true;
            this.txtNomina.Name = "txtNomina";
            this.txtNomina.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNomina.Size = new System.Drawing.Size(500, 100);
            this.txtNomina.TabIndex = 9;
            // 
            // lblNomina
            // 
            this.lblNomina.AutoSize = true;
            this.lblNomina.Location = new System.Drawing.Point(12, 220);
            this.lblNomina.Name = "lblNomina";
            this.lblNomina.Size = new System.Drawing.Size(107, 18);
            this.lblNomina.TabIndex = 8;
            this.lblNomina.Text = "Recibo de nómina";
            // 
            // txtEmpleados
            // 
            this.txtEmpleados.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmpleados.Location = new System.Drawing.Point(150, 170);
            this.txtEmpleados.Multiline = true;
            this.txtEmpleados.Name = "txtEmpleados";
            this.txtEmpleados.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtEmpleados.Size = new System.Drawing.Size(500, 40);
            this.txtEmpleados.TabIndex = 7;
            // 
            // lblEmpleados
            // 
            this.lblEmpleados.AutoSize = true;
            this.lblEmpleados.Location = new System.Drawing.Point(12, 170);
            this.lblEmpleados.Name = "lblEmpleados";
            this.lblEmpleados.Size = new System.Drawing.Size(94, 18);
            this.lblEmpleados.TabIndex = 6;
            this.lblEmpleados.Text = "Lista Empleados";
            // 
            // txtCompanias
            // 
            this.txtCompanias.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanias.Location = new System.Drawing.Point(150, 20);
            this.txtCompanias.Multiline = true;
            this.txtCompanias.Name = "txtCompanias";
            this.txtCompanias.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCompanias.Size = new System.Drawing.Size(500, 40);
            this.txtCompanias.TabIndex = 1;
            this.txtCompanias.Text = "1\r\n2\r\n3";
            // 
            // lblCompanias
            // 
            this.lblCompanias.AutoSize = true;
            this.lblCompanias.Location = new System.Drawing.Point(10, 20);
            this.lblCompanias.Name = "lblCompanias";
            this.lblCompanias.Size = new System.Drawing.Size(65, 18);
            this.lblCompanias.TabIndex = 0;
            this.lblCompanias.Text = "Compañias";
            // 
            // txtTipo
            // 
            this.txtTipo.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipo.Location = new System.Drawing.Point(150, 120);
            this.txtTipo.Multiline = true;
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTipo.Size = new System.Drawing.Size(500, 40);
            this.txtTipo.TabIndex = 5;
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(12, 120);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(94, 18);
            this.lblTipo.TabIndex = 4;
            this.lblTipo.Text = "Tipo de Nómina";
            // 
            // txtClase
            // 
            this.txtClase.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClase.Location = new System.Drawing.Point(150, 70);
            this.txtClase.Multiline = true;
            this.txtClase.Name = "txtClase";
            this.txtClase.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtClase.Size = new System.Drawing.Size(500, 40);
            this.txtClase.TabIndex = 3;
            // 
            // lblClase
            // 
            this.lblClase.AutoSize = true;
            this.lblClase.Location = new System.Drawing.Point(12, 70);
            this.lblClase.Name = "lblClase";
            this.lblClase.Size = new System.Drawing.Size(98, 18);
            this.lblClase.TabIndex = 2;
            this.lblClase.Text = "Clase de Nómina";
            // 
            // txtAccionesTitulos
            // 
            this.txtAccionesTitulos.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccionesTitulos.Location = new System.Drawing.Point(150, 530);
            this.txtAccionesTitulos.Multiline = true;
            this.txtAccionesTitulos.Name = "txtAccionesTitulos";
            this.txtAccionesTitulos.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAccionesTitulos.Size = new System.Drawing.Size(500, 40);
            this.txtAccionesTitulos.TabIndex = 19;
            // 
            // lblAccionesTitulos
            // 
            this.lblAccionesTitulos.AutoSize = true;
            this.lblAccionesTitulos.Location = new System.Drawing.Point(12, 530);
            this.lblAccionesTitulos.Name = "lblAccionesTitulos";
            this.lblAccionesTitulos.Size = new System.Drawing.Size(99, 18);
            this.lblAccionesTitulos.TabIndex = 18;
            this.lblAccionesTitulos.Text = "Acciones Títulos";
            // 
            // txtJubilacionPensionRetiro
            // 
            this.txtJubilacionPensionRetiro.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJubilacionPensionRetiro.Location = new System.Drawing.Point(150, 580);
            this.txtJubilacionPensionRetiro.Multiline = true;
            this.txtJubilacionPensionRetiro.Name = "txtJubilacionPensionRetiro";
            this.txtJubilacionPensionRetiro.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtJubilacionPensionRetiro.Size = new System.Drawing.Size(500, 40);
            this.txtJubilacionPensionRetiro.TabIndex = 21;
            // 
            // lblJubilacionPensionRetiro
            // 
            this.lblJubilacionPensionRetiro.Location = new System.Drawing.Point(12, 580);
            this.lblJubilacionPensionRetiro.Name = "lblJubilacionPensionRetiro";
            this.lblJubilacionPensionRetiro.Size = new System.Drawing.Size(149, 40);
            this.lblJubilacionPensionRetiro.TabIndex = 20;
            this.lblJubilacionPensionRetiro.Text = "Jubilación Pensión \r\nRetiro";
            // 
            // txtSeparacionIndemnizacion
            // 
            this.txtSeparacionIndemnizacion.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeparacionIndemnizacion.Location = new System.Drawing.Point(150, 633);
            this.txtSeparacionIndemnizacion.Multiline = true;
            this.txtSeparacionIndemnizacion.Name = "txtSeparacionIndemnizacion";
            this.txtSeparacionIndemnizacion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSeparacionIndemnizacion.Size = new System.Drawing.Size(500, 40);
            this.txtSeparacionIndemnizacion.TabIndex = 23;
            // 
            // lblSeparacionIndemnizacion
            // 
            this.lblSeparacionIndemnizacion.Location = new System.Drawing.Point(12, 633);
            this.lblSeparacionIndemnizacion.Name = "lblSeparacionIndemnizacion";
            this.lblSeparacionIndemnizacion.Size = new System.Drawing.Size(132, 40);
            this.lblSeparacionIndemnizacion.TabIndex = 22;
            this.lblSeparacionIndemnizacion.Text = "Separación Indemnización";
            // 
            // FrmConfiguracionConsultas
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(684, 562);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlBotones);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FrmConfiguracionConsultas";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuración Consultas";
            this.Load += new System.EventHandler(this.FrmConfiguracionConsultas_Load);
            this.pnlBotones.ResumeLayout(false);
            this.pnlBotones.PerformLayout();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBotones;
        private System.Windows.Forms.Button cmdAceptar;
        private System.Windows.Forms.Button cmdCancelar;
        private System.Windows.Forms.Label lblIndicaciones;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.TextBox txtClase;
        private System.Windows.Forms.Label lblClase;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.TextBox txtCompanias;
        private System.Windows.Forms.Label lblCompanias;
        private System.Windows.Forms.TextBox txtEmpleados;
        private System.Windows.Forms.Label lblEmpleados;
        private System.Windows.Forms.TextBox txtNomina;
        private System.Windows.Forms.Label lblNomina;
        private System.Windows.Forms.TextBox txtHorasExtra;
        private System.Windows.Forms.Label lblHorasExtra;
        private System.Windows.Forms.TextBox txtIncapacidades;
        private System.Windows.Forms.Label lblIncapacidades;
        private System.Windows.Forms.TextBox txtOtrosPagos;
        private System.Windows.Forms.Label lblOtrosPagos;
        private System.Windows.Forms.TextBox txtMetodosPago;
        private System.Windows.Forms.Label lblMetodosPago;
        private System.Windows.Forms.TextBox txtAccionesTitulos;
        private System.Windows.Forms.Label lblAccionesTitulos;
        private System.Windows.Forms.TextBox txtJubilacionPensionRetiro;
        private System.Windows.Forms.Label lblJubilacionPensionRetiro;
        private System.Windows.Forms.TextBox txtSeparacionIndemnizacion;
        private System.Windows.Forms.Label lblSeparacionIndemnizacion;
    }
}
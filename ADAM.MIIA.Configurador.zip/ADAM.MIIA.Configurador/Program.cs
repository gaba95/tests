using ADAM.MIIA.Configurador.UI;

namespace ADAM.MIIA.Configurador;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new frmConfiguracion());
    }
}

﻿using ADAM.Recibos.Controls;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Principal;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Enums;
using ADAM.Recibos.Principal.Test.Fakes;
using ADAM.Recibos.Principal.Test.Helpers;
using ADAM.Recibos.Utilerias.Enums;
using System.Collections.Concurrent;
using System.IO.Compression;
using System.Reflection;
using System.Xml;

namespace ADAM.Recibos.Principal.Test.Classes
{

    [TestClass]
    public class GenerateXmlTest
    {

        [TestInitialize]
        public void TestInit()
        {
            CustomMessageBox.SuppressUI = true;
        }

        [TestCleanup]
        public void TestCleanup()
        {
            CustomMessageBox.SuppressUI = false;
        }

        [TestMethod]
        public void Constructor_NullAppSettings_ThrowsArgumentNullException()
        {
            var ex = Assert.Throws<ArgumentNullException>(() =>
                new GenerateXml(
                    TipoPlataforma.SQLServer,
                    null!,
                    new Trabajadores(),
                    compania: "CBS",
                    conceptoFactura: "X",
                    metodoPagoDefault: "01",
                    rutaCertificado: @"C:\tmp\a.cer",
                    rutaLlave: @"C:\tmp\a.key",
                    passwordLlave: "Test1234!"
                )
            );

            StringAssert.Contains(ex.Message, "appSettings");
        }

        [TestMethod]
        public void Constructor_NullWorkerList_ThrowsArgumentNullException()
        {
            var ex = Assert.Throws<ArgumentNullException>(() =>
                new GenerateXml(
                    TipoPlataforma.SQLServer,
                    new FakeAppSettings().With("applicationUser", "test"),
                    null!,
                    compania: "CBS",
                    conceptoFactura: "X",
                    metodoPagoDefault: "01",
                    rutaCertificado: @"C:\tmp\a.cer",
                    rutaLlave: @"C:\tmp\a.key",
                    passwordLlave: "Test1234!"
                )
            );

            StringAssert.Contains(ex.Message, "listaTrabajadores");
        }

        [TestMethod]
        public void Constructor_EmptyCompany_ThrowArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() =>
                new GenerateXml(
                    TipoPlataforma.SQLServer,
                    new FakeAppSettings().With("aplicationUser", "unit_test_user"),
                    new Trabajadores(),
                    compania: "",
                    conceptoFactura: "X",
                    metodoPagoDefault: "01",
                    rutaCertificado: @"C:\tmp\a.cer",
                    rutaLlave: @"C:\tmp\a.key",
                    passwordLlave: "Test1234!"
                )
            );

            StringAssert.Contains(ex.Message, "compania");
        }

        [TestMethod]
        public void Constructor_EmptyInvoiceConcept_ThrowArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() =>
                new GenerateXml(
                    TipoPlataforma.SQLServer,
                    new FakeAppSettings().With("aplicationUser", "unit_test_user"),
                    new Trabajadores(),
                    compania: "CBS",
                    conceptoFactura: "",
                    metodoPagoDefault: "01",
                    rutaCertificado: @"C:\tmp\a.cer",
                    rutaLlave: @"C:\tmp\a.key",
                    passwordLlave: "Test1234!"
                )
            );

            StringAssert.Contains(ex.Message, "conceptoFactura");
        }

        [TestMethod]
        public void Constructor_EmptyPaymentMethod_ThrowArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() =>
                new GenerateXml(
                    TipoPlataforma.SQLServer,
                    new FakeAppSettings().With("aplicationUser", "unit_test_user"),
                    new Trabajadores(),
                    compania: "CBS",
                    conceptoFactura: "X",
                    metodoPagoDefault: "",
                    rutaCertificado: @"C:\tmp\a.cer",
                    rutaLlave: @"C:\tmp\a.key",
                    passwordLlave: "Test1234!"
                )
            );

            StringAssert.Contains(ex.Message, "metodoPagoDefault");
        }

        [TestMethod]
        public void BuildXmlFile_MultipleFilesFalse_InvalidDirectory_ReturnsErrorMessage()
        {
            var build = GenerateXmlTestFactory.Create();
            var method = typeof(GenerateXml).GetMethod(
                "BuildXmlFile", BindingFlags.NonPublic | BindingFlags.Instance);

            var result = ((string message, string filepath, bool success))method!.Invoke(
                build,
                new object[] { "0001", "<xml/>", @"Z:\no\such\dir", "test.xml", false })!;

            StringAssert.Contains(result.message, "Error al escribir archivo para trabajador 0001");
            Assert.IsFalse(result.success);
        }

        [TestMethod]
        public void BuildXmlFile_MultipleFilesTrue_InvalidDirectory_ReturnsExceptionMessage()
        {
            var build = GenerateXmlTestFactory.Create();
            var method = typeof(GenerateXml).GetMethod(
                "BuildXmlFile", BindingFlags.NonPublic | BindingFlags.Instance);

            var result = ((string message, string filepath, bool success))method!.Invoke(
                build,
                new object[] { "0001", "<xml/>", @"Z:\no\such\dir", "test.xml", true })!;

            Assert.AreEqual(string.Empty, result.filepath);
            Assert.IsFalse(string.IsNullOrEmpty(result.message), "Should contain exception message");
            Assert.IsFalse(result.success);
        }

        [TestMethod]
        public void BuildXmlFile_MultipleFilesTrue_CreatesFile()
        {
            var build = GenerateXmlTestFactory.Create(); 
            var type = build.GetType(); 

            var outputDirectory = new TestTempDirectory("GenerateXmlTest"); 
            var trabajador = "0002"; 
            var xmlEnviar = "<nomina><a>2<a/></nomina>"; 
            var nombreArchivo = "2025_01_ADAM.xml"; // Find the private method

            var method = type.GetMethod( "BuildXmlFile", BindingFlags.NonPublic | BindingFlags.Instance ); // Invoke it

            var result = ((string message, string filepath, bool success))method.Invoke(
                build, 
                new object[] {
                    trabajador,
                    xmlEnviar,
                    outputDirectory.PathValue, 
                    nombreArchivo, 
                    true 
                } );

            Assert.IsTrue(File.Exists(result.filepath), "Debió crear un archivo individual");
            var fileText = File.ReadAllText(result.filepath);
            StringAssert.Contains(fileText, "<nomina>");
            Assert.IsTrue(result.success);

        }

        [TestMethod]
        public void BuildXmlFile_MultipleFilesFalse_Appends_AndRemovesXmlHeader()
        {
            // Arrange
            var build = GenerateXmlTestFactory.Create();
            var type = build.GetType();

            var outputDirectory = new TestTempDirectory("GenerateXmlTest");

            // First XML
            var xml = "<?xmlVersion=\"1.0\" enconding=\"utf-8\"?><nomina><a>1</a></nomina>";

            // Locate the private method once
            var method = type.GetMethod(
                "BuildXmlFile",
                BindingFlags.NonPublic | BindingFlags.Instance
            );

            // Invoke #1
            var result = ((string message, string filepath, bool success))method.Invoke(
                build,
                new object[]
                {
                    "0001",
                    xml,
                    outputDirectory.PathValue,
                    "previo.xml",
                    false
                }
            );

            // Second XML
            var xml2 = "<?xmlVersion=\"1.0\" enconding=\"utf-8\"?><nomina><a>2</a></nomina>";

            // Invoke #2
            var result2 = ((string message, string filepath, bool success))method.Invoke(
                build,
                new object[]
                {
                    "0001",
                    xml2,
                    outputDirectory.PathValue,
                    "previo.xml",
                    false
                }
            );

            Assert.AreEqual(result.filepath, result2.filepath, "Debe ser el mismo archivo previo");

            var fullContent = File.ReadAllText(result.filepath);

            Assert.IsFalse(fullContent.Contains("<?xml version=\"1.0\""), "No debe quedar encabezado");
            StringAssert.Contains(fullContent, "<a>1</a>");
            StringAssert.Contains(fullContent, "<a>2</a>");

        }

        [TestMethod]
        public void XsdTemplates_WhiteList_MustBeValid()
        {
            var expectedKeys = new[]
            {
                "catCFDI.xsd",
                "catNomina.xsd",
                "cfdv40.xsd",
                "tdCFDI.xsd",
                "nomina12.xsd",
                "nomina12_40ADAM.xsd",
                "nomina12_40ADAM_ext.xsd"
            };

            WhiteListAssertions.AssertContainsExpectedKeysAndSameValues(
                XsdTemplates.xsdWhiteList,
                "xsdWhiteList",
                expectedKeys);

            WhiteListAssertions.AssertNoEmptyOrWhitespaceKeyAndValues(
                XsdTemplates.xsdWhiteList,
                "xsdWhiteList");
        }

        [TestMethod]
        public void XslTemplates_WhiteList_MustBeValid()
        {
            var expectedKeys = new[]
            {
                "nomina12_40ADAM.xslt",
                "nomina12_40ADAMEle.xslt",
                "nomina12_40ADAMExp.xslt",
                "nomina12_40ADAM_ext.xsd",
                "remision52ADAM.xslt",
                "nomina12_33Benavides.xslt"
            };

            WhiteListAssertions.AssertContainsExpectedKeysAndSameValues(
                XslTemplates.xslWhiteList,
                "xslWhiteList",
                expectedKeys);

            WhiteListAssertions.AssertNoEmptyOrWhitespaceKeyAndValues(
                XslTemplates.xslWhiteList,
                "xslWhiteList");
        }

        [TestMethod]
        public void Run_EmptyWorkerList_ShouldThrowDirectoryNotFoundException()
        {
            // Arrange — empty Trabajadores causes Parallel.ForEach to skip,
            // then ZipFile.CreateFromDirectory fails on non-existent path
            var build = GenerateXmlTestFactory.Create();

            // Act & Assert
            var ex = Assert.Throws<DirectoryNotFoundException>(() =>
                build.Run(
                    objetoCallBack: null,
                    generaArchivosPrevio: true,
                    archivoXSLT: "nomina12_40ADAM.xslt",
                    archivoXSD: "nomina12.xsd",
                    validaXSD: false,
                    rutaGenerador: @"C:\nonexistent\generador",
                    rutaArchivosSalida: @"C:\nonexistent\output",
                    generarMultiplesArchivos: true,
                    generaDatosAdicionales: false,
                    procedimientoAdicionales: string.Empty,
                    fPreviousExecutionState: 0,
                    protectorPantallaActivo: 0,
                    nullVar: 0,
                    defaultEndpoint: "http://localhost",
                    defaultTimeout: 30
                ).GetAwaiter().GetResult()
            );

            Assert.IsNotNull(ex);
        }

        [TestMethod]
        public void Run_EmptyWorkerList_WithScreenSaverActive_ShouldThrowDirectoryNotFoundException()
        {
            // Arrange — covers the protectorPantallaActivo == 1 branch
            var build = GenerateXmlTestFactory.Create();

            // Act & Assert
            var ex = Assert.Throws<DirectoryNotFoundException>(() =>
                build.Run(
                    objetoCallBack: null,
                    generaArchivosPrevio: true,
                    archivoXSLT: "nomina12_40ADAM.xslt",
                    archivoXSD: "nomina12.xsd",
                    validaXSD: false,
                    rutaGenerador: @"C:\nonexistent\generador",
                    rutaArchivosSalida: @"C:\nonexistent\output",
                    generarMultiplesArchivos: true,
                    generaDatosAdicionales: false,
                    procedimientoAdicionales: string.Empty,
                    fPreviousExecutionState: 0,
                    protectorPantallaActivo: 1,
                    nullVar: 0,
                    defaultEndpoint: "http://localhost",
                    defaultTimeout: 30
                ).GetAwaiter().GetResult()
            );

            Assert.IsNotNull(ex);
        }

        [TestMethod]
        public void Run_EmptyWorkerList_NotMultipleFiles_ShouldComplete()
        {
            // Arrange — generarMultiplesArchivos = false covers the single-file branch
            // (File.AppendAllText for closing node, and single-file open path)
            using var outputDir = new TestTempDirectory("RunTest");
            var build = GenerateXmlTestFactory.Create();

            // Act — should complete without error for empty worker list
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: @"C:\nonexistent\generador",
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: false,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — verify output files were created
            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip file should be created");
        }

        [TestMethod]
        public void Run_MaxDegreeOfParallelism_SetBasedOnProcessorCount()
        {
            // Arrange
            using var outputDir = new TestTempDirectory("RunMaxDOP");
            var build = GenerateXmlTestFactory.Create();

            // Act — Run with empty workers to execute MaxDegreeOfParallelism assignment
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: @"C:\nonexistent\generador",
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — verify MaxDegreeOfParallelism = (ProcessorCount - 1) * 10
            var prop = typeof(GenerateXml).GetProperty("MaxDegreeOfParallelism",
                BindingFlags.NonPublic | BindingFlags.Instance);
            var actual = (int)prop!.GetValue(build)!;
            var expected = (Environment.ProcessorCount - 1) * 10;

            Assert.AreEqual(expected, actual,
                $"MaxDegreeOfParallelism should be (ProcessorCount({Environment.ProcessorCount}) - 1) * 10 = {expected}");
        }

        [TestMethod]
        public void Run_NotMultipleFiles_AppendClosingNominasTag()
        {
            // Arrange — !generarMultiplesArchivos creates <appUser>_Previo.xml
            // and appends </nominas> closing tag
            using var outputDir = new TestTempDirectory("RunClosingNode");
            var settings = new FakeAppSettings()
                .With("applicationUser", "test_closing_user");
            var build = GenerateXmlTestFactory.Create(settings: settings);

            // Act
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: @"C:\nonexistent\generador",
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: false,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — verify Previo.xml exists and contains closing tag
            var previoPath = Path.Combine(outputDir.PathValue, "test_closing_user_Previo.xml");
            Assert.IsTrue(File.Exists(previoPath), "Previo.xml should exist");

            var content = File.ReadAllText(previoPath);
            StringAssert.Contains(content, "</nominas>",
                "Previo.xml should contain the </nominas> closing tag");
        }

        [TestMethod]
        public void Run_NotMultipleFiles_PrevioFileNameUsesApplicationUser()
        {
            // Arrange — verify the file name pattern uses applicationUser from settings
            using var outputDir = new TestTempDirectory("RunPrevioName");
            var customUser = "mi_usuario_prueba";
            var settings = new FakeAppSettings()
                .With("applicationUser", customUser);
            var build = GenerateXmlTestFactory.Create(settings: settings);

            // Act
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: @"C:\nonexistent\generador",
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: false,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — the Previo.xml should be named <applicationUser>_Previo.xml
            var expectedFile = Path.Combine(outputDir.PathValue, $"{customUser}_Previo.xml");
            Assert.IsTrue(File.Exists(expectedFile),
                $"Expected file '{customUser}_Previo.xml' was not created");
        }

        [TestMethod]
        public void Run_MultipleFiles_CreatesZipFromOutputDirectory()
        {
            // Arrange — generarMultiplesArchivos = true, verifies zip creation
            using var outputDir = new TestTempDirectory("RunZipMulti");
            var build = GenerateXmlTestFactory.Create();

            // Act
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — zip file should exist and be a valid zip archive
            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip file should be created");

            using var archive = ZipFile.OpenRead(zipFile);
            Assert.IsNotNull(archive, "Should be a valid zip archive");
        }

        [TestMethod]
        public void Run_NotMultipleFiles_ZipContainsPrevioXml()
        {
            // Arrange — verify the zip contains the Previo.xml file
            using var outputDir = new TestTempDirectory("RunZipPrevio");
            var settings = new FakeAppSettings()
                .With("applicationUser", "zip_user");
            var build = GenerateXmlTestFactory.Create(settings: settings);

            // Act
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: @"C:\nonexistent\generador",
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: false,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — zip should contain the Previo.xml
            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip file should be created");

            using var archive = ZipFile.OpenRead(zipFile);
            var previoEntry = archive.Entries
                .FirstOrDefault(e => e.Name == "zip_user_Previo.xml");
            Assert.IsNotNull(previoEntry,
                "Zip should contain zip_user_Previo.xml");
        }

        [TestMethod]
        public void Run_MultipleFiles_ScreenSaverReactivated_ShouldComplete()
        {
            // Arrange — protectorPantallaActivo == 1 triggers SystemParametersInfo call
            // Verifies the screen saver branch doesn't prevent completion
            using var outputDir = new TestTempDirectory("RunScreenSaver");
            var build = GenerateXmlTestFactory.Create();

            // Act
            build.Run(
                objetoCallBack: null,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 1,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            // Assert — completes successfully and zip exists
            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip file should be created after screen saver reactivation");
        }

        #region ProcessResultWorkersFile Tests

        private static MethodInfo GetProcessResultWorkersFileMethod()
        {
            return typeof(GenerateXml).GetMethod(
                "ProcessResultWorkersFile",
                BindingFlags.NonPublic | BindingFlags.Instance)!;
        }

        private static CallBackThread CreateNoOpCallBackThread()
        {
            return new CallBackThread(
                null!,
                () => Task.CompletedTask,
                (string s, bool r) => { });
        }

        [TestMethod]
        public void ProcessResultWorkersFile_EmptyFileList_ReturnsEmptyResult()
        {
            // Arrange — empty file list covers initialization, UpdateUI,
            // empty Parallel.ForEach, and the post-loop message + return
            var build = GenerateXmlTestFactory.Create();
            var callBack = CreateNoOpCallBackThread();
            var method = GetProcessResultWorkersFileMethod();

            // Act — method returns void after S3241 fix
            method.Invoke(build,
                new object[] { callBack, new ConcurrentBag<string>(), "http://localhost", 30 });

            // Assert — method completed without exception for empty list
            Assert.IsNotNull(build);
        }

        [TestMethod]
        public void ProcessResultWorkersFile_XmlWithoutNominaNodes_ReturnsEmptyResult()
        {
            // Arrange — XML without <nomina> nodes covers xmlDocument.Load,
            // SelectNodes (empty), empty batches, no SendMessage calls
            using var tempDir = new TestTempDirectory("ProcessResultNoNomina");
            var xmlPath = Path.Combine(tempDir.PathValue, "test.xml");
            File.WriteAllText(xmlPath, "<?xml version=\"1.0\"?><root><item>test</item></root>");

            var build = GenerateXmlTestFactory.Create();
            var callBack = CreateNoOpCallBackThread();
            var method = GetProcessResultWorkersFileMethod();

            // Act — method returns void after S3241 fix
            method.Invoke(build,
                new object[] { callBack, new ConcurrentBag<string>(new[] { xmlPath }), "http://localhost", 30 });

            // Assert — XML file was loaded but no nomina nodes processed
            Assert.IsTrue(File.Exists(xmlPath));
        }

        [TestMethod]
        public void ProcessResultWorkersFile_NonExistentFile_ThrowsAggregateException()
        {
            // Arrange — non-existent file causes xmlDocument.Load to throw,
            // Parallel.ForEach wraps it in AggregateException (no MessageBox reached)
            var build = GenerateXmlTestFactory.Create();
            var callBack = CreateNoOpCallBackThread();
            var method = GetProcessResultWorkersFileMethod();

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                method.Invoke(build,
                    new object[] { callBack, new ConcurrentBag<string>(new[] { @"C:\nonexistent\file.xml" }), "http://localhost", 30 }));

            Assert.IsInstanceOfType<AggregateException>(ex.InnerException);
        }

        [TestMethod]
        public void ProcessResultWorkersFile_XmlWithNominaNodes_ProcessesBatchesAndReturnsResults()
        {
            // Arrange — XML with <nomina> nodes covers the full ForEach body:
            // Load, SelectNodes, Cast, BatchTasks, inner foreach,
            // SendMessageAndUpdateUi, Task.WhenAll, result.AddRange
            // EnviaXmlTimbradoAsync catches network errors and returns error message string
            using var tempDir = new TestTempDirectory("ProcessResultNomina");
            var xmlPath = Path.Combine(tempDir.PathValue, "test_nomina.xml");
            File.WriteAllText(xmlPath,
                "<?xml version=\"1.0\"?><nominas><nomina><worker>001</worker></nomina></nominas>");

            var build = GenerateXmlTestFactory.Create();
            var callBack = CreateNoOpCallBackThread();
            var method = GetProcessResultWorkersFileMethod();

            // Act — endpoint is unreachable but WebServiceHelper.EnviaXmlTimbrado
            // catches exceptions internally; method returns void after S3241 fix
            method.Invoke(build,
                new object[] { callBack, new ConcurrentBag<string>(new[] { xmlPath }), "http://localhost:9999", 1 });

            // Assert — XML file with nomina nodes was processed without exception
            Assert.IsTrue(File.Exists(xmlPath));
        }

        #endregion

        #region BatchTasks Tests

        private static MethodInfo GetBatchTasksMethod()
        {
            return typeof(GenerateXml).GetMethod(
                "BatchTasks",
                BindingFlags.NonPublic | BindingFlags.Static)!
                .MakeGenericMethod(typeof(string));
        }

        [TestMethod]
        public void BatchTasks_EmptyList_ReturnsNoBatches()
        {
            var method = GetBatchTasksMethod();

            var result = ((IEnumerable<IEnumerable<string>>)method.Invoke(null,
                new object[] { Enumerable.Empty<string>(), 3 })!).ToList();

            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void BatchTasks_FewerItemsThanBatchSize_ReturnsSingleBatch()
        {
            var method = GetBatchTasksMethod();
            var items = new[] { "a", "b" };

            var result = ((IEnumerable<IEnumerable<string>>)method.Invoke(null,
                new object[] { items.AsEnumerable(), 5 })!).ToList();

            Assert.AreEqual(1, result.Count);
            CollectionAssert.AreEqual(new[] { "a", "b" }, result[0].ToList());
        }

        [TestMethod]
        public void BatchTasks_ExactBatchSize_ReturnsSingleBatch()
        {
            var method = GetBatchTasksMethod();
            var items = new[] { "a", "b", "c" };

            var result = ((IEnumerable<IEnumerable<string>>)method.Invoke(null,
                new object[] { items.AsEnumerable(), 3 })!).ToList();

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(3, result[0].Count());
        }

        [TestMethod]
        public void BatchTasks_MoreItemsThanBatchSize_ReturnsMultipleBatches()
        {
            var method = GetBatchTasksMethod();
            var items = new[] { "1", "2", "3", "4", "5" };

            var result = ((IEnumerable<IEnumerable<string>>)method.Invoke(null,
                new object[] { items.AsEnumerable(), 2 })!).ToList();

            Assert.AreEqual(3, result.Count, "5 items / batch 2 = 3 batches");
            CollectionAssert.AreEqual(new[] { "1", "2" }, result[0].ToList());
            CollectionAssert.AreEqual(new[] { "3", "4" }, result[1].ToList());
            CollectionAssert.AreEqual(new[] { "5" }, result[2].ToList());
        }

        #endregion

        #region GetXmlNamespaceManager Tests

        [TestMethod]
        public void GetXmlNamespaceManager_ReturnsCfdiNamespace()
        {
            var method = typeof(GenerateXml).GetMethod(
                "GetXmlNamespaceManager",
                BindingFlags.NonPublic | BindingFlags.Static)!;

            var xmlDoc = new XmlDocument();
            xmlDoc.LoadXml("<root/>");

            var nsmgr = (XmlNamespaceManager)method.Invoke(null, new object[] { xmlDoc })!;

            Assert.AreEqual("http://www.sat.gob.mx/cfd/4", nsmgr.LookupNamespace("cfdi"));
        }

        #endregion

        #region EnviaXmlTimbradoAsync Tests

        private static MethodInfo GetEnviaXmlTimbradoAsyncMethod()
        {
            return typeof(GenerateXml).GetMethod(
                "EnviaXmlTimbradoAsync",
                BindingFlags.NonPublic | BindingFlags.Instance)!;
        }

        [TestMethod]
        public void EnviaXmlTimbradoAsync_ValidCfdiXml_ExtractsRfcAndNombre()
        {
            // Arrange — valid cfdi:Receptor with namespace covers the try path
            var build = GenerateXmlTestFactory.Create();
            var method = GetEnviaXmlTimbradoAsyncMethod();

            var xml = "<cfdi:Comprobante xmlns:cfdi=\"http://www.sat.gob.mx/cfd/4\">"
                    + "<cfdi:Receptor Rfc=\"XAXX010101000\" Nombre=\"Juan Perez\"/>"
                    + "</cfdi:Comprobante>";

            // Act — endpoint is unreachable; WebServiceHelper catches and returns error
            var task = (Task<string>)method.Invoke(build,
                new object[] { "http://localhost:9999", 1, xml })!;
            var result = task.GetAwaiter().GetResult();

            // Assert — result includes extracted Rfc-Nombre prefix
            StringAssert.StartsWith(result, "Trabajador: XAXX010101000-Juan Perez");
        }

        [TestMethod]
        public void EnviaXmlTimbradoAsync_XmlWithoutNamespace_FallsBackToXDocument()
        {
            // Arrange — no namespace on Receptor forces XmlDocument path to fail,
            // catch block uses XDocument with cfdi namespace which also won't find it
            // so rfc/nombre stay empty
            var build = GenerateXmlTestFactory.Create();
            var method = GetEnviaXmlTimbradoAsyncMethod();

            var xml = "<Comprobante><Receptor Rfc=\"ABC123\" Nombre=\"Test\"/></Comprobante>";

            // Act
            var task = (Task<string>)method.Invoke(build,
                new object[] { "http://localhost:9999", 1, xml })!;
            var result = task.GetAwaiter().GetResult();

            // Assert — no cfdi namespace match, so rfc and nombre are empty
            StringAssert.StartsWith(result, "Trabajador: -");
        }

        [TestMethod]
        public void EnviaXmlTimbradoAsync_XDocumentFallback_ExtractsRfcAndNombre()
        {
            // Arrange — XML where XmlDocument.SelectSingleNode fails (missing Rfc attribute
            // on cfdi:Receptor throws NullReferenceException), catch block uses XDocument
            // and finds the element with cfdi namespace
            var build = GenerateXmlTestFactory.Create();
            var method = GetEnviaXmlTimbradoAsyncMethod();

            // XmlDocument try path: finds cfdi:Receptor but receptorNode.Attributes["Rfc"]
            // returns null -> NullReferenceException -> falls into catch
            // XDocument catch path: finds cfdi:Receptor with Rfc and Nombre via XNamespace
            var xml = "<cfdi:Comprobante xmlns:cfdi=\"http://www.sat.gob.mx/cfd/4\">"
                    + "<cfdi:Receptor Nombre=\"Maria Lopez\"/>"
                    + "</cfdi:Comprobante>";

            // Act
            var task = (Task<string>)method.Invoke(build,
                new object[] { "http://localhost:9999", 1, xml })!;
            var result = task.GetAwaiter().GetResult();

            // Assert — XDocument fallback extracts Nombre but no Rfc
            StringAssert.StartsWith(result, "Trabajador: -Maria Lopez");
        }

        [TestMethod]
        public void EnviaXmlTimbradoAsync_XDocumentFallback_NoReceptor_EmptyRfcAndNombre()
        {
            // Arrange — XML with cfdi namespace but no Receptor element at all.
            // XmlDocument: SelectSingleNode returns null -> NullReferenceException -> catch
            // XDocument: Descendants("Receptor") returns null -> skipped
            var build = GenerateXmlTestFactory.Create();
            var method = GetEnviaXmlTimbradoAsyncMethod();

            var xml = "<cfdi:Comprobante xmlns:cfdi=\"http://www.sat.gob.mx/cfd/4\">"
                    + "<cfdi:Emisor Rfc=\"EMIT010101\" Nombre=\"Emisor\"/>"
                    + "</cfdi:Comprobante>";

            // Act
            var task = (Task<string>)method.Invoke(build,
                new object[] { "http://localhost:9999", 1, xml })!;
            var result = task.GetAwaiter().GetResult();

            // Assert — both rfc and nombre remain empty
            StringAssert.StartsWith(result, "Trabajador: -");
        }

        [TestMethod]
        public void EnviaXmlTimbradoAsync_XDocumentFallback_OnlyRfc_NombreStaysEmpty()
        {
            // Arrange — cfdi:Receptor has only Rfc, no Nombre attribute
            // XmlDocument: finds Receptor but Nombre attribute is null -> NullReferenceException -> catch
            // XDocument: finds Receptor, extracts Rfc, Nombre stays empty
            var build = GenerateXmlTestFactory.Create();
            var method = GetEnviaXmlTimbradoAsyncMethod();

            var xml = "<cfdi:Comprobante xmlns:cfdi=\"http://www.sat.gob.mx/cfd/4\">"
                    + "<cfdi:Receptor Rfc=\"SOLO010101\"/>"
                    + "</cfdi:Comprobante>";

            // Act
            var task = (Task<string>)method.Invoke(build,
                new object[] { "http://localhost:9999", 1, xml })!;
            var result = task.GetAwaiter().GetResult();

            // Assert — rfc extracted, nombre empty
            StringAssert.StartsWith(result, "Trabajador: SOLO010101-");
        }

        #endregion

        #region SendMessageAndUpdateUi Tests

        [TestMethod]
        public void SendMessageAndUpdateUi_CallsEnviaAndReturnsMessage()
        {
            // Arrange — calls EnviaXmlTimbradoAsync then UpdateUI, returns message
            var build = GenerateXmlTestFactory.Create();
            var method = typeof(GenerateXml).GetMethod(
                "SendMessageAndUpdateUi",
                BindingFlags.NonPublic | BindingFlags.Instance)!;

            var callBack = CreateNoOpCallBackThread();

            var xml = "<cfdi:Comprobante xmlns:cfdi=\"http://www.sat.gob.mx/cfd/4\">"
                    + "<cfdi:Receptor Rfc=\"UI010101\" Nombre=\"UITest\"/>"
                    + "</cfdi:Comprobante>";

            // Act
            var task = (Task<string>)method.Invoke(build,
                new object[] { callBack, "http://localhost:9999", 1, xml })!;
            var result = task.GetAwaiter().GetResult();

            // Assert — result starts with the extracted Rfc-Nombre prefix
            StringAssert.StartsWith(result, "Trabajador: UI010101-UITest");
        }

        #endregion

        #region Run with Workers (ForEach body) Tests

        private static Trabajadores CreateSingleWorker(
            string numTrabajador = "001",
            string claseNomina = "Q",
            string tipoNomina = "N",
            int anio = 2025,
            int periodo = 1,
            ManejoNomina manejoNomina = ManejoNomina.periodica,
            int pagoSeparacion = 0,
            bool esTimbradoRelacionado = false,
            int numeroLiquidacion = 0)
        {
            return new Trabajadores
            {
                new Trabajador
                {
                    numTrabajador = numTrabajador,
                    claseNomina = claseNomina,
                    tipoNomina = tipoNomina,
                    anio = anio,
                    periodo = periodo,
                    manejoNomina = manejoNomina,
                    pagoSeparacion = pagoSeparacion,
                    esTimbradoRelacionado = esTimbradoRelacionado,
                    numeroLiquidacion = numeroLiquidacion
                }
            };
        }

        private GenerateXml CreateSutWithFakeWorker(
            FakeBRReciboElectronico fakeBR,
            Trabajadores? workers = null,
            FakeAppSettings? settings = null)
        {
            workers = workers ?? CreateSingleWorker();
            settings = settings ?? (FakeAppSettings)GenerateXmlTestFactory.CreateDefaultAppSettings();
            return GenerateXmlTestFactory.CreateWithFakeBR(fakeBR, workers, settings);
        }

        [TestMethod]
        public void Run_SingleWorker_MultipleFiles_ValidaXSDFalse_CreatesOutputFile()
        {
            // Covers: ForEach body entry, factory call, Nomina construction,
            // ObtenDatasetRecibo, ConvierteDatasetXml, TransformaXml (no XSLT file),
            // DepuraNodosNomina, validaXSD=false (resultadoValidacionXSD=true),
            // extended validations (empty), BuildXmlFile (multiple), resultfilelist.Add,
            // resultadoValidacionXSD=true → contador++, UpdateUI
            using var outputDir = new TestTempDirectory("RunWorker");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip should be created");

            using var archive = ZipFile.OpenRead(zipFile);
            Assert.IsTrue(archive.Entries.Count > 0, "Zip should contain at least one file");
        }

        [TestMethod]
        public void Run_SingleWorker_NotMultipleFiles_CreatesPrevioXml()
        {
            // Covers: ForEach body with generarMultiplesArchivos=false → nombreArchivo="previo.xml",
            // BuildXmlFile appends to Previo.xml, closing </nominas> tag
            using var outputDir = new TestTempDirectory("RunWorkerPrevio");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: false,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var previoPath = Path.Combine(outputDir.PathValue, "unit_test_user_Previo.xml");
            Assert.IsTrue(File.Exists(previoPath), "Previo.xml should be created");
            var content = File.ReadAllText(previoPath);
            StringAssert.Contains(content, "</nominas>");
        }

        [TestMethod]
        public void Run_WorkerInteractiva_SetsConceptoFacturaFromPagoSeparacion()
        {
            // Covers: manejoNomina == ManejoNomina.interactiva branch
            // where ConceptoFactura is set to trabajador.pagoSeparacion
            using var outputDir = new TestTempDirectory("RunInteractiva");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var workers = CreateSingleWorker(
                manejoNomina: ManejoNomina.interactiva,
                pagoSeparacion: 42);
            var sut = CreateSutWithFakeWorker(fakeBR, workers);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip should be created");

            // Verify the filename includes the pagoSeparacion suffix
            using var archive = ZipFile.OpenRead(zipFile);
            var entry = archive.Entries.FirstOrDefault(e => e.Name.Contains("_42_"));
            Assert.IsNotNull(entry,
                "Multiple files with interactiva + pagoSeparacion!=0 should include _42_ in filename");
        }

        [TestMethod]
        public void Run_WorkerInteractiva_PagoSeparacionZero_NoSuffix()
        {
            // Covers: interactiva branch where pagoSeparacion == 0 → no suffix appended
            using var outputDir = new TestTempDirectory("RunInteractivaZero");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var workers = CreateSingleWorker(
                manejoNomina: ManejoNomina.interactiva,
                pagoSeparacion: 0);
            var sut = CreateSutWithFakeWorker(fakeBR, workers);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile));

            using var archive = ZipFile.OpenRead(zipFile);
            var entry = archive.Entries.FirstOrDefault(e => e.Name.EndsWith("_ADAM.xml"));
            Assert.IsNotNull(entry, "Should create file with _ADAM.xml suffix");
            Assert.IsFalse(entry.Name.Contains("_0_"),
                "pagoSeparacion=0 should not add a suffix");
        }

        [TestMethod]
        public void Run_WorkerEsTimbradoRelacionado_ExecutesInsertaNodoPath()
        {
            // Covers: esTimbradoRelacionado == true → PayrollHelper.InsertaNodoTimbradoRelacionado
            using var outputDir = new TestTempDirectory("RunTimbradoRel");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var workers = CreateSingleWorker(esTimbradoRelacionado: true);
            var sut = CreateSutWithFakeWorker(fakeBR, workers);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip should be created even with timbrado relacionado");
        }

        [TestMethod]
        public void Run_GeneraDatosAdicionales_WithData_ExecutesAdicionalesPath()
        {
            // Covers: generaDatosAdicionales == true, non-null dataset with rows
            using var outputDir = new TestTempDirectory("RunAdicionales");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset(),
                DatasetAdicionales = FakeBRReciboElectronico.CreateAdicionalesDataset()
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: true,
                procedimientoAdicionales: "sp_adicionales",
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Zip should be created with adicionales");
        }

        [TestMethod]
        public void Run_GeneraDatosAdicionales_NullDataset_SkipsAdicionales()
        {
            // Covers: generaDatosAdicionales == true but dataset is null → skips InsertaAdicionales
            using var outputDir = new TestTempDirectory("RunAdicionalesNull");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset(),
                DatasetAdicionales = null
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: true,
                procedimientoAdicionales: "sp_adicionales",
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile));
        }

        [TestMethod]
        public void Run_GeneraDatosAdicionales_EmptyDataset_SkipsAdicionales()
        {
            // Covers: generaDatosAdicionales == true but dataset has 0 rows → skips InsertaAdicionales
            using var outputDir = new TestTempDirectory("RunAdicionalesEmpty");
            var emptyDs = new System.Data.DataSet("Empty");
            emptyDs.Tables.Add("adicional");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset(),
                DatasetAdicionales = emptyDs
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: true,
                procedimientoAdicionales: "sp_adicionales",
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile));
        }

        [TestMethod]
        public void Run_ValidaXSDTrue_WithoutXsdFiles_SetsContadorError()
        {
            // Covers: validaXSD == true → ValidaXmlvsXsd (fails without real XSD files),
            // resultadoValidacionXSD = false → contadorError++
            using var outputDir = new TestTempDirectory("RunValidaXSD");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: true,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile), "Should complete even when XSD validation fails");
        }

        [TestMethod]
        public void Run_MultipleWorkers_AllProcessed()
        {
            // Covers: Parallel.ForEach with multiple workers, resultfilelist logic
            using var outputDir = new TestTempDirectory("RunMultiWorkers");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var workers = new Trabajadores
            {
                new Trabajador { numTrabajador = "001", claseNomina = "Q", tipoNomina = "N", anio = 2025, periodo = 1, manejoNomina = ManejoNomina.periodica },
                new Trabajador { numTrabajador = "002", claseNomina = "Q", tipoNomina = "N", anio = 2025, periodo = 1, manejoNomina = ManejoNomina.periodica },
                new Trabajador { numTrabajador = "003", claseNomina = "Q", tipoNomina = "N", anio = 2025, periodo = 1, manejoNomina = ManejoNomina.periodica }
            };
            var sut = CreateSutWithFakeWorker(fakeBR, workers);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile));

            using var archive = ZipFile.OpenRead(zipFile);
            Assert.AreEqual(3, archive.Entries.Count(e => e.Name.EndsWith("_ADAM.xml")),
                "Should have 3 individual XML files for 3 workers");
        }

        [TestMethod]
        public void Run_MultipleFiles_FilenameContainsWorkerFields()
        {
            // Covers: generarMultiplesArchivos filename pattern:
            // {anio}_{periodo}_{claseNomina}_{tipoNomina}_{numTrabajador}_ADAM.xml
            using var outputDir = new TestTempDirectory("RunFilename");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var workers = CreateSingleWorker(
                numTrabajador: "EMP99",
                claseNomina: "S",
                tipoNomina: "E",
                anio: 2025,
                periodo: 6);
            var sut = CreateSutWithFakeWorker(fakeBR, workers);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            using var archive = ZipFile.OpenRead(zipFile);
            var entry = archive.Entries.FirstOrDefault(e => e.Name.EndsWith("_ADAM.xml"));
            Assert.IsNotNull(entry);
            StringAssert.Contains(entry.Name, "2025_6_S_E_EMP99_ADAM.xml");
        }

        [TestMethod]
        public void Run_WorkerWithScreenSaverAndMultipleFlags_Completes()
        {
            // Covers: multiple combined flags with worker processing
            using var outputDir = new TestTempDirectory("RunCombined");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var workers = CreateSingleWorker(
                manejoNomina: ManejoNomina.interactiva,
                pagoSeparacion: 5,
                esTimbradoRelacionado: true);
            var sut = CreateSutWithFakeWorker(fakeBR, workers);
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: true,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 1,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile));

            using var archive = ZipFile.OpenRead(zipFile);
            var entry = archive.Entries.FirstOrDefault(e => e.Name.Contains("_5_"));
            Assert.IsNotNull(entry,
                "Interactiva+pagoSeparacion=5 with timbrado relacionado should create file with _5_ suffix");
        }

        #endregion

        #region Run generaArchivosPrevio=false (Stamp Phase) Tests

        [TestMethod]
        public void Run_GeneraArchivosPrevioFalse_WithWorkers_ExecutesStampPhase()
        {
            // Covers: !generaArchivosPrevio branch → calls ProcessResultWorkersFile
            // ProcessResultWorkersFile fails (XML files lack valid root) but the branch is exercised
            using var outputDir = new TestTempDirectory("RunStampPhase");
            var fakeBR = new FakeBRReciboElectronico
            {
                DatasetRecibo = FakeBRReciboElectronico.CreateMinimalDataset()
            };
            var sut = CreateSutWithFakeWorker(fakeBR);
            var callBack = CreateNoOpCallBackThread();

            var ex = Assert.Throws<AggregateException>(() =>
                sut.Run(
                    objetoCallBack: callBack,
                    generaArchivosPrevio: false,
                    archivoXSLT: "nomina12_40ADAM.xslt",
                    archivoXSD: "nomina12.xsd",
                    validaXSD: false,
                    rutaGenerador: outputDir.PathValue,
                    rutaArchivosSalida: outputDir.PathValue,
                    generarMultiplesArchivos: true,
                    generaDatosAdicionales: false,
                    procedimientoAdicionales: string.Empty,
                    fPreviousExecutionState: 0,
                    protectorPantallaActivo: 0,
                    nullVar: 0,
                    defaultEndpoint: "http://localhost:9999",
                    defaultTimeout: 1
                ).GetAwaiter().GetResult()
            );

            // The stamp phase was entered but ProcessResultWorkersFile failed on invalid XML
            Assert.IsNotNull(ex);
        }

        [TestMethod]
        public void Run_GeneraArchivosPrevioFalse_EmptyWorkers_ExecutesStampPhase()
        {
            // Covers: !generaArchivosPrevio with empty worker list → stamp phase with empty file list
            using var outputDir = new TestTempDirectory("RunStampEmpty");
            var sut = GenerateXmlTestFactory.Create();
            var callBack = CreateNoOpCallBackThread();

            sut.Run(
                objetoCallBack: callBack,
                generaArchivosPrevio: false,
                archivoXSLT: "nomina12_40ADAM.xslt",
                archivoXSD: "nomina12.xsd",
                validaXSD: false,
                rutaGenerador: outputDir.PathValue,
                rutaArchivosSalida: outputDir.PathValue,
                generarMultiplesArchivos: true,
                generaDatosAdicionales: false,
                procedimientoAdicionales: string.Empty,
                fPreviousExecutionState: 0,
                protectorPantallaActivo: 0,
                nullVar: 0,
                defaultEndpoint: "http://localhost",
                defaultTimeout: 30
            ).GetAwaiter().GetResult();

            var zipFile = $"{outputDir.PathValue}.zip";
            Assert.IsTrue(File.Exists(zipFile));
        }

        #endregion

    }
}

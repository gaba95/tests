﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.GeneracionRecibosElectronicos.Enums;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmMapeoCatalogosDIAN : Form
    {
        private const string ColClave = "clave";

        private ICatalogoDian _catalogosDIAN;
        private ICatalogoAdicional _catalogoAdicional;
        private TreeView arbolAuxCatalogo = null;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Institucion { get; set; }

        #region Events

        #region FrmMapeoCatalogosDIAN_Load
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmMapeoCatalogosDIAN_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }
        #endregion 

        /// <summary>
        /// Cambiar Mapeo DIAN
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdCambiar_Click(object sender, EventArgs e)
        {
            if (gridDatosDIAN.RowCount == 0)
                return;

            FrmCambiaMapeoDIAN cambiaMapa = new FrmCambiaMapeoDIAN();
            cambiaMapa.compania = this.compania;
            cambiaMapa.tipoPlataforma = this.tipoPlataforma;
            cambiaMapa.seccion = cboSeccion.SelectedValue.ToString();
            cambiaMapa.campo = cboCampo.SelectedValue.ToString();
            cambiaMapa.claveDian = gridDatosDIAN.CurrentRow.Cells[ColClave].Value.ToString();
            cambiaMapa.descripcion = gridDatosDIAN.CurrentRow.Cells["descripcion"].Value.ToString();
            cambiaMapa.tipo = gridDatosDIAN.CurrentRow.Cells["tipo"].Value.ToString();
            cambiaMapa.FrmMapeoCatalogosDIAN = this;
            cambiaMapa.ShowDialog();

            arbolCatalogos.Nodes.Clear();
            cargaArbolCatalogosByCompany(cboCompania.SelectedValue.ToString());
        }


        private void cmdQuitar_Click(object sender, EventArgs e)
        {
            if (gridDatosDIAN.RowCount == 0)
                return;

            if (gridDatosDIAN.CurrentRow.Cells[ColClave].Value.ToString().Trim() == "")
                return;

            if (MessageBox.Show("¿Esta seguro?", "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                if (_catalogosDIAN.bajaRelacionDatoCatalogoDIAN(gridDatosADAM.CurrentRow.Cells["compania"].Value.ToString(), gridDatosADAM.CurrentRow.Cells["id_campo"].Value.ToString(), gridDatosADAM.CurrentRow.Cells["clave_dian"].Value.ToString(), gridDatosADAM.CurrentRow.Cells["clave_adam"].Value.ToString()))
                    LlenaGridEquivalenciasDIAN(compania, cboCampo.SelectedValue.ToString(), gridDatosDIAN.CurrentRow.Cells[ColClave].Value.ToString());

            arbolCatalogos.Nodes.Clear();
            cargaArbolCatalogosByCompany(cboCompania.SelectedValue.ToString());
        }

        ///// <summary>
        /// Compania Dropdown Events
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboCompania_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboCompania.Tag != null) return;

            compania = cboCompania.SelectedValue.ToString();
            llenaComboSeccion();
            llenaComboCampos(cboSeccion.SelectedValue.ToString());
            llenaGridTablaDIAN(cboCampo.SelectedValue.ToString());
            arbolCatalogos.Nodes.Clear();
            cargaArbolCatalogosByCompany(cboCompania.SelectedValue.ToString());
        }

        private void cboSeccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboSeccion.Tag != null) return;

            llenaComboCampos(cboSeccion.SelectedValue.ToString());
            llenaGridTablaDIAN(cboCampo.SelectedValue.ToString());
        }

        private void cboCampo_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboCampo.Tag != null) return;
            llenaGridTablaDIAN(cboCampo.SelectedValue.ToString());
        }

        private void gridValores_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            cmdCambiar_Click(sender, new EventArgs());
        }

        private void gridDatosSAT_SelectionChanged(object sender, EventArgs e)
        {
            if (gridDatosDIAN.RowCount == 0)
                return;
            LlenaGridEquivalenciasDIAN(compania, cboCampo.SelectedValue.ToString(), gridDatosDIAN.CurrentRow.Cells[ColClave].Value.ToString());
        }

        #endregion

        #region Métodos de la clase

        #region FrmMapeoCatalogosDIAN
        /// <summary>
        /// Constructor
        /// </summary>
        public FrmMapeoCatalogosDIAN()
        {
            InitializeComponent();
        }
        #endregion 

        #region InicializaClase
        /// <summary>
        /// Init Class
        /// </summary>
        private void InicializaClase()
        {
            _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            // PTF-4277 Config Catalogs by Institution
            lblTitulo.Text = String.Format("Mapeo de Catálogos ADAM - {0}", this.Institucion);
            lblDatosDIAN.Text = String.Format("Catálogo {0}", this.Institucion);
            lblArbol.Location = new System.Drawing.Point(pnlPrincipal.Width - 310, 104);
            lblArbol.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblArbol.Dock = DockStyle.None;

            // Fill Company Dropdown
            this.cboCompania.Tag = true;
            cboCompania.DataSource = _catalogoAdicional.obtenDatasetCompanias(LanguageCodes.Colombia).Tables[0];
            cboCompania.DisplayMember = "nombre_cia";
            cboCompania.ValueMember = "compania";
            cboCompania.Tag = null;

            // Select Default Company
            if (!string.IsNullOrEmpty(compania))
            { cboCompania.SelectedItem = compania; }
            compania = cboCompania.SelectedValue.ToString();

            // Fill Seccion Combo
            llenaComboSeccion();
            if (cboSeccion.Items.Count > 0)
            {
                // Fill Fields Combo
                llenaComboCampos(cboSeccion.SelectedValue.ToString());

                // Fill Tabla ADAM Grid
                llenaGridTablaDIAN(cboCampo.SelectedValue.ToString());
                if (cboCampo.Items.Count > 0)
                {
                    // Fill DIAN Grid automatically
                    llenaGridTablaDIAN(cboCampo.SelectedValue.ToString());

                    // Fill DIAN Mapping automatically
                    LlenaGridEquivalenciasDIAN(compania, cboCampo.SelectedValue.ToString(), gridDatosDIAN.CurrentRow.Cells[ColClave].Value.ToString());
                }
            }
            //Fill aux treeview for structure reference
            arbolAuxCatalogo = new TreeView();
            cargaArbolAux();
            //Fill treeview
            cargaArbolCatalogosByCompany(compania);
        }
        #endregion

        #region llenaArbolCatalogos
        /// <summary>
        /// Loads data into catalogs tree nodes
        /// </summary>
        /// <param></param>
        private void cargaArbolCatalogos()
        {
            DataSet mapped = _catalogosDIAN.obtenDatasetTreeViewCatalogosDIAN();

            if (mapped.Tables[0].Rows.Count > 0)
            {
                arbolCatalogos.Nodes.Clear();

                foreach (DataRow map in mapped.Tables[0].Rows)
                {
                    TreeNode selectedCom = new TreeNode();
                    //look for node in root
                    TreeNode[] com = arbolCatalogos.Nodes.Find(map["compania"].ToString(), false);
                    if (com.Length > 0)
                    {
                        selectedCom = com[0];
                    }
                    else
                    {
                        selectedCom = new TreeNode();
                        selectedCom.Text = map["compania"].ToString() + " - " + map["nombre_cia"].ToString();
                        selectedCom.Name = map["compania"].ToString();
                        selectedCom.Tag = map["compania"].ToString();

                        arbolCatalogos.Nodes.Add(selectedCom);
                    }

                    cargaSeccionNode(selectedCom, map);
                }

                arbolCatalogos.ExpandAll();
                arbolCatalogos.SelectedNode = arbolCatalogos.Nodes[0];
            }
        }
        /// <summary>
        /// Loads data into catalogs tree nodes
        /// </summary>
        /// <param></param>
        private void cargaArbolCatalogosByCompany(string company)
        {
            DataSet mapped = _catalogosDIAN.obtenDatasetTreeViewCatalogosDIANByCompany(company);

            if (mapped.Tables[0].Rows.Count > 0)
            {
                arbolCatalogos.Nodes.Clear();

                foreach (DataRow map in mapped.Tables[0].Rows)
                {
                    TreeNode selectedCom = new TreeNode();
                    //look for node in root
                    TreeNode[] com = arbolCatalogos.Nodes.Find(map["compania"].ToString(), false);
                    if (com.Length > 0)
                    {
                        selectedCom = com[0];
                    }
                    else
                    {
                        selectedCom = new TreeNode();
                        selectedCom.Text = map["compania"].ToString() + " - " + map["nombre_cia"].ToString();
                        selectedCom.Name = map["compania"].ToString();
                        selectedCom.Tag = map["compania"].ToString();

                        arbolCatalogos.Nodes.Add(selectedCom);
                    }

                    cargaSeccionNode(selectedCom, map);
                }

                arbolCatalogos.ExpandAll();
                arbolCatalogos.SelectedNode = arbolCatalogos.Nodes[0];

                CollapsePenultimateLevelNodes(arbolCatalogos.Nodes);
            }
        }
        /// <summary>
        /// Loop Recursivily in every node of the Treeview, Collapsing all nodes where the child nodes dont have any child
        /// </summary>
        /// <param name="nodes"></param>
        private void CollapsePenultimateLevelNodes(TreeNodeCollection nodes)
        {
            foreach (TreeNode tn in nodes)
            {
                if (tn.Nodes.Count == 0)
                {
                    tn.Parent.Collapse();

                }
                else
                {
                    CollapsePenultimateLevelNodes(tn.Nodes);
                }
            }
        }
        /// <summary>
        /// Loads data into catalogs tree nodes
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="map"></param>
        private void cargaSeccionNode(TreeNode parent, DataRow map)
        {
            TreeNode seccion = new TreeNode();
            TreeNode campo = new TreeNode();
            //look for field in arbolAuxCatalogo
            TreeNode[] auxCampo = arbolAuxCatalogo.Nodes.Find(map["id_campo"].ToString(), true);
            if (auxCampo.Length > 0)
            {
                //look for section in company's nodes based on auxCampo's parent
                TreeNode[] auxSeccion = parent.Nodes.Find(auxCampo[0].Parent.Name, false);
                if (auxSeccion.Length > 0)
                {
                    seccion = auxSeccion[0];
                    //look for field in section's nodes
                    TreeNode[] treeCampo = seccion.Nodes.Find(auxCampo[0].Name, false);
                    if (treeCampo.Length > 0)
                    {
                        campo = treeCampo[0];
                    }
                    else
                    {
                        campo.Text = auxCampo[0].Text;
                        campo.Name = auxCampo[0].Name;
                        seccion.Nodes.Add(campo);
                    }
                }
                else
                {
                    seccion.Text = auxCampo[0].Parent.Text;
                    seccion.Name = auxCampo[0].Parent.Name;
                    parent.Nodes.Add(seccion);

                    campo.Text = auxCampo[0].Text;
                    campo.Name = auxCampo[0].Name;
                    seccion.Nodes.Add(campo);

                }

                cargaCampoNode(campo, map);
            }
        }
        /// <summary>
        /// Loads data into catalogs tree nodes
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="map"></param>
        private void cargaCampoNode(TreeNode parent, DataRow map)
        {
            TreeNode mapped = new TreeNode();
            mapped.Text = map["clave_dian"].ToString() + "-" + map["clave_adam"].ToString();
            mapped.Name = map["clave_dian"].ToString() + "-" + map["clave_adam"].ToString();
            mapped.Tag = map["clave_dian"].ToString() + "-" + map["clave_adam"].ToString();

            TreeNode claveDIAN = new TreeNode();
            claveDIAN.Text = "Clave DIAN: " + map["clave_dian"].ToString();
            claveDIAN.Name = map["clave_dian"].ToString();
            claveDIAN.Tag = map["clave_dian"].ToString();

            mapped.Nodes.Add(claveDIAN);

            TreeNode claveADAM = new TreeNode();
            claveADAM.Text = "Clave ADAM: " + map["clave_adam"].ToString();
            claveADAM.Name = map["clave_adam"].ToString();
            claveADAM.Tag = map["clave_adam"].ToString();

            mapped.Nodes.Add(claveADAM);

            parent.Nodes.Add(mapped);
        }
        /// <summary>
        /// Fills the aux tree used for reference
        /// </summary>
        /// <param></param>
        private void cargaArbolAux()
        {
            if (cboSeccion.Items.Count > 0)
            {
                DataTable _arbolAuxCatalogo = _catalogosDIAN.obtenDataSetCatalogosAux().Tables[0];

                foreach (DataRowView secc in cboSeccion.Items)
                {
                    TreeNode seccion = new TreeNode();
                    seccion.Text = secc[ColClave].ToString();
                    seccion.Name = secc[ColClave].ToString();

                    foreach (DataRow cam in _arbolAuxCatalogo.Select("id_padre = '" + seccion.Text + "'"))
                    {
                        TreeNode t = new TreeNode();
                        t.Text = cam["descripcion"].ToString();
                        t.Name = cam[ColClave].ToString();

                        seccion.Nodes.Add(t);
                    }

                    arbolAuxCatalogo.Nodes.Add(seccion);

                }
            }
        }
        #endregion

        #region llenaComboSeccion
        /// <summary>
        /// Fill Combo Seccion
        /// </summary>
        private void llenaComboSeccion()
        {
            // Set Tag to avoid events 
            this.cboSeccion.Tag = true;

            // Fill Combo
            cboSeccion.ValueMember = ColClave;
            cboSeccion.DisplayMember = "descripcion";
            cboSeccion.DataSource = _catalogosDIAN.dsListaSeccionesDIAN("query").Tables[0];

            // Set Tag
            this.cboSeccion.Tag = null;
        }
        #endregion 

        #region llenaComboCampos
        /// <summary>
        /// Fill Combo Seccion
        /// </summary>
        private void llenaComboCampos(string szIdPadre)
        {
            // Set Tag to avoid events 
            this.cboCampo.Tag = true;

            // Fill Combo
            cboCampo.ValueMember = ColClave;
            cboCampo.DisplayMember = "descripcion";
            cboCampo.DataSource = _catalogosDIAN.dsListaCamposDIAN(szIdPadre, "query").Tables[0];

            // Set Tag
            this.cboCampo.Tag = null;
        }
        #endregion

        #region LlenaGridCamposDIAN
        /// <summary>
        /// Fill DIAN Fields Grid
        /// </summary>
        /// <param name="szTipo"></param>
        public void llenaGridTablaDIAN(string szIdCampo)
        {
            try
            {
                gridDatosDIAN.DataSource = _catalogosDIAN.obtenDatasetTablaDIAN(szIdCampo).Tables[0];

                gridDatosDIAN.Columns["tipo"].HeaderText = "Tipo";
                gridDatosDIAN.Columns[ColClave].HeaderText = "Clave";
                gridDatosDIAN.Columns["descripcion"].HeaderText = "Descripción";
                gridDatosDIAN.Refresh();
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
        #endregion 

        #region LlenaGridEquivalenciasDIAN
        /// <summary>
        /// Fill DIAN Mapping Data
        /// </summary>
        /// <param name="tipo"></param>
        /// <param name="claveSAT"></param>
        public void LlenaGridEquivalenciasDIAN(string szCompania, string szCampo, string szClaveDian)
        {
            try
            {
                // Clean the Grid
                gridDatosADAM.DataSource = null;

                // Load the Data
                DataSet dsMapeo = _catalogosDIAN.obtenDatasetRelacionCatalogosDIAN(szCompania, szCampo, szClaveDian);

                if (dsMapeo.Tables.Count > 0)
                {
                    gridDatosADAM.DataSource = dsMapeo.Tables[0];

                    gridDatosADAM.Columns["compania"].HeaderText = "Compañía";
                    gridDatosADAM.Columns["id_campo"].HeaderText = "Campo";
                    gridDatosADAM.Columns["clave_dian"].HeaderText = "Clave DIAN";
                    gridDatosADAM.Columns["clave_adam"].HeaderText = "Clave ADAM";
                    gridDatosADAM.Refresh();
                }

            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        #endregion

        #endregion

    }
}

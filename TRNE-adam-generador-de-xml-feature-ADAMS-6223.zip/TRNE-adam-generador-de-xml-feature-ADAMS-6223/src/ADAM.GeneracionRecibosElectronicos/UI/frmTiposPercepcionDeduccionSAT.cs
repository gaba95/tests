using System;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmTiposPercepcionDeduccionSAT : Form
    {

        #region variables de la clase

        private ICatalogoAdicional _catalogoAdicional;
        private ApplicationSettingsBase _appSettings;

        #endregion

        #region propiedades de la clase

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        #endregion

        #region eventos de la clase

        private void FrmTiposPercepcion_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }

        private void cboTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTipo.Items.Count == 0)
                return;

            gridTiposPercepciones.DataSource = _catalogoAdicional.obtenDatasetTiposPercepcionDeduccion(int.Parse(cboTipo.SelectedValue.ToString())).Tables[0];
        }

        private void gridTiposPercepciones_SelectionChanged(object sender, EventArgs e)
        {
            llenaGridConceptos();
        }

        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            FrmAgregarConcepto agregar = new FrmAgregarConcepto();
            agregar.tipoPlataforma = this.tipoPlataforma;
            agregar.tipoConcepto = int.Parse(cboTipo.SelectedValue.ToString());
            agregar.claveTipo = gridTiposPercepciones.SelectedRows[0].Cells["clave"].Value.ToString();
            agregar.DescripcionTipo = gridTiposPercepciones.SelectedRows[0].Cells["descripcion"].Value.ToString();
            agregar.FrmPadre = this;
            agregar.ShowDialog();
        }

        private void cmdQuitar_Click(object sender, EventArgs e)
        {
            if (gridConceptos.RowCount == 0)
                return;

            if (_catalogoAdicional.BajaRelacionConcepto(int.Parse(cboTipo.SelectedValue.ToString()), gridTiposPercepciones.SelectedRows[0].Cells["clave"].Value.ToString(), int.Parse(gridConceptos.SelectedRows[0].Cells["concepto"].Value.ToString())))
                llenaGridConceptos();

        }

        #endregion

        #region metodos de la clase

        public FrmTiposPercepcionDeduccionSAT(ApplicationSettingsBase appSettings)
        {
            _appSettings = appSettings;
            InitializeComponent();
        }

        private void InicializaClase()
        {
            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, _appSettings);
            llenaComboTipos();
        }

        private void llenaComboTipos()
        {
            try
            {
                cboTipo.DisplayMember = "descripcion";
                cboTipo.ValueMember = "item";
                cboTipo.DataSource = _catalogoAdicional.obtenDatasetDescripcionTipos().Tables[0];
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }


        }

        public void llenaGridConceptos()
        {
            try
            {
                if (gridTiposPercepciones.SelectedRows.Count == 0)
                    return;
                gridConceptos.DataSource = _catalogoAdicional.obtenDatasetRelacionConceptos(int.Parse(cboTipo.SelectedValue.ToString()), gridTiposPercepciones.SelectedRows[0].Cells["clave"].Value.ToString()).Tables[0];
                gridConceptos.Columns["tipo_concepto_sat"].Visible = false;


            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }

        }

        #endregion

    }
}

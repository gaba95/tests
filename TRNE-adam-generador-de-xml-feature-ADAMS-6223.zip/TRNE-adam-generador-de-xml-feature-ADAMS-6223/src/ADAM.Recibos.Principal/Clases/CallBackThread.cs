﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;

namespace ADAM.Recibos.Principal
{
    public delegate void CallBackDelegate(string stado = "",bool reset = false);
    public delegate void ThreadFunctionDelegate();

    public class CallBackThread : IDisposable
    {
        #region Variables

        private readonly Func<Task> _ThreadFunction;
        private CallBackDelegate _CallBackFunction;
        private Thread _Thread;

        private bool _disposedValue = false;
        private bool _startedValue = false;

        #endregion

        #region Properties

        public Boolean Cancelar { get; set; }

        public ISynchronizeInvoke BaseControl { get; private set; }

        #endregion

        #region Methods

        public CallBackThread(ISynchronizeInvoke caller, ThreadFunctionDelegate threadMethod, CallBackDelegate callbackFunction)
        {
            BaseControl = caller;
            _ThreadFunction = () => Task.Run(() => threadMethod);
            _CallBackFunction = callbackFunction;
            _Thread = new Thread(ThreadFunction);
        }

        public CallBackThread(ISynchronizeInvoke caller, Func<Task> threadMethod, CallBackDelegate callbackFunction)
        {
            BaseControl = caller;
            _ThreadFunction = threadMethod;
            _CallBackFunction = callbackFunction;
            _Thread = new Thread(ThreadFunction);
        }

        public void Start()
        {
            if (!_startedValue)
            {
                _Thread.Start();
                _startedValue = true;
            }
            else
            {
                throw new InvalidOperationException("Thread ya iniciado");
            }
        }

        private void ThreadFunction()
        {
            _ThreadFunction.Invoke();
            _startedValue = true;

        }

        public void UpdateUI(String cadenaProcedures, bool reset = false)
        {
            if (BaseControl != null && _CallBackFunction != null)
                BaseControl.Invoke(_CallBackFunction, new object[] { cadenaProcedures, reset });
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing && _Thread.ThreadState != ThreadState.Stopped)
                    _Thread.Abort();

                _Thread = null;
                BaseControl = null;
                _CallBackFunction = null;
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        #endregion
    }
}

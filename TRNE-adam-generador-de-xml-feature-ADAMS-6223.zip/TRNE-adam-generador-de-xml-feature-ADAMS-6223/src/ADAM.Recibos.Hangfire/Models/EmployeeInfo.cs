﻿using Newtonsoft.Json;

namespace ADAM.Recibos.Hangfire.Models
{
    public class EmployeeInfo
    {
        [JsonProperty("compania")]
        public string Compania { get; set; }

        [JsonProperty("tipo_nomina")]
        public string TipoNomina { get; set; }

        [JsonProperty("clase_nomina")]
        public string ClaseNomina { get; set; }

        [JsonProperty("anio")]
        public string Anio { get; set; }

        [JsonProperty("periodo")]
        public string Periodo { get; set; }

        [JsonProperty("trabajador")]
        public string Trabajador { get; set; }

        [JsonProperty("numero_liquidacion")]
        public string NumeroLiquidacion { get; set; }

        [JsonProperty("manejo_nomina")]
        public string ManejoNomina { get; set; }
    }
}

﻿using System.Data;

namespace ADAM.Recibos.Datos.Clases.CatalogoSAT
{
    public interface ICatalogoSat
    {
        // Informacion de configuracion de catalgos SAT - ADAM
        DataSet dsListaCatalogosSAT();
        DataSet obtenDatasetCatalogosSAT(string tipo);
        DataSet obtenDatasetRelacionCatalogosSATADAM(string tipo, string claveSAT, string compania);
        DataSet obtenCatalogoADAM(string tipo, string compania);
        bool AltaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM);
        bool BajaRelacionDatoCatalogoADAM(string tipo, string compania, string claveSAT, string claveADAM);
        DataSet obtenDatasetCatalogos(string tabla);
    }
}

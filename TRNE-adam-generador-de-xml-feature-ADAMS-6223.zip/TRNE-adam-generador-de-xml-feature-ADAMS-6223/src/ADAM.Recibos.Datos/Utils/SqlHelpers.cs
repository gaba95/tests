﻿using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

namespace ADAM.Recibos.Datos.Utils
{
    public static class SqlHelpers
    {
        public static DataTable ExecuteSpToDataTable(IDbConnection connection, string spName, string tableName, Action<IDbCommand> configureParams)
        {
            using var cmd = connection.CreateCommand();
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 10 * 60;
            configureParams(cmd);

            using var reader = cmd.ExecuteReader();
            DataTable dt = new();
            dt.Load(reader);
            dt.TableName = tableName;
            return dt;
        }

        public static void AddCharParam(IDbCommand cmd, string name, int size, object value)
        {
            var p = cmd.CreateParameter();
            p.ParameterName = name;
            p.DbType = DbType.AnsiStringFixedLength;
            p.Size = size;
            p.Value = value;
            cmd.Parameters.Add(p);
        }

        public static void AddIntParam(IDbCommand cmd, string name, object value)
        {
            var p = cmd.CreateParameter();
            p.ParameterName = name;
            p.DbType = DbType.Int32;
            p.Value = value;
            cmd.Parameters.Add(p);
        }

        public static void AddVarCharParam(IDbCommand cmd, string name, object value)
        {
            var p = cmd.CreateParameter();
            p.ParameterName = name;
            p.DbType = DbType.AnsiString;
            p.Value = value;
            cmd.Parameters.Add(p);
        }
    }
}

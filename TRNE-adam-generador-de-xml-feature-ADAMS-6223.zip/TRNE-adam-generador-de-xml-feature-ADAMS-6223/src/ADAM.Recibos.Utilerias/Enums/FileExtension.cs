﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public enum FileExtension
    {
        txt = 0,
        csv = 1
    }
}

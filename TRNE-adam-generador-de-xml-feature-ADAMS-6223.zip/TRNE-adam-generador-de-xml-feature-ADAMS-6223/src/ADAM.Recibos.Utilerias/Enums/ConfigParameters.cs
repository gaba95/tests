﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public enum ConfigParameters
    {
        server,
        database,
        user,
        password,
        applicationUser,
        applicationPath,
        platform,
        plattaform,  // Legacy typo
        version,
        dsn,
        tipoOracle,
        puertoOracle,
        rutaArchivos
    }
}

using ADAM.Recibos.Datos;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Test.Fakes;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Test.Classes.Helpers
{
    [TestClass]
    public class BRReciboElectronicoHelperTests
    {
        #region Helpers

        private static FakeAppSettings CreateSqlSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "TestDB")
                .With(ConfigParameters.user.ToString(), "sa")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.version.ToString(), "5");
        }

        private static FakeAppSettings CreateOracleSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "ORCL")
                .With(ConfigParameters.user.ToString(), "system")
                .With(ConfigParameters.password.ToString(), "oracle")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.puertoOracle.ToString(), "1521")
                .With(ConfigParameters.tipoOracle.ToString(), "SERVICE_NAME");
        }

        private static FakeAppSettings CreateOdbcSettings()
        {
            return new FakeAppSettings()
                .With(ConfigParameters.dsn.ToString(), "TestDSN")
                .With(ConfigParameters.user.ToString(), "admin")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user");
        }

        #endregion

        #region CreateInstance - SQLServer

        [TestMethod]
        public void CreateInstance_SQLServer_ReturnsBRReciboElectronicoSql()
        {
            var result = BRReciboElectronicoHelper.CreateInstance(
                TipoPlataforma.SQLServer, CreateSqlSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<BRReciboElectronicoSql>(result);
        }

        #endregion

        #region CreateInstance - ORACLE

        [TestMethod]
        public void CreateInstance_Oracle_ReturnsBRReciboElectronicoOracle()
        {
            var result = BRReciboElectronicoHelper.CreateInstance(
                TipoPlataforma.ORACLE, CreateOracleSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<BRReciboElectronicoOracle>(result);
        }

        #endregion

        #region CreateInstance - ODBC

        [TestMethod]
        public void CreateInstance_ODBC_ReturnsBRReciboElectronicoOdbc()
        {
            var result = BRReciboElectronicoHelper.CreateInstance(
                TipoPlataforma.ODBC, CreateOdbcSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<BRReciboElectronicoOdbc>(result);
        }

        #endregion

        #region CreateInstance - Default

        [TestMethod]
        public void CreateInstance_InvalidPlatform_ReturnsBRReciboElectronicoSql()
        {
            var result = BRReciboElectronicoHelper.CreateInstance(
                (TipoPlataforma)999, CreateSqlSettings());

            Assert.IsNotNull(result);
            Assert.IsInstanceOfType<BRReciboElectronicoSql>(result);
        }

        #endregion
    }
}

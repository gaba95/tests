using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmConsultaCatalogosDIAN : Form
    {
        #region Properties

        private ICatalogoSat _catalogoSAT;
        DataTable _arbolCatalogosDS = null;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Institucion { get; set; }

        #endregion

        #region Events

        private void FrmConsultaCatalogosDIAN_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }

        private void gridDatosDIAN_SelectionChanged(object sender, EventArgs e)
        {
        }

        #endregion

        #region Methods

        public FrmConsultaCatalogosDIAN()
        {
            InitializeComponent();
        }

        private void InicializaClase()
        {
            _catalogoSAT = CatalogoSatHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);

            //PTF-4277 Config Catalogs by Institution
            lblTitulo.Text = String.Format("Consulta de Catálogos ADAM - {0}", this.Institucion);
            _arbolCatalogosDS = _catalogoSAT.obtenDatasetCatalogos("tb_catalogos_dian").Tables[0];
            cargaArbolCatalogos(0, null);
        }

        private void cargaArbolCatalogos(int parentId, TreeNode parentNode)
        {
            TreeNode childNode;

            if (_arbolCatalogosDS != null)
            { 
                foreach (DataRow dr in _arbolCatalogosDS.Select("id_padre =" + parentId))
                {
                    TreeNode t = new TreeNode();
                    t.Text = dr["nombre_catalogo"].ToString();
                    t.Name = dr["tabla"].ToString();
                    t.Tag = dr["id_catalogo"].ToString();
                    if (parentNode == null)
                    {
                        arbolCatalogos.Nodes.Add(t);
                        childNode = t;
                    }
                    else
                    {
                        parentNode.Nodes.Add(t);
                        childNode = t;
                    }

                    cargaArbolCatalogos(Convert.ToInt32(dr["id_catalogo"].ToString()), childNode);
                }
            }
        }
        
        public void LlenaGridDatosDIAN(string tipo)
        {
            try
            {
                gridDatosDIAN.DataSource = _catalogoSAT.obtenDatasetCatalogosSAT(tipo).Tables[0];

                gridDatosDIAN.Columns["tipo"].HeaderText = "Tipo";
                gridDatosDIAN.Columns["clave_sat"].HeaderText = String.Format("Cve. {0}", this.Institucion); //PTF-4277
                gridDatosDIAN.Columns["descripcion_sat"].HeaderText = "Descripción";
                gridDatosDIAN.Refresh();
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
        
        private void arbolCatalogos_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode _selectedNode = arbolCatalogos.SelectedNode;

            DataRow r = _arbolCatalogosDS.Rows[int.Parse(_selectedNode.Tag.ToString()) - 1];

            if (r["tabla"].ToString() != "")
            {
                gridDatosDIAN.DataSource = _catalogoSAT.obtenDatasetCatalogos(r["tabla"].ToString()).Tables[0];
                gridDatosDIAN.Refresh();
            }
        }

        #endregion 
    }
}

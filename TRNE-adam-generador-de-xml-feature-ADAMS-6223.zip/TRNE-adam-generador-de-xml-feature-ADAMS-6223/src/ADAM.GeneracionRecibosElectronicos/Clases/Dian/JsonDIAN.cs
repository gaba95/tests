﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class JsonDian : IJsonDIAN
    {
        #region Propiedades de la clase

        public Period periodo { get; set; }
        public GeneralInformation informacionGeneral { get; set; }
        public Employer empleador { get; set; }
        public List<IEmployee> trabajador { get; set; }

        #endregion

        #region Metodos de la clase

        public string WriteJsonRequest(string jsonPath, string company, string year, string month)
        {
            try
            {
                // Set Filenames
                var jsonFileName = Path.Combine(jsonPath, $"DIAN_COL_{company}_{year}-{month}_{DateTime.Now.ToString("yyyyMMddHHmmss")}_Request.json");
                var htmlFileName = Path.Combine(jsonPath, $"DIAN_COL_{company}_{year}-{month}_{DateTime.Now.ToString("yyyyMMddHHmmss")}_Request.html");

                // File Content
                string jsonOutput = JsonConvert.SerializeObject(this, Formatting.Indented);
                string htmlOutput = String.Format("<html><body><pre><code>{0}</code></pre></body></html>", jsonOutput);

                // Write Preview File
                File.WriteAllText(jsonFileName, jsonOutput);
                File.WriteAllText(htmlFileName, htmlOutput);

                return htmlFileName;
            }
            catch
            {
                return string.Empty;
            }
        }

        public IJsonDIAN JsonDianByEmployee(IEmployee employee)
        {
            List<IEmployee> emps = new List<IEmployee>();
            emps.Add(employee);

            IJsonDIAN aJsonDian = this;

            aJsonDian.trabajador = emps;

            return aJsonDian;      
        }

        #endregion
    }
}

﻿namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    public enum ColumnValueType
    {
        String = 1,
        Num = 2,
        Date = 3
    }
}

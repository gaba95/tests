﻿using ADAM.GeneracionRecibosElectronicos.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("trabajador", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class EmployeeFull : IEmployee
    {
        [JsonIgnore]
        public string employeeId { get; set; }
        public PredecessorInformation informacionPredecesor { get; set; }
        public string tipoTrabajador { get; set; }
        public string subtipoTrabajador { get; set; }
        public bool altoRiesgoPension { get; set; }
        public string tipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public string primerApellido { get; set; }
        public string segundoApellido { get; set; }
        public string primerNombre { get; set; }
        public string otrosNombres { get; set; }

        [JsonIgnore]
        public string nombreCompleto => string.Format("{0} {1} {2} {3}", primerApellido, segundoApellido, primerNombre, otrosNombres).Trim();
 
        public string lugarTrabajoPais { get; set; }
        public string lugarTrabajoDepartamentoEstado { get; set; }
        public string lugarTrabajoMunicipioCiudad { get; set; }
        public string lugarTrabajoDireccion { get; set; }
        public bool salarioIntegral { get; set; }
        public int tipoContrato { get; set; }
        public decimal sueldo { get; set; }
        public string fechaIngreso { get; set; }
        public string fechaRetiro { get; set; }
        public int tiempoLaborado { get; set; }
        public string emailTrabajador { get; set; }
        public decimal comprobanteTotal { get; set; }
        public string tipoMoneda { get; set; }
        public decimal trm { get; set; }
        public string notas { get; set; }
        public XMLSequenceNumber numeroSecuenciaXML { get; set; }
        public PlaceGenerationXML lugarGeneracionXML { get; set; }
        public Payment pago { get; set; }
        public List<PaymentDates> fechasPago { get; set; }
        public Perceptions devengados { get; set; }
        public Deductions deducciones { get; set; }
        public decimal redondeo { get; set; }
        public decimal devengadosTotal { get; set; }
        public decimal deduccionesTotal { get; set; }
        [Browsable(false)]
        public Notificaciones respuestaDian { get; set; }
        public string respuestaDianMessage => respuestaDian?.mensaje;
        public string codigoMensajeDian => respuestaDian?.codigoMensaje;
        public string respuestaDianEstatus => respuestaDian?.codigoMensaje == "0" && respuestaDian.categoriaMensaje != "Error" ? Enum.GetName(typeof(DianResponseStatus), DianResponseStatus.Correcto) : Enum.GetName(typeof(DianResponseStatus), DianResponseStatus.Incorrecto);
       
    }
}

﻿using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal
{
    public class Trabajadores : List<Trabajador> { }

    public class Trabajador
    {
        public string numTrabajador { get; set; }
        public string claseNomina { get; set; }
        public int numeroLiquidacion { get; set; }
        public int periodo { get; set; }
        //AZ-1061: Needed for cancellations, to add related node
        public bool esTimbradoRelacionado { get; set; }
        public int pagoSeparacion { get; set; }
        //AZ-1071: Add tipoNomina, anio and manejoNomina for Trabajador data
        public String tipoNomina { get; set; }
        public int anio { get; set; }
        public ManejoNomina manejoNomina { set; get; }
    }
}

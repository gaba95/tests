﻿using System;
using System.Net;
using System.Xml;
using System.Data;
using System.ServiceModel;
using System.Net.Security;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;
using ADAM.Recibos.Principal.Clases.Helpers;
using wsStampingStatus;

namespace ADAM.Recibos.Principal.Clases
{
    public class WebServiceHelper
    {
        public static string EnviaXmlTimbrado(string compania, string defaultEndpoint, int defaultTimeout, string xmlEnviar, TipoPlataforma tipoPlataforma)
        {
            wsNomina.NominaService wsService;

            try
            {
                #region Web Service Endpoint
                // Web Service Endpoint
                string wsEndpoint;

                // Get Config from Database
                DataSet dConfig = CatalogoAdicionalHelper.CreateInstance(tipoPlataforma, Properties.AppSettings.Default).obtenConfiguracionCompania(compania);
                if (dConfig != null && dConfig.Tables[0].Rows.Count > 0)
                {
                    Func<string, string> getParameterStringValue = (string id_parametro) =>
                    {
                        var parametro = dConfig.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                        if (parametro != null && parametro.Length > 0)
                        {
                            return parametro[0]?.Field<string>("alfanumerico");
                        }
                        return string.Empty;
                    };

                    // Set Endpoint
                    wsEndpoint = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                }
                else
                {
                    // Get Default Endpoint
                    // system.ServiceModel -> Client -> Endpoint
                    wsEndpoint = defaultEndpoint;
                }
                #endregion

                #region Web Service Client
                // Initialize the Service Class
                // Set the URL Address dynamically
                Uri baseAddress = new Uri(wsEndpoint);
                var binding = new BasicHttpBinding();
                binding.MaxReceivedMessageSize = int.MaxValue;
                binding.MaxBufferSize = int.MaxValue;
                binding.MaxBufferPoolSize = int.MaxValue;
                binding.AllowCookies = true;
                binding.CloseTimeout = new TimeSpan(0, defaultTimeout, 0);
                binding.OpenTimeout = new TimeSpan(0, defaultTimeout, 0);
                binding.SendTimeout = new TimeSpan(0, defaultTimeout, 0);
                binding.ReceiveTimeout = new TimeSpan(0, defaultTimeout, 0);

                var readerQuotas = new XmlDictionaryReaderQuotas();
                readerQuotas.MaxArrayLength = int.MaxValue;
                readerQuotas.MaxStringContentLength = int.MaxValue;
                readerQuotas.MaxDepth = 32;
                binding.ReaderQuotas = readerQuotas;
                if (baseAddress.Scheme.ToLower() == "https")
                {
                    binding.Security.Mode = BasicHttpSecurityMode.Transport;
                }

                // Set Web Service
                wsService = new wsNomina.NominaServiceClient(binding, new EndpointAddress(baseAddress));
                #endregion 

                // Transform to byte array
                byte[] contenido = System.Text.Encoding.UTF8.GetBytes(xmlEnviar);
                string contenido64 = Convert.ToBase64String(contenido);
                byte[] array = Convert.FromBase64String(contenido64);

                // Add Support for TLS 1.2
                // System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) =>
                {
                    if (sslPolicyErrors == SslPolicyErrors.None)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                };

                // Call Web Service
                var wsResponse = wsService.enviarComprobante(new wsNomina.enviarComprobanteRequest(new wsNomina.enviarComprobanteRequestBody(array)));

                // Default
                return $"Servicio: {wsEndpoint}\tRespuesta: {wsResponse.Body.enviarComprobanteReturn}";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static StatusRegistro[] GetStampingStatus(string[] connectionParameters, string endpoint, string company, string payrollType, 
                                                         string payrollClass, string anio, string period, string versionAtr, 
                                                         TipoPlataforma tipoPlataforma)
        {
            StampingStatusService wsStatusService;

            getStampingStatus request = new getStampingStatus();
            request.requestInfo = new EstatusInfoRequest();
            request.requestInfo.instancia = connectionParameters[1]; // Database
            request.requestInfo.compania = company;
            request.requestInfo.anio = anio;
            request.requestInfo.periodo = period;
            request.requestInfo.tipoNomina = payrollType;
            request.requestInfo.claseNomina = payrollClass;
            request.requestInfo.versionAtr = versionAtr;

            String statusServiceEndPoint = endpoint.Substring(0, endpoint.LastIndexOf("/")) + "/StampingStatusService";
            Uri baseAddress = new Uri(statusServiceEndPoint);
            var binding = new BasicHttpBinding();
            binding.MaxReceivedMessageSize = int.MaxValue;
            binding.MaxBufferSize = int.MaxValue;
            binding.MaxBufferPoolSize = int.MaxValue;
            binding.AllowCookies = true;

            var readerQuotas = new XmlDictionaryReaderQuotas();
            readerQuotas.MaxArrayLength = int.MaxValue;
            readerQuotas.MaxStringContentLength = int.MaxValue;
            readerQuotas.MaxDepth = 32;
            binding.ReaderQuotas = readerQuotas;
            if (baseAddress.Scheme.ToLower() == "https")
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }

            wsStatusService = new wsStampingStatus.StampingStatusServiceClient(binding, new EndpointAddress(statusServiceEndPoint));
            getStampingStatusResponse response = wsStatusService.getStampingStatus(request);

            return response.getStampingStatusReturn;
        }
    }
}

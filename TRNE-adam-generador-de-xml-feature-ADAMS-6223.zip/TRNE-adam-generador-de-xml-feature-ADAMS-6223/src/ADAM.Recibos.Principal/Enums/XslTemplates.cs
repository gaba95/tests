﻿namespace ADAM.Recibos.Principal.Enums
{
    public static class XslTemplates
    {
        public static readonly IReadOnlyDictionary<string, string> xslWhiteList = new Dictionary<string, string>
        {
            { "nomina12_40ADAM.xslt", "nomina12_40ADAM.xslt" },
            { "nomina12_40ADAMEle.xslt", "nomina12_40ADAMEle.xslt"},
            { "nomina12_40ADAMExp.xslt", "nomina12_40ADAMExp.xslt" },
            { "nomina12_40ADAM_ext.xsd", "nomina12_40ADAM_ext.xsd" },  // Special Case - Extended Validations
            { "remision52ADAM.xslt", "remision52ADAM.xslt" },
            { "nomina12_33Benavides.xslt", "nomina12_33Benavides.xslt" }
        };
    }
}

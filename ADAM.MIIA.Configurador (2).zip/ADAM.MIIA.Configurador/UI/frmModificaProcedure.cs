using System.Configuration;
using ADAM.MIIA.Configuration;

namespace ADAM.MIIA.Configurador.UI;

public partial class frmModificaProcedure : Form
{
    private bool esNuevoRegistro = false;

    public string tabla { get; set; } = "";
    public string procedure { get; set; } = "";
    public string procedure2 { get; set; } = "";
    public MIIAProceduresSection? MIIAProceduresSection { get; set; }
    public System.Configuration.Configuration? config { get; set; }
    public frmConfiguracion? frmPadre { get; set; }

    public frmModificaProcedure()
    {
        InitializeComponent();
    }

    private void frmModificaProcedure_Load(object? sender, EventArgs e)
    {
        if (tabla.Trim() != "")
        {
            CargaValoresActuales();
            esNuevoRegistro = false;
            txtTabla.ReadOnly = true;
        }
        else
        {
            esNuevoRegistro = true;
            txtTabla.ReadOnly = false;
        }
    }

    private void txtTabla_Leave(object? sender, EventArgs e)
    {
        txtTabla.Text = txtTabla.Text.ToUpper();
    }

    private void cmdAceptar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        if (GuardarProcedure(txtTabla.Text.Trim()))
        {
            DialogResult = DialogResult.OK;
            Close();
        }
        else
        {
            DialogResult = DialogResult.None;
        }
    }

    private void CargaValoresActuales()
    {
        txtTabla.Text = tabla;
        txtProcedure.Text = procedure;
        txtProcedure2.Text = procedure2;
    }

    private bool GuardarProcedure(string tabla)
    {
        try
        {
            if (!Validar())
                return false;

            if (esNuevoRegistro)
            {
                var nuevoProcedure = new ProcedureMIIA();
                nuevoProcedure.ProcedureMIIAProp = txtTabla.Text;
                nuevoProcedure.Procedimiento = txtProcedure.Text;
                nuevoProcedure.Procedimiento2 = txtProcedure2.Text;
                MIIAProceduresSection!.Procedures.Add(nuevoProcedure);
            }
            else
            {
                var existingProc = MIIAProceduresSection!.Procedures[tabla];
                if (existingProc != null)
                {
                    existingProc.Procedimiento = txtProcedure.Text;
                    existingProc.Procedimiento2 = txtProcedure2.Text;
                }
            }

            config!.Save();
            frmPadre!.llenaGridProcedures();
            return true;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    private bool Validar()
    {
        string tablaNueva = txtTabla.Text;

        if (esNuevoRegistro)
        {
            foreach (ProcedureMIIA proc in MIIAProceduresSection!.Procedures)
            {
                if (proc.ProcedureMIIAProp == tablaNueva)
                {
                    UIHelper.ShowMessage("La tabla que esta intentando ingresar ya existe", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtTabla.Focus();
                    return false;
                }
            }
        }

        if (txtTabla.Text.Trim() == string.Empty)
        {
            txtTabla.Focus();
            UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        if (txtProcedure.Text.Trim() == string.Empty)
        {
            txtProcedure.Focus();
            UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        return true;
    }
}

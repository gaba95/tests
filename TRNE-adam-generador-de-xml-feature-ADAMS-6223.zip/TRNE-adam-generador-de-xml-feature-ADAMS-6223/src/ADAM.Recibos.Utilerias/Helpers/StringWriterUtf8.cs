﻿using System.Text;

namespace ADAM.Recibos.Utilerias.Helpers
{
    public class StringWriterUtf8 : System.IO.StringWriter
    {
        public StringWriterUtf8(StringBuilder sb)
            : base(sb)
        {
        }

        public override Encoding Encoding
        {
            get { return Encoding.UTF8; }
        }
    }
}

﻿namespace ADAM.Recibos.Utilerias.Tests.Dummys
{
    internal class BaseDummy
    {
        protected string _baseField = "baseValue";
    }
}

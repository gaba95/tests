﻿namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    public enum Countries
    {
        México = 1,
        Colombia = 2
    }
}

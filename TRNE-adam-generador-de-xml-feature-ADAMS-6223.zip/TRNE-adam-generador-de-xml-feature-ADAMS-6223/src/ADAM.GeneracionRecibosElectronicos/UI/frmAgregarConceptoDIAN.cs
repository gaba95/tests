using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmAgregarConceptoDIAN : Form
    {
        #region Properties

        private string _claveTipo = "";
        private string _DescripcionTipo = "";

        private ICatalogoDian _catalogosDIAN;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string tipoConcepto { get; set; } = "";
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string campo { get; set; } = "";
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string claveTipo { get { return _claveTipo; } set { _claveTipo = value; lblClaveTipo.Text = "Clave: " + _claveTipo; } }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DescripcionTipo { get { return _DescripcionTipo; } set { _DescripcionTipo = value; lblDescripcionTipo.Text = "Descripción: " + _DescripcionTipo; } }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FrmTiposPercepcionDeduccionDIAN FrmPadre { get; set; }

        #endregion 

        #region Events

        private void FrmAgregarConceptoDIAN_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }
        
        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            if (GuardaCambios())
            {
                FrmPadre.LlenaGridEquivalenciasDIAN(compania, campo);
            }
        }
        #endregion

        #region Methods
        
        private void InicializaClase()
        {
            _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            LlenaComboConceptos();
        }
        
        public FrmAgregarConceptoDIAN()
        {
            InitializeComponent();
        }

        private void LlenaComboConceptos()
        {
            try
            {
                cboConceptos.ValueMember = "concepto";
                cboConceptos.DisplayMember = "descripcion";
                cboConceptos.DataSource = _catalogosDIAN.obtenDatasetConceptosRelacionarDIAN(tipoConcepto).Tables[0];
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
        
        private bool GuardaCambios()
        {
            try
            {
                if (cboConceptos.SelectedValue == null)
                    return false;

                if (_catalogosDIAN.existRelacionDatoConceptoDIAN(compania, campo, cboConceptos.SelectedValue.ToString()))
                {
                    MessageBox.Show(String.Format("El Concepto '{0}' ya se encuentra asociado", cboConceptos.SelectedValue.ToString()), "Concepto Asociado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                // Add Relationship
                return _catalogosDIAN.altaRelacionDatoConceptoDIAN(compania, campo, cboConceptos.SelectedValue.ToString());
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        #endregion 
    }
}

using Moq;
using System;
using System.Data;
using System.Data.Common;
using System.Reflection;
using System.Threading.Tasks;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoDIAN
{
    [TestClass]
    public class CatalogoDianSqlTests
    {
        #region Constructor & Basic Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            // Act
            var service = new CatalogoDianSql(mockFactory.Object);

            // Assert
            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        #endregion

        #region Interface & Structure Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoDian()
        {
            var serviceType = typeof(CatalogoDianSql);
            Assert.IsTrue(typeof(ICatalogoDian).IsAssignableFrom(serviceType), "Debe implementar ICatalogoDian");
        }

        [TestMethod]
        public void ShouldContainMethod_getDatasetInformationDian()
        {
            var method = typeof(CatalogoDianSql).GetMethod("getDatasetInformationDian");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(6, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_getParentIdCatalog()
        {
            var method = typeof(CatalogoDianSql).GetMethod("getParentIdCatalog");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_getTypeClassification()
        {
            var method = typeof(CatalogoDianSql).GetMethod("getTypeClassification");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_getDatasetEmployeesReceiptDian()
        {
            var method = typeof(CatalogoDianSql).GetMethod("getDatasetEmployeesReceiptDian");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenCorrelativoDian()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenCorrelativoDian");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_ActualizaBitacoraCorrelativosDian()
        {
            var method = typeof(CatalogoDianSql).GetMethod("ActualizaBitacoraCorrelativosDian");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(Task<bool>), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_AltaResultadoValidacion()
        {
            var method = typeof(CatalogoDianSql).GetMethod("AltaResultadoValidacion");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetBitacoraCorrelativosDianEmpleado()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetBitacoraCorrelativosDianEmpleado");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_dsListaSeccionesDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("dsListaSeccionesDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_dsListaCamposDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("dsListaCamposDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDataSetConceptosAux()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDataSetConceptosAux");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDataSetCatalogosAux()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDataSetCatalogosAux");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTablaDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetTablaDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenCatalogoAdamDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenCatalogoAdamDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_altaRelacionDatoCatalogoDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("altaRelacionDatoCatalogoDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_bajaRelacionDatoCatalogoDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("bajaRelacionDatoCatalogoDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetRelacionCatalogosDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetRelacionCatalogosDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTreeViewCatalogosDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetTreeViewCatalogosDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTreeViewCatalogosDIANByCompany()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetTreeViewCatalogosDIANByCompany");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTreeViewConceptosDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetTreeViewConceptosDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTreeViewConceptosDIANByCompany()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetTreeViewConceptosDIANByCompany");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetConceptosRelacionarDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetConceptosRelacionarDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_getDatasetConceptosADAM()
        {
            var method = typeof(CatalogoDianSql).GetMethod("getDatasetConceptosADAM");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_altaRelacionDatoConceptoDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("altaRelacionDatoConceptoDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_existRelacionDatoConceptoDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("existRelacionDatoConceptoDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetRelacionConceptosDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("obtenDatasetRelacionConceptosDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_bajaRelacionDatoConceptoDIAN()
        {
            var method = typeof(CatalogoDianSql).GetMethod("bajaRelacionDatoConceptoDIAN");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        #endregion

        #region getDatasetInformationDian Tests (SqlHelpers + retry)

        [TestMethod]
        public void GetDatasetInformationDian_ShouldReturnNull_WhenNoRows()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB();

            // Act
            var result = service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1");

            // Assert – mock reader returns 0 rows, so dt.Rows.Count == 0 → returns null
            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetDatasetInformationDian_ShouldConfigureStoredProcedureWithSixParams()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1");

            // Assert – 6 VarChar params: company, year, month, employee, id_parent_node, tipo
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(6));
            mockCommand.Verify(c => c.ExecuteReader(), Times.Once());
            Assert.AreEqual("sp_conceptos_json_dian", mockCommand.Object.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, mockCommand.Object.CommandType);
        }

        [TestMethod]
        public void GetDatasetInformationDian_ShouldRetry_OnConnectionFailure()
        {
            // Arrange
            int callCount = 0;
            var mockReader = new Mock<IDataReader>();
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.GetSchemaTable()).Returns(new DataTable());

            var mockCommand = CreateMockCommand(mockReader);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(() =>
            {
                callCount++;
                if (callCount == 2)
                    throw new Exception("Connection failed");
                return mockConnection.Object;
            });

            var service = new CatalogoDianSql(mockFactory.Object);

            // Act
            var result = service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1");

            // Assert – retried and succeeded
            Assert.IsNull(result); // 0 rows → null
        }

        [TestMethod]
        public void GetDatasetInformationDian_ShouldThrow_AfterMaxRetries()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoDianSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert
            Assert.Throws<Exception>(() =>
                service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1"));
        }

        [TestMethod]
        public void GetDatasetInformationDian_ShouldReturnDataSet_WhenRowsExist()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true);

            // Act
            var result = service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("Table", result.Tables[0].TableName);
        }

        #endregion

        #region getDatasetEmployeesReceiptDian Tests (SqlHelpers + retry)

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldReturnNull_WhenNoRows()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB();

            // Act
            var result = service.getDatasetEmployeesReceiptDian("COMP", "2026", "01");

            // Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldConfigureStoredProcedureWithThreeParams()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.getDatasetEmployeesReceiptDian("COMP", "2026", "01");

            // Assert – 3 VarChar params: company, year, month
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(3));
            Assert.AreEqual("sp_trabajadores_recibo_dian", mockCommand.Object.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, mockCommand.Object.CommandType);
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldReturnDataSet_WhenRowsExist()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true);

            // Act
            var result = service.getDatasetEmployeesReceiptDian("COMP", "2026", "01");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldThrow_AfterMaxRetries()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoDianSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert
            Assert.Throws<Exception>(() =>
                service.getDatasetEmployeesReceiptDian("COMP", "2026", "01"));
        }

        #endregion

        #region obtenCorrelativoDian Tests (SqlHelpers + retry)

        [TestMethod]
        public void ObtenCorrelativoDian_ShouldReturnDataSet_WithCorrectTableName()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB();

            // Act
            var result = service.obtenCorrelativoDian("COMP", "TRAB000001");

            // Assert – always returns DataSet (no row count check)
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("Table", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenCorrelativoDian_ShouldConfigureThreeParams()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.obtenCorrelativoDian("COMP", "TRAB000001");

            // Assert – 3 params: compania (Char), trabajador (Char), fecha_envio (DateTime)
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(3));
            Assert.AreEqual("sp_correlativo_dian", mockCommand.Object.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, mockCommand.Object.CommandType);
        }

        [TestMethod]
        public void ObtenCorrelativoDian_ShouldThrow_AfterMaxRetries()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoDianSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert
            Assert.Throws<Exception>(() =>
                service.obtenCorrelativoDian("COMP", "TRAB000001"));
        }

        #endregion

        #region obtenCatalogoAdamDIAN Tests (SqlHelpers + retry)

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldReturnNull_WhenNoRows()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB();

            // Act
            var result = service.obtenCatalogoAdamDIAN("campo1", "COMP");

            // Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldConfigureTwoParams()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.obtenCatalogoAdamDIAN("campo1", "COMP");

            // Assert – 2 VarChar params: id_campo, compania
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(2));
            Assert.AreEqual("usp_obtiene_catalogo_adam_dian", mockCommand.Object.CommandText);
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldReturnDataSet_WhenRowsExist()
        {
            // Arrange
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true);

            // Act
            var result = service.obtenCatalogoAdamDIAN("campo1");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldThrow_AfterMaxRetries()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            var service = new CatalogoDianSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert
            Assert.Throws<Exception>(() =>
                service.obtenCatalogoAdamDIAN("campo1"));
        }

        #endregion

        #region SqlConnection-cast methods – InvalidCastException Tests

        [TestMethod]
        public void GetParentIdCatalog_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.getParentIdCatalog());
        }

        [TestMethod]
        public void GetTypeClassification_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.getTypeClassification());
        }

        [TestMethod]
        public void ActualizaBitacoraCorrelativosDian_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.ActualizaBitacoraCorrelativosDian("COMP", "NUM001", "DOC001", "OK"));
        }

        [TestMethod]
        public void AltaResultadoValidacion_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.AltaResultadoValidacion("NUM001", "ERR01", "Error message"));
        }

        [TestMethod]
        public void ObtenDatasetBitacoraCorrelativosDianEmpleado_Correctos_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetBitacoraCorrelativosDianEmpleado("COMP", "TRAB001", true));
        }

        [TestMethod]
        public void ObtenDatasetBitacoraCorrelativosDianEmpleado_NoCorrectos_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetBitacoraCorrelativosDianEmpleado("COMP", "TRAB001", false));
        }

        [TestMethod]
        public void DsListaSeccionesDIAN_WithoutTipoConcepto_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.dsListaSeccionesDIAN("query"));
        }

        [TestMethod]
        public void DsListaSeccionesDIAN_WithTipoConcepto_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.dsListaSeccionesDIAN("concepto", "percepcion"));
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithoutTipoConcepto_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.dsListaCamposDIAN("parent1", "query"));
        }

        [TestMethod]
        public void DsListaCamposDIAN_WithTipoConcepto_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.dsListaCamposDIAN("parent1", "concepto", "percepcion"));
        }

        [TestMethod]
        public void ObtenDataSetConceptosAux_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDataSetConceptosAux());
        }

        [TestMethod]
        public void ObtenDataSetCatalogosAux_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDataSetCatalogosAux());
        }

        [TestMethod]
        public void ObtenDatasetTablaDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTablaDIAN("campo1"));
        }

        [TestMethod]
        public void AltaRelacionDatoCatalogoDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.altaRelacionDatoCatalogoDIAN("COMP", "campo1", "dian01", "adam01"));
        }

        [TestMethod]
        public void BajaRelacionDatoCatalogoDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.bajaRelacionDatoCatalogoDIAN("COMP", "campo1", "dian01", "adam01"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionCatalogosDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetRelacionCatalogosDIAN("COMP", "campo1", "dian01"));
        }

        [TestMethod]
        public void ObtenDatasetTreeViewCatalogosDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTreeViewCatalogosDIAN());
        }

        [TestMethod]
        public void ObtenDatasetTreeViewCatalogosDIANByCompany_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetTreeViewCatalogosDIANByCompany("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetTreeViewConceptosDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTreeViewConceptosDIAN());
        }

        [TestMethod]
        public void ObtenDatasetTreeViewConceptosDIANByCompany_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetTreeViewConceptosDIANByCompany("COMP"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionarDIAN_Deduccion_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetConceptosRelacionarDIAN("deduccion"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionarDIAN_Percepcion_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetConceptosRelacionarDIAN("percepcion"));
        }

        [TestMethod]
        public void GetDatasetConceptosADAM_Deduccion_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.getDatasetConceptosADAM("deduccion", "100"));
        }

        [TestMethod]
        public void GetDatasetConceptosADAM_Percepcion_ShouldThrowInvalidCastException()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.getDatasetConceptosADAM("percepcion", "100"));
        }

        [TestMethod]
        public void AltaRelacionDatoConceptoDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.altaRelacionDatoConceptoDIAN("COMP", "campo1", "100"));
        }

        [TestMethod]
        public void ExistRelacionDatoConceptoDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.existRelacionDatoConceptoDIAN("COMP", "campo1", "100"));
        }

        [TestMethod]
        public void ObtenDatasetRelacionConceptosDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.obtenDatasetRelacionConceptosDIAN("COMP", "campo1"));
        }

        [TestMethod]
        public void BajaRelacionDatoConceptoDIAN_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            var service = CreateServiceWithMockDB();
            Assert.Throws<InvalidCastException>(() =>
                service.bajaRelacionDatoConceptoDIAN("COMP", "campo1", "100"));
        }

        #endregion

        #region State=Closed Branch Tests (IDbConnection methods)

        [TestMethod]
        public void GetDatasetInformationDian_ShouldCallOpen_WhenConnectionIsClosed()
        {
            var (service, _) = CreateServiceWithFullMockDB(connectionState: ConnectionState.Closed);

            var result = service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetDatasetInformationDian_ShouldReturnDataSet_WhenConnectionIsClosedAndRowsExist()
        {
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true, connectionState: ConnectionState.Closed);

            var result = service.getDatasetInformationDian("COMP", "2026", "01", "EMP001", "parent1", "type1");

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldCallOpen_WhenConnectionIsClosed()
        {
            var (service, _) = CreateServiceWithFullMockDB(connectionState: ConnectionState.Closed);

            var result = service.getDatasetEmployeesReceiptDian("COMP", "2026", "01");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetDatasetEmployeesReceiptDian_ShouldReturnDataSet_WhenConnectionIsClosedAndRowsExist()
        {
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true, connectionState: ConnectionState.Closed);

            var result = service.getDatasetEmployeesReceiptDian("COMP", "2026", "01");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenCorrelativoDian_ShouldCallOpen_WhenConnectionIsClosed()
        {
            var (service, _) = CreateServiceWithFullMockDB(connectionState: ConnectionState.Closed);

            var result = service.obtenCorrelativoDian("COMP", "TRAB000001");

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldCallOpen_WhenConnectionIsClosed()
        {
            var (service, _) = CreateServiceWithFullMockDB(connectionState: ConnectionState.Closed);

            var result = service.obtenCatalogoAdamDIAN("campo1");

            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenCatalogoAdamDIAN_ShouldReturnDataSet_WhenConnectionIsClosedAndRowsExist()
        {
            var (service, _) = CreateServiceWithFullMockDB(hasRows: true, connectionState: ConnectionState.Closed);

            var result = service.obtenCatalogoAdamDIAN("campo1");

            Assert.IsNotNull(result);
        }

        #endregion

        #region Helpers

        /// <summary>
        /// Creates a CatalogoDianSql with a mock IDbConnection (non-SqlConnection).
        /// Methods that cast to SqlConnection will throw InvalidCastException.
        /// </summary>
        private CatalogoDianSql CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            return new CatalogoDianSql(mockFactory.Object);
        }

        /// <summary>
        /// Creates a CatalogoDianSql with full IDbCommand mock chain (for SqlHelpers-based methods).
        /// When hasRows=true, the DataTable will contain one row so methods return non-null DataSet.
        /// </summary>
        private (CatalogoDianSql service, Mock<IDbCommand> mockCommand) CreateServiceWithFullMockDB(bool hasRows = false, ConnectionState connectionState = ConnectionState.Open)
        {
            var schemaTable = new DataTable();
            schemaTable.Columns.Add("ColumnName", typeof(string));
            schemaTable.Columns.Add("ColumnOrdinal", typeof(int));
            schemaTable.Columns.Add("ColumnSize", typeof(int));
            schemaTable.Columns.Add("DataType", typeof(Type));
            schemaTable.Columns.Add("AllowDBNull", typeof(bool));
            schemaTable.Columns.Add("IsKey", typeof(bool));
            schemaTable.Columns.Add("IsUnique", typeof(bool));

            var mockReader = new Mock<IDataReader>();
            if (hasRows)
            {
                // Add schema row for the column
                var schemaRow = schemaTable.NewRow();
                schemaRow["ColumnName"] = "col1";
                schemaRow["ColumnOrdinal"] = 0;
                schemaRow["ColumnSize"] = 255;
                schemaRow["DataType"] = typeof(string);
                schemaRow["AllowDBNull"] = true;
                schemaRow["IsKey"] = false;
                schemaRow["IsUnique"] = false;
                schemaTable.Rows.Add(schemaRow);

                // Simulate one row: first Read() returns true, second returns false
                var readSequence = mockReader.SetupSequence(r => r.Read());
                readSequence.Returns(true);
                readSequence.Returns(false);
                mockReader.Setup(r => r.FieldCount).Returns(1);
                mockReader.Setup(r => r.GetName(0)).Returns("col1");
                mockReader.Setup(r => r.GetFieldType(0)).Returns(typeof(string));
                mockReader.Setup(r => r.GetValue(0)).Returns("value1");
                mockReader.Setup(r => r.IsDBNull(0)).Returns(false);
            }
            else
            {
                mockReader.Setup(r => r.Read()).Returns(false);
            }
            mockReader.Setup(r => r.GetSchemaTable()).Returns(schemaTable);

            var mockCommand = CreateMockCommand(mockReader);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(connectionState);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new CatalogoDianSql(mockFactory.Object);
            return (service, mockCommand);
        }

        private Mock<IDbCommand> CreateMockCommand(Mock<IDataReader> mockReader)
        {
            var mockCommand = new Mock<IDbCommand>();
            mockCommand.SetupProperty(c => c.CommandText);
            mockCommand.SetupProperty(c => c.CommandType);
            mockCommand.SetupProperty(c => c.CommandTimeout);

            var mockParams = new Mock<IDataParameterCollection>();
            mockCommand.Setup(c => c.Parameters).Returns(mockParams.Object);
            mockCommand.Setup(c => c.CreateParameter()).Returns(() => new Mock<IDbDataParameter>().Object);
            mockCommand.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            return mockCommand;
        }

        #endregion
    }
}

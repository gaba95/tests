using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using ADAM.GeneracionRecibosElectronicos.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class EmployeeFullTests
    {
        [TestMethod]
        public void EmployeeFull_NombreCompleto_ConcatenatesNames()
        {
            var emp = new EmployeeFull
            {
                primerApellido = "Rodríguez",
                segundoApellido = "Martínez",
                primerNombre = "Ana",
                otrosNombres = "María"
            };

            Assert.AreEqual("Rodríguez Martínez Ana María", emp.nombreCompleto);
        }

        [TestMethod]
        public void EmployeeFull_ImplementsIEmployee()
        {
            var emp = new EmployeeFull();
            Assert.IsInstanceOfType(emp, typeof(IEmployee));
        }

        [TestMethod]
        public void EmployeeFull_RespuestaDianMessage_ReturnsNull_WhenNoRespuesta()
        {
            var emp = new EmployeeFull();
            Assert.IsNull(emp.respuestaDianMessage);
        }

        [TestMethod]
        public void EmployeeFull_CodigoMensajeDian_ReturnsNull_WhenNoRespuesta()
        {
            var emp = new EmployeeFull();
            Assert.IsNull(emp.codigoMensajeDian);
        }

        [TestMethod]
        public void EmployeeFull_RespuestaDianEstatus_ReturnsIncorrecto_WhenNoRespuesta()
        {
            var emp = new EmployeeFull();
            // When respuestaDian is null, codigoMensaje is null (not "0"), so result is Incorrecto
            Assert.AreEqual("Incorrecto", emp.respuestaDianEstatus);
        }

        [TestMethod]
        public void EmployeeFull_RespuestaDianEstatus_ReturnsCorrecto_WhenCodigoIs0AndNotError()
        {
            var emp = new EmployeeFull
            {
                respuestaDian = new Notificaciones
                {
                    codigoMensaje = "0",
                    categoriaMensaje = "Info",
                    mensaje = "OK"
                }
            };

            Assert.AreEqual("Correcto", emp.respuestaDianEstatus);
        }

        [TestMethod]
        public void EmployeeFull_RespuestaDianEstatus_ReturnsIncorrecto_WhenCategoriaIsError()
        {
            var emp = new EmployeeFull
            {
                respuestaDian = new Notificaciones
                {
                    codigoMensaje = "0",
                    categoriaMensaje = "Error",
                    mensaje = "Error occurred"
                }
            };

            Assert.AreEqual("Incorrecto", emp.respuestaDianEstatus);
        }

        [TestMethod]
        public void EmployeeFull_RespuestaDianEstatus_ReturnsIncorrecto_WhenCodigoIsNot0()
        {
            var emp = new EmployeeFull
            {
                respuestaDian = new Notificaciones
                {
                    codigoMensaje = "99",
                    categoriaMensaje = "Info",
                    mensaje = "Some error"
                }
            };

            Assert.AreEqual("Incorrecto", emp.respuestaDianEstatus);
        }

        [TestMethod]
        public void EmployeeFull_RespuestaDianMessage_ReturnsMessage()
        {
            var emp = new EmployeeFull
            {
                respuestaDian = new Notificaciones { mensaje = "Documento procesado" }
            };

            Assert.AreEqual("Documento procesado", emp.respuestaDianMessage);
        }

        [TestMethod]
        public void EmployeeFull_Serialization_IgnoresEmployeeId()
        {
            var emp = new EmployeeFull { employeeId = "E001", primerNombre = "Test" };
            var json = JsonConvert.SerializeObject(emp);

            Assert.IsFalse(json.Contains("employeeId"));
        }

        [TestMethod]
        public void EmployeeFull_Properties_SetAndGet()
        {
            var emp = new EmployeeFull
            {
                employeeId = "E002",
                tipoTrabajador = "02",
                subtipoTrabajador = "01",
                altoRiesgoPension = false,
                tipoDocumento = "CE",
                numeroDocumento = "987654321",
                sueldo = 5000000m,
                fechaIngreso = "2021-06-01",
                tipoContrato = 2,
                tipoMoneda = "COP",
                trm = 1.0m,
                comprobanteTotal = 4500000m,
                devengadosTotal = 5000000m,
                deduccionesTotal = 500000m,
                redondeo = 0.01m
            };

            Assert.AreEqual("E002", emp.employeeId);
            Assert.AreEqual(5000000m, emp.sueldo);
            Assert.AreEqual(4500000m, emp.comprobanteTotal);
        }
    }
}

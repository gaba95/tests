using System.Configuration;
using System.Data;
using System.Text.RegularExpressions;
using ADAM.MIIA.Configuration;
using ADAM.Framework.Encription;
using Microsoft.Data.SqlClient;
using Oracle.ManagedDataAccess.Client;

namespace ADAM.MIIA.Configurador.UI;

public partial class frmModificaCliente : Form
{
    private const string UserIdKey = ";User Id=";
    private const string PasswordKey = ";Password=";
    private const string ConnectionErrorFormat = "Hubo un error en la conexion, erro: ";

    private bool esNuevoRegistro = false;

    private Encripta.Encriptador myEncrypt = new Encripta.Encriptador();

    private const string patronMail = @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

    public string clienteMIIA { get; set; } = "";
    public string descripcion { get; set; } = "";
    public string TipoConexion { get; set; } = "";
    public string Usuario { get; set; } = "";
    public string Password { get; set; } = "";
    public string HoraInicio { get; set; } = "";
    public string HoraFin { get; set; } = "";
    public string CorreoDe { get; set; } = "";
    public string CorreoPara { get; set; } = "";
    public string IdiomaEspaniol { get; set; } = "";
    public string IdiomaIngles { get; set; } = "";
    public string ActivarResumenEnExcel { get; set; } = "";
    public string Servidor { get; set; } = "";
    public string baseDatos { get; set; } = "";
    public MIIAConfigSection? MIIAConfigSection { get; set; }
    public System.Configuration.Configuration? config { get; set; }
    public frmConfiguracion? frmPadre { get; set; }

    public frmModificaCliente()
    {
        InitializeComponent();
    }

    private void frmModificaCliente_Load(object? sender, EventArgs e)
    {
        LlenaCboTipoCon();

        if (clienteMIIA.Trim() != "")
        {
            txtClaveCliente.ReadOnly = true;
            CargaValoresActuales();
            esNuevoRegistro = false;
        }
        else
        {
            esNuevoRegistro = true;
        }
    }

    private void cmdAceptar_Click(object? sender, EventArgs e)
    {
        this.DialogResult = DialogResult.Cancel;

        if (GuardarCliente(txtClaveCliente.Text.Trim()))
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        else
        {
            this.DialogResult = DialogResult.None;
        }
    }

    private void cmdProbar_Click(object? sender, EventArgs e)
    {
        ProbarConexionBaseDatos();
    }

    private void cboTipoCon_SelectedValueChanged(object? sender, EventArgs e)
    {
        if (cboTipoCon.SelectedValue?.ToString() == "ORACLE")
        {
            txtServidor.Enabled = false;
        }
        else
        {
            txtServidor.Enabled = true;
        }
    }

    private void CargaValoresActuales()
    {
        txtClaveCliente.Text = clienteMIIA;
        txtDescripcion.Text = descripcion;
        cboTipoCon.SelectedValue = TipoConexion;
        txtUsuario.Text = Usuario;
        txtPassword.Text = Password;
        txtServidor.Text = Servidor;
        txtBase.Text = baseDatos;

        if (HoraInicio != "")
        {
            dtpHoraInicio.Value = new DateTime(2000, 1, 1,
                Convert.ToInt32(HoraInicio.Split(':')[0]),
                Convert.ToInt32(HoraInicio.Split(':')[1]), 0, DateTimeKind.Unspecified);
        }

        if (HoraFin != "")
        {
            dtpHoraFin.Value = new DateTime(2000, 1, 1,
                Convert.ToInt32(HoraFin.Split(':')[0]),
                Convert.ToInt32(HoraFin.Split(':')[1]), 0, DateTimeKind.Unspecified);
        }

        txtCorreoDe.Text = CorreoDe;
        txtCorreoPara.Text = CorreoPara;

        txtServidor.Text = Servidor;
        txtBase.Text = baseDatos;

        // PTF-2206: Multi language support added to the email notifications.
        chkIdiomaEspaniol.Checked = Convert.ToBoolean(IdiomaEspaniol);
        chkIdiomaIngles.Checked = Convert.ToBoolean(IdiomaIngles);

        // PTF-1600: Excel summaries support added.
        chkActivarResumenEnExcel.Checked = Convert.ToBoolean(ActivarResumenEnExcel);
    }

    private bool GuardarCliente(string claveCliente)
    {
        try
        {
            if (!Validar())
                return false;

            if (esNuevoRegistro)
            {
                var nuevoCliente = new ClienteMIIA();
                nuevoCliente.ClienteMIIAProp = txtClaveCliente.Text;
                nuevoCliente.Descripcion = txtDescripcion.Text;
                nuevoCliente.TipoConexion = cboTipoCon.SelectedValue!.ToString()!;
                nuevoCliente.Usuario = txtUsuario.Text;
                nuevoCliente.Password = myEncrypt.CryptoEncrypt(txtPassword.Text);
                nuevoCliente.HoraInicio = dtpHoraInicio.Text;
                nuevoCliente.HoraFin = dtpHoraFin.Text;
                nuevoCliente.CorreoDe = txtCorreoDe.Text;
                nuevoCliente.CorreoPara = txtCorreoPara.Text;
                nuevoCliente.Servidor = txtServidor.Text;
                nuevoCliente.DataBase = txtBase.Text;
                // PTF-2206
                nuevoCliente.IdiomaEspaniol = chkIdiomaEspaniol.Checked.ToString();
                nuevoCliente.IdiomaIngles = chkIdiomaIngles.Checked.ToString();
                nuevoCliente.ActivarResumenEnExcel = chkActivarResumenEnExcel.Checked.ToString(); // PTF-1600

                MIIAConfigSection!.Clientes.Add(nuevoCliente);
            }
            else
            {
                var cliente = MIIAConfigSection!.Clientes[claveCliente];
                if (cliente == null) return false;
                cliente.Descripcion = txtDescripcion.Text;
                cliente.TipoConexion = cboTipoCon.SelectedValue!.ToString()!;
                cliente.Usuario = txtUsuario.Text;
                cliente.Password = myEncrypt.CryptoEncrypt(txtPassword.Text);
                cliente.HoraInicio = dtpHoraInicio.Text;
                cliente.HoraFin = dtpHoraFin.Text;
                cliente.CorreoDe = txtCorreoDe.Text;
                cliente.CorreoPara = txtCorreoPara.Text;
                cliente.Servidor = txtServidor.Text;
                cliente.DataBase = txtBase.Text;
                // PTF-2206
                cliente.IdiomaEspaniol = chkIdiomaEspaniol.Checked.ToString();
                cliente.IdiomaIngles = chkIdiomaIngles.Checked.ToString();
                cliente.ActivarResumenEnExcel = chkActivarResumenEnExcel.Checked.ToString(); // PTF-1600
            }

            config!.Save();
            frmPadre!.llenaGridClientes();
            return true;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }

    private bool Validar()
    {
        // 1) Validate key doesn't exist
        string claveNueva = txtClaveCliente.Text;

        if (esNuevoRegistro)
        {
            foreach (ClienteMIIA cliente in MIIAConfigSection!.Clientes)
            {
                if (cliente.ClienteMIIAProp == claveNueva)
                {
                    UIHelper.ShowMessage("La Clave que esta intentando ingresar ya existe", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtClaveCliente.Focus();
                    return false;
                }
            }
        }

        foreach (Control campo in this.Controls)
        {
            if (campo.GetType().ToString() == "System.Windows.Forms.TextBox"
                && ((TextBox)campo).Text.Trim() == string.Empty)
            {
                ((TextBox)campo).Focus();
                UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Validate emails
        if (txtCorreoDe.Text != ""
            && !Regex.IsMatch(txtCorreoDe.Text, patronMail, RegexOptions.None, TimeSpan.FromSeconds(1)))
        {
            UIHelper.ShowMessage("El campo no tiene el formato de correo, favor de corregir", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtCorreoDe.Focus();
            return false;
        }

        if (txtCorreoPara.Text != "")
        {
            string[] listaCorreos = txtCorreoPara.Text.Split(';');
            foreach (string correo in listaCorreos)
            {
                if (!Regex.IsMatch(correo, patronMail, RegexOptions.IgnoreCase, TimeSpan.FromSeconds(1)))
                {
                    UIHelper.ShowMessage("El correo '" + correo + "' no tiene el formato de correo, favor de corregir", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtCorreoPara.Focus();
                    return false;
                }
            }
        }

        // PTF-2206: Multi language support
        if (!chkIdiomaEspaniol.Checked && !chkIdiomaIngles.Checked)
        {
            UIHelper.ShowMessage("Debe seleccionar al menos una opci\u00F3n para el campo: Idioma de Notificaciones.", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        // PTF-2206: Multi language support
        if (chkIdiomaIngles.Checked && !SoportaCompatibilidadMultilenguaje())
        {
            UIHelper.ShowMessage("Para habilitar el idioma Ingles primero debe actualizar en el ambiente cliente todos los procedimientos configurados. Adem\u00E1s, debe actualizar los siguientes procedimientos: "
                            + "\r\n\t- sp_alta_errores_movimientos"
                            + "\r\n\t- sp_valida_campos_MIIA"
                            + "\r\n\t- sp_alta_warnings_movimientos_miia",
                            "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }

    private void ProbarConexionBaseDatos()
    {
        string usuario = txtUsuario.Text;
        string password = txtPassword.Text;
        string server = txtServidor.Text;
        string DataBase = txtBase.Text;
        string conString;

        if (cboTipoCon.SelectedValue?.ToString() == "SQL")
        {
            conString = "Server=" + server + ";Database=" + DataBase + UserIdKey + usuario + PasswordKey + password + ";";
            var conn = new SqlConnection(conString);

            try
            {
                conn.Open();

                if (conn.State == ConnectionState.Open)
                {
                    UIHelper.ShowMessage("La conexi\u00F3n se realizo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                UIHelper.ShowMessage(ConnectionErrorFormat + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            conString = "Data Source=" + DataBase + UserIdKey + usuario + PasswordKey + password + ";";
            var conn = new OracleConnection(conString);

            try
            {
                conn.Open();

                if (conn.State == ConnectionState.Open)
                {
                    UIHelper.ShowMessage("La conexi\u00F3n se realizo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                UIHelper.ShowMessage(ConnectionErrorFormat + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        this.DialogResult = DialogResult.None;
    }

    // PTF-2206: Multi language support to the email notifications.
    private bool SoportaCompatibilidadMultilenguaje()
    {
        string usuario = txtUsuario.Text;
        string password = txtPassword.Text;
        string server = txtServidor.Text;
        string DataBase = txtBase.Text;
        string conString;
        string consulta;
        int ML_MultipleErrores = 0;

        if (cboTipoCon.SelectedValue?.ToString() == "SQL")
        {
            conString = "Server=" + server + ";Database=" + DataBase + UserIdKey + usuario + PasswordKey + password + ";";
            var conn = new SqlConnection(conString);

            try
            {
                conn.Open();

                if (conn.State != ConnectionState.Open)
                {
                    UIHelper.ShowMessage("No se puede verificar si el ambiente del cliente soporta la compatibilidad multilenguaje, verifique los par\u00E1metros de conexi\u00F3n.", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                consulta = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME IN (N'sp_alta_errores_movimientos', N'sp_valida_campos_MIIA') AND PARAMETER_NAME='@cultura'";
                var comandoSql = new SqlCommand(consulta, conn);
                ML_MultipleErrores = Convert.ToInt32(comandoSql.ExecuteScalar());

                if (ML_MultipleErrores != 2)
                {
                    ML_MultipleErrores = 0;
                }

                comandoSql.Dispose();

                consulta = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME = N'sp_alta_warnings_movimientos_miia' AND PARAMETER_NAME IN ('@clasificacion','@id_error','@cultura')";
                comandoSql = new SqlCommand(consulta, conn);
                ML_MultipleErrores += Convert.ToInt32(comandoSql.ExecuteScalar());

                comandoSql.Dispose();
                conn.Close();

                return ML_MultipleErrores == 5;
            }
            catch (Exception ex)
            {
                UIHelper.ShowMessage(ConnectionErrorFormat + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            conString = "Data Source=" + DataBase + UserIdKey + usuario + PasswordKey + password + ";";
            var conn = new OracleConnection(conString);

            try
            {
                conn.Open();

                if (conn.State != ConnectionState.Open)
                {
                    UIHelper.ShowMessage("No se puede verificar si el ambiente del cliente soporta la compatibilidad multilenguaje, verifique los par\u00E1metros de conexi\u00F3n.", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                consulta = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME IN (N'sp_alta_errores_movimientos', N'sp_valida_campos_MIIA') AND PARAMETER_NAME='@cultura'";
                var comandoOracle = new OracleCommand(consulta, conn);
                ML_MultipleErrores = Convert.ToInt32(comandoOracle.ExecuteScalar());

                if (ML_MultipleErrores != 2)
                {
                    ML_MultipleErrores = 0;
                }

                comandoOracle.Dispose();

                consulta = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME = N'sp_alta_warnings_movimientos_miia' AND PARAMETER_NAME IN ('@clasificacion','@id_error','@cultura')";
                comandoOracle = new OracleCommand(consulta, conn);
                ML_MultipleErrores += Convert.ToInt32(comandoOracle.ExecuteScalar());

                comandoOracle.Dispose();
                conn.Close();

                return ML_MultipleErrores == 5;
            }
            catch (Exception ex)
            {
                UIHelper.ShowMessage(ConnectionErrorFormat + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        this.DialogResult = DialogResult.None;
        return false;
    }

    private void LlenaCboTipoCon()
    {
        var dt = new DataTable();
        dt.Columns.Add("tipo");
        dt.Columns.Add("descripcion");

        dt.Rows.Add("SQL", "SQL Server");
        dt.Rows.Add("ORACLE", "ORACLE");

        cboTipoCon.DataSource = dt;
        cboTipoCon.ValueMember = "tipo";
        cboTipoCon.DisplayMember = "descripcion";
    }
}

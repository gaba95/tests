using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using Moq;
using System.Configuration;
using System.Data.Odbc;

namespace ADAM.Recibos.Datos.Tests.Clases.Common
{
    [TestClass]
    public class OdbcConnectionFactoryTests
    {
        private Mock<ApplicationSettingsBase> CreateMockSettings(
            string dsn = "TestDSN",
            string user = "testUser",
            string password = "testPwd",
            string applicationUser = "app-user-123")
        {
            var mock = new Mock<ApplicationSettingsBase>();
            mock.Setup(s => s[ConfigParameters.dsn.ToString()]).Returns(dsn);
            mock.Setup(s => s[ConfigParameters.user.ToString()]).Returns(user);
            mock.Setup(s => s[ConfigParameters.password.ToString()]).Returns(password);
            mock.Setup(s => s[ConfigParameters.applicationUser.ToString()]).Returns(applicationUser);
            return mock;
        }

        [TestMethod]
        public void Constructor_SetsAppSettings()
        {
            var settings = CreateMockSettings();
            var factory = new OdbcConnectionFactory(settings.Object);

            Assert.IsNotNull(factory);
        }

        [TestMethod]
        public void ApplicationUser_ReplacesHyphensWithUnderscores()
        {
            var settings = CreateMockSettings(applicationUser: "app-user-123");
            var factory = new OdbcConnectionFactory(settings.Object);

            // Force BuildConnectionString to set _applicationUser by calling CreateConnection
            factory.CreateConnection();

            Assert.AreEqual("app_user_123", factory.ApplicationUser);
        }

        [TestMethod]
        public void ApplicationUser_NoHyphens_ReturnsUnchanged()
        {
            var settings = CreateMockSettings(applicationUser: "appuser123");
            var factory = new OdbcConnectionFactory(settings.Object);

            factory.CreateConnection();

            Assert.AreEqual("appuser123", factory.ApplicationUser);
        }

        [TestMethod]
        public void CreateConnection_ValidSettings_ReturnsOdbcConnection()
        {
            var settings = CreateMockSettings();
            var factory = new OdbcConnectionFactory(settings.Object);

            var connection = factory.CreateConnection();

            Assert.IsNotNull(connection);
            Assert.IsInstanceOfType<OdbcConnection>(connection);
        }

        [TestMethod]
        public void CreateConnection_NullDsn_CatchesExceptionReturnsNull()
        {
            var mock = new Mock<ApplicationSettingsBase>();
            mock.Setup(s => s[ConfigParameters.applicationUser.ToString()]).Returns("user");
            mock.Setup(s => s[ConfigParameters.dsn.ToString()]).Throws(new Exception("missing dsn"));

            var factory = new OdbcConnectionFactory(mock.Object);

            var connection = factory.CreateConnection();

            Assert.IsNull(connection);
        }

        [TestMethod]
        public void CreateConnection_OdbcException_ReturnsNull()
        {
            var mock = new Mock<ApplicationSettingsBase>();
            mock.Setup(s => s[ConfigParameters.applicationUser.ToString()]).Throws(CreateOdbcException());

            var factory = new OdbcConnectionFactory(mock.Object);

            var connection = factory.CreateConnection();

            Assert.IsNull(connection);
        }

        [TestMethod]
        public void CheckConnection_InvalidDsn_ReturnsFalse()
        {
            var settings = CreateMockSettings(dsn: "NonExistentDSN_XYZ");
            var factory = new OdbcConnectionFactory(settings.Object);

            var result = factory.CheckConnection();

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CheckConnection_CreateConnectionReturnsNull_ReturnsFalse()
        {
            var mock = new Mock<ApplicationSettingsBase>();
            mock.Setup(s => s[ConfigParameters.applicationUser.ToString()]).Throws(new Exception("bad"));

            var factory = new OdbcConnectionFactory(mock.Object);

            var result = factory.CheckConnection();

            Assert.IsFalse(result);
        }

        private static OdbcException CreateOdbcException()
        {
            try
            {
                using var conn = new OdbcConnection("DSN=NonExistent_Test_DSN_12345");
                conn.Open();
            }
            catch (OdbcException ex)
            {
                return ex;
            }
            throw new InvalidOperationException("Could not create OdbcException");
        }
    }
}

﻿using System.Diagnostics.CodeAnalysis;
using System.Drawing;

namespace ADAM.Recibos.Controls
{
    [ExcludeFromCodeCoverage]
    public partial class CustomProgressBar: ProgressBar
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public CustomProgressBar()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
        }
        #endregion 

        #region OnPaint
        /// <summary>
        /// On Paint
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            // Draw percentage
            Rectangle rect = this.ClientRectangle;
            Graphics g = e.Graphics;
            ProgressBarRenderer.DrawHorizontalBar(g, rect);

            // Add Percentage
            if (this.Value > 0)
            {
                Rectangle clip = new Rectangle(rect.X, rect.Y, (int)Math.Round(((float)this.Value / this.Maximum) * rect.Width), rect.Height);
                ProgressBarRenderer.DrawHorizontalChunks(g, clip);

                // Draw Percentage
                using (Font f = new Font(FontFamily.GenericMonospace, 10, FontStyle.Bold))
                {
                    int percentage = (int)Math.Round(((double)this.Value / (double)this.Maximum) * 100);
                    var lblProgress = $"{this.Value} de {this.Maximum} ({percentage}%)";
                    SizeF size = g.MeasureString(lblProgress, f);
                    Point location = new Point((int)((rect.Width / 2) - (size.Width / 2)), (int)((rect.Height / 2) - (size.Height / 2) + 2));
                    g.DrawString(lblProgress, f, Brushes.Black, location);
                }
            }
        }
        #endregion 
    }
}

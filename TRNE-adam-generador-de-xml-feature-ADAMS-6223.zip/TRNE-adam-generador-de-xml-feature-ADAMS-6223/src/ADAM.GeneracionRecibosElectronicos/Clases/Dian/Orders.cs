﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("libranzas", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Orders
    {
        [JsonProperty("descripcion")]
        public string DeduccionDescripcion { get; set; } = "";

        [JsonProperty("deduccion")]
        public decimal Deduccion { get; set; }
    }
}

using ADAM.Recibos.Hangfire.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.Recibos.Hangfire.Tests.Models
{
    [TestClass]
    public class EmployeeInfoTests
    {
        [TestMethod]
        public void EmployeeInfo_Properties_SetAndGetCorrectly()
        {
            var info = new EmployeeInfo
            {
                Compania = "01",
                TipoNomina = "Q",
                ClaseNomina = "N",
                Anio = "2026",
                Periodo = "6",
                Trabajador = "EMP001",
                NumeroLiquidacion = "1",
                ManejoNomina = "2"
            };

            Assert.AreEqual("01", info.Compania);
            Assert.AreEqual("Q", info.TipoNomina);
            Assert.AreEqual("N", info.ClaseNomina);
            Assert.AreEqual("2026", info.Anio);
            Assert.AreEqual("6", info.Periodo);
            Assert.AreEqual("EMP001", info.Trabajador);
            Assert.AreEqual("1", info.NumeroLiquidacion);
            Assert.AreEqual("2", info.ManejoNomina);
        }

        [TestMethod]
        public void EmployeeInfo_Serialization_RoundTrip()
        {
            var info = new EmployeeInfo
            {
                Compania = "02",
                TipoNomina = "M",
                ClaseNomina = "E",
                Anio = "2025",
                Periodo = "12",
                Trabajador = "W999",
                NumeroLiquidacion = "3",
                ManejoNomina = "1"
            };

            var json = JsonConvert.SerializeObject(info);
            var deserialized = JsonConvert.DeserializeObject<EmployeeInfo>(json);

            Assert.IsNotNull(deserialized);
            Assert.AreEqual("02", deserialized!.Compania);
            Assert.AreEqual("M", deserialized.TipoNomina);
            Assert.AreEqual("E", deserialized.ClaseNomina);
            Assert.AreEqual("2025", deserialized.Anio);
            Assert.AreEqual("12", deserialized.Periodo);
            Assert.AreEqual("W999", deserialized.Trabajador);
            Assert.AreEqual("3", deserialized.NumeroLiquidacion);
            Assert.AreEqual("1", deserialized.ManejoNomina);
        }

        [TestMethod]
        public void EmployeeInfo_JsonPropertyNames_AreCorrect()
        {
            var info = new EmployeeInfo
            {
                Compania = "C",
                TipoNomina = "T",
                ClaseNomina = "K",
                Anio = "2026",
                Periodo = "1",
                Trabajador = "W",
                NumeroLiquidacion = "0",
                ManejoNomina = "1"
            };

            var json = JsonConvert.SerializeObject(info);

            Assert.IsTrue(json.Contains("\"compania\""));
            Assert.IsTrue(json.Contains("\"tipo_nomina\""));
            Assert.IsTrue(json.Contains("\"clase_nomina\""));
            Assert.IsTrue(json.Contains("\"anio\""));
            Assert.IsTrue(json.Contains("\"periodo\""));
            Assert.IsTrue(json.Contains("\"trabajador\""));
            Assert.IsTrue(json.Contains("\"numero_liquidacion\""));
            Assert.IsTrue(json.Contains("\"manejo_nomina\""));
        }

        [TestMethod]
        public void EmployeeInfo_DefaultValues_AreNull()
        {
            var info = new EmployeeInfo();

            Assert.IsNull(info.Compania);
            Assert.IsNull(info.TipoNomina);
            Assert.IsNull(info.ClaseNomina);
            Assert.IsNull(info.Anio);
            Assert.IsNull(info.Periodo);
            Assert.IsNull(info.Trabajador);
            Assert.IsNull(info.NumeroLiquidacion);
            Assert.IsNull(info.ManejoNomina);
        }

        [TestMethod]
        public void EmployeeInfo_Deserialization_FromJsonString()
        {
            var json = @"{""compania"":""05"",""tipo_nomina"":""S"",""clase_nomina"":""A"",""anio"":""2024"",""periodo"":""3"",""trabajador"":""T100"",""numero_liquidacion"":""2"",""manejo_nomina"":""1""}";

            var info = JsonConvert.DeserializeObject<EmployeeInfo>(json);

            Assert.IsNotNull(info);
            Assert.AreEqual("05", info!.Compania);
            Assert.AreEqual("S", info.TipoNomina);
            Assert.AreEqual("A", info.ClaseNomina);
            Assert.AreEqual("2024", info.Anio);
            Assert.AreEqual("3", info.Periodo);
            Assert.AreEqual("T100", info.Trabajador);
            Assert.AreEqual("2", info.NumeroLiquidacion);
            Assert.AreEqual("1", info.ManejoNomina);
        }
    }
}

using System.Data;
using Oracle.ManagedDataAccess.Client;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Datos.Utils;

namespace ADAM.Recibos.Datos
{
    public class BRReciboElectronicoOracle : IBRReciboElectronico
    {
        private readonly IDbConnectionFactory _connectionFactory;

        private const string AlterSessionDateFormat = "ALTER SESSION SET nls_date_format = 'YYYYMMDD'";
        private const string ParamCompania = "i_compania";
        private const string ParamTrabajador = "i_trabajador";
        private const string ParamTipoNomina = "i_tipo_nomina";
        private const string ParamClaseNomina = "i_clase_nomina";
        private const string ParamAnio = "i_anio";
        private const string ParamPeriodo = "i_periodo";
        private const string ParamNumeroLiquidacion = "i_numero_liquidacion";
        private const string ParamManejoNomina = "i_manejo_nomina";
        private const string ParamReturnValue = "i_return_value";

        public string ApplicationUser
        {
            get
            {
                return _connectionFactory.ApplicationUser;
            }
        }

        public BRReciboElectronicoOracle(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public bool CheckDbConnection()
        {
            return _connectionFactory.CheckConnection();
        }

        public DataSet ObtenDatasetReciboFull(string compania, string trabajador, string tipoNomina, string claseNomina, int anio, int periodo, ManejoNomina manejoNomina, int numeroLiquidacion, string conceptoFactura, string formaPagoDefault)
        {
            Nomina nomina = new Nomina(compania, trabajador, tipoNomina, claseNomina, anio, periodo, manejoNomina, numeroLiquidacion, conceptoFactura, formaPagoDefault);
            return ObtenDatasetRecibo(nomina);
        }

        public DataSet ObtenDatasetRecibo(Nomina nomina)
        {
            DataSet dsCompleto = new();

            // Agregar Datos Principales
            DataSet dsPrincipal = ObtenDatasetPrincipal(nomina);
            dsCompleto.Tables.Add(dsPrincipal.Tables["TablePrincipal"].Copy());

            // Agregar horas extra
            DataSet dsHorasExtra = ObtenDatasetHorasExtra(nomina);
            dsCompleto.Tables.Add(dsHorasExtra.Tables["TableHorasExtra"].Copy());

            // Incapacidades
            DataSet dsIncapacidades = ObtenDatasetIncapacidades(nomina);
            dsCompleto.Tables.Add(dsIncapacidades.Tables["TableIncapacidades"].Copy());

            // Otros Pagos
            DataSet dsOtrosPagos = ObtenDatasetOtrosPagos(nomina);
            dsCompleto.Tables.Add(dsOtrosPagos.Tables["TableOtrosPagos"].Copy());

            // Acciones Titulos
            DataSet dsAccionesTitulos = ObtenDatasetAccionesTitulos(nomina);
            dsCompleto.Tables.Add(dsAccionesTitulos.Tables["TableAccionesTitulos"].Copy());

            // Jubilacion Pension Retiro
            DataSet dsJubilacionPensionRetiro = ObtenDatasetJubilacionPensionRetiro(nomina);
            dsCompleto.Tables.Add(dsJubilacionPensionRetiro.Tables["TableJubilacionPensionRetiro"].Copy());

            // Separacion Indemnizacion
            DataSet dsSeparacionIndemnizacion = ObtenDatasetSeparacionIndemnizacion(nomina);
            
            dsCompleto.Tables.Add(dsSeparacionIndemnizacion.Tables["TableSeparacionIndemnizacion"].Copy());

            // Devolver un unico Dataset con todos los tables para pasarlo al XSLT
            return dsCompleto;


        }

        public DataSet ObtenDatasetAdicionales(Nomina nomina, string procedimiento)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildAdicionalesCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();

            DataSet dsResult = new();

            var adapter = new OracleDataAdapter(oracleStmt);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();
                var oracleFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                oracleFormatoFecha.Prepare();
                oracleFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(dsResult);
            return dsResult;
        }

        internal virtual DataSet ObtenDatasetPrincipal(Nomina nomina)
        {
            var dsResult = FetchPrincipalRaw(nomina);
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TablePrincipal";
            }
            return dsResult;
        }

        internal virtual DataSet FetchPrincipalRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();
            
            const string oracleQuery01 = AlterSessionDateFormat;
            var oracleFormatoFecha = new OracleCommand(oracleQuery01, oracleConnection);
            oracleFormatoFecha.CommandType = CommandType.Text;
            oracleFormatoFecha.Prepare();
            oracleFormatoFecha.ExecuteNonQuery();
            
            var oracleStmt = BuildPrincipalCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();

            return SqlCommandExecutor.Request(new OracleDataAdapter(oracleStmt));
        }

        internal virtual DataSet ObtenDatasetHorasExtra(Nomina nomina)
        {
            DataSet dsHorasExtra = FetchHorasExtraRaw(nomina);
            if (dsHorasExtra != null && dsHorasExtra.Tables.Count > 0)
            {
                dsHorasExtra.Tables[0].TableName = "TableHorasExtra";
            }
            return dsHorasExtra;
        }

        internal virtual DataSet FetchHorasExtraRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildHorasExtraCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();

            DataSet dsHorasExtra = new DataSet();

            var adapter = new OracleDataAdapter(oracleStmt);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();

                // Cambiar el formato de fecha
                var cmdFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                cmdFormatoFecha.Prepare();
                cmdFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(dsHorasExtra);
            return dsHorasExtra;
        }

        internal virtual DataSet ObtenDatasetIncapacidades(Nomina nomina)
        {
            DataSet ds = FetchIncapacidadesRaw(nomina);
            ds.Tables[0].TableName = "TableIncapacidades";
            return ds;
        }

        internal virtual DataSet FetchIncapacidadesRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildIncapacidadesCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();

            DataSet ds = new();

            var adapter = new OracleDataAdapter(oracleStmt);

            // Si la conexion se cerro se vuelve a abrir y se configura el formato de fecha
            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();

                // Cambiar el formato de fecha
                var cmdFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                cmdFormatoFecha.Prepare();
                cmdFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(ds);
            return ds;
        }

        internal virtual DataSet ObtenDatasetOtrosPagos(Nomina nomina)
        {
            DataSet dsResult = FetchOtrosPagosRaw(nomina);
            if (dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableOtrosPagos";
            }
            return dsResult;
        }

        internal virtual DataSet FetchOtrosPagosRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildOtrosPagosCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();

            DataSet dsResult = new DataSet();

            var adapter = new OracleDataAdapter(oracleStmt);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();
                var oracleFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                oracleFormatoFecha.Prepare();
                oracleFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(dsResult);
            return dsResult;
        }

        internal virtual DataSet ObtenDatasetAccionesTitulos(Nomina nomina)
        {
            DataSet dsResult = FetchAccionesTitulosRaw(nomina);
            if (dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableAccionesTitulos";
            }
            return dsResult;
        }

        internal virtual DataSet FetchAccionesTitulosRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildAccionesTitulosCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();
            
            DataSet dsResult = new DataSet();

            var adapter = new OracleDataAdapter(oracleStmt);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();

                // Cambiar el formato de fecha
                var oracleFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                oracleFormatoFecha.Prepare();
                oracleFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(dsResult);
            return dsResult;
        }

        internal virtual DataSet ObtenDatasetJubilacionPensionRetiro(Nomina nomina)
        {
            DataSet dsResult = FetchJubilacionPensionRetiroRaw(nomina);
            if (dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableJubilacionPensionRetiro";
            }
            return dsResult;
        }

        internal virtual DataSet FetchJubilacionPensionRetiroRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildJubilacionPensionRetiroCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            oracleStmt.Prepare();

            DataSet dsResult = new DataSet();

            var adapter = new OracleDataAdapter(oracleStmt);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();
                // Cambiar el formato de fecha
                var oracleFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                oracleFormatoFecha.Prepare();
                oracleFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(dsResult);
            return dsResult;
        }

        internal virtual DataSet ObtenDatasetSeparacionIndemnizacion(Nomina nomina)
        {
            DataSet dsResult = FetchSeparacionIndemnizacionRaw(nomina);
            if (dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableSeparacionIndemnizacion";
            }
            return dsResult;
        }

        internal virtual DataSet FetchSeparacionIndemnizacionRaw(Nomina nomina)
        {
            using OracleConnection oracleConnection = (OracleConnection)this._connectionFactory.CreateConnection();

            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();

            var oracleStmt = BuildSeparacionIndemnizacionCommand(nomina);
            oracleStmt.Connection = oracleConnection;
            
            DataSet dsResult = new DataSet();

            var adapter = new OracleDataAdapter(oracleStmt);

            if (oracleConnection.State == ConnectionState.Closed)
            {
                oracleConnection.Open();

                // Cambiar el formato de fecha
                var oracleFormatoFecha = new OracleCommand(AlterSessionDateFormat, oracleConnection)
                {
                    CommandType = CommandType.Text
                };
                oracleFormatoFecha.Prepare();
                oracleFormatoFecha.ExecuteNonQuery();
            }

            adapter.Fill(dsResult);
            return dsResult;
        }

        internal virtual OracleCommand BuildAdicionalesCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_horas_extra_sat");
            oracleStmt.CommandType = CommandType.StoredProcedure;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamClaseNomina, OracleDbType.Char, 2).Value = nomina.ClaseNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor, ParameterDirection.Output);
            return oracleStmt;
        }

        internal virtual OracleCommand BuildPrincipalCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_nomina_sat")
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char, 4).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char, 10).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamClaseNomina, OracleDbType.Char, 2).Value = nomina.ClaseNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add("i_metodo_pago", OracleDbType.Char, 2).Value = nomina.FormaPagoDefault;

            // STAM-220 Se agrega campo bandera para generar con o sin pago de separacion, se utiliza el mismo campo conceptoFactura para no modificar la firma del metodo
            if (nomina.ManejoNomina == ManejoNomina.interactiva)
            {
                int pagoSeparacion;
                int.TryParse(nomina.ConceptoFactura, out pagoSeparacion);
                oracleStmt.Parameters.Add("i_pago_separacion", OracleDbType.Int16).Value = pagoSeparacion;
            }
            else
            {
                oracleStmt.Parameters.Add("i_pago_separacion", OracleDbType.Int16).Value = 0;
            }

            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor, ParameterDirection.Output);
            return oracleStmt;
        }

        internal virtual OracleCommand BuildHorasExtraCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_horas_extra_sat")
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamClaseNomina, OracleDbType.Char, 2).Value = nomina.ClaseNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor, ParameterDirection.Output);
            return oracleStmt;
        }

        internal virtual OracleCommand BuildIncapacidadesCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_incapacidades_sat")
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(new OracleParameter(ParamReturnValue, OracleDbType.RefCursor, 0, ParameterDirection.Output, false, 0, 0, "", DataRowVersion.Current, null));
            return oracleStmt;
        }

        internal virtual OracleCommand BuildOtrosPagosCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_otros_pagos_sat")
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamClaseNomina, OracleDbType.Char, 2).Value = nomina.ClaseNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor, ParameterDirection.Output);
            return oracleStmt;
        }

        internal virtual OracleCommand BuildAccionesTitulosCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_acciones_titulos");
            oracleStmt.CommandType = CommandType.StoredProcedure;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor, ParameterDirection.Output);
            return oracleStmt;
        }

        internal virtual OracleCommand BuildJubilacionPensionRetiroCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_jubilacion_pension_retiro");
            oracleStmt.CommandType = CommandType.StoredProcedure;
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor, ParameterDirection.Output);
            return oracleStmt;
        }

        internal virtual OracleCommand BuildSeparacionIndemnizacionCommand(Nomina nomina)
        {
            var oracleStmt = new OracleCommand("sp_separacion_indemnizacion")
            {
                CommandType = CommandType.StoredProcedure
            };
            oracleStmt.Parameters.Add(ParamCompania, OracleDbType.Char).Value = nomina.Compania;
            oracleStmt.Parameters.Add(ParamTrabajador, OracleDbType.Char).Value = nomina.Trabajador;
            oracleStmt.Parameters.Add(ParamTipoNomina, OracleDbType.Char, 2).Value = nomina.TipoNomina;
            oracleStmt.Parameters.Add(ParamAnio, OracleDbType.Int16).Value = nomina.Anio;
            oracleStmt.Parameters.Add(ParamPeriodo, OracleDbType.Int16).Value = nomina.Periodo;
            oracleStmt.Parameters.Add(ParamNumeroLiquidacion, OracleDbType.Int32).Value = nomina.NumeroLiquidacion;
            oracleStmt.Parameters.Add(ParamManejoNomina, OracleDbType.Int16).Value = nomina.ManejoNomina;
            oracleStmt.Parameters.Add(ParamReturnValue, OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            return oracleStmt;
        }

    }
}

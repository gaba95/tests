﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("salud", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Health
    {
        [JsonProperty("porcentaje")]
        public decimal DeduccionPorcentaje { get; set; }

        [JsonProperty("deduccion")]
        public decimal Deduccion { get; set; }
    }
}

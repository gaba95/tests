using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class JsonDianFull : JsonDian
    {
        public AddGlobalPayrollResponse respuestaDian { get; set; }

    }
}

﻿using System;
using System.Data;
using System.Data.Common;
using Microsoft.Data.SqlClient;

namespace ADAM.Recibos.Datos.Utils
{
    public static class SqlCommandExecutor
    {
        public static DataSet Request(DbDataAdapter adapter)
        {
            var dataSet = new DataSet();

            if (adapter.SelectCommand == null) { return null; }

            try
            {
                if (adapter.SelectCommand.Connection.State == ConnectionState.Closed)
                    adapter.SelectCommand.Connection.Open();

                adapter.SelectCommand.CommandTimeout = 10 * 60;
                adapter.Fill(dataSet);
                adapter.Dispose();

                return dataSet;
            }
            catch (SqlException sqlEx)
            {
                _ = sqlEx.Message;
                return null;
            }
            catch (Exception ex)
            {
                _ = ex.Message;
                return null;
            }
        }

        public static bool Request(DbCommand command, bool executeScalar)
        {
            try
            {
                int result;

                if (command.Connection.State == ConnectionState.Closed)
                    command.Connection.Open();
                
                if (executeScalar)
                    result = (int)command.ExecuteScalar();
                else
                    result = command.ExecuteNonQuery();

                return result > 0;
            }
            catch (SqlException sqlEx)
            {
                _ = sqlEx.Message;
                return false;
            }
            catch (Exception ex)
            {
                _ = ex.Message;
                return false;
            }
        }

        public static string Request(DbCommand command)
        {
            try
            {
                if (command.Connection.State == ConnectionState.Closed)
                    command.Connection.Open();

                var result = (string)command.ExecuteScalar();

                return result;
            }
            catch (SqlException sqlEx)
            {
                _ = sqlEx.Message;
                return string.Empty;
            }
            catch (Exception ex)
            {
                _ = ex.Message;
                return string.Empty;
            }
        }
    }
}

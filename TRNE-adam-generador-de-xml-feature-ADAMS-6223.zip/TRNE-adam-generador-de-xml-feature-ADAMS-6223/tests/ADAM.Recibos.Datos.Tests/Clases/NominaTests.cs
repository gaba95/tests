using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Utilerias.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Datos.Tests.Clases
{
    [TestClass]
    public class NominaTests
    {
        [TestMethod]
        public void Nomina_Constructor_SetsAllProperties()
        {
            var nomina = new Nomina(
                compania: "01",
                trabajador: "EMP001",
                tipoNomina: "Q",
                claseNomina: "N",
                anio: 2026,
                periodo: 6,
                manejoNomina: ManejoNomina.periodica,
                numeroLiquidacion: 1,
                conceptoFactura: "CFDI",
                formaPagoDefault: "99");

            Assert.AreEqual("01", nomina.Compania);
            Assert.AreEqual("EMP001", nomina.Trabajador);
            Assert.AreEqual("Q", nomina.TipoNomina);
            Assert.AreEqual("N", nomina.ClaseNomina);
            Assert.AreEqual(2026, nomina.Anio);
            Assert.AreEqual(6, nomina.Periodo);
            Assert.AreEqual(ManejoNomina.periodica, nomina.ManejoNomina);
            Assert.AreEqual(1, nomina.NumeroLiquidacion);
            Assert.AreEqual("CFDI", nomina.ConceptoFactura);
            Assert.AreEqual("99", nomina.FormaPagoDefault);
        }

        [TestMethod]
        public void Nomina_Constructor_WithInteractivaManejoNomina()
        {
            var nomina = new Nomina(
                compania: "02",
                trabajador: "W999",
                tipoNomina: "M",
                claseNomina: "E",
                anio: 2025,
                periodo: 12,
                manejoNomina: ManejoNomina.interactiva,
                numeroLiquidacion: 3,
                conceptoFactura: "Nomina",
                formaPagoDefault: "01");

            Assert.AreEqual(ManejoNomina.interactiva, nomina.ManejoNomina);
            Assert.AreEqual("02", nomina.Compania);
            Assert.AreEqual(3, nomina.NumeroLiquidacion);
        }

        [TestMethod]
        public void Nomina_Properties_CanBeModifiedAfterConstruction()
        {
            var nomina = new Nomina("01", "T1", "Q", "N", 2026, 1, ManejoNomina.periodica, 1, "CF", "99");

            nomina.Compania = "03";
            nomina.Trabajador = "T2";
            nomina.Anio = 2027;

            Assert.AreEqual("03", nomina.Compania);
            Assert.AreEqual("T2", nomina.Trabajador);
            Assert.AreEqual(2027, nomina.Anio);
        }
    }
}

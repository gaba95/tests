﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("anticipos", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Advances
    {
        [JsonProperty("descripcion")]
        public string AnticipoDescripcion { get; set; } = "";

        [JsonProperty("anticipo")]
        public decimal Anticipo { get; set; }
    }
}

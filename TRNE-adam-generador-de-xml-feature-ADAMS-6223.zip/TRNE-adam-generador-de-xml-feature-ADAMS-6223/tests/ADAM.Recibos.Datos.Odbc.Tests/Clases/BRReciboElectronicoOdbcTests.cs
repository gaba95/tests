﻿using System.Data;
using System.Data.Odbc;
using System.Reflection;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using Moq;

namespace ADAM.Recibos.Datos.Odbc.Tests.Clases;

[TestClass]
public class BRReciboElectronicoOdbcTests
{
    #region Helpers

    private static Nomina CreateTestNomina()
    {
        return new Nomina("COMP", "TRAB000001", "TN", "CN", 2026, 1, ManejoNomina.periodica, 1, "CF", "01");
    }

    private static BRReciboElectronicoOdbc CreateServiceWithMockDB(Mock<IDbConnectionFactory>? mockFactory = null)
    {
        mockFactory ??= new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
        mockFactory.Setup(f => f.CheckConnection()).Returns(true);
        return new BRReciboElectronicoOdbc(mockFactory.Object);
    }

    private static (BRReciboElectronicoOdbc service, Mock<IDbConnectionFactory> mockFactory) CreateServiceWithRealOdbcConnection()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        var callCount = 0;
        mockFactory.Setup(f => f.CreateConnection()).Returns(() =>
        {
            callCount++;
            if (callCount == 1)
                return Mock.Of<IDbConnection>();
            return new OdbcConnection("DSN=FakeNonExistentDSN_12345;");
        });
        mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");

        var service = new BRReciboElectronicoOdbc(mockFactory.Object);
        return (service, mockFactory);
    }

    #endregion

    #region Constructor

    [TestMethod]
    public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());

        var service = new BRReciboElectronicoOdbc(mockFactory.Object);

        Assert.IsNotNull(service);
        mockFactory.Verify(f => f.CreateConnection(), Times.Once);
    }

    #endregion

    #region ApplicationUser Property

    [TestMethod]
    public void ApplicationUser_ShouldReturnFactoryApplicationUser()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.ApplicationUser).Returns("ExpectedUser");

        var service = new BRReciboElectronicoOdbc(mockFactory.Object);

        Assert.AreEqual("ExpectedUser", service.ApplicationUser);
    }

    #endregion

    #region CheckDbConnection

    [TestMethod]
    public void CheckDbConnection_ShouldReturnTrue_WhenFactoryReturnsTrue()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.CheckConnection()).Returns(true);

        var service = new BRReciboElectronicoOdbc(mockFactory.Object);

        Assert.IsTrue(service.CheckDbConnection());
    }

    [TestMethod]
    public void CheckDbConnection_ShouldReturnFalse_WhenFactoryReturnsFalse()
    {
        var mockFactory = new Mock<IDbConnectionFactory>();
        mockFactory.Setup(f => f.CreateConnection()).Returns(Mock.Of<IDbConnection>());
        mockFactory.Setup(f => f.CheckConnection()).Returns(false);

        var service = new BRReciboElectronicoOdbc(mockFactory.Object);

        Assert.IsFalse(service.CheckDbConnection());
    }

    #endregion

    #region Structure / Reflection

    [TestMethod]
    public void ClassShouldImplementInterface_IBRReciboElectronico()
    {
        Assert.IsTrue(typeof(IBRReciboElectronico).IsAssignableFrom(typeof(BRReciboElectronicoOdbc)));
    }

    [TestMethod]
    [DataRow("ObtenDatasetRecibo")]
    [DataRow("ObtenDatasetReciboFull")]
    [DataRow("ObtenDatasetAdicionales")]
    [DataRow("CheckDbConnection")]
    public void ShouldContainPublicMethod(string methodName)
    {
        var method = typeof(BRReciboElectronicoOdbc).GetMethod(methodName, BindingFlags.Public | BindingFlags.Instance);
        Assert.IsNotNull(method, $"Public method {methodName} not found");
    }

    [TestMethod]
    public void ShouldContainPrivateMethod_ObtenDatasetAdicional()
    {
        var method = typeof(BRReciboElectronicoOdbc).GetMethod("ObtenDatasetAdicional", BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.IsNotNull(method, "Private method ObtenDatasetAdicional not found");
    }

    [TestMethod]
    public void ShouldContainProperty_ApplicationUser()
    {
        var prop = typeof(BRReciboElectronicoOdbc).GetProperty("ApplicationUser", BindingFlags.Public | BindingFlags.Instance);
        Assert.IsNotNull(prop, "Property ApplicationUser not found");
        Assert.IsTrue(prop.CanRead);
    }

    #endregion

    #region InvalidCastException - Mock IDbConnection

    [TestMethod]
    public void ObtenDatasetRecibo_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        var nomina = CreateTestNomina();

        Assert.Throws<InvalidCastException>(() => service.ObtenDatasetRecibo(nomina));
    }

    [TestMethod]
    public void ObtenDatasetReciboFull_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();

        Assert.Throws<InvalidCastException>(() =>
            service.ObtenDatasetReciboFull("COMP", "TRAB000001", "TN", "CN", 2026, 1, ManejoNomina.periodica, 1, "CF", "01"));
    }

    [TestMethod]
    public void ObtenDatasetAdicionales_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        var nomina = CreateTestNomina();

        Assert.Throws<InvalidCastException>(() => service.ObtenDatasetAdicionales(nomina, "SELECT 1"));
    }

    #endregion

    #region Real OdbcConnection - OdbcException on Open

    [TestMethod]
    public void ObtenDatasetRecibo_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        var nomina = CreateTestNomina();

        Assert.Throws<OdbcException>(() => service.ObtenDatasetRecibo(nomina));
    }

    [TestMethod]
    public void ObtenDatasetReciboFull_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();

        Assert.Throws<OdbcException>(() =>
            service.ObtenDatasetReciboFull("COMP", "TRAB000001", "TN", "CN", 2026, 1, ManejoNomina.periodica, 1, "CF", "01"));
    }

    [TestMethod]
    public void ObtenDatasetAdicionales_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        var nomina = CreateTestNomina();

        Assert.Throws<OdbcException>(() => service.ObtenDatasetAdicionales(nomina, "SELECT 1"));
    }

    #endregion

    #region Private Method - ObtenDatasetAdicional via Reflection

    [TestMethod]
    public void ObtenDatasetAdicional_Private_ShouldThrowInvalidCastException_WhenNotOdbcConnection()
    {
        var service = CreateServiceWithMockDB();
        var nomina = CreateTestNomina();

        var method = typeof(BRReciboElectronicoOdbc).GetMethod("ObtenDatasetAdicional", BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.IsNotNull(method);

        var ex = Assert.Throws<TargetInvocationException>(() =>
            method.Invoke(service, new object[] { nomina, "SELECT 1" }));
        Assert.IsInstanceOfType<InvalidCastException>(ex.InnerException);
    }

    [TestMethod]
    public void ObtenDatasetAdicional_Private_RealOdbcConnection_ShouldThrowOdbcException()
    {
        var (service, _) = CreateServiceWithRealOdbcConnection();
        var nomina = CreateTestNomina();

        var method = typeof(BRReciboElectronicoOdbc).GetMethod("ObtenDatasetAdicional", BindingFlags.NonPublic | BindingFlags.Instance);
        Assert.IsNotNull(method);

        var ex = Assert.Throws<TargetInvocationException>(() =>
            method.Invoke(service, new object[] { nomina, "SELECT 1" }));
        Assert.IsInstanceOfType<OdbcException>(ex.InnerException);
    }

    #endregion
}

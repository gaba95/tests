﻿using System.Text;
using Newtonsoft.Json;
using ADAM.Recibos.Hangfire.Models;
using System.Text.Encodings.Web;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.Recibos.Hangfire
{
    public static class HangfireHelper
    {
        private static readonly HttpClientHandler httpClientHandler = new HttpClientHandler
        {
            AllowAutoRedirect = true,
            MaxAutomaticRedirections = 2,
            ServerCertificateCustomValidationCallback = (message, cert, chain, sslPolicyErrors) => sslPolicyErrors == System.Net.Security.SslPolicyErrors.None
        };

        private static readonly HttpClient client = new HttpClient(httpClientHandler);

        public static Task<HttpResponseMessage> CreateEmployeeRequestAsync(string url, string endpoint, EmployeeRequest employeeRequest)
        {
            Uri baseUri;

            if (!Uri.TryCreate(url, UriKind.Absolute, out baseUri))
            {
                throw new ArgumentException("Url no valida.", nameof(url));
            }

            string sanitizedUrl = UrlEncoder.Default.Encode(baseUri.AbsolutePath);
            string sanitizedEndPoint = UrlEncoder.Default.Encode(endpoint);
			GlobalHelper.ValidateUrl(sanitizedUrl);

			var fullUrl = new Uri($"{sanitizedUrl}{sanitizedEndPoint}");

            return CreateEmployeeRequestCoreAsync(fullUrl, employeeRequest);
        }

        private static async Task<HttpResponseMessage> CreateEmployeeRequestCoreAsync(Uri fullUrl, EmployeeRequest employeeRequest)
        {
            string json = JsonConvert.SerializeObject(employeeRequest);
            HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");

            using (var request = new HttpRequestMessage(HttpMethod.Post, fullUrl))
            {
                request.Content = content;

                try
                {
                    return await client.SendAsync(request);
                }
                catch (HttpRequestException ex)
                {
                    // Manejo específico de excepciones relacionadas con la solicitud HTTP/HTTPS
                    throw new InvalidOperationException("Error al enviar la solicitud HTTP/HTTPS.", ex);
                }
                catch (Exception ex)
                {
                    // Manejo genérico de excepciones
                    throw new InvalidOperationException("Ocurrió un error al procesar la solicitud.", ex);
                }
            }
        }        
    }
}
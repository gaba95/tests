﻿using System.Data;
using Microsoft.Data.SqlClient;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos
{
    public class BRReciboElectronicoSql : IBRReciboElectronico
    {
        private const string ProcNominaSat = "sp_nomina_sat";
        private const string TablePrincipalName = "TablePrincipal";
        private const string ParamCompania = "@compania";
        private const string ParamTrabajador = "@trabajador";
        private const string ParamTipoNomina = "@tipo_nomina";
        private const string ParamClaseNomina = "@clase_nomina";
        private const string ParamAnio = "@anio";
        private const string ParamPeriodo = "@periodo";
        private const string ParamNumeroLiquidacion = "@numero_liquidacion";
        private const string ParamManejoNomina = "@manejo_nomina";
        private const string ParamConceptoFactura = "@concepto_factura";
        private const string ParamMetodoPago = "@metodo_pago";

        private readonly IDbConnectionFactory _connectionFactory;

        public string ApplicationUser
        {
            get
            {
                return _connectionFactory.ApplicationUser;
            }
        }

        public BRReciboElectronicoSql(IDbConnectionFactory connectionFactory)
        {
            this._connectionFactory = connectionFactory;
            this._connectionFactory.CreateConnection();
        }

        public bool CheckDbConnection()
        {
            return _connectionFactory.CheckConnection();
        }

        public DataSet ObtenDatasetReciboFull(string compania, string trabajador, string tipoNomina,
                                              string claseNomina, int anio, int periodo,
                                              ManejoNomina manejoNomina, int numeroLiquidacion,
                                              string conceptoFactura, string formaPagoDefault)
        {
            // Local Data
            DataSet ds = new();

            using (var dbConnection = this._connectionFactory.CreateConnection())
            {
                if (dbConnection.State == ConnectionState.Closed)
                    dbConnection.Open();

                #region Datos Principales
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, ProcNominaSat, TablePrincipalName, cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddCharParam(cmd, ParamClaseNomina, 2, claseNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                    SqlHelpers.AddVarCharParam(cmd, ParamConceptoFactura, conceptoFactura);
                    SqlHelpers.AddCharParam(cmd, ParamMetodoPago, 1, formaPagoDefault);
                }));
                #endregion

                #region Horas Extra
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_horas_extra_sat", "TableHorasExtra", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddCharParam(cmd, ParamClaseNomina, 2, claseNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion
                
                #region Incapacidades
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_incapacidades_sat", "TableIncapacidades", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion

                #region Otros Pagos
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_otros_pagos_sat", "TableOtrosPagos", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddCharParam(cmd, ParamClaseNomina, 2, claseNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion

                #region Acciones Titulos
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_acciones_titulos", "TableAccionesTitulos", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion

                #region Jubilación Pensión Retiro
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_jubilacion_pension_retiro", "TableJubilacionPensionRetiro", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion

                #region Separacion Indemnizacion
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_separacion_indemnizacion", "TableSeparacionIndemnizacion", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion

                #region Subcontratacion
                ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, "sp_subcontratacion", "TableSubcontratacion", cmd =>
                {
                    SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                    SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                    SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                    SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                    SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                    SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                    SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                }));
                #endregion

                #region Conceptos Separación
                if (manejoNomina == ManejoNomina.interactiva)
                {
                    ds.Tables.Add(SqlHelpers.ExecuteSpToDataTable(dbConnection, ProcNominaSat, "TableConceptosSeparacion", cmd =>
                    {
                        SqlHelpers.AddCharParam(cmd, ParamCompania, 4, compania);
                        SqlHelpers.AddCharParam(cmd, ParamTrabajador, 10, trabajador);
                        SqlHelpers.AddCharParam(cmd, ParamTipoNomina, 2, tipoNomina);
                        SqlHelpers.AddCharParam(cmd, ParamClaseNomina, 2, claseNomina);
                        SqlHelpers.AddIntParam(cmd, ParamAnio, anio);
                        SqlHelpers.AddIntParam(cmd, ParamPeriodo, periodo);
                        SqlHelpers.AddIntParam(cmd, ParamNumeroLiquidacion, numeroLiquidacion);
                        SqlHelpers.AddIntParam(cmd, ParamManejoNomina, (int)manejoNomina);
                        SqlHelpers.AddVarCharParam(cmd, ParamConceptoFactura, conceptoFactura);
                        SqlHelpers.AddCharParam(cmd, ParamMetodoPago, 1, formaPagoDefault);
                        SqlHelpers.AddIntParam(cmd, "@i_pago_separacion", 1);
                    }));

                    // Validate if TablePrincipal has no rows, in this case exchange table names
                    // to display header info, otherwise no header info will be displayed
                    if (ds.Tables[TablePrincipalName].Rows.Count <= 0)
                    {
                        ds.Tables[TablePrincipalName].TableName = "TableConceptosSeparacionZero"; //As it doesn't have info, rename it to not take it into account in xslt
                        ds.Tables["TableConceptosSeparacion"].TableName = TablePrincipalName;
                    }
                }
                #endregion 
            }

            // PTF-2091
            // Validate if TablePrincipal has no rows, in this case exchange table names
            // to display header info, otherwise no header info will be displayed
            if (manejoNomina == ManejoNomina.interactiva && ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].TableName = "TableConceptosSeparacionZero"; //As it doesn't have info, rename it to not take it into account in xslt
                ds.Tables[8].TableName = TablePrincipalName;
            }

            // Default
            return ds;
        }

        public DataSet ObtenDatasetRecibo(Nomina nomina)
        {
            int connectionRetries = 0;

            DataSet dsPrincipal = null;

            // Added connection tries to this method as well, because of random errors the user was getting
            // when generating multiple XMLs
            while (connectionRetries < Database.MaxConnectionRetries)
            {
                try
                {
                    if (!_connectionFactory.CheckConnection())
                    {
                        connectionRetries++;
                        continue;
                    }

                    Task<DataSet>[] obtenDatosTaks;

                    if (nomina.ManejoNomina == ManejoNomina.interactiva)
                    {
                        obtenDatosTaks = new Task<DataSet>[9];
                    }
                    else
                    {
                        obtenDatosTaks = new Task<DataSet>[8];
                    }

                    // Llenar los datos principales
                    obtenDatosTaks[0] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetPrincipal(nomina); });

                    // Agregar Horas Extra
                    obtenDatosTaks[1] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetHorasExtra(nomina); });

                    // Agregar Incapacidades
                    obtenDatosTaks[2] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetIncapacidades(nomina); });

                    // Agregar Otros Pagos
                    obtenDatosTaks[3] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetOtrosPagos(nomina); });

                    // Agregar Acciones Titulos
                    obtenDatosTaks[4] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetAccionesTitulos(nomina); });

                    // Agregar Jubilacion Pension Retiro
                    obtenDatosTaks[5] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetJubilacionPensionRetiro(nomina); });

                    // Agregar Separacion Indemnizacion
                    obtenDatosTaks[6] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetSeparacionIndemnizacion(nomina); });

                    // Agregar Subcontratacion
                    obtenDatosTaks[7] = Task.Factory.StartNew<DataSet>(() => { return ObtenDatasetSubcontratacion(nomina); });

                    //PTF-2091: Add Separation-Only concepts for second node, if it's an interactive payroll
                    if (nomina.ManejoNomina == ManejoNomina.interactiva)
                    {
                        obtenDatosTaks[8] = Task.Factory.StartNew<DataSet>(() => { return ObtenDataseConceptosSeparacion(nomina); });
                    }

                    // Espera a que todas las tareas terminen
                    Task.WaitAll(obtenDatosTaks);

                    // Check if TablePrincipal has no rows, in this case exchange table names
                    // to display header info, otherwise no header info will be displayed
                    if (nomina.ManejoNomina == ManejoNomina.interactiva && obtenDatosTaks[0].Result.Tables[0].Rows.Count == 0)
                    {
                        obtenDatosTaks[0].Result.Tables[0].TableName = "TableConceptosSeparacionZero"; //As it doesn't have info, rename it to not take it into account in xslt
                        obtenDatosTaks[8].Result.Tables[0].TableName = TablePrincipalName;
                    }

                    // Agrega los diferentes datatables al dataset principal
                    dsPrincipal = new DataSet();
                    foreach (var task in obtenDatosTaks)
                    {
                        dsPrincipal.Tables.Add(task.Result.Tables[0].Copy());
                    }

                    return dsPrincipal;
                }
                catch
                {
                    connectionRetries++;

                    if (connectionRetries == Database.MaxConnectionRetries)
                        throw;
                }
            }

            // Devolver un unico Dataset con todos los tables para pasarlo al XSLT
            return dsPrincipal;
        }

        #region Call from obtenDatasetRecibo method

        private DataSet ObtenDatasetPrincipal(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = ProcNominaSat;

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamClaseNomina, SqlDbType.Char, 2).Value = nomina.ClaseNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Parameters.Add(ParamConceptoFactura, SqlDbType.VarChar).Value = nomina.ConceptoFactura;
            sqlStmt.Parameters.Add(ParamMetodoPago, SqlDbType.Char).Value = nomina.FormaPagoDefault;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = TablePrincipalName;
            }

            return dsResult;
        }

        private DataSet ObtenDataseConceptosSeparacion(Nomina nomina)
        {

            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = ProcNominaSat;

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamClaseNomina, SqlDbType.Char, 2).Value = nomina.ClaseNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Parameters.Add(ParamConceptoFactura, SqlDbType.VarChar).Value = nomina.ConceptoFactura;
            sqlStmt.Parameters.Add(ParamMetodoPago, SqlDbType.Char).Value = nomina.FormaPagoDefault;
            sqlStmt.Parameters.Add("@i_pago_separacion", SqlDbType.Int).Value = 1;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableConceptosSeparacion";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetHorasExtra(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_horas_extra_sat";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamClaseNomina, SqlDbType.Char, 2).Value = nomina.ClaseNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableHorasExtra";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetIncapacidades(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_incapacidades_sat";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableIncapacidades";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetOtrosPagos(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_otros_pagos_sat";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamClaseNomina, SqlDbType.Char, 2).Value = nomina.ClaseNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableOtrosPagos";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetAccionesTitulos(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_acciones_titulos";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableAccionesTitulos";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetJubilacionPensionRetiro(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_jubilacion_pension_retiro";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableJubilacionPensionRetiro";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetSeparacionIndemnizacion(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_separacion_indemnizacion";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableSeparacionIndemnizacion";
            }

            return dsResult;
        }

        private DataSet ObtenDatasetSubcontratacion(Nomina nomina)
        {
            using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

            if (sqlConnection.State == ConnectionState.Closed)
                sqlConnection.Open();

            const string sqlQuery = "sp_subcontratacion";

            var sqlStmt = new SqlCommand(sqlQuery, sqlConnection)
            {
                CommandType = CommandType.StoredProcedure
            };

            sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
            sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
            sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
            sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
            sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
            sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
            sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
            sqlStmt.Prepare();

            var dsResult = SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                dsResult.Tables[0].TableName = "TableSubcontratacion";
            }

            return dsResult;
        }

        #endregion  Call from ObtenDatasetRecibo method

        public DataSet ObtenDatasetAdicionales(Nomina nomina, string procedimiento)
        {
            if (SafeProcedures.WhiteList.TryGetValue(procedimiento, out string safeProcName))
            {
                int connectionRetries = 0;

                // Added connection tries to this method as well, because of random errors the user was getting
                // when generating multiple XMLs
                while (connectionRetries < Database.MaxConnectionRetries)
                {
                    try
                    {
                        using SqlConnection sqlConnection = (SqlConnection)this._connectionFactory.CreateConnection();

                        if (sqlConnection.State == ConnectionState.Closed)
                            sqlConnection.Open();

                        var sqlStmt = new SqlCommand(safeProcName, sqlConnection)
                        {
                            CommandType = CommandType.StoredProcedure
                        };

                        sqlStmt.Parameters.Add(ParamCompania, SqlDbType.Char, 4).Value = nomina.Compania;
                        sqlStmt.Parameters.Add(ParamTrabajador, SqlDbType.Char, 10).Value = nomina.Trabajador;
                        sqlStmt.Parameters.Add(ParamTipoNomina, SqlDbType.Char, 2).Value = nomina.TipoNomina;
                        sqlStmt.Parameters.Add(ParamClaseNomina, SqlDbType.Char, 2).Value = nomina.ClaseNomina;
                        sqlStmt.Parameters.Add(ParamAnio, SqlDbType.Int).Value = nomina.Anio;
                        sqlStmt.Parameters.Add(ParamPeriodo, SqlDbType.Int).Value = nomina.Periodo;
                        sqlStmt.Parameters.Add(ParamNumeroLiquidacion, SqlDbType.Int).Value = nomina.NumeroLiquidacion;
                        sqlStmt.Parameters.Add(ParamManejoNomina, SqlDbType.Int).Value = nomina.ManejoNomina;
                        sqlStmt.Prepare();

                        return SqlCommandExecutor.Request(new SqlDataAdapter(sqlStmt));
                    }
                    catch
                    {
                        connectionRetries++;

                        if (connectionRetries == Database.MaxConnectionRetries)
                            throw;
                    }
                }

                return null;
            }
            else
            {
                return null;    
            }
        }

        #region Helper Methods

        

        

        #endregion
    }
}

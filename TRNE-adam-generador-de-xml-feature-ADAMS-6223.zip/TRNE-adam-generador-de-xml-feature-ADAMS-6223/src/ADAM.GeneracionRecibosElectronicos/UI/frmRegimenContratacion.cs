using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Diagnostics.CodeAnalysis;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.GeneracionRecibosElectronicos.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmRegimenContratacion : Form
    {

        #region variables de la clase
        private ICatalogoAdicional _catalogoAdicional;
        #endregion

        #region propiedades de la clase

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; } = "";

    #endregion

        #region eventos de la clase
    
        private void FrmRegimenContratacion_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }

        private void cboCompania_SelectedIndexChanged(object sender, EventArgs e)
        {
            compania = cboCompania.SelectedValue.ToString();

            if (compania.Equals("System.Data.DataRowView"))
            {
                DataRowView drvCompania = cboCompania.SelectedValue as DataRowView;

                compania = (drvCompania != null) ? drvCompania[0].ToString() : "";
            }

            // Fill Employees
            LlenaGridTrabajadores();
        }

        private void cmdCambiar_Click(object sender, EventArgs e)
        {
            FrmCambiaRegimen cambia = new FrmCambiaRegimen();
            cambia.gridTrabajadores = this.gridTrabajadoresRegimen;
            cambia.tipoPlataforma = this.tipoPlataforma;
            cambia.FrmRegimen = this;

            cambia.ShowDialog();
        }
    #endregion

        #region metodos de la clase

        /// <summary>
        /// Constructor.
        /// </summary>
        public FrmRegimenContratacion()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialize class.
        /// </summary>
        private void InicializaClase()
        {

            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);

            // Fill Company Dropdown
            cboCompania.DataSource = _catalogoAdicional.obtenDatasetCompanias(LanguageCodes.Mexico).Tables[0];
            cboCompania.DisplayMember = "nombre_cia";
            cboCompania.ValueMember = "compania";

            // Select Default Company
            if (!string.IsNullOrEmpty(compania))
            { cboCompania.SelectedItem = compania; }

            // Fill Employees
            LlenaGridTrabajadores();
        }

        /// <summary>
        /// Load, grid employees.
        /// </summary>
        public void LlenaGridTrabajadores()
        {
            try
            {
                gridTrabajadoresRegimen.DataSource = _catalogoAdicional.obtenDatasetTrabajadoresRegimen(compania).Tables[0];
                gridTrabajadoresRegimen.Columns["compania"].HeaderText = "compañia";
                gridTrabajadoresRegimen.Columns["regimen"].HeaderText = "régimen";
                gridTrabajadoresRegimen.Columns["descripcion"].HeaderText = "descripción";
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
    
    #endregion

    }
}

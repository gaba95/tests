﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("auxilios", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Attendances
    {
        [JsonProperty("descripcion")]
        public string AuxilioSDescripcion { get; set; } = "";

        [JsonProperty("valor")]
        public decimal AuxilioS { get; set; }
        public bool esSalarial { get; set; }

    }
}

using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using ADAM.GeneracionRecibosElectronicos.Tests.Classes.Helpers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{

    [TestClass]
    public class RestClientTests
    {
        private static string BaseUrl => TestServer.Url;

        [TestMethod]
        public void LoginRequest_WhenServerReturns200_ReturnsJwt()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl,
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var response = client.LoginRequest();

            Assert.IsNotNull(response);
            Assert.AreEqual("OK", response.type);
            Assert.IsNotNull(response.content);
            Assert.AreEqual("jwt-token-from-test-server", response.content.jwt);
        }

        [TestMethod]
        public void LoginRequest_WhenServerReturns401_PopulatesTypeAndValidationMessage()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl,
                userName = "badTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var response = client.LoginRequest();

            Assert.IsNotNull(response);
            Assert.AreEqual(HttpStatusCode.Unauthorized.ToString(), response.type);
            Assert.IsTrue(!string.IsNullOrWhiteSpace(response.validationMessage));
        }

        [TestMethod]
        public void LoginRequest_WhenEndpointUnreachable_ReturnsErrorType()
        {
            var client = new RestApiClient
            {
                endPoint = "http://127.0.0.1:1/",
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var response = client.LoginRequest();

            Assert.IsNotNull(response);
            Assert.AreEqual("Error", response.type);
            Assert.IsTrue(!string.IsNullOrWhiteSpace(response.validationMessage));
        }

        [TestMethod]
        public void AddPayrollRequest_WhenEndpointUnreachable_ReturnsResponseWithNotification()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl,
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var result = client.AddPayrollRequest("123-45", "token");

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.notificaciones);
            Assert.IsTrue(result.notificaciones.Count > 0);
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.notificaciones[0].mensaje));
        }

        [TestMethod]
        public void AddPayrollRequest_WhenServerReturns200_DoesNotThrow_ReturnsResponse()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl,
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var result = client.AddPayrollRequest("123-45", "token");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AddPayrollRequest_WhenServerReturns500_ReturnsResponseWithNotification()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl,
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var result = client.AddPayrollRequest("123-452", "fail");

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.notificaciones);
            Assert.IsTrue(result.notificaciones.Count > 0);
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.notificaciones[0].mensaje));
        }

        [TestMethod]
        public void GetDocumentState_WhenServerReturns200_ReturnsNonNull()
        {
            var client = new RestApiClient { endPoint = TestServer.ExternalUrl };

            var resp = client.getDocumentState("ok", "123-452", "docId", DateTime.UtcNow);

            Assert.IsNotNull(resp);
        }

        [TestMethod]
        public void GetDocumentState_WhenServerReturns200_CoversSucessBranch()
        {
            var client = new RestApiClient
            {
                endPoint = TestServer.ExternalUrl,
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var resp = client.getDocumentState("ok","123-452","docId", DateTime.UtcNow);
            Assert.IsNotNull(resp);
        }

        [TestMethod]
        public void GetDocumentState_WhenServerReturns500_CoversElseBranch_AddDianError()
        {
            var client = new RestApiClient
            {
                endPoint = TestServer.ExternalUrl,
                userName = "goodTest",
                userPwd = TestServer.ToSecureString("pwd")
            };

            var resp = client.getDocumentState("fail", "123-452", "docId", DateTime.UtcNow);

            Assert.IsNotNull(resp);
            Assert.IsNotNull(resp.dianErrors);
            Assert.IsTrue(resp.dianErrors.Count > 0);

            Assert.IsFalse(string.IsNullOrWhiteSpace(resp.dianErrors[0].description));
        }

        [TestMethod]
        public void AddPayrollRequest_Defaults_AreNull()
        {
            var dto = new AddPayrollRequest();
            Assert.IsNull(dto.json);
        }

        [TestMethod]
        public void AddPayrollRequest_Serializes_And_Deserializes()
        {
            var original = new AddPayrollRequest { json = "{\"nomina\":\"data\"}" };

            var serialized = JsonConvert.SerializeObject(original);
            var roundtrip = JsonConvert.DeserializeObject<AddPayrollRequest>(serialized);

            Assert.IsNotNull(roundtrip);
            Assert.AreEqual(original.json, roundtrip.json);
        }

        [TestMethod]
        public void AddPayrollResponse_Defaults_AreNull()
        {
            var dto = new AddPayrollResponse();
            Assert.IsNull(dto.message);
            Assert.IsNull(dto.errores);
            Assert.IsNull(dto.notificaciones);
        }

        [TestMethod]
        public void AddPayrollResponse_JsonExtensionData_CapturesUnknownFieldsIntoErrores()
        {
            string json = @"
            {
                ""message"": ""Processed"",
                ""unknownField1"": ""Value1"",
                ""unknownField2"": { ""code"": ""E01"", ""desc"": ""Invalid something"" }
            }";

            var dto = JsonConvert.DeserializeObject<AddPayrollResponse>(json);

            Assert.IsNotNull(dto);
            Assert.AreEqual("Processed", dto.message);

            Assert.IsNotNull(dto.errores, "errores should capture unknown fields via JsonExtensionData.");
            Assert.IsTrue(dto.errores.ContainsKey("unknownField1"));
            Assert.IsTrue(dto.errores.ContainsKey("unknownField2"));

            var nested = dto.errores["unknownField2"] as JObject;
            Assert.IsNotNull(nested);
            Assert.AreEqual("E01", nested["code"]?.ToString());
            Assert.AreEqual("Invalid something", nested["desc"]?.ToString());
        }

        [TestMethod]
        public void AddPayrollResponse_WithNotificaciones_And_ResultadoValidacion_NestedLists_Roundtrip()
        {
            var dto = new AddPayrollResponse
            {
                message = "OK",
                notificaciones = new List<Notificaciones>
                {
                    new Notificaciones
                    {
                        categoriaMensaje = "VALIDATION",
                        codigoMensaje = "VAL001",
                        mensaje = "Documento inválido",
                        documentoID = "D-100",
                        estadoAccion = "RECHAZADO",
                        tipoDocumento = "Nómina",
                        numeroDocumento = "N-1",
                        resultadoValidacion = new List<ResultadoValidacion>
                        {
                            new ResultadoValidacion
                            {
                                documentoID = "D-100",
                                errorCode = "E01",
                                errorMessage = "Campo requerido",
                                fechaInicioPeriodo = "2026-02-10",
                                identificacion = "123",
                                numeroDocumento = "N-1",
                                propertyName = "Salario",
                                tipoDocumento = "Nómina",
                                trabajador = "Juan Perez"
                            }
                        }
                    }
                }
            };

            var json = JsonConvert.SerializeObject(dto);
            var roundtrip = JsonConvert.DeserializeObject<AddPayrollResponse>(json);

            Assert.IsNotNull(roundtrip);
            Assert.AreEqual("OK", roundtrip.message);
            Assert.IsNotNull(roundtrip.notificaciones);
            Assert.AreEqual(1, roundtrip.notificaciones.Count);
            var notif = roundtrip.notificaciones[0];

            Assert.AreEqual("VALIDATION", notif.categoriaMensaje);
            Assert.AreEqual("VAL001", notif.codigoMensaje);
            Assert.AreEqual("Documento inválido", notif.mensaje);
            Assert.AreEqual("D-100", notif.documentoID);
            Assert.AreEqual("RECHAZADO", notif.estadoAccion);
            Assert.AreEqual("Nómina", notif.tipoDocumento);
            Assert.AreEqual("N-1", notif.numeroDocumento);

            Assert.IsNotNull(notif.resultadoValidacion);
            Assert.AreEqual(1, notif.resultadoValidacion.Count);

            var res = notif.resultadoValidacion[0];
            Assert.AreEqual("D-100", res.documentoID);
            Assert.AreEqual("E01", res.errorCode);
            Assert.AreEqual("Campo requerido", res.errorMessage);
            Assert.AreEqual("2026-02-10", res.fechaInicioPeriodo);
            Assert.AreEqual("123", res.identificacion);
            Assert.AreEqual("N-1", res.numeroDocumento);
            Assert.AreEqual("Salario", res.propertyName);
            Assert.AreEqual("Nómina", res.tipoDocumento);
            Assert.AreEqual("Juan Perez", res.trabajador);
        }

        [TestMethod]
        public void AddPayrollResponse_MissingOptionalFields_DoNotThrow()
        {
            string json = @"{ ""message"": ""OK"" }";
            var dto = JsonConvert.DeserializeObject<AddPayrollResponse>(json);

            Assert.IsNotNull(dto);
            Assert.AreEqual("OK", dto.message);

            Assert.IsNull(dto.notificaciones);
            Assert.IsNull(dto.errores);
        }

        [TestMethod]
        public void AddGlobalPayrollResponse_Should_Set_And_Get_Properties()
        {
            var dto = new AddGlobalPayrollResponse
            {
                message = "OK"
            };

            Assert.AreEqual("OK", dto.message);
            Assert.IsNull(dto.errores);
        }

        [TestMethod]
        public void AddGlobalPayrollResponse_Should_Serialize_And_Deserialize()
        {
            var original = new AddGlobalPayrollResponse
            {
                message = "SUCCESS"
            };

            var json = JsonConvert.SerializeObject(original);
            var result = JsonConvert.DeserializeObject<AddGlobalPayrollResponse>(json);

            Assert.IsNotNull(result);
            Assert.AreEqual("SUCCESS", result.message);
            Assert.IsNull(result.errores);
        }

        [TestMethod]
        public void AddGlobalPayrollResponse_Should_Capture_Unknown_Fields_In_Errores()
        {
            string json = @"
            {
                ""message"": ""FAIL"",
                ""extra1"": ""value1"",
                ""extra2"": 42,
                ""extra3"": { ""deep"": true }
            }";

            var dto = JsonConvert.DeserializeObject<AddGlobalPayrollResponse>(json);

            Assert.IsNotNull(dto);
            Assert.AreEqual("FAIL", dto.message);

            Assert.IsNotNull(dto.errores);
            Assert.IsTrue(dto.errores.ContainsKey("extra1"));
            Assert.IsTrue(dto.errores.ContainsKey("extra2"));
            Assert.IsTrue(dto.errores.ContainsKey("extra3"));

            Assert.AreEqual("value1", TestServer.GetExt<string>(dto.errores, "extra1"));
            Assert.AreEqual(42, TestServer.GetExt<int>(dto.errores, "extra2"));

            var extra3 = dto.errores["extra3"] as JObject ?? (dto.errores["extra3"] as JToken) as JObject;
            Assert.IsNotNull(extra3);
            Assert.IsTrue(extra3["deep"]!.ToObject<bool>());
        }

        [TestMethod]
        public void AddGlobalPayrollResponse_Deserializing_Empty_Object_Keeps_Errores_Null()
        {
            var dto = JsonConvert.DeserializeObject<AddGlobalPayrollResponse>(@"{ ""message"": ""X"" }");

            Assert.IsNotNull(dto);
            Assert.AreEqual("X", dto.message);
            Assert.IsNull(dto.errores);
        }

        [TestMethod]
        public void DianErrors_Should_Set_And_Get_All_Properties()
        {
            var err = new DianErrors
            {
                code = "WARN01",
                description = "Observación parcial"
            };

            Assert.AreEqual("WARN01", err.code);
            Assert.AreEqual("Observación parcial", err.description);
        }

        [TestMethod]
        public void DianErrors_Should_Serialize_And_Deserialize_Roundtrip()
        {
            var original = new DianErrors
            {
                code = "0",
                description = "OK"
            };

            var json = JsonConvert.SerializeObject(original);
            var copy = JsonConvert.DeserializeObject<DianErrors>(json);

            Assert.IsNotNull(copy);
            Assert.AreEqual("0", copy.code);
            Assert.AreEqual("OK", copy.description);
        }

        [TestMethod]
        public void DocumentStateResponse_Should_Set_And_Get_All_Properties()
        {
            var nowUtc = new DateTime(2024, 12, 31, 23, 59, 59, DateTimeKind.Utc);

            var dto = new DocumentStateResponse
            {
                estadoDocumento = "ACEPTADO",
                fechaGeneracion = nowUtc,
                cune = "CUNE-ABC-123",
                numeroDocumento = "NUM-0001",
                dianErrors = new List<DianErrors>
                {
                    new DianErrors { code = "0", description = "OK" }
                }
            };

            Assert.AreEqual("ACEPTADO", dto.estadoDocumento);
            Assert.AreEqual(nowUtc, dto.fechaGeneracion);
            Assert.AreEqual("CUNE-ABC-123", dto.cune);
            Assert.AreEqual("NUM-0001", dto.numeroDocumento);

            Assert.IsNotNull(dto.dianErrors);
            Assert.AreEqual(1, dto.dianErrors.Count);
            Assert.AreEqual("0", dto.dianErrors[0].code);
            Assert.AreEqual("OK", dto.dianErrors[0].description);
        }

        [TestMethod]
        public void DocumentStateResponse_Should_Serialize_And_Deserialize_Roundtrip()
        {
            var original = new DocumentStateResponse
            {
                estadoDocumento = "RECHAZADO",
                fechaGeneracion = new DateTime(2025, 1, 10, 8, 30, 0, DateTimeKind.Utc),
                cune = "CUNE-XYZ-789",
                numeroDocumento = "NUM-7777",
                dianErrors = new List<DianErrors>
                {
                    new DianErrors { code = "E01", description = "Error en estructura" },
                    new DianErrors { code = "E02", description = "Campo requerido" }
                }
            };

            var json = JsonConvert.SerializeObject(original);
            var copy = JsonConvert.DeserializeObject<DocumentStateResponse>(json);

            Assert.IsNotNull(copy);
            Assert.AreEqual("RECHAZADO", copy.estadoDocumento);
            Assert.AreEqual(original.fechaGeneracion, copy.fechaGeneracion);
            Assert.AreEqual("CUNE-XYZ-789", copy.cune);
            Assert.AreEqual("NUM-7777", copy.numeroDocumento);

            Assert.IsNotNull(copy.dianErrors);
            Assert.AreEqual(2, copy.dianErrors.Count);
            Assert.AreEqual("E01", copy.dianErrors[0].code);
            Assert.AreEqual("Error en estructura", copy.dianErrors[0].description);
        }

        [TestMethod]
        public void DocumentStateResponse_Deserialize_From_Raw_Json_With_dianErrors_Array()
        {
            var json = @"
            {
                ""estadoDocumento"": ""EN_PROCESO"",
                ""fechaGeneracion"": ""2025-06-01T12:15:00Z"",
                ""cune"": ""CUNE-TEST-0001"",
                ""numeroDocumento"": ""NOM-2025-0001"",
                ""DianErrors"": [
                    { ""code"": ""W01"", ""description"": ""En validación"" },
                    { ""code"": ""W02"", ""description"": ""Pendiente de firma"" }
                ]
            }";

            var dto = JsonConvert.DeserializeObject<DocumentStateResponse>(json);

            Assert.IsNotNull(dto);
            Assert.AreEqual("EN_PROCESO", dto.estadoDocumento);
            Assert.AreEqual(DateTime.Parse("2025-06-01T12:15:00Z").ToUniversalTime(), dto.fechaGeneracion.ToUniversalTime());
            Assert.AreEqual("CUNE-TEST-0001", dto.cune);
            Assert.AreEqual("NOM-2025-0001", dto.numeroDocumento);

            Assert.IsNotNull(dto.dianErrors);
            Assert.AreEqual(2, dto.dianErrors.Count);
            Assert.AreEqual("W01", dto.dianErrors[0].code);
            Assert.AreEqual("En validación", dto.dianErrors[0].description);
        }

        [TestMethod]
        public void DocumentStateResponse_Default_dianErrors_Is_Null_Unless_Initialized()
        {
            var dto = new DocumentStateResponse();
            Assert.IsNull(dto.dianErrors);
        }

        [TestMethod]
        public void RestApiClient_JsonProperty_CanSetAndGetValue()
        {
            var client = new RestApiClient();
            var expected = "{\"a\":1}";
            client.json = expected;

            Assert.AreEqual(expected, client.json);
        }

        [TestMethod]
        public void RestApiClient_JsonProperty_AllowsNull()
        {
            var client = new RestApiClient();
            client.json = null;

            Assert.IsNull(client.json);
        }

        [TestMethod]
        public void AddPayrollRequest_WhenServerReturnsNonSuccess_PopulatesNotificacionesAndReturns()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl
            };

            var result = client.AddPayrollRequest("123-45", "fail");

            Assert.IsNotNull(result, "Method should return an AddPayrollResponse instance.");
            Assert.IsNotNull(result.notificaciones, "notificaciones should be initialized to avoid NullReference.");
            Assert.IsTrue(result.notificaciones.Count > 0, "Should contain at least one notification from the ELSE branch.");
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.notificaciones[0].mensaje),
                "Notification message should come from response.ReasonPhrase.");
        }

        [TestMethod]
        public void AddPayrollRequest_WhenServerReturns200_DeserializesBody_And_Returns()
        {
            var client = new RestApiClient
            {
                endPoint = BaseUrl
            };

            var result = client.AddPayrollRequest("123-45", "ok");

            Assert.IsNotNull(result, "Method should return an AddPayrollResponse instance.");
        }

        [TestMethod]
        public void AddPayrollRequest_WhenEndpointUnreachable_PopulatesNotificacionesWithException_And_Returns()
        {
            var client = new RestApiClient
            {
                endPoint = "http://127.0.0.1:1/"
            };

            var result = client.AddPayrollRequest("123-45", "any");

            Assert.IsNotNull(result, "Method should return an AddPayrollResponse instance from the catch block.");
            Assert.IsNotNull(result.notificaciones, "notificaciones should be initialized to avoid NullReference.");
            Assert.IsTrue(result.notificaciones.Count > 0, "Should contain at least one notification from the CATCH branch.");
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.notificaciones[0].mensaje),
                "Notification message should be the exception message.");
        }

        [TestMethod]
        public void GetDocumentState_WhenEndpointUnreachable_ReturnsDianErrors()
        {
            var client = new RestApiClient
            {
                endPoint = "http://127.0.0.1:1/"
            };

            var resp = client.getDocumentState("token", "123-452", "docId", DateTime.UtcNow);

            Assert.IsNotNull(resp);
            Assert.IsNotNull(resp.dianErrors);
            Assert.IsTrue(resp.dianErrors.Count > 0);
            Assert.IsFalse(string.IsNullOrWhiteSpace(resp.dianErrors[0].description));
        }
    }
}

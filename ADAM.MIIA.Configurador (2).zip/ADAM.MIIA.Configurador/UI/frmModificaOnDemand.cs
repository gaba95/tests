using System.Configuration;
using ADAM.MIIA.Configuration;

namespace ADAM.MIIA.Configurador.UI;

public partial class frmModificaOnDemand : Form
{
    private bool esNuevoRegistro = false;

    public string Clave { get; set; } = "";
    public string RegExArchivo { get; set; } = "";
    public string procedure { get; set; } = "";
    public MIIAOnDemandSection? MIIAOnDemandSection { get; set; }
    public System.Configuration.Configuration? config { get; set; }
    public frmConfiguracion? frmPadre { get; set; }

    public frmModificaOnDemand()
    {
        InitializeComponent();
    }

    private void frmModificaOnDemand_Load(object? sender, EventArgs e)
    {
        if (Clave.Trim() != "")
        {
            CargaValoresActuales();
            esNuevoRegistro = false;
            txtClave.ReadOnly = true;
        }
        else
        {
            esNuevoRegistro = true;
            txtClave.ReadOnly = false;
        }
    }

    private void cmdAceptar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        if (GuardarOnDemand(txtClave.Text.Trim()))
        {
            DialogResult = DialogResult.OK;
            Close();
        }
        else
        {
            DialogResult = DialogResult.None;
        }
    }

    private void CargaValoresActuales()
    {
        txtClave.Text = Clave;
        txtRegEx.Text = RegExArchivo;
        txtProcedure.Text = procedure;
    }

    private bool Validar()
    {
        string claveNueva = txtClave.Text;

        if (esNuevoRegistro)
        {
            foreach (OnDemandMIIA onDemand in MIIAOnDemandSection!.OnDemand)
            {
                if (onDemand.Clave == claveNueva)
                {
                    UIHelper.ShowMessage("La Clave que esta intentando ingresar ya existe", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtClave.Focus();
                    return false;
                }
            }
        }

        foreach (Control campo in Controls)
        {
            if (campo.GetType().ToString() == "System.Windows.Forms.TextBox"
                && ((TextBox)campo).Text.Trim() == string.Empty)
            {
                ((TextBox)campo).Focus();
                UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        return true;
    }

    private bool GuardarOnDemand(string Clave)
    {
        try
        {
            if (!Validar())
                return false;

            if (esNuevoRegistro)
            {
                var nuevoRegistro = new OnDemandMIIA();
                nuevoRegistro.Clave = txtClave.Text;
                nuevoRegistro.RegExArchivo = txtRegEx.Text;
                nuevoRegistro.Procedimiento = txtProcedure.Text;
                MIIAOnDemandSection!.OnDemand.Add(nuevoRegistro);
            }
            else
            {
                var existingItem = MIIAOnDemandSection!.OnDemand[Clave];
                if (existingItem != null)
                {
                    existingItem.RegExArchivo = txtRegEx.Text;
                    existingItem.Procedimiento = txtProcedure.Text;
                }
            }

            var onDemandItem = MIIAOnDemandSection!.OnDemand[Clave];
            if (onDemandItem != null)
            {
                onDemandItem.RegExArchivo = txtRegEx.Text;
                onDemandItem.Procedimiento = txtProcedure.Text;
            }

            config!.Save();
            return true;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }
}

using System.Data;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Test.Fakes
{
    internal sealed class FakeBRReciboElectronico : IBRReciboElectronico
    {
        public string ApplicationUser => "fake_user";

        public DataSet? DatasetRecibo { get; set; }

        public DataSet? DatasetAdicionales { get; set; }

        public bool CheckDbConnection() => true;

        public DataSet ObtenDatasetRecibo(Nomina nomina) => DatasetRecibo!;

        public DataSet ObtenDatasetReciboFull(string compania, string trabajador, string tipoNomina,
            string claseNomina, int anio, int periodo, ManejoNomina manejoNomina,
            int numeroLiquidacion, string conceptoFactura, string formaPagoDefault)
            => DatasetRecibo!;

        public DataSet ObtenDatasetAdicionales(Nomina nomina, string procedimiento) => DatasetAdicionales!;

        /// <summary>
        /// Creates a minimal DataSet with one table and one row that XmlHelper.ConvierteDatasetXml can process.
        /// </summary>
        public static DataSet CreateMinimalDataset()
        {
            var ds = new DataSet("Recibo");
            var table = ds.Tables.Add("nomina");
            table.Columns.Add("trabajador", typeof(string));
            table.Columns.Add("monto", typeof(decimal));
            table.Rows.Add("001", 1000m);
            return ds;
        }

        /// <summary>
        /// Creates a DataSet for adicionales with one table and rows.
        /// </summary>
        public static DataSet CreateAdicionalesDataset()
        {
            var ds = new DataSet("Adicionales");
            var table = ds.Tables.Add("adicional");
            table.Columns.Add("concepto", typeof(string));
            table.Columns.Add("valor", typeof(string));
            table.Rows.Add("DATO1", "VALOR1");
            return ds;
        }
    }
}

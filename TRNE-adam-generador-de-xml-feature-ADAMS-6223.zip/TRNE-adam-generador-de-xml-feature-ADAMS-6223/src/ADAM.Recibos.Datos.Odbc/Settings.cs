﻿using System.Diagnostics.CodeAnalysis;

namespace ADAM.Recibos.Datos.Odbc.Properties 
{
    [ExcludeFromCodeCoverage]
    internal sealed partial class Settings 
    {
        public Settings() 
        {
        }
        
        private void SettingChangingEventHandler(object sender, System.Configuration.SettingChangingEventArgs e) 
        {
            // No implementation required
        }
        
        private void SettingsSavingEventHandler(object sender, System.ComponentModel.CancelEventArgs e) 
        {
            // No implementation required
        }
    }
}

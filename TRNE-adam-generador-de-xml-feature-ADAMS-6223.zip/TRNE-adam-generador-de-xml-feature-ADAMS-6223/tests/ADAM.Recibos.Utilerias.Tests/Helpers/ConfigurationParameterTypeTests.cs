using ADAM.Recibos.Utilerias.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Utilerias.Tests.Helpers
{
    [TestClass]
    public class ConfigurationParameterTypeTests
    {
        [TestMethod]
        public void ConfigurationTypes_ContainsExpectedValues()
        {
            var values = Enum.GetValues(typeof(ConfigurationTypes));

            Assert.AreEqual(12, values.Length);
        }

        [TestMethod]
        [DataRow(ConfigurationTypes.temp_path)]
        [DataRow(ConfigurationTypes.api_url)]
        [DataRow(ConfigurationTypes.ws_user)]
        [DataRow(ConfigurationTypes.ws_password)]
        [DataRow(ConfigurationTypes.stamping_site)]
        [DataRow(ConfigurationTypes.xslt_file)]
        [DataRow(ConfigurationTypes.xsd_file)]
        [DataRow(ConfigurationTypes.generation_type)]
        [DataRow(ConfigurationTypes.additional_generation)]
        [DataRow(ConfigurationTypes.additional_proc)]
        [DataRow(ConfigurationTypes.default_country)]
        [DataRow(ConfigurationTypes.timeout)]
        public void ConfigurationTypes_AllValues_AreDefined(ConfigurationTypes type)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(ConfigurationTypes), type));
        }

        [TestMethod]
        public void ConfigurationTypes_ToString_ReturnsExpectedName()
        {
            Assert.AreEqual("temp_path", ConfigurationTypes.temp_path.ToString());
            Assert.AreEqual("api_url", ConfigurationTypes.api_url.ToString());
            Assert.AreEqual("ws_user", ConfigurationTypes.ws_user.ToString());
            Assert.AreEqual("ws_password", ConfigurationTypes.ws_password.ToString());
            Assert.AreEqual("stamping_site", ConfigurationTypes.stamping_site.ToString());
            Assert.AreEqual("timeout", ConfigurationTypes.timeout.ToString());
        }

        [TestMethod]
        public void ConfigurationTypes_Parse_FromString()
        {
            var result = Enum.Parse<ConfigurationTypes>("api_url");
            Assert.AreEqual(ConfigurationTypes.api_url, result);
        }
    }
}

using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Principal.Test.Classes.Helpers
{
    [TestClass]
    public class WebServiceHelperTests
    {
        #region EnviaXmlTimbrado - Structure

        [TestMethod]
        public void EnviaXmlTimbrado_MethodExists()
        {
            var method = typeof(WebServiceHelper).GetMethod("EnviaXmlTimbrado");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(string), method.ReturnType);
            Assert.AreEqual(5, method.GetParameters().Length);
        }

        [TestMethod]
        public void EnviaXmlTimbrado_IsStatic()
        {
            var method = typeof(WebServiceHelper).GetMethod("EnviaXmlTimbrado");
            Assert.IsNotNull(method);
            Assert.IsTrue(method.IsStatic);
        }

        #endregion

        #region EnviaXmlTimbrado - Exception handling

        [TestMethod]
        public void EnviaXmlTimbrado_WhenDatabaseUnavailable_ReturnsErrorMessage()
        {
            var result = WebServiceHelper.EnviaXmlTimbrado(
                "CBS",
                "http://localhost:9999/NominaService",
                1,
                "<xml></xml>",
                TipoPlataforma.SQLServer);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Length > 0, "Debe retornar un mensaje de error");
        }

        [TestMethod]
        public void EnviaXmlTimbrado_WhenEmptyXml_ReturnsErrorMessage()
        {
            var result = WebServiceHelper.EnviaXmlTimbrado(
                "CBS",
                "http://localhost:9999/NominaService",
                1,
                "",
                TipoPlataforma.ORACLE);

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void EnviaXmlTimbrado_WhenEmptyCompany_ReturnsErrorMessage()
        {
            var result = WebServiceHelper.EnviaXmlTimbrado(
                "",
                "http://localhost:9999/NominaService",
                1,
                "<xml/>",
                TipoPlataforma.SQLServer);

            Assert.IsNotNull(result);
        }

        #endregion

        #region GetStampingStatus - Structure

        [TestMethod]
        public void GetStampingStatus_MethodExists()
        {
            var method = typeof(WebServiceHelper).GetMethod("GetStampingStatus");
            Assert.IsNotNull(method);
            Assert.AreEqual(9, method.GetParameters().Length);
        }

        [TestMethod]
        public void GetStampingStatus_IsStatic()
        {
            var method = typeof(WebServiceHelper).GetMethod("GetStampingStatus");
            Assert.IsNotNull(method);
            Assert.IsTrue(method.IsStatic);
        }

        [TestMethod]
        public void GetStampingStatus_WhenInvalidEndpoint_ThrowsException()
        {
            string[] connParams = { "server", "database" };

            try
            {
                WebServiceHelper.GetStampingStatus(
                    connParams,
                    "",
                    "CBS",
                    "TP",
                    "CN",
                    "2026",
                    "1",
                    "4.0",
                    TipoPlataforma.SQLServer);

                Assert.Fail("Se esperaba una excepción");
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex);
            }
        }

        [TestMethod]
        public void GetStampingStatus_WhenEndpointNoSlash_ThrowsException()
        {
            string[] connParams = { "server", "database" };

            try
            {
                WebServiceHelper.GetStampingStatus(
                    connParams,
                    "http://localhost:9999",
                    "CBS",
                    "TP",
                    "CN",
                    "2026",
                    "1",
                    "4.0",
                    TipoPlataforma.SQLServer);

                Assert.Fail("Se esperaba una excepción de conexión");
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex);
            }
        }

        #endregion

        #region WebServiceHelper - Class structure

        [TestMethod]
        public void WebServiceHelper_IsPublicClass()
        {
            var type = typeof(WebServiceHelper);
            Assert.IsTrue(type.IsPublic);
            Assert.IsTrue(type.IsClass);
        }

        [TestMethod]
        public void WebServiceHelper_HasExpectedMethods()
        {
            var type = typeof(WebServiceHelper);

            Assert.IsNotNull(type.GetMethod("EnviaXmlTimbrado"));
            Assert.IsNotNull(type.GetMethod("GetStampingStatus"));
        }

        #endregion
    }
}

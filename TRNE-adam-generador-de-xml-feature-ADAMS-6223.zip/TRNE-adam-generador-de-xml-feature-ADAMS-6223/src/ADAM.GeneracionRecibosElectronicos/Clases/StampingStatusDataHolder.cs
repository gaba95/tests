﻿using System;
using System.Collections.Generic;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos.Clases
{
    class StampingStatusDataHolder
    {
        readonly Dictionary<ManejoNomina, StampingStatusTempInfo> stampingStatusInfo;

        public StampingStatusDataHolder()
        {
            this.stampingStatusInfo = new Dictionary<ManejoNomina, StampingStatusTempInfo>();
            this.stampingStatusInfo.Add(ManejoNomina.periodica, new StampingStatusTempInfo());
            this.stampingStatusInfo.Add(ManejoNomina.interactiva, new StampingStatusTempInfo());
        }

        public StampingStatusTempInfo getInfo(ManejoNomina manejoNomina)
        {
            return stampingStatusInfo[manejoNomina];
        }

        public bool processedPeriodica()
        {
            return  !string.IsNullOrEmpty(stampingStatusInfo[ManejoNomina.periodica].PayrollType);
        }

        public bool processedInteractiva()
        {
            return !string.IsNullOrEmpty(stampingStatusInfo[ManejoNomina.interactiva].PayrollType);
        }

        public void reset()
        {
            foreach(StampingStatusTempInfo statusInfo in stampingStatusInfo.Values)
            {
                statusInfo.PayrollType = String.Empty;
                statusInfo.PayrollClass = String.Empty;
                statusInfo.CompanyRFC = String.Empty;
                statusInfo.ReceiptVersion = String.Empty;
                statusInfo.Periods = String.Empty;
                statusInfo.Year = String.Empty;
            }
        }

        public void setCompany(String companyRFC)
        {
            stampingStatusInfo[ManejoNomina.periodica].CompanyRFC = companyRFC;
            stampingStatusInfo[ManejoNomina.interactiva].CompanyRFC = companyRFC;
        }

        public void setReceiptVersion(String version)
        {
            stampingStatusInfo[ManejoNomina.periodica].ReceiptVersion = version;
            stampingStatusInfo[ManejoNomina.interactiva].ReceiptVersion = version;
        }

        public void addPayrollType(ManejoNomina manejoNomina, String payrollType)
        {
            stampingStatusInfo[manejoNomina].PayrollType = addFilter(payrollType, stampingStatusInfo[manejoNomina].PayrollType);
        }

        public void addPayrollClass(ManejoNomina manejoNomina, String payrollClass)
        {
            stampingStatusInfo[manejoNomina].PayrollClass = addFilter(payrollClass, stampingStatusInfo[manejoNomina].PayrollClass);
        }

        public void addPeriods(ManejoNomina manejoNomina, String periods)
        {
            stampingStatusInfo[manejoNomina].Periods = addFilter(periods, stampingStatusInfo[manejoNomina].Periods);
        }

        public void addYear(ManejoNomina manejoNomina, String year)
        {
            stampingStatusInfo[manejoNomina].Year = addFilter(year, stampingStatusInfo[manejoNomina].Year);
        }

        private static String addFilter(String valueToAdd, String filterText)
        {
            filterText ??= string.Empty;

            valueToAdd = "'" + valueToAdd + "'";
            if (!filterText.Contains(valueToAdd))
            {
                if (string.IsNullOrEmpty(filterText))
                {
                    filterText += valueToAdd;
                }
                else
                {
                    filterText += "," + valueToAdd;
                }
            }

            return filterText;
        }
    }
}

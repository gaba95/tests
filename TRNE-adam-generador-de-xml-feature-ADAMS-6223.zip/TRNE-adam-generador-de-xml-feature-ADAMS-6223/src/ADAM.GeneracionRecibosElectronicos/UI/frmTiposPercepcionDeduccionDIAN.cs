﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.GeneracionRecibosElectronicos.Enums;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmTiposPercepcionDeduccionDIAN : Form
    {
        private const string ColDescripcion = "descripcion";
        private const string ColClave = "clave";
        private const string ColConceptoAdam = "concepto_adam";

        private ICatalogoDian _catalogosDIAN;
        private ICatalogoAdicional _catalogoAdicional;

        private TreeView arbolAuxCatalogo;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Institucion { get; set; }

        #region Events

        /// Form Load
        private void FrmTiposPercepcion_Load(object sender, EventArgs e) { InicializaClase(); }

        /// Compania Dropdown Events
        private void cboCompania_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboCompania.Tag != null) return;

            // Fill Grids
            compania = cboCompania.SelectedValue.ToString();
            llenaTipoConcepto();
            llenaComboSeccion(cboTipoConcepto.SelectedValue.ToString().ToLower());
            llenaGridTablaDIAN(cboSeccion.SelectedValue.ToString(), cboTipoConcepto.SelectedValue.ToString().ToLower());
            arbolConceptos.Nodes.Clear();
            cargaArbolConceptosByCompany(cboCompania.SelectedValue.ToString());
        }

        /// Concept Type Dropdown Events
        private void cboTipoConcepto_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboTipoConcepto.Tag != null) return;

            // Fill Grids
            llenaComboSeccion(cboTipoConcepto.SelectedValue.ToString().ToLower());
            if (cboSeccion.Items.Count > 0)
            {
                llenaGridTablaDIAN(cboSeccion.SelectedValue.ToString(), cboTipoConcepto.SelectedValue.ToString().ToLower());
            }
        }

        /// Section Drowpdown Events
        private void cboSeccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboSeccion.Tag != null) return;

            // Fill Grid
            llenaGridTablaDIAN(cboSeccion.SelectedValue.ToString(), cboTipoConcepto.SelectedValue.ToString().ToLower());
        }

        /// Fill DIAN Mapping Info
        private void gridDatosDIAN_SelectionChanged(object sender, EventArgs e)
        {
            if (gridDatosDIAN.SelectedRows.Count == 0)
                return;
            LlenaGridEquivalenciasDIAN(compania, gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString());
        }

        /// Add Mapping
        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            FrmAgregarConceptoDIAN FrmChangeConcept = new FrmAgregarConceptoDIAN();
            FrmChangeConcept.compania = this.compania;
            FrmChangeConcept.tipoPlataforma = this.tipoPlataforma;
            FrmChangeConcept.tipoConcepto = cboTipoConcepto.SelectedValue.ToString();
            FrmChangeConcept.campo = gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString();
            FrmChangeConcept.claveTipo = gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString();
            FrmChangeConcept.DescripcionTipo = gridDatosDIAN.SelectedRows[0].Cells[ColDescripcion].Value.ToString();
            FrmChangeConcept.FrmPadre = this;
            FrmChangeConcept.ShowDialog();

            arbolConceptos.Nodes.Clear();
            cargaArbolConceptosByCompany(cboCompania.SelectedValue.ToString());
        }

        /// Remove Mapping
        private void cmdQuitar_Click(object sender, EventArgs e)
        {
            if (gridDatosADAM.RowCount == 0)
                return;

            if (_catalogosDIAN.bajaRelacionDatoConceptoDIAN(compania, gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString(), gridDatosADAM.SelectedRows[0].Cells[ColConceptoAdam].Value.ToString()))
                LlenaGridEquivalenciasDIAN(compania, gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString());

            arbolConceptos.Nodes.Clear();
            cargaArbolConceptosByCompany(cboCompania.SelectedValue.ToString());
        }

        /// Load File Button Click Event
        private void cmdCargar_Click(object sender, EventArgs e)
        {
            // Show Form
            FrmCargaConceptosDIAN cargaConceptosDIAN = new FrmCargaConceptosDIAN();
            cargaConceptosDIAN.compania = compania;
            cargaConceptosDIAN.tipoConcepto = cboTipoConcepto.SelectedValue.ToString();
            cargaConceptosDIAN.idCampo = cboSeccion.SelectedValue.ToString();
            cargaConceptosDIAN.ShowDialog();

            // Refresh Grid
            LlenaGridEquivalenciasDIAN(compania, gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString());
        }

        #endregion

        #region Metodos de la clase

        public FrmTiposPercepcionDeduccionDIAN() 
        { 
            InitializeComponent(); 
        }

        private void InicializaClase()
        {
            _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            // PTF-4277 Config Catalogs by Institution
            lblTitulo.Text = String.Format("Mapeo de Conceptos concepto ADAM - {0}", this.Institucion);
            lblDatosDIAN.Text = String.Format("Conceptos {0}", this.Institucion);
            lblArbol.Location = new System.Drawing.Point(pnlPrincipal.Width - 410, 104);
            lblArbol.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblArbol.Dock = DockStyle.None;

            // Fill Company Dropdown
            this.cboCompania.Tag = true;
            cboCompania.DataSource = _catalogoAdicional.obtenDatasetCompanias(LanguageCodes.Colombia).Tables[0];
            cboCompania.DisplayMember = "nombre_cia";
            cboCompania.ValueMember = "compania";
            cboCompania.Tag = null;

            // Select Default Company
            if (!string.IsNullOrEmpty(compania))
            { cboCompania.SelectedItem = compania; }
            compania = cboCompania.SelectedValue.ToString();

            // Fill Concepts Type
            llenaTipoConcepto();

            // Fill Section
            llenaComboSeccion(cboTipoConcepto.SelectedValue.ToString().ToLower());
            if (cboSeccion.Items.Count > 0)
            {
                // Fill DIAN Conceptos Grid
                llenaGridTablaDIAN(cboSeccion.SelectedValue.ToString(), cboTipoConcepto.SelectedValue.ToString().ToLower());

                // Fill DIAN Concepts
                LlenaGridEquivalenciasDIAN(compania, gridDatosDIAN.SelectedRows[0].Cells[ColClave].Value.ToString());
            }

            arbolAuxCatalogo = new TreeView();
            cargaArbolAux();

            cargaArbolConceptosByCompany(cboCompania.SelectedValue.ToString());
        }

        #region llenaArbolConceptos

        /// Loads companies into catalogs tree.
        private void cargaArbolConceptos()
        {
            DataSet mapped = _catalogosDIAN.obtenDatasetTreeViewConceptosDIAN();

            if (mapped.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow map in mapped.Tables[0].Rows)
                {
                    TreeNode selectedCom = new TreeNode();
                    TreeNode[] com = arbolConceptos.Nodes.Find(map["compania"].ToString(), false);
                    if (com.Length > 0)
                    {
                        selectedCom = com[0];
                    }
                    else
                    {
                        selectedCom = new TreeNode();
                        selectedCom.Text = map["compania"].ToString() + " - " + map["nombre_cia"].ToString(); ;
                        selectedCom.Name = map["compania"].ToString();
                        selectedCom.Tag = map["compania"].ToString();

                        arbolConceptos.Nodes.Add(selectedCom);
                    }

                    cargaSeccionNode(selectedCom, map);
                }

                arbolConceptos.ExpandAll();
                arbolConceptos.SelectedNode = arbolConceptos.Nodes[0];
            }
        }

        /// Loads companie into catalogs tree.
        private void cargaArbolConceptosByCompany(string company)
        {
            DataSet mapped = _catalogosDIAN.obtenDatasetTreeViewConceptosDIANByCompany(company);

            if (mapped.Tables[0].Rows.Count > 0)
            {
                arbolConceptos.Nodes.Clear();

                foreach (DataRow map in mapped.Tables[0].Rows)
                {
                    TreeNode selectedCom = new TreeNode();
                    TreeNode[] com = arbolConceptos.Nodes.Find(map["compania"].ToString(), false);
                    if (com.Length > 0)
                    {
                        selectedCom = com[0];
                    }
                    else
                    {
                        selectedCom = new TreeNode();
                        selectedCom.Text = map["compania"].ToString() + " - " + map["nombre_cia"].ToString(); ;
                        selectedCom.Name = map["compania"].ToString();
                        selectedCom.Tag = map["compania"].ToString();

                        arbolConceptos.Nodes.Add(selectedCom);
                    }

                    cargaSeccionNode(selectedCom, map);
                }

                arbolConceptos.ExpandAll();
                arbolConceptos.SelectedNode = arbolConceptos.Nodes[0];

                CollapsePenultimateLevelNodes(arbolConceptos.Nodes);
            }
        }

        /// Loop Recursivily in every node of the Treeview, Collapsing all nodes where the child nodes dont have any child
        private void CollapsePenultimateLevelNodes(TreeNodeCollection nodes)
        {
            foreach (TreeNode tn in nodes)
            {
                if (tn.Nodes.Count == 0) { tn.Parent.Collapse(); }
                else { CollapsePenultimateLevelNodes(tn.Nodes); }
            }
        }

        /// Loads sections into company nodes of catalogs tree.
        private void cargaSeccionNode(TreeNode parent, DataRow map)
        {
            TreeNode seccion = new TreeNode();
            TreeNode campo = new TreeNode();
            //look for field in arbolAuxCatalogo
            TreeNode[] auxCampo = arbolAuxCatalogo.Nodes.Find(map["id_campo"].ToString(), true);
            if (auxCampo.Length > 0)
            {
                //look for section in company's nodes based on auxCampo's parent
                TreeNode[] auxSeccion = parent.Nodes.Find(auxCampo[0].Parent.Name, true);
                if (auxSeccion.Length > 0)
                {
                    seccion = auxSeccion[0];
                    //look for field in section's nodes
                    TreeNode[] treeCampo = seccion.Nodes.Find(auxCampo[0].Name, false);
                    if (treeCampo.Length > 0)
                    {
                        campo = treeCampo[0];
                    }
                    else
                    {
                        campo.Text = map["id_campo"].ToString() + "-" + auxCampo[0].Text;
                        campo.Name = auxCampo[0].Name;
                        seccion.Nodes.Add(campo);
                    }
                }
                else
                {
                    seccion.Text = auxCampo[0].Parent.Text;
                    seccion.Name = auxCampo[0].Parent.Name;

                    TreeNode[] auxTop = parent.Nodes.Find(auxCampo[0].Parent.Parent.Name, false);
                    if (auxTop.Length > 0)
                    {
                        TreeNode[] auxTopSeccion = auxTop[0].Nodes.Find(seccion.Name, false);
                        if (auxTopSeccion.Length < 1)
                        {
                            auxTop[0].Nodes.Add(seccion);
                        }

                    }
                    else
                    {
                        TreeNode top = new TreeNode();
                        top.Text = auxCampo[0].Parent.Parent.Text;
                        top.Name = auxCampo[0].Parent.Parent.Name;
                        parent.Nodes.Add(top);

                        top.Nodes.Add(seccion);
                    }

                    campo.Text = auxCampo[0].Name + "-" + auxCampo[0].Text;
                    campo.Name = auxCampo[0].Name;
                    seccion.Nodes.Add(campo);

                }

                cargaCampoNode(campo, map);
            }
        }

        /// Loads fields into section nodes of catalogs tree.
        private void cargaCampoNode(TreeNode parent, DataRow map)
        {
            TreeNode mapped = new TreeNode();
            mapped.Text = map[ColConceptoAdam].ToString() + "-" + map[ColDescripcion].ToString();
            mapped.Name = map[ColConceptoAdam].ToString();
            mapped.Tag = map[ColConceptoAdam].ToString();

            TreeNode claveDIAN = new TreeNode();
            claveDIAN.Text = "Concepto ADAM: " + map[ColConceptoAdam].ToString();
            claveDIAN.Name = map[ColConceptoAdam].ToString();
            claveDIAN.Tag = map[ColConceptoAdam].ToString();

            mapped.Nodes.Add(claveDIAN);

            TreeNode claveADAM = new TreeNode();
            claveADAM.Text = "Descripción: " + map[ColDescripcion].ToString();
            claveADAM.Name = map[ColDescripcion].ToString();
            claveADAM.Tag = map[ColDescripcion].ToString();

            mapped.Nodes.Add(claveADAM);

            parent.Nodes.Add(mapped);
        }

        /// Fills the aux tree used for reference
        private void cargaArbolAux()
        {
            if (cboTipoConcepto.Items.Count > 0)
            {
                DataTable _arbolAuxConcepto = _catalogosDIAN.obtenDataSetConceptosAux().Tables[0];
                foreach (DataRowView secc in cboTipoConcepto.Items)
                {
                    TreeNode tipoConcepto = new TreeNode();
                    tipoConcepto.Text = secc[ColDescripcion].ToString();
                    tipoConcepto.Name = secc[ColClave].ToString();

                    foreach (DataRow cam in _arbolAuxConcepto.Select("tipo_concepto = '" + tipoConcepto.Name + "'"))
                    {
                        TreeNode seccion = new TreeNode();
                        seccion.Text = cam["id_padre"].ToString();
                        seccion.Name = cam["id_padre"].ToString();

                        foreach (DataRow con in _arbolAuxConcepto.Select("clave = '" + cam[ColClave] + "'"))
                        {
                            TreeNode concepto = new TreeNode();
                            concepto.Text = con[ColDescripcion].ToString();
                            concepto.Name = con[ColClave].ToString();

                            seccion.Nodes.Add(concepto);
                        }

                        tipoConcepto.Nodes.Add(seccion);
                    }

                    arbolAuxCatalogo.Nodes.Add(tipoConcepto);
                }
            }
        }
        #endregion

        /// Fill Concept Type Dropdown
        private void llenaTipoConcepto()
        {
            // Set Tag to avoid events 
            this.cboTipoConcepto.Tag = true;

            // Create the DataSet
            DataTable tableTipoConc = new DataTable("TipoConcepto");
            tableTipoConc.Columns.Add(ColClave);
            tableTipoConc.Columns.Add(ColDescripcion);
            tableTipoConc.Rows.Add("percepcion", "Percepciones/Devengados");
            tableTipoConc.Rows.Add("deduccion", "Deducciones");

            // Create a DataSet and put both tables in it.
            DataSet dsConc = new DataSet("TiposConc");
            dsConc.Tables.Add(tableTipoConc);

            // Fill Combo
            cboTipoConcepto.ValueMember = ColClave;
            cboTipoConcepto.DisplayMember = ColDescripcion;
            cboTipoConcepto.DataSource = dsConc.Tables[0];

            // Set Tag
            this.cboTipoConcepto.Tag = null;
        }

        /// Fill Section Combo
        private void llenaComboSeccion(string szTipoConcepto)
        {
            try
            {
                // Set Tag to avoid events 
                this.cboSeccion.Tag = true;

                // Fill Combo
                cboSeccion.ValueMember = ColClave;
                cboSeccion.DisplayMember = ColDescripcion;
                cboSeccion.DataSource = _catalogosDIAN.dsListaSeccionesDIAN("concepto", szTipoConcepto).Tables[0];

                // Set Tag
                this.cboSeccion.Tag = null;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        /// Fill DIAN Fields Grid
        public void llenaGridTablaDIAN(string szSeccion, string szTipoConcepto)
        {
            try
            {
                gridDatosDIAN.DataSource = _catalogosDIAN.dsListaCamposDIAN(szSeccion, "concepto", szTipoConcepto).Tables[0];
                if (gridDatosDIAN.Columns.Contains(ColClave)) { gridDatosDIAN.Columns[ColClave].HeaderText = "Clave"; }
                if (gridDatosDIAN.Columns.Contains(ColDescripcion)) { gridDatosDIAN.Columns[ColDescripcion].HeaderText = "Descripción"; }
                gridDatosDIAN.Refresh();
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        /// Fill DIAN Equivalences
        public void LlenaGridEquivalenciasDIAN(string szCompania, string szCampo)
        {
            try
            {
                if (gridDatosDIAN.SelectedRows.Count == 0)
                    return;
                gridDatosADAM.DataSource = _catalogosDIAN.obtenDatasetRelacionConceptosDIAN(szCompania, szCampo).Tables[0];
                if (gridDatosADAM.Columns.Contains("id_campo")) { gridDatosADAM.Columns["id_campo"].HeaderText = "Clave DIAN"; }
                if (gridDatosADAM.Columns.Contains(ColConceptoAdam)) { gridDatosADAM.Columns[ColConceptoAdam].HeaderText = "Concepto ADAM"; }
                if (gridDatosADAM.Columns.Contains(ColDescripcion)) { gridDatosADAM.Columns[ColDescripcion].HeaderText = "Descripción ADAM"; }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        #endregion

    }
}

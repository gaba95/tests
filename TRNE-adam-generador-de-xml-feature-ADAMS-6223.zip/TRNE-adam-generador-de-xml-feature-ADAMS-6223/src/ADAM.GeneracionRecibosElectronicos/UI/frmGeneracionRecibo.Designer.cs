using System;

namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmGeneracionRecibo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGeneracionRecibo));
            this.lblClaseNomina = new System.Windows.Forms.Label();
            this.lblCompania = new System.Windows.Forms.Label();
            this.cboCompania = new System.Windows.Forms.ComboBox();
            this.lblTipoNomina = new System.Windows.Forms.Label();
            this.pnlInferior = new System.Windows.Forms.Panel();
            this.pnlTrabajadores = new System.Windows.Forms.Panel();
            this.gridTrabajadores = new System.Windows.Forms.DataGridView();
            this.pnlTools = new System.Windows.Forms.Panel();
            this.pnlUtilities = new System.Windows.Forms.Panel();
            this.cboTipoSeleccion = new System.Windows.Forms.ComboBox();
            this.lblContador = new System.Windows.Forms.Label();
            this.lblSeleccionados = new System.Windows.Forms.Label();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.cmdExporta = new System.Windows.Forms.Button();
            this.pnlFiltros = new System.Windows.Forms.Panel();
            this.btnStateRefresh = new System.Windows.Forms.Button();
            this.lblEstado = new System.Windows.Forms.Label();
            this.pnlEstadosTimbrado = new System.Windows.Forms.Panel();
            this.chkStateFinalizado = new System.Windows.Forms.CheckBox();
            this.chkStateConError = new System.Windows.Forms.CheckBox();
            this.chkStateCancelado = new System.Windows.Forms.CheckBox();
            this.chkStateEliminado = new System.Windows.Forms.CheckBox();
            this.chkStateEnProceso = new System.Windows.Forms.CheckBox();
            this.chkStateSinTimbrar = new System.Windows.Forms.CheckBox();
            this.chkStateTodos = new System.Windows.Forms.CheckBox();
            this.gridTotales = new System.Windows.Forms.DataGridView();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pnlResultados = new System.Windows.Forms.Panel();
            this.pbResultados = new ADAM.Recibos.Controls.CustomProgressBar();
            this.lbGenerados = new System.Windows.Forms.ListBox();
            this.pnlSuperior = new System.Windows.Forms.Panel();
            this.grpInteractiva = new System.Windows.Forms.GroupBox();
            this.optInteractivaEspecifico = new System.Windows.Forms.RadioButton();
            this.optInteractivaRango = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlCtrsEspecificosInteractiva = new System.Windows.Forms.Panel();
            this.txtMesesInteractiva = new ADAM.GeneracionRecibosElectronicos.UI.CueTextBox();
            this.txtAniosInteractiva = new ADAM.GeneracionRecibosElectronicos.UI.CueTextBox();
            this.pnlCrtsRangoInteractiva = new System.Windows.Forms.Panel();
            this.nupAnioInteractivaHasta = new System.Windows.Forms.NumericUpDown();
            this.cboMesInteractivaHasta = new System.Windows.Forms.ComboBox();
            this.nupAnioInteractivaDesde = new System.Windows.Forms.NumericUpDown();
            this.cboMesInteractivaDesde = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grpPeriodica = new System.Windows.Forms.GroupBox();
            this.optPeriodicaEspecifico = new System.Windows.Forms.RadioButton();
            this.optPeriodicaRango = new System.Windows.Forms.RadioButton();
            this.pnlPeriodica = new System.Windows.Forms.Panel();
            this.pnlCtrsPeriodicaEspecificos = new System.Windows.Forms.Panel();
            this.txtPeriodosPeriodica = new ADAM.GeneracionRecibosElectronicos.UI.CueTextBox();
            this.txtMesesPeriodica = new ADAM.GeneracionRecibosElectronicos.UI.CueTextBox();
            this.txtAniosPeriodica = new ADAM.GeneracionRecibosElectronicos.UI.CueTextBox();
            this.pnlPeriodosPeriodicaRango = new System.Windows.Forms.Panel();
            this.lblAPeriodicaRangoPeriodo = new System.Windows.Forms.Label();
            this.nupPeriodoDesde = new System.Windows.Forms.NumericUpDown();
            this.nupPeriodoHasta = new System.Windows.Forms.NumericUpDown();
            this.pnlMesPeriodicaRango = new System.Windows.Forms.Panel();
            this.lblGuionMeses = new System.Windows.Forms.Label();
            this.cboMesPeriodicaDesde = new System.Windows.Forms.ComboBox();
            this.cboMesPeriodicaHasta = new System.Windows.Forms.ComboBox();
            this.pnlAnioPeriodicaRango = new System.Windows.Forms.Panel();
            this.lblAPeriodicaRangoAnio = new System.Windows.Forms.Label();
            this.nupAnioPeriodicaDesde = new System.Windows.Forms.NumericUpDown();
            this.nupAnioPeriodicaHasta = new System.Windows.Forms.NumericUpDown();
            this.optMensual = new System.Windows.Forms.RadioButton();
            this.optPeriodo = new System.Windows.Forms.RadioButton();
            this.lblMesPeriodica = new System.Windows.Forms.Label();
            this.lblPeriodo = new System.Windows.Forms.Label();
            this.lblAnio = new System.Windows.Forms.Label();
            this.chlClaseNomina = new System.Windows.Forms.CheckedListBox();
            this.chlTipoNomina = new System.Windows.Forms.CheckedListBox();
            this.cboFormaPago = new System.Windows.Forms.ComboBox();
            this.lblMetodoPago = new System.Windows.Forms.Label();
            this.txtConceptoFactura = new System.Windows.Forms.TextBox();
            this.lblConcepto = new System.Windows.Forms.Label();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.pnlInstitucion = new System.Windows.Forms.Panel();
            this.lblInstitucion = new System.Windows.Forms.Label();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.cmdTrabajadores = new System.Windows.Forms.Button();
            this.cmdGeneraArchivo = new System.Windows.Forms.Button();
            this.cmdCopiar = new System.Windows.Forms.Button();
            this.cmdGenera = new System.Windows.Forms.Button();
            this.cmdSalir = new System.Windows.Forms.Button();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            this.cmdCambioPais = new System.Windows.Forms.Button();
            this.chkValidaXSD = new System.Windows.Forms.CheckBox();
            this.cmdConfigurations = new System.Windows.Forms.Button();
            this.cmdQueries = new System.Windows.Forms.Button();
            this.MnuConfigurations = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuQueries = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pnlInferior.SuspendLayout();
            this.pnlTrabajadores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridTrabajadores)).BeginInit();
            this.pnlTools.SuspendLayout();
            this.pnlUtilities.SuspendLayout();
            this.pnlFiltros.SuspendLayout();
            this.pnlEstadosTimbrado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridTotales)).BeginInit();
            this.pnlResultados.SuspendLayout();
            this.pnlSuperior.SuspendLayout();
            this.grpInteractiva.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlCtrsEspecificosInteractiva.SuspendLayout();
            this.pnlCrtsRangoInteractiva.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioInteractivaHasta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioInteractivaDesde)).BeginInit();
            this.grpPeriodica.SuspendLayout();
            this.pnlPeriodica.SuspendLayout();
            this.pnlCtrsPeriodicaEspecificos.SuspendLayout();
            this.pnlPeriodosPeriodicaRango.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupPeriodoDesde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupPeriodoHasta)).BeginInit();
            this.pnlMesPeriodicaRango.SuspendLayout();
            this.pnlAnioPeriodicaRango.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioPeriodicaDesde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioPeriodicaHasta)).BeginInit();
            this.pnlLogo.SuspendLayout();
            this.pnlInstitucion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.pnlHerramientas.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblClaseNomina
            // 
            this.lblClaseNomina.AutoSize = true;
            this.lblClaseNomina.Location = new System.Drawing.Point(447, 35);
            this.lblClaseNomina.Name = "lblClaseNomina";
            this.lblClaseNomina.Size = new System.Drawing.Size(102, 18);
            this.lblClaseNomina.TabIndex = 0;
            this.lblClaseNomina.Text = "Clase de Nómina:";
            // 
            // lblCompania
            // 
            this.lblCompania.AutoSize = true;
            this.lblCompania.Location = new System.Drawing.Point(58, 6);
            this.lblCompania.Name = "lblCompania";
            this.lblCompania.Size = new System.Drawing.Size(64, 18);
            this.lblCompania.TabIndex = 0;
            this.lblCompania.Text = "Compañia:";
            // 
            // cboCompania
            // 
            this.cboCompania.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompania.FormattingEnabled = true;
            this.cboCompania.Location = new System.Drawing.Point(136, 2);
            this.cboCompania.Name = "cboCompania";
            this.cboCompania.Size = new System.Drawing.Size(300, 26);
            this.cboCompania.TabIndex = 1;
            this.cboCompania.SelectedIndexChanged += new System.EventHandler(this.cboCompania_SelectedIndexChanged);
            // 
            // lblTipoNomina
            // 
            this.lblTipoNomina.AutoSize = true;
            this.lblTipoNomina.Location = new System.Drawing.Point(24, 35);
            this.lblTipoNomina.Name = "lblTipoNomina";
            this.lblTipoNomina.Size = new System.Drawing.Size(98, 18);
            this.lblTipoNomina.TabIndex = 1;
            this.lblTipoNomina.Text = "Tipo de Nómina:";
            // 
            // pnlInferior
            // 
            this.pnlInferior.Controls.Add(this.pnlTrabajadores);
            this.pnlInferior.Controls.Add(this.pnlTools);
            this.pnlInferior.Controls.Add(this.gridTotales);
            this.pnlInferior.Controls.Add(this.splitter1);
            this.pnlInferior.Controls.Add(this.pnlResultados);
            this.pnlInferior.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlInferior.Location = new System.Drawing.Point(0, 229);
            this.pnlInferior.Name = "pnlInferior";
            this.pnlInferior.Size = new System.Drawing.Size(982, 520);
            this.pnlInferior.TabIndex = 1;
            // 
            // pnlTrabajadores
            // 
            this.pnlTrabajadores.Controls.Add(this.gridTrabajadores);
            this.pnlTrabajadores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTrabajadores.Location = new System.Drawing.Point(0, 59);
            this.pnlTrabajadores.Name = "pnlTrabajadores";
            this.pnlTrabajadores.Size = new System.Drawing.Size(982, 346);
            this.pnlTrabajadores.TabIndex = 18;
            // 
            // gridTrabajadores
            // 
            this.gridTrabajadores.AllowUserToAddRows = false;
            this.gridTrabajadores.AllowUserToDeleteRows = false;
            this.gridTrabajadores.AllowUserToResizeColumns = false;
            this.gridTrabajadores.AllowUserToResizeRows = false;
            this.gridTrabajadores.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridTrabajadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridTrabajadores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridTrabajadores.Location = new System.Drawing.Point(0, 0);
            this.gridTrabajadores.MultiSelect = false;
            this.gridTrabajadores.Name = "gridTrabajadores";
            this.gridTrabajadores.ReadOnly = true;
            this.gridTrabajadores.RowHeadersVisible = false;
            this.gridTrabajadores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridTrabajadores.Size = new System.Drawing.Size(982, 346);
            this.gridTrabajadores.TabIndex = 1;
            this.gridTrabajadores.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellContentClick);
            this.gridTrabajadores.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gridTrabajadores_CellPainting);
            this.gridTrabajadores.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridTrabajadores_CellValueChanged);
            this.gridTrabajadores.ColumnAdded += new System.Windows.Forms.DataGridViewColumnEventHandler(this.gridTrabajadores_ColumnAdded);
            this.gridTrabajadores.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridTrabajadores_ColumnHeaderMouseClick);
            this.gridTrabajadores.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.gridTrabajadores_RowPrePaint);
            this.gridTrabajadores.Scroll += new System.Windows.Forms.ScrollEventHandler(this.gridTrabajadores_Scroll);
            // 
            // pnlTools
            // 
            this.pnlTools.Controls.Add(this.pnlUtilities);
            this.pnlTools.Controls.Add(this.pnlFiltros);
            this.pnlTools.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTools.Location = new System.Drawing.Point(0, 0);
            this.pnlTools.Name = "pnlTools";
            this.pnlTools.Size = new System.Drawing.Size(982, 59);
            this.pnlTools.TabIndex = 17;
            // 
            // pnlUtilities
            // 
            this.pnlUtilities.Controls.Add(this.cboTipoSeleccion);
            this.pnlUtilities.Controls.Add(this.lblContador);
            this.pnlUtilities.Controls.Add(this.lblSeleccionados);
            this.pnlUtilities.Controls.Add(this.chkSelectAll);
            this.pnlUtilities.Controls.Add(this.cmdExporta);
            this.pnlUtilities.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlUtilities.Location = new System.Drawing.Point(0, 30);
            this.pnlUtilities.Name = "pnlUtilities";
            this.pnlUtilities.Size = new System.Drawing.Size(982, 29);
            this.pnlUtilities.TabIndex = 8;
            // 
            // cboTipoSeleccion
            // 
            this.cboTipoSeleccion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoSeleccion.Font = new System.Drawing.Font("Trebuchet MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTipoSeleccion.FormattingEnabled = true;
            this.cboTipoSeleccion.Items.AddRange(new object[] {
            "Todos",
            "Sin Percepciones/Deducciones"});
            this.cboTipoSeleccion.Location = new System.Drawing.Point(282, 2);
            this.cboTipoSeleccion.Name = "cboTipoSeleccion";
            this.cboTipoSeleccion.Size = new System.Drawing.Size(188, 24);
            this.cboTipoSeleccion.TabIndex = 32;
            // 
            // lblContador
            // 
            this.lblContador.Font = new System.Drawing.Font("Trebuchet MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContador.Location = new System.Drawing.Point(213, 6);
            this.lblContador.Name = "lblContador";
            this.lblContador.Size = new System.Drawing.Size(61, 18);
            this.lblContador.TabIndex = 31;
            this.lblContador.Text = "0";
            // 
            // lblSeleccionados
            // 
            this.lblSeleccionados.Font = new System.Drawing.Font("Trebuchet MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeleccionados.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblSeleccionados.Location = new System.Drawing.Point(139, 5);
            this.lblSeleccionados.Name = "lblSeleccionados";
            this.lblSeleccionados.Size = new System.Drawing.Size(84, 18);
            this.lblSeleccionados.TabIndex = 30;
            this.lblSeleccionados.Text = "Seleccionados:";
            this.lblSeleccionados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Font = new System.Drawing.Font("Trebuchet MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSelectAll.Location = new System.Drawing.Point(18, 5);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(114, 20);
            this.chkSelectAll.TabIndex = 29;
            this.chkSelectAll.Text = "Seleccionar Todos";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // cmdExporta
            // 
            this.cmdExporta.Font = new System.Drawing.Font("Trebuchet MS", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExporta.Location = new System.Drawing.Point(478, 2);
            this.cmdExporta.Name = "cmdExporta";
            this.cmdExporta.Size = new System.Drawing.Size(162, 24);
            this.cmdExporta.TabIndex = 27;
            this.cmdExporta.Text = "Exporta Lista empleados CSV";
            this.cmdExporta.UseVisualStyleBackColor = true;
            this.cmdExporta.Click += new System.EventHandler(this.cmdExporta_Click);
            // 
            // pnlFiltros
            // 
            this.pnlFiltros.Controls.Add(this.btnStateRefresh);
            this.pnlFiltros.Controls.Add(this.lblEstado);
            this.pnlFiltros.Controls.Add(this.pnlEstadosTimbrado);
            this.pnlFiltros.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFiltros.Location = new System.Drawing.Point(0, 0);
            this.pnlFiltros.Name = "pnlFiltros";
            this.pnlFiltros.Size = new System.Drawing.Size(982, 29);
            this.pnlFiltros.TabIndex = 7;
            // 
            // btnStateRefresh
            // 
            this.btnStateRefresh.Location = new System.Drawing.Point(744, 2);
            this.btnStateRefresh.Name = "btnStateRefresh";
            this.btnStateRefresh.Size = new System.Drawing.Size(128, 26);
            this.btnStateRefresh.TabIndex = 15;
            this.btnStateRefresh.Text = "Refrescar estados";
            this.btnStateRefresh.UseVisualStyleBackColor = true;
            this.btnStateRefresh.Click += new System.EventHandler(this.BtnStateRefresh_Click);
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(80, 5);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(48, 18);
            this.lblEstado.TabIndex = 14;
            this.lblEstado.Text = "Estado:";
            // 
            // pnlEstadosTimbrado
            // 
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateFinalizado);
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateConError);
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateCancelado);
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateEliminado);
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateEnProceso);
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateSinTimbrar);
            this.pnlEstadosTimbrado.Controls.Add(this.chkStateTodos);
            this.pnlEstadosTimbrado.Location = new System.Drawing.Point(133, 2);
            this.pnlEstadosTimbrado.Name = "pnlEstadosTimbrado";
            this.pnlEstadosTimbrado.Size = new System.Drawing.Size(605, 27);
            this.pnlEstadosTimbrado.TabIndex = 13;
            // 
            // chkStateFinalizado
            // 
            this.chkStateFinalizado.AutoSize = true;
            this.chkStateFinalizado.Location = new System.Drawing.Point(513, 2);
            this.chkStateFinalizado.Name = "chkStateFinalizado";
            this.chkStateFinalizado.Size = new System.Drawing.Size(80, 22);
            this.chkStateFinalizado.TabIndex = 24;
            this.chkStateFinalizado.Text = "Finalizado";
            this.chkStateFinalizado.UseVisualStyleBackColor = true;
            this.chkStateFinalizado.CheckedChanged += new System.EventHandler(this.ChkStateFinalizado_CheckedChanged);
            // 
            // chkStateConError
            // 
            this.chkStateConError.AutoSize = true;
            this.chkStateConError.Location = new System.Drawing.Point(428, 2);
            this.chkStateConError.Name = "chkStateConError";
            this.chkStateConError.Size = new System.Drawing.Size(80, 22);
            this.chkStateConError.TabIndex = 23;
            this.chkStateConError.Text = "Con Error";
            this.chkStateConError.UseVisualStyleBackColor = true;
            this.chkStateConError.CheckedChanged += new System.EventHandler(this.ChkStateConError_CheckedChanged);
            // 
            // chkStateCancelado
            // 
            this.chkStateCancelado.AutoSize = true;
            this.chkStateCancelado.Location = new System.Drawing.Point(159, 2);
            this.chkStateCancelado.Name = "chkStateCancelado";
            this.chkStateCancelado.Size = new System.Drawing.Size(84, 22);
            this.chkStateCancelado.TabIndex = 20;
            this.chkStateCancelado.Text = "Cancelado";
            this.chkStateCancelado.UseVisualStyleBackColor = true;
            this.chkStateCancelado.CheckedChanged += new System.EventHandler(this.ChkStateCancelado_CheckedChanged);
            // 
            // chkStateEliminado
            // 
            this.chkStateEliminado.AutoSize = true;
            this.chkStateEliminado.Location = new System.Drawing.Point(250, 2);
            this.chkStateEliminado.Name = "chkStateEliminado";
            this.chkStateEliminado.Size = new System.Drawing.Size(78, 22);
            this.chkStateEliminado.TabIndex = 21;
            this.chkStateEliminado.Text = "Eliminado";
            this.chkStateEliminado.UseVisualStyleBackColor = true;
            this.chkStateEliminado.CheckedChanged += new System.EventHandler(this.ChkStateEliminado_CheckedChanged);
            // 
            // chkStateEnProceso
            // 
            this.chkStateEnProceso.AutoSize = true;
            this.chkStateEnProceso.Location = new System.Drawing.Point(334, 2);
            this.chkStateEnProceso.Name = "chkStateEnProceso";
            this.chkStateEnProceso.Size = new System.Drawing.Size(88, 22);
            this.chkStateEnProceso.TabIndex = 22;
            this.chkStateEnProceso.Text = "En Proceso";
            this.chkStateEnProceso.UseVisualStyleBackColor = true;
            this.chkStateEnProceso.CheckedChanged += new System.EventHandler(this.ChkStateEnProceso_CheckedChanged);
            // 
            // chkStateSinTimbrar
            // 
            this.chkStateSinTimbrar.AutoSize = true;
            this.chkStateSinTimbrar.Checked = true;
            this.chkStateSinTimbrar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStateSinTimbrar.Location = new System.Drawing.Point(68, 2);
            this.chkStateSinTimbrar.Name = "chkStateSinTimbrar";
            this.chkStateSinTimbrar.Size = new System.Drawing.Size(89, 22);
            this.chkStateSinTimbrar.TabIndex = 19;
            this.chkStateSinTimbrar.Text = "Sin Timbrar";
            this.chkStateSinTimbrar.UseVisualStyleBackColor = true;
            this.chkStateSinTimbrar.CheckedChanged += new System.EventHandler(this.ChkStateSinTimbrar_CheckedChanged);
            // 
            // chkStateTodos
            // 
            this.chkStateTodos.AutoSize = true;
            this.chkStateTodos.Location = new System.Drawing.Point(3, 2);
            this.chkStateTodos.Name = "chkStateTodos";
            this.chkStateTodos.Size = new System.Drawing.Size(59, 22);
            this.chkStateTodos.TabIndex = 18;
            this.chkStateTodos.Text = "Todos";
            this.chkStateTodos.UseVisualStyleBackColor = true;
            this.chkStateTodos.CheckedChanged += new System.EventHandler(this.ChkStateTodos_CheckedChanged);
            // 
            // gridTotales
            // 
            this.gridTotales.AllowUserToDeleteRows = false;
            this.gridTotales.AllowUserToResizeRows = false;
            this.gridTotales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridTotales.ColumnHeadersVisible = false;
            this.gridTotales.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gridTotales.Location = new System.Drawing.Point(0, 405);
            this.gridTotales.MultiSelect = false;
            this.gridTotales.Name = "gridTotales";
            this.gridTotales.ReadOnly = true;
            this.gridTotales.RowHeadersVisible = false;
            this.gridTotales.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gridTotales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridTotales.Size = new System.Drawing.Size(982, 45);
            this.gridTotales.TabIndex = 4;
            this.gridTotales.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.gridTotales_DataError);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 450);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(982, 10);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // pnlResultados
            // 
            this.pnlResultados.Controls.Add(this.pbResultados);
            this.pnlResultados.Controls.Add(this.lbGenerados);
            this.pnlResultados.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlResultados.Location = new System.Drawing.Point(0, 460);
            this.pnlResultados.Name = "pnlResultados";
            this.pnlResultados.Size = new System.Drawing.Size(982, 60);
            this.pnlResultados.TabIndex = 3;
            // 
            // pbResultados
            // 
            this.pbResultados.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pbResultados.Location = new System.Drawing.Point(0, 40);
            this.pbResultados.Name = "pbResultados";
            this.pbResultados.Size = new System.Drawing.Size(982, 20);
            this.pbResultados.Step = 1;
            this.pbResultados.TabIndex = 4;
            // 
            // lbGenerados
            // 
            this.lbGenerados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbGenerados.FormattingEnabled = true;
            this.lbGenerados.HorizontalScrollbar = true;
            this.lbGenerados.ItemHeight = 18;
            this.lbGenerados.Location = new System.Drawing.Point(0, 0);
            this.lbGenerados.Name = "lbGenerados";
            this.lbGenerados.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbGenerados.Size = new System.Drawing.Size(982, 60);
            this.lbGenerados.TabIndex = 2;
            // 
            // pnlSuperior
            // 
            this.pnlSuperior.Controls.Add(this.grpInteractiva);
            this.pnlSuperior.Controls.Add(this.grpPeriodica);
            this.pnlSuperior.Controls.Add(this.chlClaseNomina);
            this.pnlSuperior.Controls.Add(this.chlTipoNomina);
            this.pnlSuperior.Controls.Add(this.cboFormaPago);
            this.pnlSuperior.Controls.Add(this.lblMetodoPago);
            this.pnlSuperior.Controls.Add(this.txtConceptoFactura);
            this.pnlSuperior.Controls.Add(this.lblConcepto);
            this.pnlSuperior.Controls.Add(this.lblClaseNomina);
            this.pnlSuperior.Controls.Add(this.lblCompania);
            this.pnlSuperior.Controls.Add(this.cboCompania);
            this.pnlSuperior.Controls.Add(this.lblTipoNomina);
            this.pnlSuperior.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSuperior.Location = new System.Drawing.Point(0, 28);
            this.pnlSuperior.Name = "pnlSuperior";
            this.pnlSuperior.Padding = new System.Windows.Forms.Padding(0, 90, 0, 0);
            this.pnlSuperior.Size = new System.Drawing.Size(982, 201);
            this.pnlSuperior.TabIndex = 3;
            // 
            // grpInteractiva
            // 
            this.grpInteractiva.Controls.Add(this.optInteractivaEspecifico);
            this.grpInteractiva.Controls.Add(this.optInteractivaRango);
            this.grpInteractiva.Controls.Add(this.panel2);
            this.grpInteractiva.Enabled = false;
            this.grpInteractiva.Location = new System.Drawing.Point(465, 115);
            this.grpInteractiva.Name = "grpInteractiva";
            this.grpInteractiva.Size = new System.Drawing.Size(407, 84);
            this.grpInteractiva.TabIndex = 13;
            this.grpInteractiva.TabStop = false;
            this.grpInteractiva.Text = "Interactiva";
            // 
            // optInteractivaEspecifico
            // 
            this.optInteractivaEspecifico.AutoSize = true;
            this.optInteractivaEspecifico.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optInteractivaEspecifico.Location = new System.Drawing.Point(152, 0);
            this.optInteractivaEspecifico.Name = "optInteractivaEspecifico";
            this.optInteractivaEspecifico.Size = new System.Drawing.Size(81, 20);
            this.optInteractivaEspecifico.TabIndex = 9;
            this.optInteractivaEspecifico.Text = "Especificos";
            this.optInteractivaEspecifico.UseVisualStyleBackColor = true;
            this.optInteractivaEspecifico.CheckedChanged += new System.EventHandler(this.OptInteractivaEspecifico_CheckedChanged);
            // 
            // optInteractivaRango
            // 
            this.optInteractivaRango.AutoSize = true;
            this.optInteractivaRango.Checked = true;
            this.optInteractivaRango.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optInteractivaRango.Location = new System.Drawing.Point(89, 0);
            this.optInteractivaRango.Name = "optInteractivaRango";
            this.optInteractivaRango.Size = new System.Drawing.Size(55, 20);
            this.optInteractivaRango.TabIndex = 8;
            this.optInteractivaRango.TabStop = true;
            this.optInteractivaRango.Text = "Rango";
            this.optInteractivaRango.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pnlCtrsEspecificosInteractiva);
            this.panel2.Controls.Add(this.pnlCrtsRangoInteractiva);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(401, 64);
            this.panel2.TabIndex = 5;
            // 
            // pnlCtrsEspecificosInteractiva
            // 
            this.pnlCtrsEspecificosInteractiva.BackColor = System.Drawing.SystemColors.Control;
            this.pnlCtrsEspecificosInteractiva.Controls.Add(this.txtMesesInteractiva);
            this.pnlCtrsEspecificosInteractiva.Controls.Add(this.txtAniosInteractiva);
            this.pnlCtrsEspecificosInteractiva.Location = new System.Drawing.Point(81, 4);
            this.pnlCtrsEspecificosInteractiva.Name = "pnlCtrsEspecificosInteractiva";
            this.pnlCtrsEspecificosInteractiva.Size = new System.Drawing.Size(231, 61);
            this.pnlCtrsEspecificosInteractiva.TabIndex = 15;
            this.pnlCtrsEspecificosInteractiva.Visible = false;
            // 
            // txtMesesInteractiva
            // 
            this.txtMesesInteractiva.AutoCompleteCustomSource.AddRange(new string[] {
            "Texto"});
            this.txtMesesInteractiva.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtMesesInteractiva.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtMesesInteractiva.Cue = "Meses separados por comas";
            this.txtMesesInteractiva.Location = new System.Drawing.Point(0, 34);
            this.txtMesesInteractiva.Name = "txtMesesInteractiva";
            this.txtMesesInteractiva.Size = new System.Drawing.Size(231, 21);
            this.txtMesesInteractiva.TabIndex = 16;
            this.txtMesesInteractiva.Leave += new System.EventHandler(this.TxtControlValidationLeave);
            // 
            // txtAniosInteractiva
            // 
            this.txtAniosInteractiva.AutoCompleteCustomSource.AddRange(new string[] {
            "Texto"});
            this.txtAniosInteractiva.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAniosInteractiva.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAniosInteractiva.Cue = "Años separado por comas";
            this.txtAniosInteractiva.Location = new System.Drawing.Point(0, 5);
            this.txtAniosInteractiva.Name = "txtAniosInteractiva";
            this.txtAniosInteractiva.Size = new System.Drawing.Size(231, 21);
            this.txtAniosInteractiva.TabIndex = 15;
            this.txtAniosInteractiva.Leave += new System.EventHandler(this.TxtControlValidationLeave);
            // 
            // pnlCrtsRangoInteractiva
            // 
            this.pnlCrtsRangoInteractiva.BackColor = System.Drawing.Color.Transparent;
            this.pnlCrtsRangoInteractiva.Controls.Add(this.nupAnioInteractivaHasta);
            this.pnlCrtsRangoInteractiva.Controls.Add(this.cboMesInteractivaHasta);
            this.pnlCrtsRangoInteractiva.Controls.Add(this.nupAnioInteractivaDesde);
            this.pnlCrtsRangoInteractiva.Controls.Add(this.cboMesInteractivaDesde);
            this.pnlCrtsRangoInteractiva.Location = new System.Drawing.Point(83, 3);
            this.pnlCrtsRangoInteractiva.Name = "pnlCrtsRangoInteractiva";
            this.pnlCrtsRangoInteractiva.Size = new System.Drawing.Size(231, 61);
            this.pnlCrtsRangoInteractiva.TabIndex = 14;
            // 
            // nupAnioInteractivaHasta
            // 
            this.nupAnioInteractivaHasta.Location = new System.Drawing.Point(80, 5);
            this.nupAnioInteractivaHasta.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.nupAnioInteractivaHasta.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nupAnioInteractivaHasta.Name = "nupAnioInteractivaHasta";
            this.nupAnioInteractivaHasta.Size = new System.Drawing.Size(60, 21);
            this.nupAnioInteractivaHasta.TabIndex = 11;
            this.nupAnioInteractivaHasta.Value = new decimal(new int[] {
            2014,
            0,
            0,
            0});
            // 
            // cboMesInteractivaHasta
            // 
            this.cboMesInteractivaHasta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMesInteractivaHasta.FormattingEnabled = true;
            this.cboMesInteractivaHasta.Location = new System.Drawing.Point(109, 32);
            this.cboMesInteractivaHasta.Name = "cboMesInteractivaHasta";
            this.cboMesInteractivaHasta.Size = new System.Drawing.Size(100, 26);
            this.cboMesInteractivaHasta.TabIndex = 13;
            // 
            // nupAnioInteractivaDesde
            // 
            this.nupAnioInteractivaDesde.Location = new System.Drawing.Point(3, 5);
            this.nupAnioInteractivaDesde.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.nupAnioInteractivaDesde.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nupAnioInteractivaDesde.Name = "nupAnioInteractivaDesde";
            this.nupAnioInteractivaDesde.Size = new System.Drawing.Size(60, 21);
            this.nupAnioInteractivaDesde.TabIndex = 10;
            this.nupAnioInteractivaDesde.Value = new decimal(new int[] {
            2014,
            0,
            0,
            0});
            // 
            // cboMesInteractivaDesde
            // 
            this.cboMesInteractivaDesde.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMesInteractivaDesde.FormattingEnabled = true;
            this.cboMesInteractivaDesde.Location = new System.Drawing.Point(3, 32);
            this.cboMesInteractivaDesde.Name = "cboMesInteractivaDesde";
            this.cboMesInteractivaDesde.Size = new System.Drawing.Size(100, 26);
            this.cboMesInteractivaDesde.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Mes:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Año:";
            // 
            // grpPeriodica
            // 
            this.grpPeriodica.Controls.Add(this.optPeriodicaEspecifico);
            this.grpPeriodica.Controls.Add(this.optPeriodicaRango);
            this.grpPeriodica.Controls.Add(this.pnlPeriodica);
            this.grpPeriodica.Enabled = false;
            this.grpPeriodica.Location = new System.Drawing.Point(3, 115);
            this.grpPeriodica.Name = "grpPeriodica";
            this.grpPeriodica.Size = new System.Drawing.Size(459, 84);
            this.grpPeriodica.TabIndex = 12;
            this.grpPeriodica.TabStop = false;
            this.grpPeriodica.Text = "Periodica";
            // 
            // optPeriodicaEspecifico
            // 
            this.optPeriodicaEspecifico.AutoSize = true;
            this.optPeriodicaEspecifico.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPeriodicaEspecifico.Location = new System.Drawing.Point(149, 0);
            this.optPeriodicaEspecifico.Name = "optPeriodicaEspecifico";
            this.optPeriodicaEspecifico.Size = new System.Drawing.Size(81, 20);
            this.optPeriodicaEspecifico.TabIndex = 7;
            this.optPeriodicaEspecifico.Text = "Especificos";
            this.optPeriodicaEspecifico.UseVisualStyleBackColor = true;
            this.optPeriodicaEspecifico.CheckedChanged += new System.EventHandler(this.OptPeriodicaEspecifico_CheckedChanged);
            // 
            // optPeriodicaRango
            // 
            this.optPeriodicaRango.AutoSize = true;
            this.optPeriodicaRango.Checked = true;
            this.optPeriodicaRango.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPeriodicaRango.Location = new System.Drawing.Point(86, 0);
            this.optPeriodicaRango.Name = "optPeriodicaRango";
            this.optPeriodicaRango.Size = new System.Drawing.Size(55, 20);
            this.optPeriodicaRango.TabIndex = 6;
            this.optPeriodicaRango.TabStop = true;
            this.optPeriodicaRango.Text = "Rango";
            this.optPeriodicaRango.UseVisualStyleBackColor = true;
            // 
            // pnlPeriodica
            // 
            this.pnlPeriodica.Controls.Add(this.pnlCtrsPeriodicaEspecificos);
            this.pnlPeriodica.Controls.Add(this.pnlPeriodosPeriodicaRango);
            this.pnlPeriodica.Controls.Add(this.pnlMesPeriodicaRango);
            this.pnlPeriodica.Controls.Add(this.pnlAnioPeriodicaRango);
            this.pnlPeriodica.Controls.Add(this.optMensual);
            this.pnlPeriodica.Controls.Add(this.optPeriodo);
            this.pnlPeriodica.Controls.Add(this.lblMesPeriodica);
            this.pnlPeriodica.Controls.Add(this.lblPeriodo);
            this.pnlPeriodica.Controls.Add(this.lblAnio);
            this.pnlPeriodica.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPeriodica.Location = new System.Drawing.Point(3, 17);
            this.pnlPeriodica.Name = "pnlPeriodica";
            this.pnlPeriodica.Size = new System.Drawing.Size(453, 64);
            this.pnlPeriodica.TabIndex = 5;
            // 
            // pnlCtrsPeriodicaEspecificos
            // 
            this.pnlCtrsPeriodicaEspecificos.BackColor = System.Drawing.SystemColors.Control;
            this.pnlCtrsPeriodicaEspecificos.Controls.Add(this.txtPeriodosPeriodica);
            this.pnlCtrsPeriodicaEspecificos.Controls.Add(this.txtMesesPeriodica);
            this.pnlCtrsPeriodicaEspecificos.Controls.Add(this.txtAniosPeriodica);
            this.pnlCtrsPeriodicaEspecificos.Location = new System.Drawing.Point(86, 4);
            this.pnlCtrsPeriodicaEspecificos.Name = "pnlCtrsPeriodicaEspecificos";
            this.pnlCtrsPeriodicaEspecificos.Size = new System.Drawing.Size(231, 61);
            this.pnlCtrsPeriodicaEspecificos.TabIndex = 16;
            this.pnlCtrsPeriodicaEspecificos.Visible = false;
            // 
            // txtPeriodosPeriodica
            // 
            this.txtPeriodosPeriodica.AutoCompleteCustomSource.AddRange(new string[] {
            "Texto"});
            this.txtPeriodosPeriodica.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtPeriodosPeriodica.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPeriodosPeriodica.Cue = "Periodos separados por comas";
            this.txtPeriodosPeriodica.Location = new System.Drawing.Point(0, 34);
            this.txtPeriodosPeriodica.Name = "txtPeriodosPeriodica";
            this.txtPeriodosPeriodica.Size = new System.Drawing.Size(231, 21);
            this.txtPeriodosPeriodica.TabIndex = 17;
            this.txtPeriodosPeriodica.Leave += new System.EventHandler(this.TxtControlValidationLeave);
            // 
            // txtMesesPeriodica
            // 
            this.txtMesesPeriodica.AutoCompleteCustomSource.AddRange(new string[] {
            "Texto"});
            this.txtMesesPeriodica.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtMesesPeriodica.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtMesesPeriodica.Cue = "Meses separados por comas";
            this.txtMesesPeriodica.Location = new System.Drawing.Point(0, 34);
            this.txtMesesPeriodica.Name = "txtMesesPeriodica";
            this.txtMesesPeriodica.Size = new System.Drawing.Size(231, 21);
            this.txtMesesPeriodica.TabIndex = 16;
            this.txtMesesPeriodica.Leave += new System.EventHandler(this.TxtControlValidationLeave);
            // 
            // txtAniosPeriodica
            // 
            this.txtAniosPeriodica.AutoCompleteCustomSource.AddRange(new string[] {
            "Texto"});
            this.txtAniosPeriodica.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAniosPeriodica.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAniosPeriodica.Cue = "Años separado por comas";
            this.txtAniosPeriodica.Location = new System.Drawing.Point(0, 5);
            this.txtAniosPeriodica.Name = "txtAniosPeriodica";
            this.txtAniosPeriodica.Size = new System.Drawing.Size(231, 21);
            this.txtAniosPeriodica.TabIndex = 15;
            this.txtAniosPeriodica.Leave += new System.EventHandler(this.TxtControlValidationLeave);
            // 
            // pnlPeriodosPeriodicaRango
            // 
            this.pnlPeriodosPeriodicaRango.Controls.Add(this.lblAPeriodicaRangoPeriodo);
            this.pnlPeriodosPeriodicaRango.Controls.Add(this.nupPeriodoDesde);
            this.pnlPeriodosPeriodicaRango.Controls.Add(this.nupPeriodoHasta);
            this.pnlPeriodosPeriodicaRango.Location = new System.Drawing.Point(83, 35);
            this.pnlPeriodosPeriodicaRango.Name = "pnlPeriodosPeriodicaRango";
            this.pnlPeriodosPeriodicaRango.Size = new System.Drawing.Size(195, 26);
            this.pnlPeriodosPeriodicaRango.TabIndex = 12;
            // 
            // lblAPeriodicaRangoPeriodo
            // 
            this.lblAPeriodicaRangoPeriodo.AutoSize = true;
            this.lblAPeriodicaRangoPeriodo.Location = new System.Drawing.Point(69, 3);
            this.lblAPeriodicaRangoPeriodo.Name = "lblAPeriodicaRangoPeriodo";
            this.lblAPeriodicaRangoPeriodo.Size = new System.Drawing.Size(12, 18);
            this.lblAPeriodicaRangoPeriodo.TabIndex = 9;
            this.lblAPeriodicaRangoPeriodo.Text = "-";
            // 
            // nupPeriodoDesde
            // 
            this.nupPeriodoDesde.Location = new System.Drawing.Point(3, 3);
            this.nupPeriodoDesde.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.nupPeriodoDesde.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nupPeriodoDesde.Name = "nupPeriodoDesde";
            this.nupPeriodoDesde.Size = new System.Drawing.Size(60, 21);
            this.nupPeriodoDesde.TabIndex = 8;
            this.nupPeriodoDesde.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nupPeriodoHasta
            // 
            this.nupPeriodoHasta.Location = new System.Drawing.Point(89, 3);
            this.nupPeriodoHasta.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.nupPeriodoHasta.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nupPeriodoHasta.Name = "nupPeriodoHasta";
            this.nupPeriodoHasta.Size = new System.Drawing.Size(60, 21);
            this.nupPeriodoHasta.TabIndex = 9;
            this.nupPeriodoHasta.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pnlMesPeriodicaRango
            // 
            this.pnlMesPeriodicaRango.Controls.Add(this.lblGuionMeses);
            this.pnlMesPeriodicaRango.Controls.Add(this.cboMesPeriodicaDesde);
            this.pnlMesPeriodicaRango.Controls.Add(this.cboMesPeriodicaHasta);
            this.pnlMesPeriodicaRango.Location = new System.Drawing.Point(83, 32);
            this.pnlMesPeriodicaRango.Name = "pnlMesPeriodicaRango";
            this.pnlMesPeriodicaRango.Size = new System.Drawing.Size(230, 32);
            this.pnlMesPeriodicaRango.TabIndex = 13;
            this.pnlMesPeriodicaRango.Visible = false;
            // 
            // lblGuionMeses
            // 
            this.lblGuionMeses.AutoSize = true;
            this.lblGuionMeses.Location = new System.Drawing.Point(107, 7);
            this.lblGuionMeses.Name = "lblGuionMeses";
            this.lblGuionMeses.Size = new System.Drawing.Size(12, 18);
            this.lblGuionMeses.TabIndex = 10;
            this.lblGuionMeses.Text = "-";
            // 
            // cboMesPeriodicaDesde
            // 
            this.cboMesPeriodicaDesde.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMesPeriodicaDesde.FormattingEnabled = true;
            this.cboMesPeriodicaDesde.Location = new System.Drawing.Point(3, 3);
            this.cboMesPeriodicaDesde.Name = "cboMesPeriodicaDesde";
            this.cboMesPeriodicaDesde.Size = new System.Drawing.Size(100, 26);
            this.cboMesPeriodicaDesde.TabIndex = 7;
            // 
            // cboMesPeriodicaHasta
            // 
            this.cboMesPeriodicaHasta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMesPeriodicaHasta.FormattingEnabled = true;
            this.cboMesPeriodicaHasta.Location = new System.Drawing.Point(124, 3);
            this.cboMesPeriodicaHasta.Name = "cboMesPeriodicaHasta";
            this.cboMesPeriodicaHasta.Size = new System.Drawing.Size(100, 26);
            this.cboMesPeriodicaHasta.TabIndex = 10;
            // 
            // pnlAnioPeriodicaRango
            // 
            this.pnlAnioPeriodicaRango.Controls.Add(this.lblAPeriodicaRangoAnio);
            this.pnlAnioPeriodicaRango.Controls.Add(this.nupAnioPeriodicaDesde);
            this.pnlAnioPeriodicaRango.Controls.Add(this.nupAnioPeriodicaHasta);
            this.pnlAnioPeriodicaRango.Location = new System.Drawing.Point(83, 6);
            this.pnlAnioPeriodicaRango.Name = "pnlAnioPeriodicaRango";
            this.pnlAnioPeriodicaRango.Size = new System.Drawing.Size(200, 26);
            this.pnlAnioPeriodicaRango.TabIndex = 11;
            // 
            // lblAPeriodicaRangoAnio
            // 
            this.lblAPeriodicaRangoAnio.AutoSize = true;
            this.lblAPeriodicaRangoAnio.Location = new System.Drawing.Point(69, 4);
            this.lblAPeriodicaRangoAnio.Name = "lblAPeriodicaRangoAnio";
            this.lblAPeriodicaRangoAnio.Size = new System.Drawing.Size(12, 18);
            this.lblAPeriodicaRangoAnio.TabIndex = 8;
            this.lblAPeriodicaRangoAnio.Text = "-";
            // 
            // nupAnioPeriodicaDesde
            // 
            this.nupAnioPeriodicaDesde.Location = new System.Drawing.Point(3, 3);
            this.nupAnioPeriodicaDesde.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.nupAnioPeriodicaDesde.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nupAnioPeriodicaDesde.Name = "nupAnioPeriodicaDesde";
            this.nupAnioPeriodicaDesde.Size = new System.Drawing.Size(60, 21);
            this.nupAnioPeriodicaDesde.TabIndex = 6;
            this.nupAnioPeriodicaDesde.Value = new decimal(new int[] {
            2014,
            0,
            0,
            0});
            this.nupAnioPeriodicaDesde.ValueChanged += new System.EventHandler(this.txtAnio_ValueChanged);
            // 
            // nupAnioPeriodicaHasta
            // 
            this.nupAnioPeriodicaHasta.Location = new System.Drawing.Point(88, 3);
            this.nupAnioPeriodicaHasta.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.nupAnioPeriodicaHasta.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nupAnioPeriodicaHasta.Name = "nupAnioPeriodicaHasta";
            this.nupAnioPeriodicaHasta.Size = new System.Drawing.Size(60, 21);
            this.nupAnioPeriodicaHasta.TabIndex = 7;
            this.nupAnioPeriodicaHasta.Value = new decimal(new int[] {
            2014,
            0,
            0,
            0});
            // 
            // optMensual
            // 
            this.optMensual.AutoSize = true;
            this.optMensual.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optMensual.Location = new System.Drawing.Point(353, 32);
            this.optMensual.Name = "optMensual";
            this.optMensual.Size = new System.Drawing.Size(70, 22);
            this.optMensual.TabIndex = 9;
            this.optMensual.Text = "Por Mes";
            this.optMensual.UseVisualStyleBackColor = true;
            this.optMensual.CheckedChanged += new System.EventHandler(this.optMensual_CheckedChanged);
            // 
            // optPeriodo
            // 
            this.optPeriodo.AutoSize = true;
            this.optPeriodo.Checked = true;
            this.optPeriodo.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optPeriodo.Location = new System.Drawing.Point(353, 11);
            this.optPeriodo.Name = "optPeriodo";
            this.optPeriodo.Size = new System.Drawing.Size(90, 22);
            this.optPeriodo.TabIndex = 4;
            this.optPeriodo.TabStop = true;
            this.optPeriodo.Text = "Por Periodo";
            this.optPeriodo.UseVisualStyleBackColor = true;
            // 
            // lblMesPeriodica
            // 
            this.lblMesPeriodica.AutoSize = true;
            this.lblMesPeriodica.Location = new System.Drawing.Point(31, 40);
            this.lblMesPeriodica.Name = "lblMesPeriodica";
            this.lblMesPeriodica.Size = new System.Drawing.Size(34, 18);
            this.lblMesPeriodica.TabIndex = 6;
            this.lblMesPeriodica.Text = "Mes:";
            this.lblMesPeriodica.Visible = false;
            // 
            // lblPeriodo
            // 
            this.lblPeriodo.AutoSize = true;
            this.lblPeriodo.Location = new System.Drawing.Point(11, 40);
            this.lblPeriodo.Name = "lblPeriodo";
            this.lblPeriodo.Size = new System.Drawing.Size(54, 18);
            this.lblPeriodo.TabIndex = 4;
            this.lblPeriodo.Text = "Periodo:";
            // 
            // lblAnio
            // 
            this.lblAnio.AutoSize = true;
            this.lblAnio.Location = new System.Drawing.Point(32, 11);
            this.lblAnio.Name = "lblAnio";
            this.lblAnio.Size = new System.Drawing.Size(33, 18);
            this.lblAnio.TabIndex = 2;
            this.lblAnio.Text = "Año:";
            // 
            // chlClaseNomina
            // 
            this.chlClaseNomina.CheckOnClick = true;
            this.chlClaseNomina.Enabled = false;
            this.chlClaseNomina.FormattingEnabled = true;
            this.chlClaseNomina.Location = new System.Drawing.Point(555, 32);
            this.chlClaseNomina.Name = "chlClaseNomina";
            this.chlClaseNomina.Size = new System.Drawing.Size(317, 52);
            this.chlClaseNomina.TabIndex = 3;
            this.chlClaseNomina.SelectedIndexChanged += new System.EventHandler(this.chlClaseNomina_SelectedIndexChanged);
            // 
            // chlTipoNomina
            // 
            this.chlTipoNomina.CheckOnClick = true;
            this.chlTipoNomina.FormattingEnabled = true;
            this.chlTipoNomina.Location = new System.Drawing.Point(136, 32);
            this.chlTipoNomina.Name = "chlTipoNomina";
            this.chlTipoNomina.Size = new System.Drawing.Size(300, 52);
            this.chlTipoNomina.TabIndex = 2;
            this.chlTipoNomina.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.ChlTipoNomina_ItemCheck);
            // 
            // cboFormaPago
            // 
            this.cboFormaPago.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFormaPago.FormattingEnabled = true;
            this.cboFormaPago.Location = new System.Drawing.Point(555, 86);
            this.cboFormaPago.Name = "cboFormaPago";
            this.cboFormaPago.Size = new System.Drawing.Size(317, 26);
            this.cboFormaPago.TabIndex = 5;
            // 
            // lblMetodoPago
            // 
            this.lblMetodoPago.AutoSize = true;
            this.lblMetodoPago.Location = new System.Drawing.Point(457, 88);
            this.lblMetodoPago.Name = "lblMetodoPago";
            this.lblMetodoPago.Size = new System.Drawing.Size(92, 18);
            this.lblMetodoPago.TabIndex = 8;
            this.lblMetodoPago.Text = "Forma de Pago:";
            // 
            // txtConceptoFactura
            // 
            this.txtConceptoFactura.Location = new System.Drawing.Point(136, 88);
            this.txtConceptoFactura.MaxLength = 100;
            this.txtConceptoFactura.Name = "txtConceptoFactura";
            this.txtConceptoFactura.Size = new System.Drawing.Size(300, 21);
            this.txtConceptoFactura.TabIndex = 4;
            this.txtConceptoFactura.Text = "Pago de Nómina";
            // 
            // lblConcepto
            // 
            this.lblConcepto.AutoSize = true;
            this.lblConcepto.Location = new System.Drawing.Point(10, 89);
            this.lblConcepto.Name = "lblConcepto";
            this.lblConcepto.Size = new System.Drawing.Size(112, 18);
            this.lblConcepto.TabIndex = 3;
            this.lblConcepto.Text = "Concepto Factura:";
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.pnlInstitucion);
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(1115, 28);
            this.pnlLogo.TabIndex = 1;
            // 
            // pnlInstitucion
            // 
            this.pnlInstitucion.Controls.Add(this.lblInstitucion);
            this.pnlInstitucion.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlInstitucion.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlInstitucion.Location = new System.Drawing.Point(805, 0);
            this.pnlInstitucion.Name = "pnlInstitucion";
            this.pnlInstitucion.Size = new System.Drawing.Size(310, 28);
            this.pnlInstitucion.TabIndex = 15;
            // 
            // lblInstitucion
            // 
            this.lblInstitucion.AutoSize = true;
            this.lblInstitucion.BackColor = System.Drawing.Color.Transparent;
            this.lblInstitucion.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblInstitucion.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblInstitucion.Font = new System.Drawing.Font("Trebuchet MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstitucion.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblInstitucion.Location = new System.Drawing.Point(0, 0);
            this.lblInstitucion.Name = "lblInstitucion";
            this.lblInstitucion.Size = new System.Drawing.Size(56, 27);
            this.lblInstitucion.TabIndex = 0;
            this.lblInstitucion.Text = "INST";
            this.lblInstitucion.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // picLogo
            // 
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.Location = new System.Drawing.Point(17, -4);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(106, 35);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(133, 3);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(364, 23);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Generación de Recibos de Nómina Electrónicos";
            // 
            // cmdTrabajadores
            // 
            this.cmdTrabajadores.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdTrabajadores.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdTrabajadores.Location = new System.Drawing.Point(5, 5);
            this.cmdTrabajadores.Name = "cmdTrabajadores";
            this.cmdTrabajadores.Size = new System.Drawing.Size(123, 40);
            this.cmdTrabajadores.TabIndex = 0;
            this.cmdTrabajadores.Text = "&Lista de Trabajadores";
            this.cmdTrabajadores.UseVisualStyleBackColor = true;
            this.cmdTrabajadores.Click += new System.EventHandler(this.cmdTrabajadores_Click);
            // 
            // cmdGeneraArchivo
            // 
            this.cmdGeneraArchivo.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdGeneraArchivo.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdGeneraArchivo.Location = new System.Drawing.Point(5, 45);
            this.cmdGeneraArchivo.Name = "cmdGeneraArchivo";
            this.cmdGeneraArchivo.Size = new System.Drawing.Size(123, 40);
            this.cmdGeneraArchivo.TabIndex = 1;
            this.cmdGeneraArchivo.Text = "&Genera Archivo Previo XML";
            this.cmdGeneraArchivo.UseVisualStyleBackColor = true;
            this.cmdGeneraArchivo.Click += new System.EventHandler(this.cmdGeneraArchivo_Click);
            // 
            // cmdCopiar
            // 
            this.cmdCopiar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cmdCopiar.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCopiar.Location = new System.Drawing.Point(5, 670);
            this.cmdCopiar.Name = "cmdCopiar";
            this.cmdCopiar.Size = new System.Drawing.Size(120, 40);
            this.cmdCopiar.TabIndex = 7;
            this.cmdCopiar.Text = "C&opiar Resultados";
            this.cmdCopiar.UseVisualStyleBackColor = true;
            this.cmdCopiar.Click += new System.EventHandler(this.cmdCopiar_Click);
            // 
            // cmdGenera
            // 
            this.cmdGenera.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdGenera.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdGenera.Location = new System.Drawing.Point(5, 85);
            this.cmdGenera.Name = "cmdGenera";
            this.cmdGenera.Size = new System.Drawing.Size(123, 63);
            this.cmdGenera.TabIndex = 2;
            this.cmdGenera.Text = "&Enviar Datos";
            this.cmdGenera.UseVisualStyleBackColor = true;
            this.cmdGenera.Click += new System.EventHandler(this.cmdGenera_Click);
            // 
            // cmdSalir
            // 
            this.cmdSalir.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdSalir.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSalir.Location = new System.Drawing.Point(5, 247);
            this.cmdSalir.Name = "cmdSalir";
            this.cmdSalir.Size = new System.Drawing.Size(123, 40);
            this.cmdSalir.TabIndex = 20;
            this.cmdSalir.Text = "&Salir";
            this.cmdSalir.UseVisualStyleBackColor = true;
            this.cmdSalir.Click += new System.EventHandler(this.cmdSalir_Click);
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.cmdCambioPais);
            this.pnlHerramientas.Controls.Add(this.chkValidaXSD);
            this.pnlHerramientas.Controls.Add(this.cmdSalir);
            this.pnlHerramientas.Controls.Add(this.cmdConfigurations);
            this.pnlHerramientas.Controls.Add(this.cmdQueries);
            this.pnlHerramientas.Controls.Add(this.cmdGenera);
            this.pnlHerramientas.Controls.Add(this.cmdCopiar);
            this.pnlHerramientas.Controls.Add(this.cmdGeneraArchivo);
            this.pnlHerramientas.Controls.Add(this.cmdTrabajadores);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlHerramientas.Location = new System.Drawing.Point(982, 28);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Padding = new System.Windows.Forms.Padding(5);
            this.pnlHerramientas.Size = new System.Drawing.Size(133, 721);
            this.pnlHerramientas.TabIndex = 2;
            // 
            // cmdCambioPais
            // 
            this.cmdCambioPais.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cmdCambioPais.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCambioPais.Location = new System.Drawing.Point(5, 628);
            this.cmdCambioPais.Name = "cmdCambioPais";
            this.cmdCambioPais.Size = new System.Drawing.Size(120, 34);
            this.cmdCambioPais.TabIndex = 24;
            this.cmdCambioPais.Text = "C&ambiar País";
            this.cmdCambioPais.UseVisualStyleBackColor = true;
            this.cmdCambioPais.Click += new System.EventHandler(this.cmdCambioPais_Click);
            // 
            // chkValidaXSD
            // 
            this.chkValidaXSD.AutoSize = true;
            this.chkValidaXSD.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkValidaXSD.Checked = true;
            this.chkValidaXSD.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkValidaXSD.Dock = System.Windows.Forms.DockStyle.Top;
            this.chkValidaXSD.Location = new System.Drawing.Point(5, 287);
            this.chkValidaXSD.Name = "chkValidaXSD";
            this.chkValidaXSD.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.chkValidaXSD.Size = new System.Drawing.Size(123, 25);
            this.chkValidaXSD.TabIndex = 17;
            this.chkValidaXSD.Text = "Valida contra XSD";
            this.chkValidaXSD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkValidaXSD.UseVisualStyleBackColor = true;
            // 
            // cmdConfigurations
            // 
            this.cmdConfigurations.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdConfigurations.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.left_arrow;
            this.cmdConfigurations.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cmdConfigurations.Location = new System.Drawing.Point(5, 200);
            this.cmdConfigurations.Name = "cmdConfigurations";
            this.cmdConfigurations.Size = new System.Drawing.Size(123, 47);
            this.cmdConfigurations.TabIndex = 21;
            this.cmdConfigurations.Text = "Configuración";
            this.cmdConfigurations.UseVisualStyleBackColor = true;
            this.cmdConfigurations.Click += new System.EventHandler(this.cmdConfigurations_Click);
            // 
            // cmdQueries
            // 
            this.cmdQueries.Dock = System.Windows.Forms.DockStyle.Top;
            this.cmdQueries.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.left_arrow;
            this.cmdQueries.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cmdQueries.Location = new System.Drawing.Point(5, 148);
            this.cmdQueries.Name = "cmdQueries";
            this.cmdQueries.Size = new System.Drawing.Size(123, 52);
            this.cmdQueries.TabIndex = 23;
            this.cmdQueries.Text = "&Consultas";
            this.cmdQueries.UseVisualStyleBackColor = true;
            this.cmdQueries.Click += new System.EventHandler(this.cmdQueries_Click);
            // 
            // MnuConfigurations
            // 
            this.MnuConfigurations.MaximumSize = new System.Drawing.Size(143, 0);
            this.MnuConfigurations.Name = "contextMenuStrip1";
            this.MnuConfigurations.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.MnuConfigurations.ShowImageMargin = false;
            this.MnuConfigurations.ShowItemToolTips = false;
            this.MnuConfigurations.Size = new System.Drawing.Size(36, 4);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.AutoSize = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(229, 22);
            this.toolStripMenuItem1.Text = "Consulta Catalogos ADAM - DIAN";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(219, 22);
            this.toolStripMenuItem2.Text = "Mapeo Catalogos ADAM - DIAN";
            // 
            // MnuQueries
            // 
            this.MnuQueries.MaximumSize = new System.Drawing.Size(143, 0);
            this.MnuQueries.Name = "contextMenuStrip1";
            this.MnuQueries.ShowImageMargin = false;
            this.MnuQueries.ShowItemToolTips = false;
            this.MnuQueries.Size = new System.Drawing.Size(36, 4);
            // 
            // FrmGeneracionRecibo
            // 
            this.AcceptButton = this.cmdGenera;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1115, 749);
            this.Controls.Add(this.pnlInferior);
            this.Controls.Add(this.pnlSuperior);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "FrmGeneracionRecibo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Generación de Recibos Electronicos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmGeneracionRecibo_FormClosing);
            this.Load += new System.EventHandler(this.FrmGeneracionRecibo_Load);
            this.pnlInferior.ResumeLayout(false);
            this.pnlTrabajadores.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridTrabajadores)).EndInit();
            this.pnlTools.ResumeLayout(false);
            this.pnlUtilities.ResumeLayout(false);
            this.pnlUtilities.PerformLayout();
            this.pnlFiltros.ResumeLayout(false);
            this.pnlFiltros.PerformLayout();
            this.pnlEstadosTimbrado.ResumeLayout(false);
            this.pnlEstadosTimbrado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridTotales)).EndInit();
            this.pnlResultados.ResumeLayout(false);
            this.pnlSuperior.ResumeLayout(false);
            this.pnlSuperior.PerformLayout();
            this.grpInteractiva.ResumeLayout(false);
            this.grpInteractiva.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlCtrsEspecificosInteractiva.ResumeLayout(false);
            this.pnlCtrsEspecificosInteractiva.PerformLayout();
            this.pnlCrtsRangoInteractiva.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioInteractivaHasta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioInteractivaDesde)).EndInit();
            this.grpPeriodica.ResumeLayout(false);
            this.grpPeriodica.PerformLayout();
            this.pnlPeriodica.ResumeLayout(false);
            this.pnlPeriodica.PerformLayout();
            this.pnlCtrsPeriodicaEspecificos.ResumeLayout(false);
            this.pnlCtrsPeriodicaEspecificos.PerformLayout();
            this.pnlPeriodosPeriodicaRango.ResumeLayout(false);
            this.pnlPeriodosPeriodicaRango.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupPeriodoDesde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupPeriodoHasta)).EndInit();
            this.pnlMesPeriodicaRango.ResumeLayout(false);
            this.pnlMesPeriodicaRango.PerformLayout();
            this.pnlAnioPeriodicaRango.ResumeLayout(false);
            this.pnlAnioPeriodicaRango.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioPeriodicaDesde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupAnioPeriodicaHasta)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            this.pnlInstitucion.ResumeLayout(false);
            this.pnlInstitucion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.pnlHerramientas.ResumeLayout(false);
            this.pnlHerramientas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        
        private System.Windows.Forms.Label lblClaseNomina;
        private System.Windows.Forms.Label lblCompania;
        private System.Windows.Forms.ComboBox cboCompania;
        private System.Windows.Forms.Label lblTipoNomina;
        private System.Windows.Forms.Panel pnlInferior;
        private System.Windows.Forms.Panel pnlSuperior;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.ListBox lbGenerados;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Panel pnlResultados;
        private System.Windows.Forms.DataGridView gridTotales;
        private System.Windows.Forms.TextBox txtConceptoFactura;
        private System.Windows.Forms.Label lblConcepto;
        private System.Windows.Forms.Label lblMetodoPago;
        private System.Windows.Forms.ComboBox cboFormaPago;
        private System.Windows.Forms.CheckedListBox chlClaseNomina;
        private System.Windows.Forms.CheckedListBox chlTipoNomina;
        private System.Windows.Forms.GroupBox grpInteractiva;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cboMesInteractivaHasta;
        private System.Windows.Forms.ComboBox cboMesInteractivaDesde;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nupAnioInteractivaDesde;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpPeriodica;
        private System.Windows.Forms.NumericUpDown nupAnioInteractivaHasta;
        private UI.CueTextBox txtAniosInteractiva;
        private System.Windows.Forms.RadioButton optPeriodicaEspecifico;
        private System.Windows.Forms.RadioButton optPeriodicaRango;
        private System.Windows.Forms.RadioButton optInteractivaEspecifico;
        private System.Windows.Forms.RadioButton optInteractivaRango;
        private System.Windows.Forms.Panel pnlCrtsRangoInteractiva;
        private System.Windows.Forms.Panel pnlCtrsEspecificosInteractiva;
        private UI.CueTextBox txtMesesInteractiva;
        private System.Windows.Forms.Panel pnlPeriodica;
        private System.Windows.Forms.Panel pnlCtrsPeriodicaEspecificos;
        private UI.CueTextBox txtPeriodosPeriodica;
        private UI.CueTextBox txtMesesPeriodica;
        private UI.CueTextBox txtAniosPeriodica;
        private System.Windows.Forms.Panel pnlPeriodosPeriodicaRango;
        private System.Windows.Forms.Label lblAPeriodicaRangoPeriodo;
        private System.Windows.Forms.NumericUpDown nupPeriodoDesde;
        private System.Windows.Forms.NumericUpDown nupPeriodoHasta;
        private System.Windows.Forms.Panel pnlMesPeriodicaRango;
        private System.Windows.Forms.Label lblGuionMeses;
        private System.Windows.Forms.ComboBox cboMesPeriodicaDesde;
        private System.Windows.Forms.ComboBox cboMesPeriodicaHasta;
        private System.Windows.Forms.Panel pnlAnioPeriodicaRango;
        private System.Windows.Forms.Label lblAPeriodicaRangoAnio;
        private System.Windows.Forms.NumericUpDown nupAnioPeriodicaDesde;
        private System.Windows.Forms.NumericUpDown nupAnioPeriodicaHasta;
        private System.Windows.Forms.RadioButton optMensual;
        private System.Windows.Forms.RadioButton optPeriodo;
        private System.Windows.Forms.Label lblMesPeriodica;
        private System.Windows.Forms.Label lblPeriodo;
        private System.Windows.Forms.Label lblAnio;
        private System.Windows.Forms.Button cmdTrabajadores;
        private System.Windows.Forms.Button cmdGeneraArchivo;
        private System.Windows.Forms.Button cmdCopiar;
        private System.Windows.Forms.Button cmdGenera;
        private System.Windows.Forms.Button cmdSalir;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.CheckBox chkValidaXSD;
        private System.Windows.Forms.Panel pnlTools;
        private System.Windows.Forms.Panel pnlUtilities;
        private System.Windows.Forms.ComboBox cboTipoSeleccion;
        private System.Windows.Forms.Label lblContador;
        private System.Windows.Forms.Label lblSeleccionados;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.Button cmdExporta;
        private System.Windows.Forms.Panel pnlFiltros;
        private System.Windows.Forms.Button btnStateRefresh;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Panel pnlEstadosTimbrado;
        private System.Windows.Forms.CheckBox chkStateFinalizado;
        private System.Windows.Forms.CheckBox chkStateConError;
        private System.Windows.Forms.CheckBox chkStateCancelado;
        private System.Windows.Forms.CheckBox chkStateEliminado;
        private System.Windows.Forms.CheckBox chkStateEnProceso;
        private System.Windows.Forms.CheckBox chkStateSinTimbrar;
        private System.Windows.Forms.CheckBox chkStateTodos;
        private System.Windows.Forms.Panel pnlTrabajadores;
        private System.Windows.Forms.DataGridView gridTrabajadores;
        private System.Windows.Forms.ContextMenuStrip MnuConfigurations;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Button cmdConfigurations;
        private System.Windows.Forms.ContextMenuStrip MnuQueries;
        private System.Windows.Forms.Button cmdQueries;
        private System.Windows.Forms.Panel pnlInstitucion;
        private System.Windows.Forms.Label lblInstitucion;
        private System.Windows.Forms.Button cmdCambioPais;
        private ADAM.Recibos.Controls.CustomProgressBar pbResultados;
    }
}


namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmAgregarConceptoDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAgregarConceptoDIAN));
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblClaveTipo = new System.Windows.Forms.Label();
            this.lblDescripcionTipo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cboConceptos = new System.Windows.Forms.ComboBox();
            this.cmdAgregar = new System.Windows.Forms.Button();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.Location = new System.Drawing.Point(10, 20);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(443, 24);
            this.lblDescripcion.TabIndex = 0;
            this.lblDescripcion.Text = "Mapear Conceptos DIAN vs Conceptos ADAM\r\n";
            // 
            // lblClaveTipo
            // 
            this.lblClaveTipo.AutoSize = true;
            this.lblClaveTipo.Location = new System.Drawing.Point(10, 80);
            this.lblClaveTipo.Name = "lblClaveTipo";
            this.lblClaveTipo.Size = new System.Drawing.Size(36, 18);
            this.lblClaveTipo.TabIndex = 1;
            this.lblClaveTipo.Text = "Tipo:";
            // 
            // lblDescripcionTipo
            // 
            this.lblDescripcionTipo.Location = new System.Drawing.Point(10, 110);
            this.lblDescripcionTipo.Name = "lblDescripcionTipo";
            this.lblDescripcionTipo.Size = new System.Drawing.Size(180, 100);
            this.lblDescripcionTipo.TabIndex = 2;
            this.lblDescripcionTipo.Text = "----";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(200, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Concepto a Relacionar";
            // 
            // cboConceptos
            // 
            this.cboConceptos.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboConceptos.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboConceptos.DropDownWidth = 350;
            this.cboConceptos.FormattingEnabled = true;
            this.cboConceptos.Location = new System.Drawing.Point(203, 110);
            this.cboConceptos.Name = "cboConceptos";
            this.cboConceptos.Size = new System.Drawing.Size(250, 26);
            this.cboConceptos.TabIndex = 4;
            // 
            // cmdAgregar
            // 
            this.cmdAgregar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdAgregar.Location = new System.Drawing.Point(200, 200);
            this.cmdAgregar.Name = "cmdAgregar";
            this.cmdAgregar.Size = new System.Drawing.Size(110, 50);
            this.cmdAgregar.TabIndex = 5;
            this.cmdAgregar.Text = "&Agregar Concepto";
            this.cmdAgregar.UseVisualStyleBackColor = true;
            this.cmdAgregar.Click += new System.EventHandler(this.cmdAgregar_Click);
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(343, 200);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 6;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // FrmAgregarConceptoDIAN
            // 
            this.AcceptButton = this.cmdAgregar;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(484, 262);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdAgregar);
            this.Controls.Add(this.cboConceptos);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblDescripcionTipo);
            this.Controls.Add(this.lblClaveTipo);
            this.Controls.Add(this.lblDescripcion);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmAgregarConceptoDIAN";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Agregar Concepto";
            this.Load += new System.EventHandler(this.FrmAgregarConceptoDIAN_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblClaveTipo;
        private System.Windows.Forms.Label lblDescripcionTipo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboConceptos;
        private System.Windows.Forms.Button cmdAgregar;
        private System.Windows.Forms.Button cmdCerrar;
    }
}
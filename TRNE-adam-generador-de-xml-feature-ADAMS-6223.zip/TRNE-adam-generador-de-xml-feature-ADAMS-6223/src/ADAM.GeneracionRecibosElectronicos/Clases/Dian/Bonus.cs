﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("bonificacion", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Bonus
    {
        [JsonProperty("descripcion")]
        public string valorDescripcion { get; set; } = "";

        public decimal valor { get; set; }
        public bool esSalarial { get; set; }
    }
}

using System;
using System.Data;
using System.Reflection;
using Microsoft.Data.SqlClient;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Datos.Tests.Fakes;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.Datos.Tests.Clases.Common
{
    [TestClass]
    public class SqlConnectionFactoryTests
    {
        #region Helpers

        private static FakeAppSettings CreateDefaultSettings(string version = "5")
        {
            return new FakeAppSettings()
                .With(ConfigParameters.server.ToString(), "localhost")
                .With(ConfigParameters.database.ToString(), "TestDB")
                .With(ConfigParameters.user.ToString(), "sa")
                .With(ConfigParameters.password.ToString(), "pass123")
                .With(ConfigParameters.applicationUser.ToString(), "test-user")
                .With(ConfigParameters.version.ToString(), version);
        }

        private static string InvokeBuildConnectionString(SqlConnectionFactory factory)
        {
            var method = typeof(SqlConnectionFactory).GetMethod("BuildConnectionString",
                BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(method, "BuildConnectionString method not found");
            return (string)method.Invoke(factory, null)!;
        }

        #endregion

        #region Structure / Reflection Tests

        [TestMethod]
        public void Class_ShouldImplementIDbConnectionFactory()
        {
            Assert.IsTrue(typeof(IDbConnectionFactory).IsAssignableFrom(typeof(SqlConnectionFactory)));
        }

        [TestMethod]
        public void Class_ShouldHaveProtectedField_appSettings()
        {
            var field = typeof(SqlConnectionFactory).GetField("_appSettings",
                BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(field);
            Assert.IsTrue(field.IsFamily, "_appSettings should be protected");
        }

        [TestMethod]
        public void Class_ShouldHaveProtectedField_applicationUser()
        {
            var field = typeof(SqlConnectionFactory).GetField("_applicationUser",
                BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(field);
            Assert.IsTrue(field.IsFamily, "_applicationUser should be protected");
        }

        [TestMethod]
        public void Class_ShouldHavePrivateMethod_BuildConnectionString()
        {
            var method = typeof(SqlConnectionFactory).GetMethod("BuildConnectionString",
                BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(method);
            Assert.IsTrue(method.IsPrivate);
        }

        [TestMethod]
        [DataRow("CreateConnection")]
        [DataRow("CheckConnection")]
        public void Class_ShouldHavePublicMethod(string methodName)
        {
            var method = typeof(SqlConnectionFactory).GetMethod(methodName,
                BindingFlags.Public | BindingFlags.Instance);
            Assert.IsNotNull(method, $"{methodName} should be public");
        }

        #endregion

        #region Constructor Tests

        [TestMethod]
        public void Constructor_ShouldStoreAppSettings()
        {
            // Arrange
            var settings = CreateDefaultSettings();

            // Act
            var factory = new SqlConnectionFactory(settings);

            // Assert
            Assert.IsNotNull(factory);
        }

        [TestMethod]
        public void Constructor_WithNullSettings_ShouldNotThrow()
        {
            // Act — constructor only assigns the reference, no dereference yet
            var factory = new SqlConnectionFactory(null!);

            // Assert
            Assert.IsNotNull(factory);
        }

        #endregion

        #region ApplicationUser Tests

        [TestMethod]
        public void ApplicationUser_WhenUserHasDashes_ShouldReplaceWithUnderscores()
        {
            // Arrange
            var settings = CreateDefaultSettings();
            var factory = new SqlConnectionFactory(settings);
            // Force _applicationUser to be set by calling CreateConnection
            factory.CreateConnection();

            // Act
            var result = factory.ApplicationUser;

            // Assert
            Assert.AreEqual("test_user", result);
        }

        [TestMethod]
        public void ApplicationUser_WhenUserHasNoDashes_ShouldReturnAsIs()
        {
            // Arrange
            var settings = CreateDefaultSettings()
                .With(ConfigParameters.applicationUser.ToString(), "testuser");
            var factory = new SqlConnectionFactory(settings);
            factory.CreateConnection();

            // Act
            var result = factory.ApplicationUser;

            // Assert
            Assert.AreEqual("testuser", result);
        }

        [TestMethod]
        public void ApplicationUser_WhenUserHasMultipleDashes_ShouldReplaceAll()
        {
            // Arrange
            var settings = CreateDefaultSettings()
                .With(ConfigParameters.applicationUser.ToString(), "a-b-c-d");
            var factory = new SqlConnectionFactory(settings);
            factory.CreateConnection();

            // Act
            var result = factory.ApplicationUser;

            // Assert
            Assert.AreEqual("a_b_c_d", result);
        }

        [TestMethod]
        public void ApplicationUser_BeforeBuildConnectionString_ShouldThrowNullReferenceException()
        {
            // Arrange — _applicationUser is null before any call to BuildConnectionString
            var settings = CreateDefaultSettings();
            var factory = new SqlConnectionFactory(settings);

            // Act & Assert
            Assert.Throws<NullReferenceException>(() =>
            {
                _ = factory.ApplicationUser;
            });
        }

        #endregion

        #region BuildConnectionString Tests (private, via reflection)

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldReturnNonEmptyString()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            Assert.IsFalse(string.IsNullOrEmpty(result));
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldContainDataSource()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "localhost");
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldContainInitialCatalog()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "TestDB");
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldEnableMultipleActiveResultSets()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "Multiple Active Result Sets=True");
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldEnableTrustServerCertificate()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "Trust Server Certificate=True");
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldSetMinPoolSize10()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "Min Pool Size=10");
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldSetMaxPoolSizeBasedOnProcessorCount()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);
            var expectedMaxPool = (Environment.ProcessorCount - 1) * 60;

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, $"Max Pool Size={expectedMaxPool}");
        }

        [TestMethod]
        public void BuildConnectionString_Version5_ShouldSetConnectTimeout600()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "Connect Timeout=600");
        }

        [TestMethod]
        public void BuildConnectionString_Version3_ShouldReturnNonEmptyString()
        {
            // Arrange
            var settings = CreateDefaultSettings("3");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            Assert.IsFalse(string.IsNullOrEmpty(result));
        }

        [TestMethod]
        public void BuildConnectionString_Version3_ShouldContainDataSource()
        {
            // Arrange
            var settings = CreateDefaultSettings("3");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "localhost");
        }

        [TestMethod]
        public void BuildConnectionString_Version3_ShouldNotContainMinPoolSize()
        {
            // Arrange — version 3 doesn't set pool sizes
            var settings = CreateDefaultSettings("3");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            Assert.IsFalse(result.Contains("Min Pool Size=10"),
                "Version 3 should not set MinPoolSize");
        }

        [TestMethod]
        public void BuildConnectionString_Version3_ShouldNotContainMaxPoolSize()
        {
            // Arrange
            var settings = CreateDefaultSettings("3");
            var factory = new SqlConnectionFactory(settings);
            var v5MaxPool = (Environment.ProcessorCount - 1) * 60;

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            Assert.IsFalse(result.Contains($"Max Pool Size={v5MaxPool}"),
                "Version 3 should not set MaxPoolSize");
        }

        [TestMethod]
        public void BuildConnectionString_Version3_ShouldSetConnectTimeout600()
        {
            // Arrange
            var settings = CreateDefaultSettings("3");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            StringAssert.Contains(result, "Connect Timeout=600");
        }

        [TestMethod]
        public void BuildConnectionString_UnknownVersion_ShouldReturnEmpty()
        {
            // Arrange
            var settings = CreateDefaultSettings("99");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = InvokeBuildConnectionString(factory);

            // Assert
            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void BuildConnectionString_ShouldSetApplicationUser()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            InvokeBuildConnectionString(factory);

            // Assert — after BuildConnectionString, ApplicationUser is populated
            Assert.AreEqual("test_user", factory.ApplicationUser);
        }

        #endregion

        #region CreateConnection Tests

        [TestMethod]
        public void CreateConnection_Version5_ShouldReturnSqlConnection()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var connection = factory.CreateConnection();

            // Assert
            Assert.IsNotNull(connection);
            Assert.IsInstanceOfType<SqlConnection>(connection);
        }

        [TestMethod]
        public void CreateConnection_Version3_ShouldReturnSqlConnection()
        {
            // Arrange
            var settings = CreateDefaultSettings("3");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var connection = factory.CreateConnection();

            // Assert
            Assert.IsNotNull(connection);
            Assert.IsInstanceOfType<SqlConnection>(connection);
        }

        [TestMethod]
        public void CreateConnection_UnknownVersion_ShouldReturnNull()
        {
            // Arrange
            var settings = CreateDefaultSettings("99");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var connection = factory.CreateConnection();

            // Assert
            Assert.IsNull(connection);
        }

        [TestMethod]
        public void CreateConnection_EmptyVersion_ShouldReturnNull()
        {
            // Arrange
            var settings = CreateDefaultSettings("");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var connection = factory.CreateConnection();

            // Assert
            Assert.IsNull(connection);
        }

        [TestMethod]
        public void CreateConnection_Version5_ShouldReturnConnectionInClosedState()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            using var connection = factory.CreateConnection();

            // Assert
            Assert.AreEqual(ConnectionState.Closed, connection!.State);
        }

        [TestMethod]
        public void CreateConnection_Version5_ConnectionStringShouldContainExpectedServer()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            using var connection = (SqlConnection)factory.CreateConnection()!;

            // Assert
            StringAssert.Contains(connection.ConnectionString, "localhost");
        }

        [TestMethod]
        public void CreateConnection_Version5_ConnectionStringShouldContainExpectedDatabase()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            using var connection = (SqlConnection)factory.CreateConnection()!;

            // Assert
            StringAssert.Contains(connection.ConnectionString, "TestDB");
        }

        [TestMethod]
        public void CreateConnection_CalledTwice_ShouldReturnDifferentInstances()
        {
            // Arrange
            var settings = CreateDefaultSettings("5");
            var factory = new SqlConnectionFactory(settings);

            // Act
            using var conn1 = factory.CreateConnection();
            using var conn2 = factory.CreateConnection();

            // Assert
            Assert.AreNotSame(conn1, conn2);
        }

        [TestMethod]
        public void CreateConnection_NullSettings_ShouldReturnNull()
        {
            // Arrange — null appSettings causes NullReferenceException caught internally
            var factory = new SqlConnectionFactory(null!);

            // Act
            var connection = factory.CreateConnection();

            // Assert
            Assert.IsNull(connection);
        }

        #endregion

        #region CheckConnection Tests

        [TestMethod]
        public void CheckConnection_UnknownVersion_ShouldReturnFalse()
        {
            // Arrange — CreateConnection returns null → cast to SqlConnection → NullRef in using → catch returns false
            var settings = CreateDefaultSettings("99");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = factory.CheckConnection();

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CheckConnection_NullSettings_ShouldReturnFalse()
        {
            // Arrange
            var factory = new SqlConnectionFactory(null!);

            // Act
            var result = factory.CheckConnection();

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CheckConnection_EmptyVersion_ShouldReturnFalse()
        {
            // Arrange — empty version → CreateConnection returns null → catch returns false
            var settings = CreateDefaultSettings("");
            var factory = new SqlConnectionFactory(settings);

            // Act
            var result = factory.CheckConnection();

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CheckConnection_ReturnsBool()
        {
            // Arrange — verify CheckConnection returns a bool type
            var method = typeof(SqlConnectionFactory).GetMethod("CheckConnection",
                BindingFlags.Public | BindingFlags.Instance);

            // Assert
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
        }

        #endregion
    }
}

using ADAM.Recibos.Principal.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Principal.Tests.Classes
{
    [TestClass]
    public class XsdTemplatesTests
    {
        [TestMethod]
        public void XsdWhiteList_ContainsExpectedEntries()
        {
            Assert.AreEqual(7, XsdTemplates.xsdWhiteList.Count);
        }

        [TestMethod]
        [DataRow("catCFDI.xsd")]
        [DataRow("catNomina.xsd")]
        [DataRow("cfdv40.xsd")]
        [DataRow("tdCFDI.xsd")]
        [DataRow("nomina12.xsd")]
        [DataRow("nomina12_40ADAM.xsd")]
        [DataRow("nomina12_40ADAM_ext.xsd")]
        public void XsdWhiteList_ContainsKey(string key)
        {
            Assert.IsTrue(XsdTemplates.xsdWhiteList.ContainsKey(key));
        }

        [TestMethod]
        [DataRow("catCFDI.xsd", "catCFDI.xsd")]
        [DataRow("nomina12.xsd", "nomina12.xsd")]
        public void XsdWhiteList_KeyMatchesValue(string key, string expectedValue)
        {
            Assert.AreEqual(expectedValue, XsdTemplates.xsdWhiteList[key]);
        }

        [TestMethod]
        public void XsdWhiteList_DoesNotContainInvalidKey()
        {
            Assert.IsFalse(XsdTemplates.xsdWhiteList.ContainsKey("nonexistent.xsd"));
        }
    }
}

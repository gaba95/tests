using System.Windows.Forms;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.Recibos.Datos.Odbc.UI
{
    [ExcludeFromCodeCoverage]
    public partial class FrmConfiguracionConsultas : Form
    {
        #region Events

        private void FrmConfiguracionConsultas_Load(object sender, EventArgs e)
        {
            RecuperaConfiguracionActual();
        }

        private void cmdAceptar_Click(object sender, EventArgs e)
        {
            GuardarConfiguracion();
            this.Close();
        }

        #endregion

        #region Methods

        public FrmConfiguracionConsultas()
        {
            InitializeComponent();
        }

        private void RecuperaConfiguracionActual()
        {
            txtCompanias.Text = Properties.AppSettings.Default.Companias;
            txtClase.Text = Properties.AppSettings.Default.ClasesNomina;
            txtTipo.Text = Properties.AppSettings.Default.TiposNomina;
            txtEmpleados.Text = Properties.AppSettings.Default.Empleados;
            txtNomina.Text = Properties.AppSettings.Default.Nomina;

            txtMetodosPago.Text = Properties.AppSettings.Default.MetodosPago;

            txtHorasExtra.Text = Properties.AppSettings.Default.HorasExtra;
            txtIncapacidades.Text = Properties.AppSettings.Default.Incapacidades;
            txtOtrosPagos.Text = Properties.AppSettings.Default.OtrosPagos;

            txtAccionesTitulos.Text = Properties.AppSettings.Default.AccionesTitulos;
            txtJubilacionPensionRetiro.Text = Properties.AppSettings.Default.JubilacionPensionRetiro;
            txtSeparacionIndemnizacion.Text = Properties.AppSettings.Default.SeparacionIndemnizacion;
        }

        private void GuardarConfiguracion()
        {
            Properties.AppSettings.Default.Companias = txtCompanias.Text;
            Properties.AppSettings.Default.ClasesNomina = txtClase.Text;
            Properties.AppSettings.Default.TiposNomina = txtTipo.Text;
            Properties.AppSettings.Default.Empleados = txtEmpleados.Text;
            Properties.AppSettings.Default.Nomina = txtNomina.Text;

            Properties.AppSettings.Default.MetodosPago = txtMetodosPago.Text;

            Properties.AppSettings.Default.HorasExtra = txtHorasExtra.Text;
            Properties.AppSettings.Default.Incapacidades = txtIncapacidades.Text;
            Properties.AppSettings.Default.OtrosPagos = txtOtrosPagos.Text;

            Properties.AppSettings.Default.AccionesTitulos = txtAccionesTitulos.Text;
            Properties.AppSettings.Default.JubilacionPensionRetiro = txtJubilacionPensionRetiro.Text;
            Properties.AppSettings.Default.SeparacionIndemnizacion = txtSeparacionIndemnizacion.Text ;

            Properties.AppSettings.Default.Save();
        }

        #endregion
    }
}

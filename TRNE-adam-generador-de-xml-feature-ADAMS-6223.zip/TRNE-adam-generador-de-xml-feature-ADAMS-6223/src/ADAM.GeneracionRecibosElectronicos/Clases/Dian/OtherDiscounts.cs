﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("otrosDescuentos", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class OtherDiscounts
    {
        [JsonProperty("descripcion")]
        public string OtraDeduccionDescripcion { get; set; } = "";

        [JsonProperty("otraDeduccion")]
        public decimal OtraDeduccion { get; set; }
    }
}

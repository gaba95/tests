﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("cesantias", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Layoffs
    {
        [JsonProperty("pago")]
        public decimal Pago { get; set; }

        [JsonProperty("porcentaje")]
        public int PagoInteresesPorcentaje { get; set; }

        [JsonProperty("pagoIntereses")]
        public decimal PagoIntereses { get; set; }
    }
}

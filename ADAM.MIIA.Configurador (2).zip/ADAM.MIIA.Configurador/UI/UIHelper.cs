namespace ADAM.MIIA.Configurador.UI;

/// <summary>
/// Provides wrappers for UI interactions (MessageBox, ShowDialog) that can be suppressed during automated testing.
/// </summary>
public static class UIHelper
{
    /// <summary>
    /// When true, all MessageBox and ShowDialog calls are suppressed (returns default results).
    /// Set to true in unit test initialization to support CI automation.
    /// </summary>
    public static bool SuppressDialogs { get; set; } = false;

    public static DialogResult ShowMessage(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
    {
        if (SuppressDialogs)
        {
            if (buttons == MessageBoxButtons.YesNo)
                return DialogResult.Yes;
            return DialogResult.OK;
        }
        return MessageBox.Show(text, caption, buttons, icon);
    }

    public static DialogResult ShowFormDialog(Form form)
    {
        if (SuppressDialogs)
            return DialogResult.Cancel;
        return form.ShowDialog();
    }

    public static DialogResult ShowCommonDialog(CommonDialog dialog)
    {
        if (SuppressDialogs)
            return DialogResult.Cancel;
        return dialog.ShowDialog();
    }
}

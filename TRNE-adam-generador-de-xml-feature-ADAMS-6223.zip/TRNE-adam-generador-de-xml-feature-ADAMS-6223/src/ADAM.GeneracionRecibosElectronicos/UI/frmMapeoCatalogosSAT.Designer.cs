namespace ADAM.GeneracionRecibosElectronicos
{
    partial class FrmMapeoCatalogosSAT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMapeoCatalogosSAT));
            this.cmdCambiar = new System.Windows.Forms.Button();
            this.lblRegimen = new System.Windows.Forms.Label();
            this.gridDatosSAT = new System.Windows.Forms.DataGridView();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.lblCatalogoADAM = new System.Windows.Forms.Label();
            this.cboCompania = new System.Windows.Forms.ComboBox();
            this.lblCompania = new System.Windows.Forms.Label();
            this.gridDatosADAM = new System.Windows.Forms.DataGridView();
            this.lblDatosSAT = new System.Windows.Forms.Label();
            this.pnlRelleno = new System.Windows.Forms.Panel();
            this.lblCatalogo = new System.Windows.Forms.Label();
            this.cboCatalogos = new System.Windows.Forms.ComboBox();
            this.pnlHerramientas = new System.Windows.Forms.Panel();
            this.cmdQuitar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosSAT)).BeginInit();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.pnlPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosADAM)).BeginInit();
            this.pnlHerramientas.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdCambiar
            // 
            this.cmdCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCambiar.Location = new System.Drawing.Point(0, 100);
            this.cmdCambiar.Name = "cmdCambiar";
            this.cmdCambiar.Size = new System.Drawing.Size(110, 50);
            this.cmdCambiar.TabIndex = 5;
            this.cmdCambiar.Text = "&Asignar Valor";
            this.cmdCambiar.UseVisualStyleBackColor = true;
            this.cmdCambiar.Click += new System.EventHandler(this.cmdCambiar_Click);
            // 
            // lblRegimen
            // 
            this.lblRegimen.AutoSize = true;
            this.lblRegimen.Location = new System.Drawing.Point(0, -40);
            this.lblRegimen.Name = "lblRegimen";
            this.lblRegimen.Size = new System.Drawing.Size(143, 18);
            this.lblRegimen.TabIndex = 0;
            this.lblRegimen.Text = "Regimen de Contatación";
            // 
            // gridDatosSAT
            // 
            this.gridDatosSAT.AllowUserToAddRows = false;
            this.gridDatosSAT.AllowUserToDeleteRows = false;
            this.gridDatosSAT.AllowUserToResizeRows = false;
            this.gridDatosSAT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosSAT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosSAT.Dock = System.Windows.Forms.DockStyle.Left;
            this.gridDatosSAT.Location = new System.Drawing.Point(10, 100);
            this.gridDatosSAT.Name = "gridDatosSAT";
            this.gridDatosSAT.RowHeadersVisible = false;
            this.gridDatosSAT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosSAT.Size = new System.Drawing.Size(400, 219);
            this.gridDatosSAT.TabIndex = 3;
            this.gridDatosSAT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridValores_CellDoubleClick);
            this.gridDatosSAT.SelectionChanged += new System.EventHandler(this.gridDatosSAT_SelectionChanged);
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCerrar.Location = new System.Drawing.Point(0, 269);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(110, 50);
            this.cmdCerrar.TabIndex = 7;
            this.cmdCerrar.Text = "&Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(707, 50);
            this.pnlLogo.TabIndex = 15;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(354, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Mapeo de Catálogos ADAM - SAT";
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Controls.Add(this.lblCatalogoADAM);
            this.pnlPrincipal.Controls.Add(this.cboCompania);
            this.pnlPrincipal.Controls.Add(this.lblCompania);
            this.pnlPrincipal.Controls.Add(this.gridDatosADAM);
            this.pnlPrincipal.Controls.Add(this.lblDatosSAT);
            this.pnlPrincipal.Controls.Add(this.pnlRelleno);
            this.pnlPrincipal.Controls.Add(this.lblCatalogo);
            this.pnlPrincipal.Controls.Add(this.cboCatalogos);
            this.pnlPrincipal.Controls.Add(this.gridDatosSAT);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 50);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Padding = new System.Windows.Forms.Padding(10, 100, 10, 10);
            this.pnlPrincipal.Size = new System.Drawing.Size(587, 329);
            this.pnlPrincipal.TabIndex = 16;
            // 
            // lblCatalogoADAM
            // 
            this.lblCatalogoADAM.AutoSize = true;
            this.lblCatalogoADAM.Location = new System.Drawing.Point(419, 77);
            this.lblCatalogoADAM.Name = "lblCatalogoADAM";
            this.lblCatalogoADAM.Size = new System.Drawing.Size(109, 18);
            this.lblCatalogoADAM.TabIndex = 10;
            this.lblCatalogoADAM.Text = "Equivalencia ADAM";
            // 
            // cboCompania
            // 
            this.cboCompania.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompania.FormattingEnabled = true;
            this.cboCompania.Location = new System.Drawing.Point(160, 6);
            this.cboCompania.Name = "cboCompania";
            this.cboCompania.Size = new System.Drawing.Size(300, 26);
            this.cboCompania.TabIndex = 1;
            this.cboCompania.SelectedIndexChanged += new System.EventHandler(this.cboCompania_SelectedIndexChanged);
            // 
            // lblCompania
            // 
            this.lblCompania.AutoSize = true;
            this.lblCompania.Location = new System.Drawing.Point(13, 9);
            this.lblCompania.Name = "lblCompania";
            this.lblCompania.Size = new System.Drawing.Size(64, 18);
            this.lblCompania.TabIndex = 11;
            this.lblCompania.Text = "Compañia:";
            // 
            // gridDatosADAM
            // 
            this.gridDatosADAM.AllowUserToAddRows = false;
            this.gridDatosADAM.AllowUserToDeleteRows = false;
            this.gridDatosADAM.AllowUserToResizeRows = false;
            this.gridDatosADAM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridDatosADAM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosADAM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDatosADAM.Location = new System.Drawing.Point(420, 100);
            this.gridDatosADAM.Name = "gridDatosADAM";
            this.gridDatosADAM.ReadOnly = true;
            this.gridDatosADAM.RowHeadersVisible = false;
            this.gridDatosADAM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosADAM.Size = new System.Drawing.Size(157, 219);
            this.gridDatosADAM.TabIndex = 4;
            // 
            // lblDatosSAT
            // 
            this.lblDatosSAT.AutoSize = true;
            this.lblDatosSAT.Location = new System.Drawing.Point(10, 76);
            this.lblDatosSAT.Name = "lblDatosSAT";
            this.lblDatosSAT.Size = new System.Drawing.Size(78, 18);
            this.lblDatosSAT.TabIndex = 9;
            this.lblDatosSAT.Text = "Catálogo SAT";
            // 
            // pnlRelleno
            // 
            this.pnlRelleno.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlRelleno.Location = new System.Drawing.Point(410, 100);
            this.pnlRelleno.Name = "pnlRelleno";
            this.pnlRelleno.Size = new System.Drawing.Size(10, 219);
            this.pnlRelleno.TabIndex = 8;
            // 
            // lblCatalogo
            // 
            this.lblCatalogo.AutoSize = true;
            this.lblCatalogo.Location = new System.Drawing.Point(13, 41);
            this.lblCatalogo.Name = "lblCatalogo";
            this.lblCatalogo.Size = new System.Drawing.Size(63, 18);
            this.lblCatalogo.TabIndex = 6;
            this.lblCatalogo.Text = "Catálogo: ";
            // 
            // cboCatalogos
            // 
            this.cboCatalogos.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboCatalogos.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboCatalogos.DropDownWidth = 350;
            this.cboCatalogos.FormattingEnabled = true;
            this.cboCatalogos.Location = new System.Drawing.Point(160, 38);
            this.cboCatalogos.Name = "cboCatalogos";
            this.cboCatalogos.Size = new System.Drawing.Size(250, 26);
            this.cboCatalogos.TabIndex = 2;
            this.cboCatalogos.SelectedIndexChanged += new System.EventHandler(this.cboCatalogos_SelectedIndexChanged);
            // 
            // pnlHerramientas
            // 
            this.pnlHerramientas.Controls.Add(this.cmdQuitar);
            this.pnlHerramientas.Controls.Add(this.cmdCerrar);
            this.pnlHerramientas.Controls.Add(this.cmdCambiar);
            this.pnlHerramientas.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlHerramientas.Location = new System.Drawing.Point(587, 50);
            this.pnlHerramientas.Name = "pnlHerramientas";
            this.pnlHerramientas.Padding = new System.Windows.Forms.Padding(0, 50, 0, 0);
            this.pnlHerramientas.Size = new System.Drawing.Size(120, 329);
            this.pnlHerramientas.TabIndex = 17;
            // 
            // cmdQuitar
            // 
            this.cmdQuitar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdQuitar.Location = new System.Drawing.Point(0, 156);
            this.cmdQuitar.Name = "cmdQuitar";
            this.cmdQuitar.Size = new System.Drawing.Size(110, 50);
            this.cmdQuitar.TabIndex = 6;
            this.cmdQuitar.Text = "&Quitar Relación";
            this.cmdQuitar.UseVisualStyleBackColor = true;
            this.cmdQuitar.Click += new System.EventHandler(this.cmdQuitar_Click);
            // 
            // FrmMapeoCatalogosSAT
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cmdCerrar;
            this.ClientSize = new System.Drawing.Size(707, 379);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlHerramientas);
            this.Controls.Add(this.lblRegimen);
            this.Controls.Add(this.pnlLogo);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FrmMapeoCatalogosSAT";
            this.ShowInTaskbar = false;
            this.Text = "Mapeo de Catálogos ADAM - SAT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMapeoCatalogosSAT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosSAT)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosADAM)).EndInit();
            this.pnlHerramientas.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCambiar;
        private System.Windows.Forms.Label lblRegimen;
        private System.Windows.Forms.DataGridView gridDatosSAT;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Panel pnlHerramientas;
        private System.Windows.Forms.Button cmdQuitar;
        private System.Windows.Forms.ComboBox cboCatalogos;
        private System.Windows.Forms.Label lblCatalogo;
        private System.Windows.Forms.Panel pnlRelleno;
        private System.Windows.Forms.DataGridView gridDatosADAM;
        private System.Windows.Forms.Label lblDatosSAT;
        private System.Windows.Forms.Label lblCatalogoADAM;
        private System.Windows.Forms.Label lblCompania;
        private System.Windows.Forms.ComboBox cboCompania;
    }
}
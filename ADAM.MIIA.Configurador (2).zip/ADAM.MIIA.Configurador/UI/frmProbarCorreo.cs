using System.Text.RegularExpressions;

namespace ADAM.MIIA.Configurador.UI;

public partial class FrmProbarCorreo : Form
{
    public string CorreoElectronico { get; set; } = "";

    public FrmProbarCorreo()
    {
        InitializeComponent();
    }

    private void cmdAceptar_Click(object? sender, EventArgs e)
    {
        if (ValidarCorreo(txtCorreoElectronico.Text))
        {
            CorreoElectronico = txtCorreoElectronico.Text;
            DialogResult = DialogResult.OK;
        }
        else
        {
            DialogResult = DialogResult.None;
        }
    }

    private void cmdCancelar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
    }

    private static bool ValidarCorreo(string correo)
    {
        string patronCorreo = @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

        if (Regex.IsMatch(correo, patronCorreo, RegexOptions.IgnoreCase, TimeSpan.FromSeconds(1)))
        {
            return true;
        }
        else
        {
            UIHelper.ShowMessage("No es un correo valido", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }
}

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using Formatting = Newtonsoft.Json.Formatting;
using ADAM.GeneracionRecibosElectronicos.Clases;
using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using ADAM.GeneracionRecibosElectronicos.Clases.Filter;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.CatalogoDIAN;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;

namespace ADAM.GeneracionRecibosElectronicos.UI
{
    [ExcludeFromCodeCoverage]
    public partial class FrmEstadoDocumentoDIAN : Form
    {
        private DataTable _trabajadores;
        private DgQuery queryTrabajadores;
        private ICatalogoDian _catalogosDIAN;
        private ICatalogoAdicional _catalogoAdicional;
        private DateTime dateTimeTokenIsValid;
        private string szAccessToken;
        private string szResponseMsg;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string szCompany { get; set; }

        public FrmEstadoDocumentoDIAN(DataTable trabajadores)
        {
            InitializeComponent();
            // Set trabajadores DataTable
            _trabajadores = trabajadores;
            // Set Business Rules 
            _catalogosDIAN = CatalogoDianHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
        }

        #region Events

        #region Form_Events
        /// <summary>
        /// Load Form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmEstadoDocumentoDIAN_Load(object sender, EventArgs e)
        {
            //set datasource for DataGridView Trabajadores
            dgTrabajadores.DataSource = _trabajadores;
            //Format Columns
            dgTrabajadores.Columns["SalarioMensual"].DefaultCellStyle.Format = "0.00##";
            dgTrabajadores.Columns["TotalDeducciones"].DefaultCellStyle.Format = "0.00##";
            dgTrabajadores.Columns["TotalPercepciones"].DefaultCellStyle.Format = "0.00##";
            dgTrabajadores.Refresh();
        }
        #endregion

        #region dgTrabajadores_ColumnAdded
        /// <summary>
        /// Fires when a column is added
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTrabajadores_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            //Disabled Default Sort Function of the Grid, in Order to be manage from fromfiltersort
            e.Column.SortMode = DataGridViewColumnSortMode.Programmatic;
            //convert first character to upper and replace _ with space
            string principalHeaderText = (e.Column.HeaderText[0].ToString().ToUpper() + e.Column.HeaderText.Substring(1)).Replace("_", " ");
            //set a space after an every upper character
            principalHeaderText = String.Concat(principalHeaderText.Select(x => Char.IsUpper(x) ? " " + x : x.ToString())).TrimStart(' ');
            string newHeaderText = "";
            for (int i = 0; i <= principalHeaderText.Length - 1; i++)
            {
                if (Char.IsUpper(principalHeaderText[i]))
                {
                    if (i > 1 && Char.IsUpper(principalHeaderText[i - 2]))
                    {
                        //if the column header text is an acronym don't need a space after every upper character
                        newHeaderText = newHeaderText.TrimEnd() + principalHeaderText[i];
                    }
                    else
                    {
                        //if after a space exist a lower character convert to upper
                        if (i > 0 && principalHeaderText[i - 1] == ' ')
                        {
                            newHeaderText += principalHeaderText[i].ToString().ToUpper();
                        }
                        else
                        {
                            newHeaderText += principalHeaderText[i];
                        }
                    }
                }
                else
                {
                    //if after a space exist a lower character convert to upper
                    if (i > 0 && principalHeaderText[i - 1] == ' ')
                    {
                        newHeaderText += principalHeaderText[i].ToString().ToUpper();
                    }
                    else
                    {
                        newHeaderText += principalHeaderText[i];
                    }
                }
            }
            e.Column.HeaderText = newHeaderText;
        }
        #endregion

        #region dgTrabajadores_CellPainting
        /// <summary>
        /// Fires when a cell is painting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTrabajadores_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //if cell painting is header (rowindex -1) put the icon at the end of the cell
            if (e.RowIndex == -1 && e.ColumnIndex > -1)
            {
                Rectangle r = new Rectangle(e.CellBounds.X + e.CellBounds.Width - 15, e.CellBounds.Y + (e.CellBounds.Height / 2) - 5, 10, 10);
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                e.Graphics.DrawImage(Properties.Resources.down_arrow, r);
                e.Handled = true;
            }
        }
        #endregion

        #region dgTrabajadores_ColumnHeaderMouseClick
        /// <summary>
        /// Fires when user click in column header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTrabajadores_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex > -1)
            {
                //get the unique values of the column
                var uniqueValues = (from DataRow r in ((DataTable)dgTrabajadores.DataSource).Rows
                                    select r[e.ColumnIndex]).Distinct();
                //get the column that fires the event
                var pColumn = dgTrabajadores.Columns[e.ColumnIndex];
                FrmFilterSortDialog filtersort = new FrmFilterSortDialog(queryTrabajadores, pColumn, pColumn.ValueType, uniqueValues);
                //get the rectangle in screen for the cell that fires the event
                var colCoordinates = dgTrabajadores.GetCellDisplayRectangle(pColumn.Index, 0, true);
                //set location of the frmfiltersordialog based on the cell that fires the event
                if (pColumn.Width > filtersort.Width)
                {
                    filtersort.Width = pColumn.Width;
                    filtersort.Location = new Point(colCoordinates.X + pColumn.Width - filtersort.Width, pnlTrabajadores.Location.Y + dgTrabajadores.Location.Y + dgTrabajadores.ColumnHeadersHeight + colCoordinates.Height);
                }
                else
                {
                    filtersort.Location = new Point(colCoordinates.X, pnlTrabajadores.Location.Y + dgTrabajadores.Location.Y + dgTrabajadores.ColumnHeadersHeight + colCoordinates.Height);
                }
                filtersort.ShowDialog();
                Applyfilter(pColumn, filtersort.Query, filtersort.isSorted, filtersort.Sort);
            }
        }
        #endregion

        #region dgTrabajadores_RowPrePaint
        /// <summary>
        /// fires before Row Painting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTrabajadores_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (dgTrabajadores.Columns.Contains("TotalDeducciones") && dgTrabajadores.Columns.Contains("TotalPercepciones") && Convert.ToDecimal(dgTrabajadores.Rows[e.RowIndex].Cells["TotalDeducciones"].Value) == 0 && Convert.ToDecimal(dgTrabajadores.Rows[e.RowIndex].Cells["TotalPercepciones"].Value) == 0)
            {
                dgTrabajadores.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Beige;
                dgTrabajadores.Rows[e.RowIndex].Cells["TotalDeducciones"].Style.ForeColor = Color.Red;
                dgTrabajadores.Rows[e.RowIndex].Cells["TotalPercepciones"].Style.ForeColor = Color.Red;
            }
        }
        #endregion

        #region dgTrabajadores_SelectionChanged
        /// <summary>
        /// fires when row selection change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTrabajadores_SelectionChanged(object sender, EventArgs e)
        {
            if (dgTrabajadores.Rows.Count > 0 && dgTrabajadores.SelectedRows.Count > 0)
            {
                DataGridViewRow r = dgTrabajadores.SelectedRows[0];
                //get documents Dataset from tb_bitacora_correlativos_dian
                DataSet documentos = _catalogosDIAN.obtenDatasetBitacoraCorrelativosDianEmpleado(r.Cells["compania"].Value.ToString(), r.Cells["trabajador"].Value.ToString());
                //set datasource for Datagridview dgDocumentos
                dgDocumentos.DataSource = documentos;
            }
        }
        #endregion

        #region dgDocumentos_Events
        /// <summary>
        /// fires when row selection change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgDocumentos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgDocumentos.Rows.Count > 0 && dgDocumentos.SelectedRows.Count > 0)
            {
                // Local Vars
                bool auth = false;
                // Get Time for Authentication Token
                int minutes = DateTime.Compare(DateTime.UtcNow, dateTimeTokenIsValid);
                try
                {
                    // Validate if Token is Alive
                    if (minutes > 0)
                    {
                        // Get Authentication Token From CENET API
                        auth = GetAuthenticationToken(szCompany);
                    }
                    else
                    {
                        auth = true;
                    }
                    // Check Authentication
                    if (auth)
                    {
                        DataGridViewRow r = dgDocumentos.SelectedRows[0];

                        // Get Document State
                        DocumentStateResponse jsonDocumentResp;
                        bool transmit = GetDocumentState(szCompany, r.Cells["documento_id"].Value.ToString(), Convert.ToDateTime(r.Cells["fecha_envio"].Value), out jsonDocumentResp);
                        // Check Results
                        if (transmit)
                        {
                            // fill treeview
                            ShowObjectOnTreeView(jsonDocumentResp);
                        }
                        else
                        {
                            //show error message in treeview
                            ShowObjectOnTreeView(new
                            {
                                Mensaje = "Error de transmisión - CENET" + Environment.NewLine +
                                          "Error CENET: " + szResponseMsg
                            });
                        }
                    }
                    else
                    {
                        //show error message in treeview
                        ShowObjectOnTreeView(new
                        {
                            Mensaje = "Error de autenticación - CENET" + Environment.NewLine +
                                      "Error CENET: " + szResponseMsg
                        });
                    }
                }
                catch (Exception ex)
                {
                    //show error message in treeview
                    ShowObjectOnTreeView(new
                    {
                        Mensaje = "Error" + Environment.NewLine +
                                             ex.Message
                    });
                }
            }
        }
        #endregion

        #endregion

        #region Methods

        #region GetAuthenticationToken
        
        private bool GetAuthenticationToken(string szCompany)
        {
            try
            {
                // Create API Call
                RestApiClient rClient = new RestApiClient();
                LoginResponse loginResponse = new LoginResponse();
                if (szCompany == string.Empty)
                {
                    szAccessToken = "";
                    szResponseMsg = "URL, usuario y/o contraseña no validos.";
                    return false;
                }
                DataSet configuration = _catalogoAdicional.obtenConfiguracionCompania(szCompany);
                if (configuration is null || configuration.Tables.Count == 0 || configuration.Tables[0].Rows.Count == 0)
                {
                    szAccessToken = "";
                    szResponseMsg = "URL, usuario y/o contraseña no validos.";
                    return false;
                }

                //function to get value of parameters
                Func<string, string> getParameterStringValue = (string id_parametro) =>
                {
                    var parametro = configuration.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                    if (parametro != null && parametro.Length > 0)
                    {
                        return parametro[0]?.Field<string>("alfanumerico");
                    }
                    return string.Empty;
                };

                // Set API Parameters
                rClient.endPoint = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                rClient.userName = getParameterStringValue(ConfigurationTypes.ws_user.ToString());
                rClient.userPwd = new NetworkCredential(string.Empty, getParameterStringValue(ConfigurationTypes.ws_password.ToString())).SecurePassword;

                loginResponse = rClient.LoginRequest();
                // Get Response
                if (loginResponse != null)
                {
                    if (loginResponse.type.Equals("OK"))
                    {
                        dateTimeTokenIsValid = DateTime.UtcNow.AddMinutes(55);
                        szAccessToken = loginResponse.content.jwt;
                        return true;
                    }
                    else
                    {
                        szAccessToken = "";
                        szResponseMsg = loginResponse.validationMessage;
                        return false;
                    }
                }
                else
                {
                    szAccessToken = "";
                    szResponseMsg = "URL, usuario y/o contraseña no validos.";
                    return false;
                }
            }
            catch (Exception ex)
            {
                szAccessToken = "";
                szResponseMsg = "Exception: " + ex.Message;
                return false;
            }
        }
        #endregion 

        #region GetDocumentState
        /// <summary>
        /// Get Document State
        /// </summary>
        /// <param name="companyId">Company Id</param>
        /// <param name="documentoId">Document Id</param>
        /// <param name="fechaDocumento">Document Data</param>
        /// <param name="documentStateResponse">State Response</param>
        /// <returns></returns>
        private bool GetDocumentState(string companyId, string documentoId, DateTime fechaDocumento, out DocumentStateResponse documentStateResponse)
        {
            // Create API Call
            RestApiClient rClient = new RestApiClient();
            documentStateResponse = new DocumentStateResponse();

            // Get Config
            DataSet dConfig = _catalogoAdicional.obtenConfiguracionCompania(companyId);
            if (dConfig != null && dConfig.Tables[0].Rows.Count > 0)
            {
                Func<string, string> getParameterStringValue = (string id_parametro) =>
                {
                    var parametro = dConfig.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                    if (parametro != null && parametro.Length > 0)
                    {
                        return parametro[0]?.Field<string>("alfanumerico");
                    }
                    return string.Empty;
                };

                rClient.endPoint = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                rClient.userName = getParameterStringValue(ConfigurationTypes.ws_user.ToString());
                rClient.userPwd = new NetworkCredential(string.Empty, getParameterStringValue(ConfigurationTypes.ws_password.ToString())).SecurePassword;
            }
            else
            {
                rClient.endPoint = UtileriasConfig.GetEndpointAddress();
                rClient.userName = Properties.AppSettings.Default.WSUsrID;
                rClient.userPwd = new NetworkCredential(string.Empty, Properties.AppSettings.Default.WSUsrPwd).SecurePassword;
            }

            // Call CENET WS
            documentStateResponse = rClient.getDocumentState(szAccessToken, rClient.userName, documentoId, fechaDocumento);

            // Get Response
            if (documentStateResponse != null)
            {
                // Default
                return true;
            }
            else
            {
                szResponseMsg = "No se obtuvo respuesta de CENET";
                return false;
            }
        }
        #endregion

        #region Applyfilter
        /// <summary>
        /// Apply filter on dgTrabajadores based on user entries
        /// </summary>
        /// <param name="pColumn"></param>
        /// <param name="pQuery"></param>
        /// <param name="pIsSorted"></param>
        /// <param name="plistSortDirection"></param>
        private void Applyfilter(DataGridViewColumn pColumn, DgQuery pQuery, bool pIsSorted = false, System.ComponentModel.ListSortDirection plistSortDirection = System.ComponentModel.ListSortDirection.Descending)
        {
            queryTrabajadores = pQuery;
            //check if sorted is needed
            if (plistSortDirection == System.ComponentModel.ListSortDirection.Ascending && pIsSorted)
            {
                dgTrabajadores.Sort(dgTrabajadores.Columns[pColumn.Index], System.ComponentModel.ListSortDirection.Ascending);
            }
            if (plistSortDirection == System.ComponentModel.ListSortDirection.Descending && pIsSorted)
            {
                dgTrabajadores.Sort(dgTrabajadores.Columns[pColumn.Index], System.ComponentModel.ListSortDirection.Descending);
            }
            //if a query is set for the column the column change forecolor to red if not default black
            if (queryTrabajadores.FilterEnumerable.Any(t => t.ColumnIndex == pColumn.Index))
            {
                dgTrabajadores.EnableHeadersVisualStyles = false;
                dgTrabajadores.Columns[pColumn.Index].HeaderCell.Style.ForeColor = Color.Blue;
            }
            else
            {
                dgTrabajadores.EnableHeadersVisualStyles = false;
                dgTrabajadores.Columns[pColumn.Index].HeaderCell.Style.ForeColor = Color.Black;
            }
            //get the query result to apply on the grid
            var myquery = queryTrabajadores.GetQuery();
            ((DataTable)dgTrabajadores.DataSource).DefaultView.RowFilter = myquery;
        }
        #endregion

        #region DisplayTreeView
        /// <summary>
        /// creates the content of the treeview
        /// </summary>
        /// <param name="root"></param>
        /// <param name="rootName"></param>
        private void DisplayTreeView(JToken root, string rootName)
        {
            trvDocumento.BeginUpdate();
            try
            {
                trvDocumento.Nodes.Clear();
                var tNode = trvDocumento.Nodes[trvDocumento.Nodes.Add(new TreeNode(rootName))];
                tNode.Tag = root;
                AddNode(root, tNode);
                trvDocumento.CollapseAll();
                //expand first node
                if (trvDocumento.Nodes.Count > 0)
                    trvDocumento.Nodes[0].Expand();
            }
            finally
            {
                trvDocumento.EndUpdate();
            }
            trvDocumento.Refresh();
        }
        #endregion

        #region AddNode
        /// <summary>
        /// Add a new node on treeview
        /// </summary>
        /// <param name="token"></param>
        /// <param name="inTreeNode"></param>
        private void AddNode(JToken token, TreeNode inTreeNode)
        {
            if (token == null)
                return;
            if (token is JValue)
            {
                var childNode = inTreeNode.Nodes[inTreeNode.Nodes.Add(new TreeNode(token.ToString()))];
                childNode.Tag = token;
            }
            else if (token is JObject)
            {
                var obj = (JObject)token;
                foreach (var property in obj.Properties())
                {
                    var childNode = inTreeNode.Nodes[inTreeNode.Nodes.Add(new TreeNode(property.Name))];
                    childNode.Tag = property;
                    AddNode(property.Value, childNode);
                }
            }
            else if (token is JArray)
            {
                var array = (JArray)token;
                for (int i = 0; i < array.Count; i++)
                {
                    var childNode = inTreeNode.Nodes[inTreeNode.Nodes.Add(new TreeNode(i.ToString()))];
                    childNode.Tag = array[i];
                    AddNode(array[i], childNode);
                }
            }
        }
        #endregion

        #region ShowObjectOnTreeView
        /// <summary>
        /// shows any object on the treeview
        /// </summary>
        /// <param name="pObject"></param>
        /// <param name="pTitle"></param>
        private void ShowObjectOnTreeView(Object pObject, string pTitle = "Json")
        {
            using (var reader = new StringReader(JsonConvert.SerializeObject(pObject, Formatting.Indented)))
            {
                using (var JsonReader = new JsonTextReader(reader))
                {
                    var root = JToken.Load(JsonReader);
                    DisplayTreeView(root, pTitle);
                }
            }
        }
        #endregion

        #endregion
    }
}

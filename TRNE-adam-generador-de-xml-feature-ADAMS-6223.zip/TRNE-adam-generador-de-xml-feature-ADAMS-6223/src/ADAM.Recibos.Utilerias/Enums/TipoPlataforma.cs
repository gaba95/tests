﻿namespace ADAM.Recibos.Utilerias.Enums
{
    public enum TipoPlataforma
    {
        SQLServer = 1,
        ORACLE = 2,
        ODBC = 3
    }
}

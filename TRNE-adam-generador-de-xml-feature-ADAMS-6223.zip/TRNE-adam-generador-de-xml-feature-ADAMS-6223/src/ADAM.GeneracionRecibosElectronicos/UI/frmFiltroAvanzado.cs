using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics.CodeAnalysis;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmFiltroAvanzado : Form
    {

        #region variables de la clase

        #endregion

        #region propiedades de la clase

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataSet dsOriginal { get; set; } = new DataSet();

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataSet dsSeleccionados { get; set; } = new DataSet();
        
        #endregion

        #region eventos de la clase

        private void FrmFiltroAvanzado_Load(object sender, EventArgs e)
        {
            InicializaClase();
        }
        
        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            ((DataTable)gridDisponibles.DataSource).DefaultView.RowFilter = " trabajador LIKE '%" + txtFiltro.Text + "%'";
            ActualizaContadores();
        }
        
        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            foreach (DataGridViewRow renglon in gridDisponibles.SelectedRows)
            {
                //Se suspende el enlace de datos para permitir ocultar renglones
                CurrencyManager currencyManager1 = (CurrencyManager)BindingContext[gridDisponibles.DataSource];
                currencyManager1.SuspendBinding();

                DataGridViewRow newRow = (DataGridViewRow)renglon.Clone();
                for (Int32 index = 0; index < renglon.Cells.Count; index++)
                {
                    newRow.Cells[index].Value = renglon.Cells[index].Value;
                }
                gridSeleccionados.Rows.Add(newRow);
                renglon.Visible = false;

                //una vez que se agrego a la lista de seleccionados de habilita el enlace de datos
                currencyManager1.ResumeBinding();
            }
            gridSeleccionados.Sort(gridSeleccionados.Columns["trabajador"], System.ComponentModel.ListSortDirection.Ascending);

            ActualizaContadores();
            this.Cursor = Cursors.Default;

        }

        private void cmdQuitar_Click(object sender, EventArgs e)
        {

            if (gridSeleccionados.Rows.Count == 0)
                return;

            this.Cursor = Cursors.WaitCursor;
            foreach (DataGridViewRow renglon in gridSeleccionados.SelectedRows)
            {
                MostrarRenglon(renglon.Cells["trabajador"].Value.ToString());
                gridSeleccionados.Rows.Remove(renglon);
            }

            ActualizaContadores();
            this.Cursor = Cursors.Default;

        }

        private void cmdAceptar_Click(object sender, EventArgs e)
        {
            ActualizaDsSeleccion();
            ((DataTable)gridDisponibles.DataSource).DefaultView.RowFilter = "";
            this.Close();
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            //Antes de camcelar quitar el filtro actual
            ((DataTable)gridDisponibles.DataSource).DefaultView.RowFilter = "";
            this.Close();
        }

        #endregion

        #region metodos de la clase

        /// <summary>
        /// Constructor.
        /// </summary>
        public FrmFiltroAvanzado()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialize class.
        /// </summary>
        private void InicializaClase()
        {
            gridDisponibles.DataSource = dsOriginal.Tables[0];

            //Carga la estructura de la tabla en el grid NO ligado a datos
            foreach (DataGridViewColumn columna in gridDisponibles.Columns )
            {
                gridSeleccionados.Columns.Add((DataGridViewColumn)columna.Clone());
            }

            //Si hay datos seleccionados previamente, se cargan
            if (dsSeleccionados != null && dsSeleccionados.Tables.Count >0)
                CargaSeleccionActual();

        }

        /// <summary>
        /// Show row by employee.
        /// </summary>
        /// <param name="trabajador"></param>
        private void MostrarRenglon(string trabajador)
        {
            //Navigate colection rows, availables to return visibles.
            foreach (DataGridViewRow renglon in gridDisponibles.Rows)
            {
                if (!renglon.Visible && renglon.Cells["trabajador"].Value.ToString() == trabajador )
                {
                    renglon.Visible = true;
                }
            }
        }

        /// <summary>
        /// Update data selected.
        /// </summary>
        private void ActualizaDsSeleccion()
        {
            if (dsSeleccionados == null)
                dsSeleccionados = new DataSet();

            dsSeleccionados.Tables.Clear();
            dsSeleccionados.Tables.Add(dsOriginal.Tables[0].Clone());

            foreach (DataGridViewRow renglon in gridSeleccionados.Rows)
            {
                DataRow renglonTabla =  dsSeleccionados.Tables[0].Rows.Add();
                foreach (DataColumn columna in dsSeleccionados.Tables[0].Columns)
                {
                    renglonTabla[columna.ColumnName] = renglon.Cells[columna.ColumnName].Value;
                }
            }
        }

        /// <summary>
        /// Load current selection by employees selected.
        /// </summary>
        private void CargaSeleccionActual()
        {
            foreach (DataRow registro in dsSeleccionados.Tables[0].Rows)
            {
                int index =gridSeleccionados.Rows.Add();
                foreach (DataColumn columna in dsSeleccionados.Tables[0].Columns)
                {
                    gridSeleccionados.Rows[index].Cells[columna.ColumnName].Value = registro[columna.ColumnName];
                }

                //Ocultar los seleccionados del grid Disponibles
                foreach (DataGridViewRow renglon in gridDisponibles.Rows)
                {

                    if (renglon.Cells["trabajador"].Value.ToString() == gridSeleccionados.Rows[index].Cells["trabajador"].Value.ToString())
                    {
                        //Se suspende el enlace de datos para permitir ocultar renglones
                        CurrencyManager currencyManager1 = (CurrencyManager)BindingContext[gridDisponibles.DataSource];
                        currencyManager1.SuspendBinding();

                        renglon.Visible = false;

                        //una vez que se agrego a la lista de seleccionados de habilita el enlace de datos
                        currencyManager1.ResumeBinding();
                    }
                }

            }



        }

        /// <summary>
        /// Update counters.
        /// </summary>
        private void ActualizaContadores()
        {
            int visibles = 0;

            foreach (DataGridViewRow renglon in gridDisponibles.Rows)
            {
                if (renglon.Visible)
                    visibles++;
            }

            lblDisponible.Text = "Disponibles (" + visibles.ToString() + ")";
            lblSeleccionados.Text = "Seleccionados (" + gridSeleccionados.RowCount.ToString() + ")";

        }

        #endregion
    }
}

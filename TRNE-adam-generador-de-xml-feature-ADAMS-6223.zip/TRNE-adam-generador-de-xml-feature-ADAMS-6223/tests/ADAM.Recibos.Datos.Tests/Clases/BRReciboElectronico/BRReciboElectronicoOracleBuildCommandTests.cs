using Moq;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.Recibos.DatosTests
{
    [TestClass]
    public class BRReciboElectronicoOracleBuildCommandTests
    {
        #region Helpers

        private static BRReciboElectronicoOracle CreateService()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            return new BRReciboElectronicoOracle(mockFactory.Object);
        }

        private static Nomina CreateNomina(
            ManejoNomina manejoNomina = ManejoNomina.periodica,
            string conceptoFactura = "1000")
        {
            return new Nomina("0001", "  90901010", "01", "01", 2026, 1,
                manejoNomina, 0, conceptoFactura, "EFEC");
        }

        private static void AssertStandardParams(OracleCommand cmd, Nomina nomina)
        {
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
            Assert.AreEqual(nomina.Compania, cmd.Parameters["i_compania"].Value);
            Assert.AreEqual(nomina.Trabajador, cmd.Parameters["i_trabajador"].Value);
            Assert.AreEqual(nomina.TipoNomina, cmd.Parameters["i_tipo_nomina"].Value);
            Assert.AreEqual(nomina.Anio, cmd.Parameters["i_anio"].Value);
            Assert.AreEqual(nomina.Periodo, cmd.Parameters["i_periodo"].Value);
            Assert.AreEqual(nomina.NumeroLiquidacion, cmd.Parameters["i_numero_liquidacion"].Value);
            Assert.AreEqual(nomina.ManejoNomina, cmd.Parameters["i_manejo_nomina"].Value);
        }

        private static void AssertHasReturnValueParam(OracleCommand cmd)
        {
            var p = cmd.Parameters["i_return_value"];
            Assert.IsNotNull(p, "Missing i_return_value parameter");
            Assert.AreEqual(OracleDbType.RefCursor, p.OracleDbType);
            Assert.AreEqual(ParameterDirection.Output, p.Direction);
        }

        #endregion

        #region BuildAdicionalesCommand

        [TestMethod]
        public void BuildAdicionalesCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAdicionalesCommand(nomina);

            Assert.AreEqual("sp_horas_extra_sat", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildAdicionalesCommand_ShouldHave9Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAdicionalesCommand(nomina);

            Assert.AreEqual(9, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildAdicionalesCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAdicionalesCommand(nomina);

            AssertStandardParams(cmd, nomina);
            Assert.AreEqual(nomina.ClaseNomina, cmd.Parameters["i_clase_nomina"].Value);
            AssertHasReturnValueParam(cmd);
        }

        [TestMethod]
        public void BuildAdicionalesCommand_ShouldNotHaveConnection()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAdicionalesCommand(nomina);

            Assert.IsNull(cmd.Connection);
        }

        [TestMethod]
        public void BuildAdicionalesCommand_Interactiva_ShouldSetSameParams()
        {
            var service = CreateService();
            var nomina = CreateNomina(ManejoNomina.interactiva);

            var cmd = service.BuildAdicionalesCommand(nomina);

            Assert.AreEqual(9, cmd.Parameters.Count);
            Assert.AreEqual(nomina.ManejoNomina, cmd.Parameters["i_manejo_nomina"].Value);
        }

        #endregion

        #region BuildPrincipalCommand

        [TestMethod]
        public void BuildPrincipalCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.AreEqual("sp_nomina_sat", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildPrincipalCommand_Periodica_ShouldHave12Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina(ManejoNomina.periodica);

            var cmd = service.BuildPrincipalCommand(nomina);

            // 8 standard + i_metodo_pago + i_pago_separacion (else branch) + i_return_value = 11
            Assert.AreEqual(11, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildPrincipalCommand_Periodica_ShouldSetPagoSeparacionToZero()
        {
            var service = CreateService();
            var nomina = CreateNomina(ManejoNomina.periodica);

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.AreEqual((short)0, (short)(int)cmd.Parameters["i_pago_separacion"].Value);
        }

        [TestMethod]
        public void BuildPrincipalCommand_Interactiva_ShouldParsePagoSeparacion()
        {
            var service = CreateService();
            var nomina = CreateNomina(ManejoNomina.interactiva, "42");

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.AreEqual(42, (int)cmd.Parameters["i_pago_separacion"].Value);
        }

        [TestMethod]
        public void BuildPrincipalCommand_Interactiva_InvalidConceptoFactura_ShouldDefaultToZero()
        {
            var service = CreateService();
            var nomina = CreateNomina(ManejoNomina.interactiva, "NOT_A_NUMBER");

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.AreEqual(0, (int)cmd.Parameters["i_pago_separacion"].Value);
        }

        [TestMethod]
        public void BuildPrincipalCommand_ShouldSetMetodoPago()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.AreEqual(nomina.FormaPagoDefault, cmd.Parameters["i_metodo_pago"].Value);
        }

        [TestMethod]
        public void BuildPrincipalCommand_ShouldSetAllStandardParams()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildPrincipalCommand(nomina);

            AssertStandardParams(cmd, nomina);
            Assert.AreEqual(nomina.ClaseNomina, cmd.Parameters["i_clase_nomina"].Value);
            AssertHasReturnValueParam(cmd);
        }

        [TestMethod]
        public void BuildPrincipalCommand_ShouldNotHaveConnection()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.IsNull(cmd.Connection);
        }

        #endregion

        #region BuildHorasExtraCommand

        [TestMethod]
        public void BuildHorasExtraCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildHorasExtraCommand(nomina);

            Assert.AreEqual("sp_horas_extra_sat", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildHorasExtraCommand_ShouldHave9Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildHorasExtraCommand(nomina);

            Assert.AreEqual(9, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildHorasExtraCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildHorasExtraCommand(nomina);

            AssertStandardParams(cmd, nomina);
            Assert.AreEqual(nomina.ClaseNomina, cmd.Parameters["i_clase_nomina"].Value);
            AssertHasReturnValueParam(cmd);
        }

        #endregion

        #region BuildIncapacidadesCommand

        [TestMethod]
        public void BuildIncapacidadesCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildIncapacidadesCommand(nomina);

            Assert.AreEqual("sp_incapacidades_sat", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildIncapacidadesCommand_ShouldHave8Parameters()
        {
            // No ClaseNomina parameter
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildIncapacidadesCommand(nomina);

            Assert.AreEqual(8, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildIncapacidadesCommand_ShouldNotHaveClaseNomina()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildIncapacidadesCommand(nomina);

            Assert.IsFalse(cmd.Parameters.Contains("i_clase_nomina"));
        }

        [TestMethod]
        public void BuildIncapacidadesCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildIncapacidadesCommand(nomina);

            AssertStandardParams(cmd, nomina);
            AssertHasReturnValueParam(cmd);
        }

        #endregion

        #region BuildOtrosPagosCommand

        [TestMethod]
        public void BuildOtrosPagosCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildOtrosPagosCommand(nomina);

            Assert.AreEqual("sp_otros_pagos_sat", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildOtrosPagosCommand_ShouldHave9Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildOtrosPagosCommand(nomina);

            Assert.AreEqual(9, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildOtrosPagosCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildOtrosPagosCommand(nomina);

            AssertStandardParams(cmd, nomina);
            Assert.AreEqual(nomina.ClaseNomina, cmd.Parameters["i_clase_nomina"].Value);
            AssertHasReturnValueParam(cmd);
        }

        #endregion

        #region BuildAccionesTitulosCommand

        [TestMethod]
        public void BuildAccionesTitulosCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAccionesTitulosCommand(nomina);

            Assert.AreEqual("sp_acciones_titulos", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildAccionesTitulosCommand_ShouldHave8Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAccionesTitulosCommand(nomina);

            Assert.AreEqual(8, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildAccionesTitulosCommand_ShouldNotHaveClaseNomina()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAccionesTitulosCommand(nomina);

            Assert.IsFalse(cmd.Parameters.Contains("i_clase_nomina"));
        }

        [TestMethod]
        public void BuildAccionesTitulosCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildAccionesTitulosCommand(nomina);

            AssertStandardParams(cmd, nomina);
            AssertHasReturnValueParam(cmd);
        }

        #endregion

        #region BuildJubilacionPensionRetiroCommand

        [TestMethod]
        public void BuildJubilacionPensionRetiroCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildJubilacionPensionRetiroCommand(nomina);

            Assert.AreEqual("sp_jubilacion_pension_retiro", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildJubilacionPensionRetiroCommand_ShouldHave8Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildJubilacionPensionRetiroCommand(nomina);

            Assert.AreEqual(8, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildJubilacionPensionRetiroCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildJubilacionPensionRetiroCommand(nomina);

            AssertStandardParams(cmd, nomina);
            AssertHasReturnValueParam(cmd);
        }

        #endregion

        #region BuildSeparacionIndemnizacionCommand

        [TestMethod]
        public void BuildSeparacionIndemnizacionCommand_ShouldReturnCorrectStoredProcedure()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildSeparacionIndemnizacionCommand(nomina);

            Assert.AreEqual("sp_separacion_indemnizacion", cmd.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, cmd.CommandType);
        }

        [TestMethod]
        public void BuildSeparacionIndemnizacionCommand_ShouldHave8Parameters()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildSeparacionIndemnizacionCommand(nomina);

            Assert.AreEqual(8, cmd.Parameters.Count);
        }

        [TestMethod]
        public void BuildSeparacionIndemnizacionCommand_ShouldSetAllParameterValues()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildSeparacionIndemnizacionCommand(nomina);

            AssertStandardParams(cmd, nomina);
            AssertHasReturnValueParam(cmd);
        }

        [TestMethod]
        public void BuildSeparacionIndemnizacionCommand_ShouldNotHaveClaseNomina()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            var cmd = service.BuildSeparacionIndemnizacionCommand(nomina);

            Assert.IsFalse(cmd.Parameters.Contains("i_clase_nomina"));
        }

        #endregion

        #region Cross-method consistency

        [TestMethod]
        public void AllBuildCommands_ShouldHaveNoConnection()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            Assert.IsNull(service.BuildAdicionalesCommand(nomina).Connection);
            Assert.IsNull(service.BuildPrincipalCommand(nomina).Connection);
            Assert.IsNull(service.BuildHorasExtraCommand(nomina).Connection);
            Assert.IsNull(service.BuildIncapacidadesCommand(nomina).Connection);
            Assert.IsNull(service.BuildOtrosPagosCommand(nomina).Connection);
            Assert.IsNull(service.BuildAccionesTitulosCommand(nomina).Connection);
            Assert.IsNull(service.BuildJubilacionPensionRetiroCommand(nomina).Connection);
            Assert.IsNull(service.BuildSeparacionIndemnizacionCommand(nomina).Connection);
        }

        [TestMethod]
        public void AllBuildCommands_ShouldHaveReturnValueParameter()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            AssertHasReturnValueParam(service.BuildAdicionalesCommand(nomina));
            AssertHasReturnValueParam(service.BuildPrincipalCommand(nomina));
            AssertHasReturnValueParam(service.BuildHorasExtraCommand(nomina));
            AssertHasReturnValueParam(service.BuildIncapacidadesCommand(nomina));
            AssertHasReturnValueParam(service.BuildOtrosPagosCommand(nomina));
            AssertHasReturnValueParam(service.BuildAccionesTitulosCommand(nomina));
            AssertHasReturnValueParam(service.BuildJubilacionPensionRetiroCommand(nomina));
            AssertHasReturnValueParam(service.BuildSeparacionIndemnizacionCommand(nomina));
        }

        [TestMethod]
        public void MethodsWithClaseNomina_ShouldHave9Params_MethodsWithout_ShouldHave8()
        {
            var service = CreateService();
            var nomina = CreateNomina();

            // With ClaseNomina: Adicionales, HorasExtra, OtrosPagos
            Assert.AreEqual(9, service.BuildAdicionalesCommand(nomina).Parameters.Count);
            Assert.AreEqual(9, service.BuildHorasExtraCommand(nomina).Parameters.Count);
            Assert.AreEqual(9, service.BuildOtrosPagosCommand(nomina).Parameters.Count);

            // Without ClaseNomina: Incapacidades, AccionesTitulos, JubilacionPensionRetiro, SeparacionIndemnizacion
            Assert.AreEqual(8, service.BuildIncapacidadesCommand(nomina).Parameters.Count);
            Assert.AreEqual(8, service.BuildAccionesTitulosCommand(nomina).Parameters.Count);
            Assert.AreEqual(8, service.BuildJubilacionPensionRetiroCommand(nomina).Parameters.Count);
            Assert.AreEqual(8, service.BuildSeparacionIndemnizacionCommand(nomina).Parameters.Count);

            // Principal has 11 (extra: i_metodo_pago, i_pago_separacion)
            Assert.AreEqual(11, service.BuildPrincipalCommand(nomina).Parameters.Count);
        }

        [TestMethod]
        public void BuildPrincipalCommand_DifferentNominaValues_ShouldReflectInParams()
        {
            var service = CreateService();
            var nomina = new Nomina("COMP", "TRAB000002", "TN", "CN", 2025, 12,
                ManejoNomina.interactiva, 5, "99", "TRAN");

            var cmd = service.BuildPrincipalCommand(nomina);

            Assert.AreEqual("COMP", cmd.Parameters["i_compania"].Value);
            Assert.AreEqual("TRAB000002", cmd.Parameters["i_trabajador"].Value);
            Assert.AreEqual("TN", cmd.Parameters["i_tipo_nomina"].Value);
            Assert.AreEqual("CN", cmd.Parameters["i_clase_nomina"].Value);
            Assert.AreEqual(2025, cmd.Parameters["i_anio"].Value);
            Assert.AreEqual(12, cmd.Parameters["i_periodo"].Value);
            Assert.AreEqual(5, cmd.Parameters["i_numero_liquidacion"].Value);
            Assert.AreEqual(ManejoNomina.interactiva, cmd.Parameters["i_manejo_nomina"].Value);
            Assert.AreEqual("TRAN", cmd.Parameters["i_metodo_pago"].Value);
            Assert.AreEqual(99, (int)cmd.Parameters["i_pago_separacion"].Value);
        }

        #endregion
    }
}

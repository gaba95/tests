using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using ADAM.MIIA.Configuration;
using ADAM.Framework.Encription;
using Microsoft.Data.SqlClient;
using Oracle.ManagedDataAccess.Client;

namespace ADAM.MIIA.Configurador.UI;

public partial class frmConfiguracion : Form
{
    private const string ReintentosConexionKey = "reintentosConexion";
    private const string TiempoEntreReintentosKey = "tiempoEntreReintentosConexion";
    private const string RutaResumenEnExcelKey = "rutaResumenEnExcel";
    private const string FieldRequiredMessage = "El campo es requerido";
    private const string ClienteMIIAColumn = "ClienteMIIA";
    private const string ConfirmationMessage = "\u00BFEsta seguro?";
    private const string ProcedimientoColumn = "procedimiento";
    private const string ClaveColumn = "clave";
    private const string OrderIDColumn = "orderID";

    private ExeConfigurationFileMap map;
    private System.Configuration.Configuration config = null!;
    private AppSettingsSection appSettings = null!;

    private MIIAConfigSection configClientes = null!;
    private MIIADBSection configDatabases = null!;
    private MIIAProceduresSection configProcedures = null!;
    private MIIAOnDemandSection configOnDemand = null!;
    private static StringBuilder strErrorsTalentDB = new StringBuilder();

    private MIIAOrderProcessSection configOrderProcess = null!;

    private Encripta.Encriptador myEncrypt = new Encripta.Encriptador();


    public frmConfiguracion()
    {
        InitializeComponent();

        map = new ExeConfigurationFileMap();
        map.ExeConfigFilename = rutaAplicacion();

        AbrirArchivoConfiguracion();
    }

    internal void frmConfiguracion_Load(object sender, EventArgs e)
    {
        inicializarClase();
        FillConTypeDropdown();
        AplicarEstiloRetro(this);
    }

    internal void FillConTypeDropdown()
    {
        var dt = new DataTable();
        dt.Columns.Add("tipo");
        dt.Columns.Add("descripcion");

        dt.Rows.Add("SQL", "SQL");
        dt.Rows.Add("ORACLE", "ORACLE");

        cboConnectionType.DataSource = dt;
        cboConnectionType.ValueMember = "tipo";
        cboConnectionType.DisplayMember = "descripcion";
    }

    internal void cmdReinicia_Click(object sender, EventArgs e)
    {
        ReiniciarServicio();
        MostrarEstadoServicio();
    }

    internal void cmdDetener_Click(object sender, EventArgs e)
    {
        DetenerServicio();
        MostrarEstadoServicio();
    }

    internal void cmdRutaOrigen_Click(object sender, EventArgs e)
    {
        if (txtRutaOrigen.Text != "")
        {
            fbdRuta.SelectedPath = txtRutaOrigen.Text;
        }

        UIHelper.ShowCommonDialog(fbdRuta);

        if (fbdRuta.SelectedPath.Trim() != "")
        {
            if (!fbdRuta.SelectedPath.EndsWith('\\'))
            {
                txtRutaOrigen.Text = fbdRuta.SelectedPath + "\\";
            }
            else
            {
                txtRutaOrigen.Text = fbdRuta.SelectedPath;
            }
        }
    }

    internal void cmdRutaDestino_Click(object sender, EventArgs e)
    {
        if (txtRutaDestino.Text != "")
        {
            fbdRuta.SelectedPath = txtRutaDestino.Text;
        }

        UIHelper.ShowCommonDialog(fbdRuta);

        if (fbdRuta.SelectedPath.Trim() != "")
        {
            if (!fbdRuta.SelectedPath.EndsWith('\\'))
            {
                txtRutaDestino.Text = fbdRuta.SelectedPath + "\\";
            }
            else
            {
                txtRutaDestino.Text = fbdRuta.SelectedPath;
            }
        }
    }

    internal void cmdCancelar_Click(object sender, EventArgs e)
    {
        Application.Exit();
    }

    internal void cmdAceptar_Click(object sender, EventArgs e)
    {
        GuardarParametrosGenerales();
    }

    internal void cmdProbar_Click(object sender, EventArgs e)
    {
        var frmProbar = new FrmProbarCorreo();
        UIHelper.ShowFormDialog(frmProbar);

        if (frmProbar.DialogResult == DialogResult.OK)
        {
            enviarCorreoPrueba(frmProbar.CorreoElectronico);
        }
    }

    internal void timerEventos_Tick(object sender, EventArgs e)
    {
        lvEventos.Items.Clear();
        LlenaListaEventos();
    }

    internal void lvEventos_SizeChanged(object sender, EventArgs e)
    {
        lvEventos.Columns[0].Width = lvEventos.Width;
    }

    internal void chkActualiza_CheckedChanged(object sender, EventArgs e)
    {
        timerEventos.Enabled = chkActualiza.Checked;
    }

    internal void cmdActualizar_Click(object sender, EventArgs e)
    {
        timerEventos_Tick(sender, e);
    }

    internal void cmdGuardaCorreo_Click(object sender, EventArgs e)
    {
        GuardarParametrosCorreo();
    }

    internal void cmdEventViewer_Click(object sender, EventArgs e)
    {
        LlamaEventViewer();
    }

    #region Clientes

    internal void gridParametrosCliente_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
        modificarCliente();
    }

    internal void gridParametrosCliente_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
    {
        if (e.ColumnIndex == 4 && e.Value != null)
        {
            e.Value = new string('*', 10);
        }
    }

    internal void cmdModificar_Click(object sender, EventArgs e)
    {
        modificarCliente();
    }

    internal void cmdEliminar_Click(object sender, EventArgs e)
    {
        EliminarCliente();
    }

    internal void cmdAgregar_Click(object sender, EventArgs e)
    {
        AgregarCliente();
    }

    #endregion

    #region Procedures

    internal void gridProcedures_DoubleClick(object sender, EventArgs e)
    {
        modificarProcedure();
    }

    internal void cmdAgregarProc_Click(object sender, EventArgs e)
    {
        AgregarProcedure();
    }

    internal void cmdModificarProc_Click(object sender, EventArgs e)
    {
        modificarProcedure();
    }

    internal void cmdEliminarProc_Click(object sender, EventArgs e)
    {
        EliminarProcedure();
    }

    #endregion

    #region OnDemand

    internal void gridOnDemand_DoubleClick(object sender, EventArgs e)
    {
        modificarOnDemand();
    }

    internal void cmdAgregarOnDemand_Click(object sender, EventArgs e)
    {
        AgregarOnDemand();
    }

    internal void cmdModificarOnDemand_Click(object sender, EventArgs e)
    {
        modificarOnDemand();
    }

    internal void cmdEliminarOnDemand_Click(object sender, EventArgs e)
    {
        EliminarOnDemand();
    }

    #endregion

    #region Methods

    internal void inicializarClase()
    {
        CargarConfiguracionGeneral();
        CargarConfiguracioncorreo();
        LoadDataTalentDB();
        MostrarEstadoServicio();
        llenaGridClientes();
        llenaGridProcedures();
        llenaGridOnDemand();
        fillGridOrderProcess();
        timerEventos.Enabled = true;
    }

    internal void LoadDataTalentDB()
    {
        if (configDatabases != null)
        {
            var datosCliente = configDatabases.DBConnections["talendDB"];

            if (datosCliente != null)
            {
                txtUserTalent.Text = datosCliente.Usuario.ToString();
                cboConnectionType.Text = datosCliente.TipoConexion.ToString();
                txtServerTalent.Text = datosCliente.Servidor.ToString();
                txtDatabaseTalent.Text = datosCliente.DataBase.ToString();

                try
                {
                    txtPasswordTalent.Text = myEncrypt.CryptoDecrypt(datosCliente.Password.ToString());
                }
                catch (Exception)
                {
                    // Decryption failure is expected for unencrypted or corrupted passwords - display empty
                }
            }
        }
        else
        {
            strErrorsTalentDB.Append("La seccion OtherDBConnectionsMIIA no existe en el archivo de configuracion. ");
            chkEnableTalentDB.Checked = false;
        }

        if (appSettings.Settings["usarTalentDBConnection"] != null)
        {
            if (appSettings.Settings["usarTalentDBConnection"].Value == "True")
            {
                chkEnableTalentDB.Checked = true;
            }
            else
            {
                chkEnableTalentDB.Checked = false;
            }
        }
        else
        {
            strErrorsTalentDB.Append("La clave usarTalentDBConnection no existe en el archivo de configuracion. ");
            chkEnableTalentDB.Checked = false;
        }

        DisplayTalentDBConfigErrors();
    }

    internal static bool DisplayTalentDBConfigErrors()
    {
        if (strErrorsTalentDB.ToString() != "")
        {
            if (!strErrorsTalentDB.ToString().Contains("agregar"))
            {
                strErrorsTalentDB.AppendLine("Por favor agregar si se desea utilizar la auditoria de errores en TalentDB.");
            }
            UIHelper.ShowMessage(strErrorsTalentDB.ToString(), "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return true;
        }
        return false;
    }

    internal void CargarConfiguracionGeneral()
    {
        txtRutaOrigen.Text = appSettings.Settings["rutaOrigen"].Value.ToString();
        txtRutaDestino.Text = appSettings.Settings["rutaDestino"].Value.ToString();
        txtNombresArchivosCtrl.Text = appSettings.Settings["nombresArchivosControl"].Value.ToString();
        txtCarpetas.Text = appSettings.Settings["carpetasProcesar"].Value.ToString();
        cboVeces.Text = appSettings.Settings["vecesEjecutaSPs"].Value.ToString();
        cboArchivoControl.Text = appSettings.Settings["usarArchivoControl"].Value.ToString();
        txtPatron.Text = appSettings.Settings["regexValidacionArchivos"].Value.ToString();
        cboEjecucionInmediata.Text = appSettings.Settings["permitirEjecucionInmediata"].Value.ToString();
        txtNombresArchivosInmediata.Text = appSettings.Settings["nombresArchivosEjecucionInmediata"].Value.ToString();
        cboArchivosEncriptados.Text = appSettings.Settings["archivosEncriptados"].Value.ToString();

        try
        {
            if (appSettings.Settings[ReintentosConexionKey] != null)
            {
                nupdConnectionRetries.Value = Convert.ToDecimal(appSettings.Settings[ReintentosConexionKey].Value.ToString());
            }
            else
            {
                nupdConnectionRetries.Value = 0;
            }

            if (appSettings.Settings[TiempoEntreReintentosKey] != null)
            {
                nupdTimeConnectionRetries.Value = Convert.ToDecimal(appSettings.Settings[TiempoEntreReintentosKey].Value.ToString());
            }
            else
            {
                nupdTimeConnectionRetries.Value = 0;
            }
        }
        catch
        {
            // Retry/connection settings not found - use defaults
        }

        try
        {
            var pwd = appSettings.Settings["passwordGPG"].Value.ToString();
            txtPasswordGPG.Text = myEncrypt.CryptoDecrypt(appSettings.Settings["passwordGPG"].Value.ToString());
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("No se puede resolver la encripci\u00F3n del archivo, error:" + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtPasswordGPG.Text = "";
        }
        cboUsarJobsSQL.Text = appSettings.Settings["usarJobSQL"].Value.ToString();

        // PTF-1600: Excel summaries support added.
        if (appSettings.Settings[RutaResumenEnExcelKey] != null)
        {
            txtRutaResumenEnExcel.Text = appSettings.Settings[RutaResumenEnExcelKey].Value.ToString();
        }
        else
        {
            txtRutaResumenEnExcel.Text = appSettings.Settings["rutaOrigen"].Value.ToString();
        }
    }

    internal static string rutaAplicacion()
    {
        string ruta = "";

        ruta = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)!;
        ruta = ruta.Replace("file:\\", "");

        string[] archivos = System.IO.Directory.GetFiles(ruta, "*ADAMMIIAService*.config");

        if (archivos.Length == 0)
        {
            UIHelper.ShowMessage("No hay archivos de configuracion disponibles", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return "";
        }
        else
        {
            ruta = archivos[0];
        }

        return ruta;
    }

    internal void AbrirArchivoConfiguracion()
    {
        config = ConfigurationManager.OpenMappedExeConfiguration(map, ConfigurationUserLevel.None);
        appSettings = (AppSettingsSection)config.GetSection("appSettings");

        try
        {
            configClientes = (MIIAConfigSection)config.GetSection("ClientesMIIA");
            configProcedures = (MIIAProceduresSection)config.GetSection("ProceduresMIIA");
            configOnDemand = (MIIAOnDemandSection)config.GetSection("OnDemandMIIA");
            configOrderProcess = (MIIAOrderProcessSection)config.GetSection("OrderProcessMIIA");
            configDatabases = (MIIADBSection)config.GetSection("OtherDBConnectionsMIIA");
        }
        catch (InvalidCastException)
        {
            UIHelper.ShowMessage("Por favor verificar que todas las secciones han sido declaradas correctamente en el archivo de configuracion.", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    internal void GuardarParametrosGenerales()
    {
        if (!ValidaCampos())
            return;

        try
        {
            appSettings.Settings["rutaOrigen"].Value = txtRutaOrigen.Text;
            appSettings.Settings["rutaDestino"].Value = txtRutaDestino.Text;
            appSettings.Settings["nombresArchivosControl"].Value = txtNombresArchivosCtrl.Text;
            appSettings.Settings["carpetasProcesar"].Value = txtCarpetas.Text;
            appSettings.Settings["vecesEjecutaSPs"].Value = cboVeces.Text;
            appSettings.Settings["usarArchivoControl"].Value = cboArchivoControl.Text;
            appSettings.Settings["regexValidacionArchivos"].Value = txtPatron.Text;
            appSettings.Settings["permitirEjecucionInmediata"].Value = cboEjecucionInmediata.Text;
            appSettings.Settings["nombresArchivosEjecucionInmediata"].Value = txtNombresArchivosInmediata.Text;
            appSettings.Settings["archivosEncriptados"].Value = cboArchivosEncriptados.Text;
            appSettings.Settings["passwordGPG"].Value = myEncrypt.CryptoEncrypt(txtPasswordGPG.Text);
            appSettings.Settings["usarJobSQL"].Value = cboUsarJobsSQL.Text;

            // PTF-1600: Excel summaries support added.
            if (appSettings.Settings[RutaResumenEnExcelKey] != null)
            {
                appSettings.Settings[RutaResumenEnExcelKey].Value = txtRutaResumenEnExcel.Text;
            }
            else
            {
                appSettings.Settings.Add(RutaResumenEnExcelKey, txtRutaResumenEnExcel.Text);
            }

            if (appSettings.Settings[ReintentosConexionKey] != null)
            {
                appSettings.Settings[ReintentosConexionKey].Value = nupdConnectionRetries.Value.ToString();
            }
            else
            {
                appSettings.Settings.Add(ReintentosConexionKey, nupdConnectionRetries.Value.ToString());
            }

            if (appSettings.Settings[TiempoEntreReintentosKey] != null)
            {
                appSettings.Settings[TiempoEntreReintentosKey].Value = nupdTimeConnectionRetries.Value.ToString();
            }
            else
            {
                appSettings.Settings.Add(TiempoEntreReintentosKey, nupdTimeConnectionRetries.Value.ToString());
            }

            config.Save();
            UIHelper.ShowMessage("La configuraci\u00F3n se guardo correctamente en " + "\r\n" + config.FilePath, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    internal void MostrarEstadoServicio()
    {
        try
        {
            scMIIA.Refresh();
            lblEstadoServicio2.Text = "Estado del Servicio: " + scMIIA.Status.ToString();
        }
        catch (Exception)
        {
            lblEstadoServicio2.Text = "Estado del Servicio: No Disponible";
        }
    }

    internal void ReiniciarServicio()
    {
        var timeoutDetener = TimeSpan.FromMilliseconds(10000);
        var timeoutIniciar = TimeSpan.FromMilliseconds(20000);

        try
        {
            this.Cursor = Cursors.WaitCursor;
            scMIIA.Refresh();

            if (scMIIA.Status == ServiceControllerStatus.Running)
            {
                scMIIA.Stop();
                scMIIA.WaitForStatus(ServiceControllerStatus.Stopped, timeoutDetener);
            }

            scMIIA.Start();
            scMIIA.WaitForStatus(ServiceControllerStatus.Running, timeoutIniciar);

            UIHelper.ShowMessage("El servicio se reinicio correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Cursor = Cursors.Default;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al reiniciar el servicio, " + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Cursor = Cursors.Default;
        }
    }

    internal void DetenerServicio()
    {
        var timeoutDetener = TimeSpan.FromMilliseconds(10000);

        try
        {
            this.Cursor = Cursors.WaitCursor;
            scMIIA.Refresh();

            if (scMIIA.Status == ServiceControllerStatus.Running)
            {
                scMIIA.Stop();
                scMIIA.WaitForStatus(ServiceControllerStatus.Stopped, timeoutDetener);
            }

            UIHelper.ShowMessage("El servicio se detuvo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Cursor = Cursors.Default;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al detener el servicio, " + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Cursor = Cursors.Default;
        }
    }

    internal bool ValidaCampos()
    {
        if (txtRutaOrigen.Text == string.Empty)
        {
            UIHelper.ShowMessage(FieldRequiredMessage, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtRutaOrigen.Focus();
            return false;
        }

        if (txtRutaDestino.Text == string.Empty)
        {
            UIHelper.ShowMessage(FieldRequiredMessage, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtRutaDestino.Focus();
            return false;
        }

        if (txtNombresArchivosCtrl.Text == string.Empty)
        {
            UIHelper.ShowMessage(FieldRequiredMessage, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtNombresArchivosCtrl.Focus();
            return false;
        }

        if (txtCarpetas.Text == string.Empty)
        {
            UIHelper.ShowMessage(FieldRequiredMessage, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtCarpetas.Focus();
            return false;
        }

        if (txtPatron.Text == string.Empty)
        {
            UIHelper.ShowMessage(FieldRequiredMessage, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPatron.Focus();
            return false;
        }

        return true;
    }

    internal bool ValidaCamposTalent()
    {
        if (txtUserTalent.Text == string.Empty)
        {
            UIHelper.ShowMessage("El campo usuario es requerido", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtUserTalent.Focus();
            return false;
        }

        if (txtPasswordTalent.Text == string.Empty)
        {
            UIHelper.ShowMessage("El campo password es requerido", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPasswordTalent.Focus();
            return false;
        }

        if (txtServerTalent.Text == string.Empty)
        {
            UIHelper.ShowMessage("El campo servidor es requerido", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtServerTalent.Focus();
            return false;
        }

        if (txtDatabaseTalent.Text == string.Empty)
        {
            UIHelper.ShowMessage("El campo base de datos es requerido", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtDatabaseTalent.Focus();
            return false;
        }

        return true;
    }

    internal void LlenaListaEventos()
    {
        lvEventos.Sorting = System.Windows.Forms.SortOrder.Descending;
        foreach (EventLogEntry entry in EventLogADAM.Entries)
        {
            switch (entry.EntryType)
            {
                case EventLogEntryType.Information:
                    lvEventos.Items.Add(entry.TimeGenerated.ToString() + "    " + entry.Message, 0);
                    break;
                case EventLogEntryType.Warning:
                    lvEventos.Items.Add(entry.TimeGenerated.ToString() + "    " + entry.Message, 1);
                    break;
                case EventLogEntryType.Error:
                    lvEventos.Items.Add(entry.TimeGenerated.ToString() + "    " + entry.Message, 2);
                    break;
            }
        }
    }

    internal static void LlamaEventViewer()
    {
        string comando = Environment.SystemDirectory + "\\eventvwr.msc";
        var psi = new ProcessStartInfo(comando)
        {
            UseShellExecute = true
        };
        using var proc = Process.Start(psi);
    }

    #endregion

    #region Correo

    internal void CargarConfiguracioncorreo()
    {
        txtNombre.Text = appSettings.Settings["deNombre"].Value.ToString();
        txtMail.Text = appSettings.Settings["deCorreo"].Value.ToString();
        txtTitulo.Text = appSettings.Settings["tituloCorreo"].Value.ToString();
        txtMensaje.Text = appSettings.Settings["mensajeCorreo"].Value.ToString();
        cboHtml.Text = appSettings.Settings["mensajeHTML"].Value.ToString();
        cboPrioridad.Text = appSettings.Settings["prioridadCorreo"].Value.ToString();
        txtServidorCorreo.Text = appSettings.Settings["servidorCorreo"].Value.ToString();
        txtPuerto.Text = appSettings.Settings["puertoCorreo"].Value.ToString();
        cboSSL.Text = appSettings.Settings["usarSSL"].Value.ToString();
        txtUsuario.Text = appSettings.Settings["usuarioCorreo"].Value.ToString();

        try
        {
            txtPassword.Text = myEncrypt.CryptoDecrypt(appSettings.Settings["passwordCorreo"].Value.ToString());
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("No se puede resolver la encripci\u00F3n del archivo, error:" + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtPassword.Text = "";
        }

        txtTimeOut.Text = appSettings.Settings["timeOutCorreo"].Value.ToString();
    }

    internal void enviarCorreoPrueba(string destinatario)
    {
        try
        {
            var enviar = new CorreosADAM.SendMail();
            bool esHtml = false;
            bool usarSsl = false;

            if (cboHtml.SelectedItem?.ToString() == "True")
            {
                esHtml = true;
            }

            if (cboSSL.SelectedItem?.ToString() == "True")
            {
                usarSsl = true;
            }

            this.Cursor = Cursors.WaitCursor;
            if (enviar.EnviaCorreo(txtMail.Text, txtNombre.Text, destinatario, txtTitulo.Text, txtMensaje.Text, esHtml, Convert.ToInt32(cboPrioridad.SelectedItem?.ToString()), txtServidorCorreo.Text, Convert.ToInt32(txtPuerto.Text), usarSsl, txtUsuario.Text, txtPassword.Text, Convert.ToInt32(txtTimeOut.Text)))
            {
                UIHelper.ShowMessage("Correo enviado a la cuenta: " + destinatario, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                UIHelper.ShowMessage("Error al enviar el correo, error: " + enviar.Error, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Cursor = Cursors.Default;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al enviar el correo, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            this.Cursor = Cursors.Default;
        }
    }

    internal void SaveParametersTalentDB()
    {
        bool blnSucceededSave = true;

        if (!DisplayTalentDBConfigErrors())
        {
            if (chkEnableTalentDB.Checked)
            {
                if (!ValidaCamposTalent())
                    return;

                try
                {
                    if (configDatabases != null)
                    {
                        var datosCliente = configDatabases.DBConnections["talendDB"];
                        if (datosCliente != null)
                        {
                            datosCliente.Usuario = txtUserTalent.Text;
                            datosCliente.Password = myEncrypt.CryptoEncrypt(txtPasswordTalent.Text);
                            datosCliente.Servidor = txtServerTalent.Text;
                            datosCliente.TipoConexion = cboConnectionType.Text;
                            datosCliente.DataBase = txtDatabaseTalent.Text;
                        }
                        else
                        {
                            blnSucceededSave = false;
                            UIHelper.ShowMessage("Por favor verificar que la conexion de base de datos para talendDB existe en el archivo de configuracion", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n de Talent DB, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            appSettings.Settings["usarTalentDBConnection"].Value = chkEnableTalentDB.Checked.ToString();
            config.Save();

            if (blnSucceededSave)
            {
                UIHelper.ShowMessage("La configuraci\u00F3n de Talent DB se guardo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }

    internal void GuardarParametrosCorreo()
    {
        if (!ValidaCampos())
            return;

        try
        {
            appSettings.Settings["deNombre"].Value = txtNombre.Text;
            appSettings.Settings["deCorreo"].Value = txtMail.Text;
            appSettings.Settings["tituloCorreo"].Value = txtTitulo.Text;
            appSettings.Settings["mensajeCorreo"].Value = txtMensaje.Text;
            appSettings.Settings["mensajeHTML"].Value = cboHtml.Text;
            appSettings.Settings["prioridadCorreo"].Value = cboPrioridad.Text;
            appSettings.Settings["servidorCorreo"].Value = txtServidorCorreo.Text;
            appSettings.Settings["puertoCorreo"].Value = txtPuerto.Text;
            appSettings.Settings["usarSSL"].Value = cboSSL.Text;
            appSettings.Settings["usuarioCorreo"].Value = txtUsuario.Text;
            appSettings.Settings["passwordCorreo"].Value = myEncrypt.CryptoEncrypt(txtPassword.Text);
            appSettings.Settings["timeOutCorreo"].Value = txtTimeOut.Text;

            config.Save();
            UIHelper.ShowMessage("La configuraci\u00F3n se guardo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    #endregion

    #region Clientes

    public void llenaGridClientes()
    {
        var tablaClientes = new DataTable();
        tablaClientes.Columns.Add(ClienteMIIAColumn);
        tablaClientes.Columns.Add("Descripcion");
        tablaClientes.Columns.Add("tipoConexion");
        tablaClientes.Columns.Add("usuario");
        tablaClientes.Columns.Add("password");
        tablaClientes.Columns.Add("servidor");
        tablaClientes.Columns.Add("dataBase");
        tablaClientes.Columns.Add("horaInicio");
        tablaClientes.Columns.Add("horaFin");
        tablaClientes.Columns.Add("correoDe");
        tablaClientes.Columns.Add("correoPara");
        // PTF-2206
        tablaClientes.Columns.Add("idiomaEspaniol", Type.GetType("System.Boolean")!);
        tablaClientes.Columns.Add("idiomaIngles", Type.GetType("System.Boolean")!);
        tablaClientes.Columns.Add("resumenEnExcel", Type.GetType("System.Boolean")!); // PTF-1600

        foreach (ClienteMIIA datosCliente in configClientes.Clientes)
        {
            DataRow renglon = tablaClientes.NewRow();
            renglon[ClienteMIIAColumn] = datosCliente.ClienteMIIAProp.ToString();
            renglon["Descripcion"] = datosCliente.Descripcion.ToString();
            renglon["tipoConexion"] = datosCliente.TipoConexion.ToString();
            renglon["usuario"] = datosCliente.Usuario.ToString();
            try
            {
                renglon["password"] = myEncrypt.CryptoDecrypt(datosCliente.Password.ToString());
            }
            catch (Exception)
            {
                // Decryption failure is expected for unencrypted or corrupted passwords
            }

            renglon["servidor"] = datosCliente.Servidor.ToString();
            renglon["dataBase"] = datosCliente.DataBase.ToString();

            renglon["horaInicio"] = datosCliente.HoraInicio.ToString();
            renglon["horaFin"] = datosCliente.HoraFin.ToString();
            renglon["correoDe"] = datosCliente.CorreoDe.ToString();
            renglon["correoPara"] = datosCliente.CorreoPara.ToString();

            // PTF-2206
            bool existeConfigIdiomaES = !string.IsNullOrEmpty(datosCliente.IdiomaEspaniol);
            bool existeConfigIdiomaEN = !string.IsNullOrEmpty(datosCliente.IdiomaIngles);
            bool idiomaEspaniol = false;
            bool idiomaIngles = false;

            if (existeConfigIdiomaES)
            {
                idiomaEspaniol = Convert.ToBoolean(datosCliente.IdiomaEspaniol.ToString());
            }

            if (existeConfigIdiomaEN)
            {
                idiomaIngles = Convert.ToBoolean(datosCliente.IdiomaIngles.ToString());
            }

            if (!existeConfigIdiomaES && !existeConfigIdiomaEN)
            {
                idiomaEspaniol = true;
                idiomaIngles = false;
            }

            renglon["idiomaEspaniol"] = idiomaEspaniol;
            renglon["idiomaIngles"] = idiomaIngles;

            // PTF-1600
            bool existeConfigActivarResumenEnExcel = !string.IsNullOrEmpty(datosCliente.ActivarResumenEnExcel);
            bool activarResumenEnExcel = false;

            if (existeConfigActivarResumenEnExcel)
            {
                activarResumenEnExcel = Convert.ToBoolean(datosCliente.ActivarResumenEnExcel.ToString());
            }

            renglon["resumenEnExcel"] = activarResumenEnExcel;

            tablaClientes.Rows.Add(renglon);
        }

        gridParametrosCliente.DataSource = tablaClientes;
    }

    internal void modificarCliente()
    {
        if (gridParametrosCliente.Rows.Count == 0)
            return;

        string clave = gridParametrosCliente.SelectedRows[0].Cells[ClienteMIIAColumn].Value?.ToString() ?? string.Empty;
        string descripcion = gridParametrosCliente.SelectedRows[0].Cells["descripcion"].Value?.ToString() ?? string.Empty;
        string tipoConexion = gridParametrosCliente.SelectedRows[0].Cells["tipoConexion"].Value?.ToString() ?? string.Empty;
        string usuario = gridParametrosCliente.SelectedRows[0].Cells["usuario"].Value?.ToString() ?? string.Empty;
        string password = gridParametrosCliente.SelectedRows[0].Cells["password"].Value?.ToString() ?? string.Empty;

        string horaInicio = gridParametrosCliente.SelectedRows[0].Cells["horaInicio"].Value?.ToString() ?? string.Empty;
        string horaFin = gridParametrosCliente.SelectedRows[0].Cells["horaFin"].Value?.ToString() ?? string.Empty;
        string correoDe = gridParametrosCliente.SelectedRows[0].Cells["correoDe"].Value?.ToString() ?? string.Empty;
        string correoPara = gridParametrosCliente.SelectedRows[0].Cells["correoPara"].Value?.ToString() ?? string.Empty;

        // PTF-2206
        string idiomaEspaniol = gridParametrosCliente.SelectedRows[0].Cells["idiomaEspaniol"].Value?.ToString() ?? string.Empty;
        string idiomaIngles = gridParametrosCliente.SelectedRows[0].Cells["idiomaIngles"].Value?.ToString() ?? string.Empty;

        // PTF-1600
        string activarResumenEnExcel = gridParametrosCliente.SelectedRows[0].Cells["resumenEnExcel"].Value?.ToString() ?? string.Empty;

        string server = gridParametrosCliente.SelectedRows[0].Cells["servidor"].Value?.ToString() ?? string.Empty;
        string dataBase = gridParametrosCliente.SelectedRows[0].Cells["dataBase"].Value?.ToString() ?? string.Empty;

        var frmCliente = new frmModificaCliente();
        frmCliente.config = this.config;
        frmCliente.MIIAConfigSection = configClientes;
        frmCliente.clienteMIIA = clave;
        frmCliente.descripcion = descripcion;
        frmCliente.TipoConexion = tipoConexion;
        frmCliente.Usuario = usuario;
        frmCliente.Password = password;
        frmCliente.HoraInicio = horaInicio;
        frmCliente.HoraFin = horaFin;
        frmCliente.CorreoDe = correoDe;
        frmCliente.CorreoPara = correoPara;
        frmCliente.IdiomaEspaniol = idiomaEspaniol; // PTF-2206
        frmCliente.IdiomaIngles = idiomaIngles; // PTF-2206
        frmCliente.ActivarResumenEnExcel = activarResumenEnExcel; // PTF-1600
        frmCliente.Servidor = server;
        frmCliente.baseDatos = dataBase;
        frmCliente.frmPadre = this;
        UIHelper.ShowFormDialog(frmCliente);

        llenaGridClientes();
    }

    internal void AgregarCliente()
    {
        var frmCliente = new frmModificaCliente();
        frmCliente.config = this.config;
        frmCliente.MIIAConfigSection = configClientes;
        frmCliente.frmPadre = this;
        UIHelper.ShowFormDialog(frmCliente);

        llenaGridClientes();
    }

    internal void EliminarCliente()
    {
        if (gridParametrosCliente.Rows.Count == 0)
            return;

        if (UIHelper.ShowMessage(ConfirmationMessage, "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            return;

        foreach (DataGridViewRow renglon in gridParametrosCliente.SelectedRows)
        {
            configClientes.Clientes.Remove(renglon.Cells[ClienteMIIAColumn].Value?.ToString() ?? string.Empty);
        }
        config.Save();
        llenaGridClientes();
    }

    #endregion

    #region Procedures

    public void llenaGridProcedures()
    {
        var tablaProcedures = new DataTable();
        tablaProcedures.Columns.Add("tabla");
        tablaProcedures.Columns.Add(ProcedimientoColumn);
        tablaProcedures.Columns.Add("procedimiento2");

        foreach (ProcedureMIIA datosProcedure in configProcedures.Procedures)
        {
            DataRow renglon = tablaProcedures.NewRow();
            renglon["tabla"] = datosProcedure.ProcedureMIIAProp;
            renglon[ProcedimientoColumn] = datosProcedure.Procedimiento;
            renglon["procedimiento2"] = datosProcedure.Procedimiento2;
            tablaProcedures.Rows.Add(renglon);
        }
        gridProcedures.DataSource = tablaProcedures;
    }

    internal void modificarProcedure()
    {
        if (gridParametrosCliente.Rows.Count == 0)
            return;

        string tabla = gridProcedures.SelectedRows[0].Cells["tabla"].Value?.ToString() ?? string.Empty;
        string procedure = gridProcedures.SelectedRows[0].Cells[ProcedimientoColumn].Value?.ToString() ?? string.Empty;
        string procedure2 = gridProcedures.SelectedRows[0].Cells["procedimiento2"].Value?.ToString() ?? string.Empty;

        var frmProcedure = new frmModificaProcedure();
        frmProcedure.tabla = tabla;
        frmProcedure.procedure = procedure;
        frmProcedure.procedure2 = procedure2;
        frmProcedure.MIIAProceduresSection = configProcedures;
        frmProcedure.config = config;
        frmProcedure.frmPadre = this;
        UIHelper.ShowFormDialog(frmProcedure);

        llenaGridProcedures();
    }

    internal void AgregarProcedure()
    {
        var frmProcedure = new frmModificaProcedure();
        frmProcedure.config = this.config;
        frmProcedure.MIIAProceduresSection = configProcedures;
        frmProcedure.frmPadre = this;
        UIHelper.ShowFormDialog(frmProcedure);

        llenaGridProcedures();
    }

    internal void EliminarProcedure()
    {
        if (gridProcedures.Rows.Count == 0)
            return;

        if (UIHelper.ShowMessage(ConfirmationMessage, "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            return;

        foreach (DataGridViewRow renglon in gridProcedures.SelectedRows)
        {
            configProcedures.Procedures.Remove(renglon.Cells["Tabla"].Value?.ToString() ?? string.Empty);
        }
        config.Save();
        llenaGridProcedures();
    }

    #endregion

    #region OnDemand

    internal void llenaGridOnDemand()
    {
        var tablaOnDemand = new DataTable();
        tablaOnDemand.Columns.Add(ClaveColumn);
        tablaOnDemand.Columns.Add("regExArchivo");
        tablaOnDemand.Columns.Add(ProcedimientoColumn);

        foreach (OnDemandMIIA datosOnDemand in configOnDemand.OnDemand)
        {
            DataRow renglon = tablaOnDemand.NewRow();
            renglon[ClaveColumn] = datosOnDemand.Clave;
            renglon["regExArchivo"] = datosOnDemand.RegExArchivo;
            renglon[ProcedimientoColumn] = datosOnDemand.Procedimiento;
            tablaOnDemand.Rows.Add(renglon);
        }
        gridOnDemand.DataSource = tablaOnDemand;
    }

    internal void modificarOnDemand()
    {
        if (gridOnDemand.Rows.Count == 0)
            return;

        string clave = gridOnDemand.SelectedRows[0].Cells[ClaveColumn].Value?.ToString() ?? string.Empty;
        string regExArchivo = gridOnDemand.SelectedRows[0].Cells["regExArchivo"].Value?.ToString() ?? string.Empty;
        string procedure = gridOnDemand.SelectedRows[0].Cells[ProcedimientoColumn].Value?.ToString() ?? string.Empty;

        var frmOnDemand = new frmModificaOnDemand();
        frmOnDemand.Clave = clave;
        frmOnDemand.RegExArchivo = regExArchivo;
        frmOnDemand.procedure = procedure;
        frmOnDemand.MIIAOnDemandSection = configOnDemand;
        frmOnDemand.config = config;
        UIHelper.ShowFormDialog(frmOnDemand);

        llenaGridOnDemand();
    }

    internal void AgregarOnDemand()
    {
        var frmOnDemand = new frmModificaOnDemand();
        frmOnDemand.config = this.config;
        frmOnDemand.MIIAOnDemandSection = configOnDemand;
        frmOnDemand.frmPadre = this;
        UIHelper.ShowFormDialog(frmOnDemand);

        llenaGridOnDemand();
    }

    internal void EliminarOnDemand()
    {
        if (gridOnDemand.Rows.Count == 0)
            return;

        if (UIHelper.ShowMessage(ConfirmationMessage, "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            return;

        foreach (DataGridViewRow renglon in gridOnDemand.SelectedRows)
        {
            configOnDemand.OnDemand.Remove(renglon.Cells[ClaveColumn].Value?.ToString() ?? string.Empty);
        }
        config.Save();
        llenaGridOnDemand();
    }

    #endregion

    #region OrderPriorityProcess

    internal void fillGridOrderProcess()
    {
        var dtOrderProcess = new DataTable();
        dtOrderProcess.Columns.Add(OrderIDColumn);
        dtOrderProcess.Columns.Add("fileRegularExpr");

        foreach (OrderProcessMIIA dataOrderProcess in configOrderProcess.OrderProcess)
        {
            DataRow row = dtOrderProcess.NewRow();
            row[OrderIDColumn] = dataOrderProcess.OrderId;
            row["fileRegularExpr"] = dataOrderProcess.FileRegularExpr;
            dtOrderProcess.Rows.Add(row);
        }

        gridOrderProcess.DataSource = dtOrderProcess;
    }

    internal void btnAddOrderProcess_Click(object sender, EventArgs e)
    {
        var frmOrderProcess = new frmModificaOrderProcess();
        frmOrderProcess.config = this.config;
        frmOrderProcess.MIIAOrderProcessSection = configOrderProcess;
        frmOrderProcess.frmPadre = this;
        UIHelper.ShowFormDialog(frmOrderProcess);

        fillGridOrderProcess();
    }

    internal void btnUpdateOrderProcess_Click(object sender, EventArgs e)
    {
        if (gridOrderProcess.Rows.Count == 0)
            return;

        string orderID = gridOrderProcess.SelectedRows[0].Cells[OrderIDColumn].Value?.ToString() ?? string.Empty;
        string fileRegularExpr = gridOrderProcess.SelectedRows[0].Cells["fileRegularExpr"].Value?.ToString() ?? string.Empty;

        var frmOnDemand = new frmModificaOrderProcess();
        frmOnDemand.OrderId = orderID;
        frmOnDemand.FileRegularExpr = fileRegularExpr;
        frmOnDemand.MIIAOrderProcessSection = configOrderProcess;
        frmOnDemand.config = config;
        UIHelper.ShowFormDialog(frmOnDemand);

        fillGridOrderProcess();
    }

    internal void btnDeleteOrderProcess_Click(object sender, EventArgs e)
    {
        if (gridOrderProcess.Rows.Count == 0)
            return;

        if (UIHelper.ShowMessage(ConfirmationMessage, "ADAM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            return;

        foreach (DataGridViewRow row in gridOrderProcess.SelectedRows)
        {
            configOrderProcess.OrderProcess.Remove(row.Cells[OrderIDColumn].Value?.ToString() ?? string.Empty);
        }

        config.Save();
        fillGridOrderProcess();
    }

    internal void chkEnableTalentDB_CheckedChanged(object sender, EventArgs e)
    {
        grpTalentDBConnection.Enabled = chkEnableTalentDB.Checked;
        RefrescarControlesRetro(grpTalentDBConnection);
    }

    internal void TestTalentDBConnection()
    {
        string usuario = txtUserTalent.Text;
        string password = txtPasswordTalent.Text;
        string server = txtServerTalent.Text;
        string dataBase = txtDatabaseTalent.Text;
        string conString;

        if (cboConnectionType.SelectedValue?.ToString() == "SQL")
        {
            conString = "Server=" + server + ";Database=" + dataBase + ";User Id=" + usuario + ";Password=" + password + ";";
            using var conn = new SqlConnection(conString);

            try
            {
                conn.Open();

                if (conn.State == ConnectionState.Open)
                {
                    UIHelper.ShowMessage("La conexi\u00F3n se realizo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                UIHelper.ShowMessage("Hubo un error en la conexion, erro: " + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            conString = "Data Source=" + dataBase + ";User Id=" + usuario + ";Password=" + password + ";";
            using var conn = new OracleConnection(conString);

            try
            {
                conn.Open();

                if (conn.State == ConnectionState.Open)
                {
                    UIHelper.ShowMessage("La conexi\u00F3n se realizo correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                UIHelper.ShowMessage("Hubo un error en la conexion, erro: " + ex.Message + "\r\n" + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        this.DialogResult = DialogResult.None;
    }

    internal void btnTestConnection_Click(object sender, EventArgs e)
    {
        if (!ValidaCamposTalent())
            return;

        TestTalentDBConnection();
    }

    internal void frmConfiguracion_Resize(object sender, EventArgs e)
    {
        RepositionTalentDBFrame();
    }

    internal void tabParametros_Click(object sender, EventArgs e)
    {
        RepositionTalentDBFrame();
    }

    internal void RepositionTalentDBFrame()
    {
        grpTalentDBConnection.Left = 22;
        grpTalentDBConnection.Top = 29;
    }

    internal void btnSaveTalentDB_Click(object sender, EventArgs e)
    {
        SaveParametersTalentDB();
    }

    internal void cmdRutaResumenEnExcel_Click(object sender, EventArgs e)
    {
        if (txtRutaOrigen.Text != "")
        {
            fbdRuta.SelectedPath = txtRutaResumenEnExcel.Text;
        }

        UIHelper.ShowCommonDialog(fbdRuta);

        if (fbdRuta.SelectedPath.Trim() != "")
        {
            if (!fbdRuta.SelectedPath.EndsWith('\\'))
            {
                txtRutaResumenEnExcel.Text = fbdRuta.SelectedPath + "\\";
            }
            else
            {
                txtRutaResumenEnExcel.Text = fbdRuta.SelectedPath;
            }
        }
    }
    private void AplicarEstiloRetro(Control parent)
    {
        foreach (Control ctrl in parent.Controls)
        {
            if (ctrl is Button btn)
            {
                btn.FlatStyle = FlatStyle.Flat;

                btn.BackColor = Color.FromArgb(227, 237, 239);

                btn.ForeColor = Color.Black;

                btn.Font = new Font("Tahoma", 8.25f);

                btn.FlatAppearance.BorderSize = 0;

                btn.Paint += RetroPaint;
            }
            if (ctrl is TextBox txt)
            {
                if (txt.ReadOnly || !txt.Enabled)
                {
                    AplicarEstiloRetroTextBoxBloqueado(txt);
                }
                else
                {
                    AplicarEstiloRetroTextBox(txt);
                }
            }
            if (ctrl is ComboBox cmb)
            {
                if (!cmb.Enabled)
                {
                    AplicarEstiloRetroComboBoxBloqueado(cmb);
                }
                else
                {
                    AplicarEstiloRetroComboBox(cmb);
                }


            }
            if (ctrl is TabControl tab)
            {
                AplicarEstiloRetroTabControl(tab);
            }

            AplicarEstiloRetro(ctrl);
        }
    }
    private void RetroPaint(object? sender, PaintEventArgs e)
    {
        Button btn = (Button)sender!;

        Rectangle rect = btn.ClientRectangle;

        Color light = Color.White;
        Color dark = Color.Gray;

        e.Graphics.FillRectangle(
            new SolidBrush(Color.FromArgb(227, 237, 239)),
            rect);

        e.Graphics.DrawLine(
            new Pen(light),
            0,
            0,
            rect.Width - 1,
            0);

        e.Graphics.DrawLine(
            new Pen(light),
            0,
            0,
            0,
            rect.Height - 1);

        e.Graphics.DrawLine(
            new Pen(dark),
            0,
            rect.Height - 1,
            rect.Width - 1,
            rect.Height - 1);

        e.Graphics.DrawLine(
            new Pen(dark),
            rect.Width - 1,
            0,
            rect.Width - 1,
            rect.Height - 1);

        TextRenderer.DrawText(
            e.Graphics,
            btn.Text,
            btn.Font,
            rect,
            Color.Black,
            TextFormatFlags.HorizontalCenter |
            TextFormatFlags.VerticalCenter |
            TextFormatFlags.WordBreak);
    }
    private void AplicarEstiloRetroTextBox(TextBox txt)
    {
        if (txt.Parent == null)
            return;

        Control parent = txt.Parent;

        Panel panel = new Panel();

        panel.Location = new Point(txt.Left - 2, txt.Top - 2);

        panel.Size = new Size(txt.Width + 4, txt.Height + 4);

        panel.Anchor = txt.Anchor;

        panel.BackColor = Color.White;

        panel.ForeColor = Color.Black;

        panel.Paint += (s, e) =>
        {
            Rectangle r = panel.ClientRectangle;

            // negro exterior
            e.Graphics.DrawLine(Pens.Black, 0, 0, r.Width - 1, 0);
            e.Graphics.DrawLine(Pens.Black, 0, 0, 0, r.Height - 1);

            // gris interior
            e.Graphics.DrawLine(Pens.Gray, 1, 1, r.Width - 2, 1);
            e.Graphics.DrawLine(Pens.Gray, 1, 1, 1, r.Height - 2);

            // línea clara fina abajo
            e.Graphics.DrawLine(
                Pens.White,
                1,
                r.Height - 1,
                r.Width - 1,
                r.Height - 1);

            // línea clara fina derecha
            e.Graphics.DrawLine(
                Pens.White,
                r.Width - 1,
                1,
                r.Width - 1,
                r.Height - 1);
        };

        txt.BorderStyle = BorderStyle.None;

        txt.Location = new Point(3, 3);

        txt.Width = panel.Width - 6;

        txt.BackColor = Color.White;

        txt.Font = new Font("Tahoma", 8.25f);

        parent.Controls.Add(panel);

        panel.Controls.Add(txt);

        panel.BringToFront();
    }
    private void AplicarEstiloRetroTextBoxBloqueado(TextBox txt)
    {
        if (txt.Parent == null)
            return;

        Control parent = txt.Parent;

        Panel panel = new Panel();

        panel.Location = new Point(txt.Left - 2, txt.Top - 2);

        panel.Size = new Size(txt.Width + 4, txt.Height + 4);

        panel.Anchor = txt.Anchor;

        panel.BackColor = Color.FromArgb(212, 208, 200);

        panel.ForeColor = SystemColors.ControlDarkDark;

        panel.Paint += (s, e) =>
        {
            Rectangle r = panel.ClientRectangle;

            // negro exterior
            e.Graphics.DrawLine(Pens.Black, 0, 0, r.Width - 1, 0);
            e.Graphics.DrawLine(Pens.Black, 0, 0, 0, r.Height - 1);

            // gris interior
            e.Graphics.DrawLine(Pens.Gray, 1, 1, r.Width - 2, 1);
            e.Graphics.DrawLine(Pens.Gray, 1, 1, 1, r.Height - 2);

            // línea clara fina abajo
            e.Graphics.DrawLine(
                Pens.White,
                1,
                r.Height - 1,
                r.Width - 1,
                r.Height - 1);

            // línea clara fina derecha
            e.Graphics.DrawLine(
                Pens.White,
                r.Width - 1,
                1,
                r.Width - 1,
                r.Height - 1);
        };

        txt.BorderStyle = BorderStyle.None;

        txt.Location = new Point(3, 3);

        txt.Width = panel.Width - 6;

        txt.Font = new Font("Tahoma", 8.25f);

        parent.Controls.Add(panel);

        panel.Controls.Add(txt);

        panel.BringToFront();
    }
    private void AplicarEstiloRetroComboBox(ComboBox cbo)
    {
        cbo.FlatStyle = FlatStyle.Flat;

        cbo.BackColor = SystemColors.Window;

        cbo.ForeColor = Color.Black;

        cbo.Font = new Font("Tahoma", 8.25f);

        cbo.DrawMode = DrawMode.OwnerDrawFixed;

        cbo.DropDownStyle = ComboBoxStyle.DropDownList;

        cbo.ItemHeight = 18;

        cbo.DrawItem -= RetroComboBox_DrawItem;
        cbo.DrawItem += RetroComboBox_DrawItem;

        CrearPanelRetroCombo(cbo, false);
    }

    private void AplicarEstiloRetroComboBoxBloqueado(ComboBox cbo)
    {
        cbo.FlatStyle = FlatStyle.Flat;

        cbo.BackColor = SystemColors.Control;

        cbo.ForeColor = SystemColors.GrayText;

        cbo.Font = new Font("Tahoma", 8.25f);

        cbo.DrawMode = DrawMode.OwnerDrawFixed;

        cbo.DropDownStyle = ComboBoxStyle.DropDownList;

        cbo.ItemHeight = 18;

        cbo.DrawItem -= RetroComboBox_DrawItem;
        cbo.DrawItem += RetroComboBox_DrawItem;

        CrearPanelRetroCombo(cbo, true);
    }

    private void CrearPanelRetroCombo(ComboBox cbo, bool bloqueado)
    {
        if (cbo.Parent == null)
            return;

        // evitar aplicar dos veces
        if (cbo.Tag?.ToString() == "RETRO")
            return;

        cbo.Tag = "RETRO";

        Control parent = cbo.Parent;

        Panel panel = new Panel();

        panel.Location = new Point(cbo.Left - 2, cbo.Top - 2);

        panel.Size = new Size(cbo.Width + 4, cbo.Height + 4);

        panel.Anchor = cbo.Anchor;

        panel.BackColor = bloqueado
            ? SystemColors.Control
            : SystemColors.Window;

        panel.Paint += (s, e) =>
        {
            Rectangle r = panel.ClientRectangle;

            r.Width -= 1;
            r.Height -= 1;

            // negro arriba
            e.Graphics.DrawLine(
                Pens.Black,
                0,
                0,
                r.Width,
                0);

            // negro izquierda
            e.Graphics.DrawLine(
                Pens.Black,
                0,
                0,
                0,
                r.Height);

            // gris interior arriba
            e.Graphics.DrawLine(
                Pens.Gray,
                1,
                1,
                r.Width - 1,
                1);

            // gris interior izquierda
            e.Graphics.DrawLine(
                Pens.Gray,
                1,
                1,
                1,
                r.Height - 1);

            // línea blanca fina abajo
            e.Graphics.DrawLine(
                Pens.White,
                1,
                r.Height,
                r.Width,
                r.Height);

            // línea blanca fina derecha
            e.Graphics.DrawLine(
                Pens.White,
                r.Width,
                1,
                r.Width,
                r.Height);
        };

        parent.Controls.Add(panel);

        panel.Controls.Add(cbo);

        cbo.Location = new Point(2, 2);

        cbo.Width = panel.Width - 4;

        cbo.Height = panel.Height - 4;

        // IMPORTANTÍSIMO
        cbo.FlatStyle = FlatStyle.Popup;

        panel.BringToFront();
    }

    private void RetroComboBox_DrawItem(object? sender, DrawItemEventArgs e)
    {
        ComboBox cbo = (ComboBox)sender!;

        e.DrawBackground();

        if (e.Index >= 0)
        {
            string text = "";

            object item = cbo.Items[e.Index];

            // soporte para DataTable/DataSource
            if (item is DataRowView rowView)
            {
                text = rowView[cbo.DisplayMember]?.ToString() ?? "";
            }
            else
            {
                text = item?.ToString() ?? "";
            }

            Color backColor;
            Color textColor;

            if (!cbo.Enabled)
            {
                backColor = SystemColors.Control;

                textColor = SystemColors.GrayText;
            }
            else if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                backColor = SystemColors.Highlight;

                textColor = SystemColors.HighlightText;
            }
            else
            {
                backColor = SystemColors.Window;

                textColor = Color.Black;
            }

            using SolidBrush backBrush = new SolidBrush(backColor);

            e.Graphics.FillRectangle(backBrush, e.Bounds);

            TextRenderer.DrawText(
                e.Graphics,
                text,
                cbo.Font,
                e.Bounds,
                textColor,
                TextFormatFlags.Left |
                TextFormatFlags.VerticalCenter);
        }

        e.DrawFocusRectangle();
    }

    private void RefrescarControlesRetro(Control parent)
    {
        foreach (Control ctrl in parent.Controls)
        {
            // COMBOBOX
            if (ctrl is ComboBox cbo)
            {
                if (cbo.Enabled)
                {
                    cbo.BackColor = SystemColors.Window;

                    cbo.ForeColor = Color.Black;
                }
                else
                {
                    cbo.BackColor = SystemColors.Control;

                    cbo.ForeColor = SystemColors.GrayText;
                }

                if (cbo.Parent is Panel pnl)
                {
                    pnl.BackColor = cbo.Enabled
                        ? SystemColors.Window
                        : SystemColors.Control;

                    pnl.Invalidate();

                    pnl.Refresh();
                }

                cbo.Invalidate();

                cbo.Refresh();
            }

            // TEXTBOX
            if (ctrl is TextBox txt)
            {
                if (txt.Enabled && !txt.ReadOnly)
                {
                    txt.BackColor = SystemColors.Window;

                    txt.ForeColor = Color.Black;
                }
                else
                {
                    txt.BackColor = SystemColors.Control;

                    txt.ForeColor = SystemColors.GrayText;
                }

                txt.Invalidate();

                txt.Refresh();

                txt.Parent?.Invalidate();
            }

            RefrescarControlesRetro(ctrl);
        }
    }
    private void AplicarEstiloRetroTabControl(TabControl tab)
    {
        tab.DrawMode = TabDrawMode.OwnerDrawFixed;

        tab.SizeMode = TabSizeMode.Normal;

        tab.Font = new Font("Tahoma", 8.25f);

        tab.Padding = new Point(12, 4);

        tab.Appearance = TabAppearance.Normal;

        tab.DrawItem -= RetroTab_DrawItem;
        tab.DrawItem += RetroTab_DrawItem;

        foreach (TabPage page in tab.TabPages)
        {
            // mismo color del formulario
            page.BackColor = this.BackColor;

            page.ForeColor = Color.Black;
        }
    }

    private void RetroTab_DrawItem(object? sender, DrawItemEventArgs e)
    {
        TabControl tab = (TabControl)sender!;

        Graphics g = e.Graphics;

        TabPage page = tab.TabPages[e.Index];

        Rectangle rect = tab.GetTabRect(e.Index);

        // mismo color para todas
        Color backColor = SystemColors.Control;

        using SolidBrush brush = new SolidBrush(backColor);

        g.FillRectangle(brush, rect);

        // borde claro arriba
        g.DrawLine(
            Pens.White,
            rect.Left,
            rect.Bottom,
            rect.Left,
            rect.Top);

        g.DrawLine(
            Pens.White,
            rect.Left,
            rect.Top,
            rect.Right,
            rect.Top);

        // borde oscuro derecha
        g.DrawLine(
            Pens.Gray,
            rect.Right,
            rect.Top,
            rect.Right,
            rect.Bottom);

        // borde oscuro abajo
        g.DrawLine(
            Pens.Gray,
            rect.Left,
            rect.Bottom,
            rect.Right,
            rect.Bottom);

        // texto
        Rectangle textRect = rect;

        textRect.Y += 2;

        TextRenderer.DrawText(
            g,
            page.Text,
            tab.Font,
            textRect,
            Color.Black,
            TextFormatFlags.HorizontalCenter |
            TextFormatFlags.VerticalCenter);
    }
    #endregion
}

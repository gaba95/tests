﻿using System.Runtime.InteropServices;

namespace ADAM.Recibos.Utilerias.Helpers
{
    public static class NativeMethods
    {
        [DllImport("kernel32.dll", EntryPoint = "SetThreadExecutionState")]
        private static extern uint NativeSetThreadExecutionState(uint esFlags);
        public const uint ES_CONTINUOUS = 0x80000000;
        public const uint ES_SYSTEM_REQUIRED = 0x00000001;

        [DllImport("user32.dll", EntryPoint = "SystemParametersInfo")]
        private static extern bool NativeSystemParametersInfo(uint uiAction, uint uiParam, ref uint pvParam, uint fWinIni);
        public const uint SPI_SETSCREENSAVEACTIVE = 0x0011;
        public const int SPI_GETSCREENSAVERACTIVE = 16;
        public const int SPIF_SENDWININICHANGE = 2;

        private const uint KnownExecutionStateFlags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED;

        public static uint SetThreadExecutionState(uint esFlags)
        {
            if ((esFlags & ~KnownExecutionStateFlags) != 0)
                throw new System.ArgumentException($"Unknown flags: 0x{esFlags:X8}", nameof(esFlags));

            return NativeSetThreadExecutionState(esFlags);
        }

        public static bool SystemParametersInfo(uint uiAction, uint uiParam, ref uint pvParam, uint fWinIni)
        {
            if (uiAction == 0)
                throw new System.ArgumentException("uiAction must not be zero.", nameof(uiAction));

            return NativeSystemParametersInfo(uiAction, uiParam, ref pvParam, fWinIni);
        }
    }
}

﻿using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Helpers
{

    [TestClass]
    public static class TestServer
    {
        private static IHost? _host;
        private static string? _url;
        private static string? _externalUrl;

        public static string Url
            => EnsureTrailingSlash(_url ?? throw new InvalidOperationException("Test server URL not initialized."));

        public static string ExternalUrl
            => EnsureTrailingSlash(_externalUrl ?? throw new InvalidOperationException("External URL not available."));

        public static IHost TestHost => _host ?? throw new InvalidOperationException("Test server host not initialized.");

        [AssemblyInitialize]
        public static async Task AssemblyInitialize(TestContext _)
        {
            _host = Host.CreateDefaultBuilder()
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseKestrel();
                    webBuilder.UseUrls("http://*:0");
                    webBuilder.Configure(app =>
                    {
                        // Handle URL-encoded paths (from UrlEncoder.Default.Encode in getDocumentState)
                        app.Use(async (ctx, next) =>
                        {
                            var decodedPath = Uri.UnescapeDataString(ctx.Request.Path.Value ?? "");
                            if (ctx.Request.Method == "POST" && decodedPath.Contains("EstadoDocumentoNomina"))
                            {
                                var auth = ctx.Request.Headers["Authorization"].ToString();
                                if (auth.Contains("fail"))
                                {
                                    ctx.Response.StatusCode = 500;
                                    ctx.Response.Headers["Content-Type"] = "text/plain";
                                    await ctx.Response.WriteAsync("Internal Server Error");
                                    return;
                                }

                                ctx.Response.StatusCode = 200;
                                ctx.Response.Headers["Content-Type"] = "application/json";
                                await ctx.Response.WriteAsync(System.Text.Json.JsonSerializer.Serialize(new
                                {
                                    estadoDocumento = "ACEPTADO",
                                    fechaGeneracion = DateTime.UtcNow,
                                    cune = "CUNE-TEST",
                                    numeroDocumento = "DOC-1",
                                    dianErrors = Array.Empty<object>()
                                }));
                                return;
                            }
                            await next();
                        });

                        app.UseRouting();

                        app.UseEndpoints(endpoints =>
                        {
                            endpoints.MapGet("/api/security/login", () => Results.Ok(new { ping = true }));

                            endpoints.MapPost("/api/security/login", (LoginRequest req) =>
                            {
                                if (req?.login == "badTest")
                                    return Results.Unauthorized();
                                return Results.Ok(new
                                {
                                    type = "OK",
                                    validationMessage = (string?)null,
                                    content = new { jwt = "jwt-token-from-test-server" }
                                });
                            });

                            endpoints.MapPost("/api/Nomina/AgregarNomina", (HttpContext ctx) =>
                            {
                                var auth = ctx.Request.Headers["Authorization"].ToString();
                                if (auth.Contains("fail"))
                                    return Results.StatusCode(500);

                                return Results.Ok(new
                                {
                                    message = "OK",
                                    errores = new { },
                                    notificaciones = Array.Empty<object>()
                                });
                            });

                            endpoints.MapPost("/api/Nomina/EstadoDocumentoNomina", (HttpContext ctx) =>
                            {
                                var auth = ctx.Request.Headers["Authorization"].ToString();
                                if (auth.Contains("fail"))
                                    return Results.StatusCode(500);

                                return Results.Ok(new
                                {
                                    estadoDocumento = "ACEPTADO",
                                    fechaGeneracion = DateTime.UtcNow,
                                    cune = "CUNE-TEST",
                                    numeroDocumento = "DOC-1",
                                    dianErrors = Array.Empty<object>()
                                });
                            });
                        });



                    });
                })
                .Build();

            await _host.StartAsync();

            var addressesFeature = _host.Services
                .GetService(typeof(Microsoft.AspNetCore.Hosting.Server.IServer)) is Microsoft.AspNetCore.Hosting.Server.IServer server
                ? server.Features.Get<IServerAddressesFeature>()
                : null;

            var rawUrl = addressesFeature is null || addressesFeature.Addresses is null
                ? null
                : new System.Collections.Generic.List<string>(addressesFeature.Addresses)[0];

            if (string.IsNullOrWhiteSpace(rawUrl))
            {
                throw new InvalidOperationException("Failed to start test server and resolve URL.");
            }

            var uri = new Uri(rawUrl);
            _url = $"http://127.0.0.1:{uri.Port}";

            try
            {
                var hostEntry = Dns.GetHostEntry(Dns.GetHostName());
                var lanIp = hostEntry.AddressList.FirstOrDefault(
                    a => a.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a));
                if (lanIp != null)
                    _externalUrl = $"http://{lanIp}:{uri.Port}";
            }
            catch { }
        }

        public static SecureString ToSecureString(string value)
        {
            var ss = new SecureString();
            foreach (var c in value)
                ss.AppendChar(c);
            ss.MakeReadOnly();
            return ss;
        }

        public static T GetExt<T>(Dictionary<string, object> ext, string key)
        {
            var value = ext[key];

            if (value is JToken token)
                return token.ToObject<T>();

            return (T)Convert.ChangeType(value, typeof(T));
        }

        [AssemblyCleanup]
        public static async Task AssemblyCleanup()
        {
            if (_host is not null)
            {
                await _host.StopAsync();
                _host.Dispose();
            }
        }

        private static string EnsureTrailingSlash(string url)
            => url.EndsWith("/", StringComparison.Ordinal) ? url : url + "/";
    }
}

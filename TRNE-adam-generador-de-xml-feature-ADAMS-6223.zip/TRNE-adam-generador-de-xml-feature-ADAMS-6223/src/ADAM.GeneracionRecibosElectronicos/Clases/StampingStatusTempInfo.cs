﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases
{
    class StampingStatusTempInfo
    {
        public string CompanyRFC
        {
            set;
            get;
        }

        public string PayrollType
        {
            set;
            get;
        }

        public string PayrollClass
        {
            set;
            get;
        }

        public string Year
        {
            set;
            get;
        }

        public string Periods
        {
            set;
            get;
        }

        public string ReceiptVersion
        {
            set;
            get;
        }


    }
}

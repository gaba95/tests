﻿namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    public enum DianResponseStatus
    {
        NotValid,
        Correcto,
        Incorrecto
    }
}

using ADAM.Recibos.Hangfire.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.Recibos.Hangfire.Tests.Models
{
    [TestClass]
    public class EmployeeRequestTests
    {
        [TestMethod]
        public void EmployeeRequest_Properties_SetAndGetCorrectly()
        {
            var employees = new List<EmployeeInfo>
            {
                new EmployeeInfo { Compania = "01", Trabajador = "100" }
            };

            var request = new EmployeeRequest
            {
                Culture = "es-MX",
                Country = "MX",
                ProcessId = "proc-001",
                TotalEmployees = "5",
                Employees = employees
            };

            Assert.AreEqual("es-MX", request.Culture);
            Assert.AreEqual("MX", request.Country);
            Assert.AreEqual("proc-001", request.ProcessId);
            Assert.AreEqual("5", request.TotalEmployees);
            Assert.AreEqual(1, request.Employees.Count);
            Assert.AreEqual("01", request.Employees[0].Compania);
        }

        [TestMethod]
        public void EmployeeRequest_Serialization_RoundTrip()
        {
            var request = new EmployeeRequest
            {
                Culture = "es-CO",
                Country = "CO",
                ProcessId = "abc-123",
                TotalEmployees = "2",
                Employees = new List<EmployeeInfo>
                {
                    new EmployeeInfo
                    {
                        Compania = "01",
                        TipoNomina = "Q",
                        ClaseNomina = "N",
                        Anio = "2026",
                        Periodo = "1",
                        Trabajador = "EMP001",
                        NumeroLiquidacion = "1",
                        ManejoNomina = "1"
                    }
                }
            };

            var json = JsonConvert.SerializeObject(request);
            var deserialized = JsonConvert.DeserializeObject<EmployeeRequest>(json);

            Assert.IsNotNull(deserialized);
            Assert.AreEqual("es-CO", deserialized!.Culture);
            Assert.AreEqual("CO", deserialized.Country);
            Assert.AreEqual("abc-123", deserialized.ProcessId);
            Assert.AreEqual("2", deserialized.TotalEmployees);
            Assert.AreEqual(1, deserialized.Employees.Count);
        }

        [TestMethod]
        public void EmployeeRequest_JsonPropertyNames_AreCorrect()
        {
            var request = new EmployeeRequest
            {
                Culture = "en-US",
                Country = "US",
                ProcessId = "p1",
                TotalEmployees = "0",
                Employees = new List<EmployeeInfo>()
            };

            var json = JsonConvert.SerializeObject(request);

            Assert.IsTrue(json.Contains("\"Culture\""));
            Assert.IsTrue(json.Contains("\"country\""));
            Assert.IsTrue(json.Contains("\"processId\""));
            Assert.IsTrue(json.Contains("\"totalEmployees\""));
            Assert.IsTrue(json.Contains("\"Employees\""));
        }

        [TestMethod]
        public void EmployeeRequest_DefaultValues_AreNull()
        {
            var request = new EmployeeRequest();

            Assert.IsNull(request.Culture);
            Assert.IsNull(request.Country);
            Assert.IsNull(request.ProcessId);
            Assert.IsNull(request.TotalEmployees);
            Assert.IsNull(request.Employees);
        }
    }
}

﻿namespace ADAM.Recibos.Principal.Enums
{
    public static class XsdTemplates
    {
        public static readonly IReadOnlyDictionary<string, string> xsdWhiteList = new Dictionary<string, string>
        {
            { "catCFDI.xsd", "catCFDI.xsd" },
            { "catNomina.xsd", "catNomina.xsd" },
            { "cfdv40.xsd", "cfdv40.xsd" },
            { "tdCFDI.xsd", "tdCFDI.xsd" },
            { "nomina12.xsd", "nomina12.xsd" },
            { "nomina12_40ADAM.xsd", "nomina12_40ADAM.xsd" },
            { "nomina12_40ADAM_ext.xsd", "nomina12_40ADAM_ext.xsd" }
        };
    }
}

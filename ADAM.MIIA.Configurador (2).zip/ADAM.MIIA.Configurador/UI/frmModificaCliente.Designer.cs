#nullable enable
namespace ADAM.MIIA.Configurador.UI;

partial class frmModificaCliente
{
    private System.ComponentModel.IContainer? components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmModificaCliente));
        cmdAceptar = new Button();
        cmdCancelar = new Button();
        pnlBotones = new Panel();
        txtDescripcion = new TextBox();
        pnlSuperior = new Panel();
        lblTitulo = new Label();
        lblDescripcion = new Label();
        txtClaveCliente = new TextBox();
        lblClaveCliente = new Label();
        txtUsuario = new TextBox();
        lblUsuario = new Label();
        txtPassword = new TextBox();
        lblPassword = new Label();
        lblHoraInicio = new Label();
        lblHoraFin = new Label();
        lblCorreoDe = new Label();
        lblCorreoPara = new Label();
        cmdProbar = new Button();
        dtpHoraInicio = new DateTimePicker();
        txtCorreoDe = new TextBox();
        txtCorreoPara = new TextBox();
        dtpHoraFin = new DateTimePicker();
        lblServidor = new Label();
        lblBase = new Label();
        txtServidor = new TextBox();
        txtBase = new TextBox();
        Label1 = new Label();
        cboTipoCon = new ComboBox();
        chkIdiomaIngles = new CheckBox();
        chkIdiomaEspaniol = new CheckBox();
        Label5 = new Label();
        Label2 = new Label();
        chkActivarResumenEnExcel = new CheckBox();
        pnlBotones.SuspendLayout();
        pnlSuperior.SuspendLayout();
        SuspendLayout();
        // 
        // cmdAceptar
        // 
        cmdAceptar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdAceptar.DialogResult = DialogResult.Cancel;
        cmdAceptar.FlatStyle = FlatStyle.Popup;
        cmdAceptar.Location = new Point(258, 2);
        cmdAceptar.Name = "cmdAceptar";
        cmdAceptar.Size = new Size(124, 35);
        cmdAceptar.TabIndex = 0;
        cmdAceptar.Text = "Guardar";
        cmdAceptar.UseVisualStyleBackColor = true;
        cmdAceptar.Click += cmdAceptar_Click;
        // 
        // cmdCancelar
        // 
        cmdCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdCancelar.DialogResult = DialogResult.Cancel;
        cmdCancelar.FlatStyle = FlatStyle.Popup;
        cmdCancelar.Location = new Point(388, 2);
        cmdCancelar.Name = "cmdCancelar";
        cmdCancelar.Size = new Size(124, 35);
        cmdCancelar.TabIndex = 1;
        cmdCancelar.Text = "Cerrar";
        cmdCancelar.UseVisualStyleBackColor = true;
        // 
        // pnlBotones
        // 
        pnlBotones.BackColor = Color.Transparent;
        pnlBotones.Controls.Add(cmdCancelar);
        pnlBotones.Controls.Add(cmdAceptar);
        pnlBotones.Dock = DockStyle.Bottom;
        pnlBotones.Location = new Point(0, 478);
        pnlBotones.Name = "pnlBotones";
        pnlBotones.Size = new Size(522, 40);
        pnlBotones.TabIndex = 26;
        // 
        // txtDescripcion
        // 
        txtDescripcion.BorderStyle = BorderStyle.FixedSingle;
        txtDescripcion.Location = new Point(167, 80);
        txtDescripcion.MaxLength = 100;
        txtDescripcion.Name = "txtDescripcion";
        txtDescripcion.Size = new Size(233, 28);
        txtDescripcion.TabIndex = 4;
        // 
        // pnlSuperior
        // 
        pnlSuperior.BackColor = Color.FromArgb(92, 145, 163);
        pnlSuperior.Controls.Add(lblTitulo);
        pnlSuperior.Dock = DockStyle.Top;
        pnlSuperior.Location = new Point(0, 0);
        pnlSuperior.Name = "pnlSuperior";
        pnlSuperior.Size = new Size(522, 30);
        pnlSuperior.TabIndex = 0;
        // 
        // lblTitulo
        // 
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Trebuchet MS", 10.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
        lblTitulo.ForeColor = Color.White;
        lblTitulo.Location = new Point(10, 5);
        lblTitulo.Name = "lblTitulo";
        lblTitulo.Size = new Size(258, 27);
        lblTitulo.TabIndex = 0;
        lblTitulo.Text = "Configuración por cliente";
        // 
        // lblDescripcion
        // 
        lblDescripcion.AutoSize = true;
        lblDescripcion.Location = new Point(10, 80);
        lblDescripcion.Name = "lblDescripcion";
        lblDescripcion.Size = new Size(110, 23);
        lblDescripcion.TabIndex = 3;
        lblDescripcion.Text = "Descripción:";
        // 
        // txtClaveCliente
        // 
        txtClaveCliente.BorderStyle = BorderStyle.FixedSingle;
        txtClaveCliente.Location = new Point(167, 50);
        txtClaveCliente.MaxLength = 50;
        txtClaveCliente.Name = "txtClaveCliente";
        txtClaveCliente.Size = new Size(233, 28);
        txtClaveCliente.TabIndex = 2;
        // 
        // lblClaveCliente
        // 
        lblClaveCliente.AutoSize = true;
        lblClaveCliente.Location = new Point(10, 50);
        lblClaveCliente.Name = "lblClaveCliente";
        lblClaveCliente.Size = new Size(154, 23);
        lblClaveCliente.TabIndex = 1;
        lblClaveCliente.Text = "Clave del Cliente:";
        // 
        // txtUsuario
        // 
        txtUsuario.BorderStyle = BorderStyle.FixedSingle;
        txtUsuario.Location = new Point(167, 140);
        txtUsuario.MaxLength = 200;
        txtUsuario.Name = "txtUsuario";
        txtUsuario.Size = new Size(233, 28);
        txtUsuario.TabIndex = 10;
        // 
        // lblUsuario
        // 
        lblUsuario.AutoSize = true;
        lblUsuario.Location = new Point(10, 140);
        lblUsuario.Name = "lblUsuario";
        lblUsuario.Size = new Size(77, 23);
        lblUsuario.TabIndex = 9;
        lblUsuario.Text = "Usuario:";
        // 
        // txtPassword
        // 
        txtPassword.BorderStyle = BorderStyle.FixedSingle;
        txtPassword.Location = new Point(167, 170);
        txtPassword.MaxLength = 200;
        txtPassword.Name = "txtPassword";
        txtPassword.Size = new Size(233, 28);
        txtPassword.TabIndex = 12;
        txtPassword.UseSystemPasswordChar = true;
        // 
        // lblPassword
        // 
        lblPassword.AutoSize = true;
        lblPassword.Location = new Point(10, 170);
        lblPassword.Name = "lblPassword";
        lblPassword.Size = new Size(89, 23);
        lblPassword.TabIndex = 11;
        lblPassword.Text = "Password:";
        // 
        // lblHoraInicio
        // 
        lblHoraInicio.AutoSize = true;
        lblHoraInicio.Location = new Point(10, 297);
        lblHoraInicio.Name = "lblHoraInicio";
        lblHoraInicio.Size = new Size(104, 23);
        lblHoraInicio.TabIndex = 18;
        lblHoraInicio.Text = "Hora inicio:";
        // 
        // lblHoraFin
        // 
        lblHoraFin.AutoSize = true;
        lblHoraFin.Location = new Point(10, 327);
        lblHoraFin.Name = "lblHoraFin";
        lblHoraFin.Size = new Size(82, 23);
        lblHoraFin.TabIndex = 20;
        lblHoraFin.Text = "Hora fin:";
        // 
        // lblCorreoDe
        // 
        lblCorreoDe.AutoSize = true;
        lblCorreoDe.Location = new Point(10, 357);
        lblCorreoDe.Name = "lblCorreoDe";
        lblCorreoDe.Size = new Size(97, 23);
        lblCorreoDe.TabIndex = 22;
        lblCorreoDe.Text = "Correo de:";
        // 
        // lblCorreoPara
        // 
        lblCorreoPara.AutoSize = true;
        lblCorreoPara.Location = new Point(10, 387);
        lblCorreoPara.Name = "lblCorreoPara";
        lblCorreoPara.Size = new Size(112, 23);
        lblCorreoPara.TabIndex = 24;
        lblCorreoPara.Text = "Correo para:";
        // 
        // cmdProbar
        // 
        cmdProbar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cmdProbar.DialogResult = DialogResult.Cancel;
        cmdProbar.FlatStyle = FlatStyle.Popup;
        cmdProbar.Location = new Point(410, 237);
        cmdProbar.Name = "cmdProbar";
        cmdProbar.Size = new Size(100, 60);
        cmdProbar.TabIndex = 17;
        cmdProbar.Text = "Probar Conexiones";
        cmdProbar.UseVisualStyleBackColor = true;
        cmdProbar.Click += cmdProbar_Click;
        // 
        // dtpHoraInicio
        // 
        dtpHoraInicio.CustomFormat = "HH:mm";
        dtpHoraInicio.Format = DateTimePickerFormat.Custom;
        dtpHoraInicio.Location = new Point(167, 297);
        dtpHoraInicio.Name = "dtpHoraInicio";
        dtpHoraInicio.ShowUpDown = true;
        dtpHoraInicio.Size = new Size(97, 28);
        dtpHoraInicio.TabIndex = 19;
        dtpHoraInicio.Value = new DateTime(2015, 2, 27, 13, 6, 0, 0);
        // 
        // txtCorreoDe
        // 
        txtCorreoDe.BorderStyle = BorderStyle.FixedSingle;
        txtCorreoDe.Location = new Point(167, 357);
        txtCorreoDe.MaxLength = 50;
        txtCorreoDe.Name = "txtCorreoDe";
        txtCorreoDe.Size = new Size(233, 28);
        txtCorreoDe.TabIndex = 23;
        // 
        // txtCorreoPara
        // 
        txtCorreoPara.BorderStyle = BorderStyle.FixedSingle;
        txtCorreoPara.Location = new Point(167, 387);
        txtCorreoPara.MaxLength = 50;
        txtCorreoPara.Name = "txtCorreoPara";
        txtCorreoPara.Size = new Size(233, 28);
        txtCorreoPara.TabIndex = 25;
        // 
        // dtpHoraFin
        // 
        dtpHoraFin.CustomFormat = "HH:mm";
        dtpHoraFin.Format = DateTimePickerFormat.Custom;
        dtpHoraFin.Location = new Point(167, 327);
        dtpHoraFin.Name = "dtpHoraFin";
        dtpHoraFin.ShowUpDown = true;
        dtpHoraFin.Size = new Size(97, 28);
        dtpHoraFin.TabIndex = 21;
        dtpHoraFin.Value = new DateTime(2015, 2, 27, 13, 6, 0, 0);
        // 
        // lblServidor
        // 
        lblServidor.AutoSize = true;
        lblServidor.Location = new Point(10, 237);
        lblServidor.Name = "lblServidor";
        lblServidor.Size = new Size(84, 23);
        lblServidor.TabIndex = 13;
        lblServidor.Text = "Servidor:";
        // 
        // lblBase
        // 
        lblBase.AutoSize = true;
        lblBase.Location = new Point(11, 267);
        lblBase.Name = "lblBase";
        lblBase.Size = new Size(127, 23);
        lblBase.TabIndex = 15;
        lblBase.Text = "Base de Datos:";
        // 
        // txtServidor
        // 
        txtServidor.BorderStyle = BorderStyle.FixedSingle;
        txtServidor.Location = new Point(167, 237);
        txtServidor.MaxLength = 200;
        txtServidor.Name = "txtServidor";
        txtServidor.Size = new Size(233, 28);
        txtServidor.TabIndex = 14;
        // 
        // txtBase
        // 
        txtBase.BorderStyle = BorderStyle.FixedSingle;
        txtBase.Location = new Point(167, 267);
        txtBase.MaxLength = 200;
        txtBase.Name = "txtBase";
        txtBase.Size = new Size(233, 28);
        txtBase.TabIndex = 16;
        // 
        // Label1
        // 
        Label1.AutoSize = true;
        Label1.Location = new Point(11, 202);
        Label1.Name = "Label1";
        Label1.Size = new Size(131, 23);
        Label1.TabIndex = 27;
        Label1.Text = "Tipo Conexión:";
        // 
        // cboTipoCon
        // 
        cboTipoCon.FlatStyle = FlatStyle.Popup;
        cboTipoCon.FormattingEnabled = true;
        cboTipoCon.Location = new Point(168, 202);
        cboTipoCon.Name = "cboTipoCon";
        cboTipoCon.Size = new Size(183, 31);
        cboTipoCon.TabIndex = 28;
        cboTipoCon.SelectedValueChanged += cboTipoCon_SelectedValueChanged;
        // 
        // chkIdiomaIngles
        // 
        chkIdiomaIngles.AutoSize = true;
        chkIdiomaIngles.FlatStyle = FlatStyle.Popup;
        chkIdiomaIngles.Location = new Point(272, 417);
        chkIdiomaIngles.Name = "chkIdiomaIngles";
        chkIdiomaIngles.Size = new Size(78, 27);
        chkIdiomaIngles.TabIndex = 52;
        chkIdiomaIngles.Text = "Ingles";
        chkIdiomaIngles.UseVisualStyleBackColor = true;
        // 
        // chkIdiomaEspaniol
        // 
        chkIdiomaEspaniol.AutoSize = true;
        chkIdiomaEspaniol.FlatStyle = FlatStyle.Popup;
        chkIdiomaEspaniol.Location = new Point(167, 417);
        chkIdiomaEspaniol.Name = "chkIdiomaEspaniol";
        chkIdiomaEspaniol.Size = new Size(93, 27);
        chkIdiomaEspaniol.TabIndex = 51;
        chkIdiomaEspaniol.Text = "Español";
        chkIdiomaEspaniol.UseVisualStyleBackColor = true;
        // 
        // Label5
        // 
        Label5.BackColor = Color.Transparent;
        Label5.Location = new Point(12, 418);
        Label5.Name = "Label5";
        Label5.Size = new Size(148, 18);
        Label5.TabIndex = 50;
        Label5.Text = "Idioma de Notificaciones:";
        // 
        // Label2
        // 
        Label2.BackColor = Color.Transparent;
        Label2.Location = new Point(12, 447);
        Label2.Name = "Label2";
        Label2.Size = new Size(148, 18);
        Label2.TabIndex = 53;
        Label2.Text = "Resumen en Excel:";
        // 
        // chkActivarResumenEnExcel
        // 
        chkActivarResumenEnExcel.AutoSize = true;
        chkActivarResumenEnExcel.FlatStyle = FlatStyle.Popup;
        chkActivarResumenEnExcel.Location = new Point(166, 446);
        chkActivarResumenEnExcel.Name = "chkActivarResumenEnExcel";
        chkActivarResumenEnExcel.Size = new Size(245, 27);
        chkActivarResumenEnExcel.TabIndex = 54;
        chkActivarResumenEnExcel.Text = "Activar (si está disponible)";
        chkActivarResumenEnExcel.UseVisualStyleBackColor = true;
        // 
        // frmModificaCliente
        // 
        AcceptButton = cmdAceptar;
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(227, 237, 239);
        CancelButton = cmdCancelar;
        ClientSize = new Size(522, 518);
        Controls.Add(chkActivarResumenEnExcel);
        Controls.Add(Label2);
        Controls.Add(chkIdiomaIngles);
        Controls.Add(chkIdiomaEspaniol);
        Controls.Add(Label5);
        Controls.Add(cboTipoCon);
        Controls.Add(Label1);
        Controls.Add(txtBase);
        Controls.Add(txtServidor);
        Controls.Add(lblBase);
        Controls.Add(lblServidor);
        Controls.Add(dtpHoraFin);
        Controls.Add(txtCorreoPara);
        Controls.Add(txtCorreoDe);
        Controls.Add(dtpHoraInicio);
        Controls.Add(cmdProbar);
        Controls.Add(lblCorreoPara);
        Controls.Add(lblCorreoDe);
        Controls.Add(lblHoraFin);
        Controls.Add(lblHoraInicio);
        Controls.Add(txtPassword);
        Controls.Add(lblPassword);
        Controls.Add(txtUsuario);
        Controls.Add(lblUsuario);
        Controls.Add(pnlBotones);
        Controls.Add(txtDescripcion);
        Controls.Add(pnlSuperior);
        Controls.Add(lblDescripcion);
        Controls.Add(txtClaveCliente);
        Controls.Add(lblClaveCliente);
        Font = new Font("Trebuchet MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        Icon = (Icon)resources.GetObject("$this.Icon");
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "frmModificaCliente";
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Modifica Cliente";
        Load += frmModificaCliente_Load;
        pnlBotones.ResumeLayout(false);
        pnlSuperior.ResumeLayout(false);
        pnlSuperior.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    private Button cmdAceptar;
    private Button cmdCancelar;
    private Panel pnlBotones;
    private TextBox txtDescripcion;
    private Panel pnlSuperior;
    private Label lblTitulo;
    private Label lblDescripcion;
    private TextBox txtClaveCliente;
    private Label lblClaveCliente;
    private TextBox txtUsuario;
    private Label lblUsuario;
    private TextBox txtPassword;
    private Label lblPassword;
    private Label lblHoraInicio;
    private Label lblHoraFin;
    private Label lblCorreoDe;
    private Label lblCorreoPara;
    private Button cmdProbar;
    internal DateTimePicker dtpHoraInicio;
    private TextBox txtCorreoDe;
    private TextBox txtCorreoPara;
    internal DateTimePicker dtpHoraFin;
    private Label lblServidor;
    private Label lblBase;
    private TextBox txtServidor;
    private TextBox txtBase;
    private Label Label1;
    internal ComboBox cboTipoCon;
    internal CheckBox chkIdiomaIngles;
    internal CheckBox chkIdiomaEspaniol;
    private Label Label5;
    private Label Label2;
    internal CheckBox chkActivarResumenEnExcel;
}

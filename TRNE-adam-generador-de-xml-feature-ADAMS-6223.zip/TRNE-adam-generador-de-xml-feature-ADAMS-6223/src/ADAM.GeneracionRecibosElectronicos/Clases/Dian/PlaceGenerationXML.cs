﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{    
    [JsonObject("LugarGeneracionXML", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PlaceGenerationXML
    {
        public string Pais { get; set; }
        public string DepartamentoEstado { get; set; }
        public string MunicipioCiudad { get; set; }
        public string Idioma { get; set; }
    }
}

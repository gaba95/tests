﻿namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    public enum ConditionalOperator
    {
        And = 1,
        Or = 2
    }
}

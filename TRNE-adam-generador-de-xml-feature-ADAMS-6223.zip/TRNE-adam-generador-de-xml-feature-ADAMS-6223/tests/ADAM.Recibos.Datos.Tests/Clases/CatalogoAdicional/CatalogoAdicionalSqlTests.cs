using Moq;
using System;
using System.Data;
using System.Data.Common;
using System.Reflection;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Datos.Utils;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;
using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoAdicional
{
    [TestClass]
    public class CatalogoAdicionalSqlTests
    {
        #region Constructor & Basic Tests

        [TestMethod]
        public void Constructor_ShouldStoreFactoryAndCallCreateConnection()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            // Act
            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Assert
            Assert.IsNotNull(service);
            mockFactory.Verify(f => f.CreateConnection(), Times.Once());
        }

        [TestMethod]
        public void CheckDbConnection_ShouldReturnTrue_WhenConnectionIsAvailable()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act
            var result = service.CheckDbConnection();

            // Assert
            Assert.IsTrue(result);
            mockFactory.Verify(f => f.CheckConnection(), Times.Once());
        }

        [TestMethod]
        public void CheckDbConnection_ShouldReturnFalse_WhenConnectionIsNotAvailable()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(false);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act
            var result = service.CheckDbConnection();

            // Assert
            Assert.IsFalse(result);
        }

        #endregion

        #region Interface & Structure Tests

        [TestMethod]
        public void ClassShouldImplementInterface_ICatalogoAdicional()
        {
            // Arrange
            var serviceType = typeof(CatalogoAdicionalSql);

            // Act
            var implementsInterface = typeof(ICatalogoAdicional).IsAssignableFrom(serviceType);

            // Assert
            Assert.IsTrue(implementsInterface, "Debe implementar ICatalogoAdicional");
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTrabajadoresRecibo()
        {
            // Arrange
            var type = typeof(CatalogoAdicionalSql);

            // Act
            var method = type.GetMethod("obtenDatasetTrabajadoresRecibo");

            // Assert
            Assert.IsNotNull(method, "Debe existir el método obtenDatasetTrabajadoresRecibo");
            Assert.AreEqual(typeof(DataSet), method.ReturnType, "Debe retornar DataSet");
            Assert.AreEqual(6, method.GetParameters().Length, "Debe tener 6 parámetros");
        }

        [TestMethod]
        public void ShouldContainMethod_obtenCompaniasIdiomas()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenCompaniasIdiomas");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(string), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetCompanias()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetCompanias");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(1, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_existeTablaConfiguracion()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("existeTablaConfiguracion");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_DeletePayslipsData()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("DeletePayslipsData");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(6, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenConfiguracionCompania()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenConfiguracionCompania");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_GuardaConfiguracionCompania()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("GuardaConfiguracionCompania");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(void), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetClasesNomina()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetClasesNomina");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTiposNomina()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetTiposNomina");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenBasesDisponibles()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenBasesDisponibles");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenListaPeriodosMes()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenListaPeriodosMes");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTiposPercepcionDeduccion()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetTiposPercepcionDeduccion");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetDescripcionTipos()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetDescripcionTipos");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetRelacionConceptos()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetRelacionConceptos");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetConceptosRelacionar()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetConceptosRelacionar");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
            Assert.AreEqual(2, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_AltaRelacionConcepto()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("AltaRelacionConcepto");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_BajaRelacionConcepto()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("BajaRelacionConcepto");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetTrabajadoresRegimen()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetTrabajadoresRegimen");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetRegimen()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetRegimen");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_AltaRelacionRegimen()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("AltaRelacionRegimen");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(3, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenDatasetFormaPago()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenDatasetFormaPago");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_ReadCSD()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("ReadCSD");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_CreateReplaceCSD()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("CreateReplaceCSD");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
            Assert.AreEqual(4, method.GetParameters().Length);
        }

        [TestMethod]
        public void ShouldContainMethod_DeleteCSD()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("DeleteCSD");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(bool), method.ReturnType);
        }

        [TestMethod]
        public void ShouldContainMethod_obtenParametrosCompania()
        {
            var method = typeof(CatalogoAdicionalSql).GetMethod("obtenParametrosCompania");
            Assert.IsNotNull(method);
            Assert.AreEqual(typeof(DataSet), method.ReturnType);
        }

        #endregion

        #region obtenDatasetTrabajadoresRecibo Tests

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_ShouldReturnDataSet_WithCorrectTableName()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            var result = service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("Table", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_ShouldConfigureStoredProcedureParameters()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica);

            // Assert – SP should set 6 parameters: compania, tipo_nomina, clase_nomina, anio, periodo, manejo_nomina
            mockCommand.Verify(c => c.CreateParameter(), Times.Exactly(6));
            mockCommand.Verify(c => c.ExecuteReader(), Times.Once());
        }

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_ShouldConfigureCommandAsStoredProcedure()
        {
            // Arrange
            var (service, mockCommand) = CreateServiceWithFullMockDB();

            // Act
            service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.interactiva);

            // Assert
            Assert.AreEqual("sp_trabajadores_recibo_sat", mockCommand.Object.CommandText);
            Assert.AreEqual(CommandType.StoredProcedure, mockCommand.Object.CommandType);
        }

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_ShouldRetry_OnConnectionFailure()
        {
            // Arrange
            int callCount = 0;
            var mockReader = new Mock<IDataReader>();
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.GetSchemaTable()).Returns(new DataTable());

            var mockCommand = CreateMockCommand(mockReader);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            // First call in constructor, subsequent calls from method
            mockFactory.Setup(f => f.CreateConnection()).Returns(() =>
            {
                callCount++;
                // First call is from constructor, second fails, third succeeds
                if (callCount == 2)
                    throw new Exception("Connection failed");
                return mockConnection.Object;
            });

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act
            var result = service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void ObtenDatasetTrabajadoresRecibo_ShouldThrow_AfterMaxRetries()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            failingConnection.Setup(c => c.CreateCommand()).Throws(new Exception("DB error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act & Assert
            Assert.Throws<Exception>(() =>
            {
                service.obtenDatasetTrabajadoresRecibo("COMP", "TN", "CN", 2026, 1, ManejoNomina.periodica);
            });
        }

        #endregion

        #region obtenCompaniasIdiomas Tests

        [TestMethod]
        public void ObtenCompaniasIdiomas_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenCompaniasIdiomas());
        }

        #endregion

        #region obtenDatasetCompanias Tests

        [TestMethod]
        public void ObtenDatasetCompanias_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetCompanias("es-MX"));
        }

        #endregion

        #region existeTablaConfiguracion Tests

        [TestMethod]
        public void ExisteTablaConfiguracion_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.existeTablaConfiguracion());
        }

        #endregion

        #region DeletePayslipsData Tests

        [TestMethod]
        public void DeletePayslipsData_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() =>
                service.DeletePayslipsData("COMP", "TN", "CN", 2026, 1, "EMP001"));
        }

        #endregion

        #region obtenConfiguracionCompania Tests

        [TestMethod]
        public void ObtenConfiguracionCompania_ShouldReturnNull_WhenTableNotExists()
        {
            // Arrange
            var mockCommand = new Mock<DbCommand>();
            mockCommand.Setup(c => c.ExecuteScalar()).Returns(0);
            mockCommand.As<IDbCommand>().Setup(c => c.Prepare());
            mockCommand.As<IDbCommand>().Setup(c => c.Parameters).Returns(new Mock<IDataParameterCollection>().Object);
            mockCommand.As<IDbCommand>().Setup(c => c.CreateParameter()).Returns(new Mock<IDbDataParameter>().Object);

            var mockConnection = CreateMockSqlConnection(mockCommand);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act
            var result = service.obtenConfiguracionCompania("COMP");

            // Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenConfiguracionCompania_ShouldReturnNull_OnException()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            failingConnection.Setup(c => c.Open()).Throws(new Exception("Connection error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act
            var result = service.obtenConfiguracionCompania("COMP");

            // Assert
            Assert.IsNull(result);
        }

        #endregion

        #region GuardaConfiguracionCompania Tests

        [TestMethod]
        public void GuardaConfiguracionCompania_ShouldNotThrow_WhenTableNotExists()
        {
            // Arrange
            var mockCommand = new Mock<DbCommand>();
            mockCommand.Setup(c => c.ExecuteScalar()).Returns(0);
            mockCommand.As<IDbCommand>().Setup(c => c.Prepare());

            var mockConnection = CreateMockSqlConnection(mockCommand);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act
            service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "desc", "alpha");

            // Assert — CreateConnection called once in constructor + once in method
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        [TestMethod]
        public void GuardaConfiguracionCompania_ShouldNotThrow_OnException()
        {
            // Arrange — factory returns a mock IDbConnection that cannot be cast to SqlConnection,
            // so the method will throw InvalidCastException internally, which is silently caught.
            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            failingConnection.Setup(c => c.Open()).Throws(new Exception("Connection error"));

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act — should not throw (exception is caught internally)
            service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.api_url, "desc", "alpha", 1.5m, 10);

            // Assert — CreateConnection was called (once in constructor + once in method)
            mockFactory.Verify(f => f.CreateConnection(), Times.Exactly(2));
        }

        #endregion

        #region obtenDatasetClasesNomina Tests

        [TestMethod]
        public void ObtenDatasetClasesNomina_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetClasesNomina("COMP"));
        }

        #endregion

        #region obtenDatasetTiposNomina Tests

        [TestMethod]
        public void ObtenDatasetTiposNomina_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTiposNomina("COMP"));
        }

        #endregion

        #region obtenBasesDisponibles Tests

        [TestMethod]
        public void ObtenBasesDisponibles_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenBasesDisponibles());
        }

        #endregion

        #region obtenListaPeriodosMes Tests

        [TestMethod]
        public void ObtenListaPeriodosMes_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenListaPeriodosMes("COMP", "TN", 2026, 6));
        }

        #endregion

        #region obtenDatasetTiposPercepcionDeduccion Tests

        [TestMethod]
        public void ObtenDatasetTiposPercepcionDeduccion_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTiposPercepcionDeduccion(1));
        }

        #endregion

        #region obtenDatasetDescripcionTipos Tests

        [TestMethod]
        public void ObtenDatasetDescripcionTipos_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetDescripcionTipos());
        }

        #endregion

        #region obtenDatasetRelacionConceptos Tests

        [TestMethod]
        public void ObtenDatasetRelacionConceptos_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetRelacionConceptos(1, "001"));
        }

        #endregion

        #region obtenDatasetConceptosRelacionar Tests

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Deducciones_ShouldThrowInvalidCastException()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert – tipoConcepto=2 is Deducciones
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetConceptosRelacionar(2, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Incapacidad_ShouldThrowInvalidCastException()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert – tipoConcepto=4 is Incapacidad
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetConceptosRelacionar(4, "001"));
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Default_ShouldThrowInvalidCastException()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert – tipoConcepto=1 hits default (Percepciones/Otros Pagos)
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetConceptosRelacionar(1, "001"));
        }

        #endregion

        #region AltaRelacionConcepto & BajaRelacionConcepto Tests

        [TestMethod]
        public void AltaRelacionConcepto_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.AltaRelacionConcepto(1, "001", 100));
        }

        [TestMethod]
        public void BajaRelacionConcepto_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.BajaRelacionConcepto(1, "001", 100));
        }

        #endregion

        #region obtenDatasetTrabajadoresRegimen Tests

        [TestMethod]
        public void ObtenDatasetTrabajadoresRegimen_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetTrabajadoresRegimen("COMP"));
        }

        #endregion

        #region obtenDatasetRegimen Tests

        [TestMethod]
        public void ObtenDatasetRegimen_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetRegimen());
        }

        #endregion

        #region AltaRelacionRegimen Tests

        [TestMethod]
        public void AltaRelacionRegimen_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.AltaRelacionRegimen("COMP", "TRAB001", "02"));
        }

        #endregion

        #region obtenDatasetFormaPago Tests

        [TestMethod]
        public void ObtenDatasetFormaPago_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.obtenDatasetFormaPago());
        }

        #endregion

        #region ReadCSD Tests

        [TestMethod]
        public void ReadCSD_ShouldThrowInvalidCastException_WhenConnectionIsNotSqlConnection()
        {
            // Arrange - method casts IDbConnection to SqlConnection outside try-catch
            var service = CreateServiceWithMockDB();

            // Act & Assert
            Assert.Throws<InvalidCastException>(() => service.ReadCSD());
        }

        #endregion

        #region CreateReplaceCSD Tests

        [TestMethod]
        public void CreateReplaceCSD_ShouldReturnFalse_OnException()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            failingConnection.Setup(c => c.Open()).Throws(new Exception("Connection error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act
            var result = service.CreateReplaceCSD(new byte[] { 0x01 }, new byte[] { 0x02 }, "CLIENT", "pass123");

            // Assert
            Assert.IsFalse(result);
        }

        #endregion

        #region DeleteCSD Tests

        [TestMethod]
        public void DeleteCSD_ShouldReturnFalse_OnException()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            failingConnection.Setup(c => c.Open()).Throws(new Exception("Connection error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act
            var result = service.DeleteCSD("CLIENT");

            // Assert
            Assert.IsFalse(result);
        }

        #endregion

        #region obtenParametrosCompania Tests

        [TestMethod]
        public void ObtenParametrosCompania_ShouldReturnNull_OnException()
        {
            // Arrange
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            var failingConnection = new Mock<IDbConnection>();
            failingConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            failingConnection.Setup(c => c.Open()).Throws(new Exception("Connection error"));
            mockFactory.Setup(f => f.CreateConnection()).Returns(failingConnection.Object);

            // Act
            var result = service.obtenParametrosCompania("COMP");

            // Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void ObtenParametrosCompania_ShouldExecuteQueryWithParameters()
        {
            // Arrange
            var mockCommand = new Mock<DbCommand>();
            mockCommand.As<IDbCommand>().Setup(c => c.Prepare());
            mockCommand.As<IDbCommand>().Setup(c => c.Parameters).Returns(new Mock<IDataParameterCollection>().Object);

            var mockConnection = CreateMockSqlConnection(mockCommand);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");

            var service = new CatalogoAdicionalSql(mockFactory.Object);

            // Act
            var result = service.obtenParametrosCompania("COMP");

            // Assert - SqlCommandExecutor.Request returns null for mocked adapter
            Assert.IsNull(result);
        }

        #endregion

        #region RealSqlConnection Tests - obtenCompaniasIdiomas

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenCompaniasIdiomas_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenCompaniasIdiomas());
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetCompanias

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetCompanias_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetCompanias("es-MX"));
        }

        #endregion

        #region RealSqlConnection Tests - existeTablaConfiguracion

        [TestMethod]
        [TestCategory("Integration")]
        public void ExisteTablaConfiguracion_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.existeTablaConfiguracion());
        }

        #endregion

        #region RealSqlConnection Tests - DeletePayslipsData

        [TestMethod]
        [TestCategory("Integration")]
        public void DeletePayslipsData_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() =>
                service.DeletePayslipsData("COMP", "TN", "CN", 2026, 1, "EMP001"));
        }

        #endregion

        #region RealSqlConnection Tests - obtenConfiguracionCompania

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenConfiguracionCompania_RealSqlConnection_ShouldReturnNull()
        {
            // try-catch returns null on exception
            var service = CreateServiceWithRealSqlConnection();
            var result = service.obtenConfiguracionCompania("COMP");
            Assert.IsNull(result);
        }

        #endregion

        #region RealSqlConnection Tests - GuardaConfiguracionCompania

        [TestMethod]
        [TestCategory("Integration")]
        public void GuardaConfiguracionCompania_RealSqlConnection_ShouldNotThrow()
        {
            // try-catch swallows exception
            var service = CreateServiceWithRealSqlConnection();
            service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "desc", "alpha", 1.5m, 10);
        }

        [TestMethod]
        [TestCategory("Integration")]
        public void GuardaConfiguracionCompania_RealSqlConnection_AllDefaults_ShouldNotThrow()
        {
            var service = CreateServiceWithRealSqlConnection();
            service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.api_url, "desc", "alpha");
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetClasesNomina

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetClasesNomina_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetClasesNomina("COMP"));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetTiposNomina

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetTiposNomina_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetTiposNomina("COMP"));
        }

        #endregion

        #region RealSqlConnection Tests - obtenBasesDisponibles

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenBasesDisponibles_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenBasesDisponibles());
        }

        #endregion

        #region RealSqlConnection Tests - obtenListaPeriodosMes

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenListaPeriodosMes_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenListaPeriodosMes("COMP", "TN", 2026, 6));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetTiposPercepcionDeduccion

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetTiposPercepcionDeduccion_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetTiposPercepcionDeduccion(1));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetDescripcionTipos

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetDescripcionTipos_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetDescripcionTipos());
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetRelacionConceptos

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetRelacionConceptos_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetRelacionConceptos(1, "001"));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetConceptosRelacionar

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetConceptosRelacionar_Deducciones_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetConceptosRelacionar(2, "001"));
        }

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetConceptosRelacionar_Incapacidad_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetConceptosRelacionar(4, "001"));
        }

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetConceptosRelacionar_Default_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetConceptosRelacionar(1, "001"));
        }

        #endregion

        #region RealSqlConnection Tests - AltaRelacionConcepto

        [TestMethod]
        [TestCategory("Integration")]
        public void AltaRelacionConcepto_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.AltaRelacionConcepto(1, "001", 100));
        }

        #endregion

        #region RealSqlConnection Tests - BajaRelacionConcepto

        [TestMethod]
        [TestCategory("Integration")]
        public void BajaRelacionConcepto_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.BajaRelacionConcepto(1, "001", 100));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetTrabajadoresRegimen

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetTrabajadoresRegimen_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetTrabajadoresRegimen("COMP"));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetRegimen

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetRegimen_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetRegimen());
        }

        #endregion

        #region RealSqlConnection Tests - AltaRelacionRegimen

        [TestMethod]
        [TestCategory("Integration")]
        public void AltaRelacionRegimen_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.AltaRelacionRegimen("COMP", "TRAB001", "02"));
        }

        #endregion

        #region RealSqlConnection Tests - obtenDatasetFormaPago

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenDatasetFormaPago_RealSqlConnection_ShouldThrowSqlException()
        {
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.obtenDatasetFormaPago());
        }

        #endregion

        #region RealSqlConnection Tests - ReadCSD

        [TestMethod]
        [TestCategory("Integration")]
        public void ReadCSD_RealSqlConnection_ShouldThrowSqlException()
        {
            // ReadCSD opens connection outside try-catch, so SqlException propagates
            var service = CreateServiceWithRealSqlConnection();
            Assert.Throws<SqlException>(() => service.ReadCSD());
        }

        #endregion

        #region RealSqlConnection Tests - CreateReplaceCSD

        [TestMethod]
        [TestCategory("Integration")]
        public void CreateReplaceCSD_RealSqlConnection_ShouldReturnFalse()
        {
            // try-catch returns false on exception
            var service = CreateServiceWithRealSqlConnection();
            var result = service.CreateReplaceCSD(new byte[] { 0x01 }, new byte[] { 0x02 }, "CLIENT", "pass123");
            Assert.IsFalse(result);
        }

        #endregion

        #region RealSqlConnection Tests - DeleteCSD

        [TestMethod]
        [TestCategory("Integration")]
        public void DeleteCSD_RealSqlConnection_ShouldReturnFalse()
        {
            // try-catch returns false on exception
            var service = CreateServiceWithRealSqlConnection();
            var result = service.DeleteCSD("CLIENT");
            Assert.IsFalse(result);
        }

        #endregion

        #region RealSqlConnection Tests - obtenParametrosCompania

        [TestMethod]
        [TestCategory("Integration")]
        public void ObtenParametrosCompania_RealSqlConnection_ShouldReturnNull()
        {
            // try-catch returns null on exception
            var service = CreateServiceWithRealSqlConnection();
            var result = service.obtenParametrosCompania("COMP");
            Assert.IsNull(result);
        }

        #endregion

        #region Helpers

        private CatalogoAdicionalSql CreateServiceWithRealSqlConnection()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection("Server=localhost;Database=FakeDB;Connection Timeout=1;Encrypt=false;"));

            return new CatalogoAdicionalSql(mockFactory.Object);
        }

        /// <summary>
        /// Creates a CatalogoAdicionalSql with a mock IDbConnection (non-SqlConnection).
        /// Methods that cast to SqlConnection will throw InvalidCastException.
        /// </summary>
        private CatalogoAdicionalSql CreateServiceWithMockDB()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            return new CatalogoAdicionalSql(mockFactory.Object);
        }

        /// <summary>
        /// Creates a CatalogoAdicionalSql instance with IDbConnection mock chain (for SqlHelpers-based methods)
        /// </summary>
        private (CatalogoAdicionalSql service, Mock<IDbCommand> mockCommand) CreateServiceWithFullMockDB()
        {
            var mockReader = new Mock<IDataReader>();
            mockReader.Setup(r => r.Read()).Returns(false);
            mockReader.Setup(r => r.GetSchemaTable()).Returns(new DataTable());

            var mockCommand = CreateMockCommand(mockReader);

            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);

            var service = new CatalogoAdicionalSql(mockFactory.Object);
            return (service, mockCommand);
        }

        /// <summary>
        /// Creates a CatalogoAdicionalSql with a SqlConnection mock (for SqlCommand-based methods)
        /// </summary>
        private (CatalogoAdicionalSql service, Mock<DbCommand> mockCommand) CreateServiceWithSqlMockDB(int executeScalarResult = 0)
        {
            var mockCommand = new Mock<DbCommand>();
            mockCommand.Setup(c => c.ExecuteScalar()).Returns(executeScalarResult);
            mockCommand.As<IDbCommand>().Setup(c => c.Prepare());
            mockCommand.As<IDbCommand>().Setup(c => c.Parameters).Returns(new Mock<IDataParameterCollection>().Object);
            mockCommand.As<IDbCommand>().Setup(c => c.CreateParameter()).Returns(new Mock<IDbDataParameter>().Object);

            var mockConnection = CreateMockSqlConnection(mockCommand);
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Open);

            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.CreateConnection()).Returns(mockConnection.Object);
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");

            var service = new CatalogoAdicionalSql(mockFactory.Object);
            return (service, mockCommand);
        }

        private Mock<IDbCommand> CreateMockCommand(Mock<IDataReader> mockReader)
        {
            var mockCommand = new Mock<IDbCommand>();
            mockCommand.SetupProperty(c => c.CommandText);
            mockCommand.SetupProperty(c => c.CommandType);
            mockCommand.SetupProperty(c => c.CommandTimeout);

            var mockParams = new Mock<IDataParameterCollection>();
            mockCommand.Setup(c => c.Parameters).Returns(mockParams.Object);
            mockCommand.Setup(c => c.CreateParameter()).Returns(() => new Mock<IDbDataParameter>().Object);
            mockCommand.Setup(c => c.ExecuteReader()).Returns(mockReader.Object);

            return mockCommand;
        }

        private Mock<IDbConnection> CreateMockSqlConnection(Mock<DbCommand> mockCommand)
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(c => c.State).Returns(ConnectionState.Closed);
            // Return the DbCommand as IDbCommand for CreateCommand
            mockConnection.Setup(c => c.CreateCommand()).Returns(mockCommand.Object);

            return mockConnection;
        }

        private static bool IsLocalDbAvailable()
        {
            try
            {
                using var conn = new SqlConnection(LocalDbConnectionString);
                conn.Open();
                conn.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private const string LocalDbConnectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=tempdb;Integrated Security=true;Connection Timeout=5";

        private CatalogoAdicionalSql CreateServiceWithLocalDb()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection(LocalDbConnectionString));

            return new CatalogoAdicionalSql(mockFactory.Object);
        }

        #endregion

        #region LocalDB Tests - obtenCompaniasIdiomas (covers lines 87-99)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenCompaniasIdiomas_LocalDb_ReturnsEmptyString_WhenNoCompaniasTable()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            var service = CreateServiceWithLocalDb();

            // tempdb has no 'companias' table → bCountry = false → returns ""
            var result = service.obtenCompaniasIdiomas();

            Assert.AreEqual("", result);
        }

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenCompaniasIdiomas_LocalDb_BCountryTrue_ReturnsLanguages()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.companias','U') IS NOT NULL DROP TABLE dbo.companias;
                CREATE TABLE dbo.companias (
                    compania   VARCHAR(4)  NOT NULL PRIMARY KEY,
                    nombre_cia VARCHAR(60) NOT NULL,
                    cve_pais   VARCHAR(10) NULL
                );
                INSERT INTO dbo.companias VALUES ('C001','Company MX','es-MX');
                INSERT INTO dbo.companias VALUES ('C002','Company CO','es-CO');
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();

                // bCountry=true → executes STUFF/FOR XML PATH query → returns "es-CO,es-MX" or "es-MX,es-CO"
                var result = service.obtenCompaniasIdiomas();

                Assert.IsFalse(string.IsNullOrEmpty(result), "Should return language codes when companias has cve_pais column");
                StringAssert.Contains(result, "es-MX");
                StringAssert.Contains(result, "es-CO");
            }
            finally
            {
                new SqlCommand("DROP TABLE IF EXISTS dbo.companias;", setup).ExecuteNonQuery();
            }
        }

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenCompaniasIdiomas_LocalDb_BCountryTrue_SingleLanguage_ReturnsSingleCode()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.companias','U') IS NOT NULL DROP TABLE dbo.companias;
                CREATE TABLE dbo.companias (
                    compania   VARCHAR(4)  NOT NULL PRIMARY KEY,
                    nombre_cia VARCHAR(60) NOT NULL,
                    cve_pais   VARCHAR(10) NULL
                );
                INSERT INTO dbo.companias VALUES ('C001','Company MX','es-MX');
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();

                var result = service.obtenCompaniasIdiomas();

                Assert.AreEqual("es-MX", result);
            }
            finally
            {
                new SqlCommand("DROP TABLE IF EXISTS dbo.companias;", setup).ExecuteNonQuery();
            }
        }

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenCompaniasIdiomas_LocalDb_BCountryTrue_NoMatchingCompanies_ReturnsEmpty()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            // Create companias with cve_pais column (bCountry=true) but only excluded companies ('0','A')
            new SqlCommand(@"
                IF OBJECT_ID('dbo.companias','U') IS NOT NULL DROP TABLE dbo.companias;
                CREATE TABLE dbo.companias (
                    compania   VARCHAR(4)  NOT NULL PRIMARY KEY,
                    nombre_cia VARCHAR(60) NOT NULL,
                    cve_pais   VARCHAR(10) NULL
                );
                INSERT INTO dbo.companias VALUES ('0','Excluded Company','es-MX');
                INSERT INTO dbo.companias VALUES ('A','Also Excluded','es-CO');
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();

                // bCountry=true but all companies are excluded → STUFF returns NULL → empty string
                var result = service.obtenCompaniasIdiomas();

                Assert.AreEqual("", result);
            }
            finally
            {
                new SqlCommand("DROP TABLE IF EXISTS dbo.companias;", setup).ExecuteNonQuery();
            }
        }

        #endregion

        #region LocalDB Tests - existeTablaConfiguracion (covers lines 174-180)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ExisteTablaConfiguracion_LocalDb_ReturnsFalse_WhenNoConfigTable()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            var service = CreateServiceWithLocalDb();

            // tempdb has no 'tb_configuracion_adicional_compania' table → returns false
            var result = service.existeTablaConfiguracion();

            Assert.IsFalse(result);
        }

        #endregion

        #region LocalDB Tests - obtenDatasetCompanias (covers lines 132-163)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenDatasetCompanias_LocalDb_ReturnsNull_WhenNoTables()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            var service = CreateServiceWithLocalDb();

            // tempdb has no companias/aut_companias tables → bCountry = false,
            // existeTablaConfiguracion = false, else branch executes,
            // SqlCommandExecutor catches SQL error and returns null
            var result = service.obtenDatasetCompanias("es-MX");

            Assert.IsNull(result);
        }

        #endregion

        #region LocalDB Tests - obtenDatasetCompanias bCountry=true (covers lines 134-151)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenDatasetCompanias_LocalDb_BCountryTrue_ExecutesCountryBranch()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            // Create tables so bCountry = true (companias has cve_pais column)
            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.aut_companias','U') IS NOT NULL DROP TABLE dbo.aut_companias;
                IF OBJECT_ID('dbo.companias','U') IS NOT NULL DROP TABLE dbo.companias;
                CREATE TABLE dbo.companias (
                    compania   VARCHAR(4)  NOT NULL PRIMARY KEY,
                    nombre_cia VARCHAR(60) NOT NULL,
                    registro_fiscal VARCHAR(20) NULL,
                    cve_pais   VARCHAR(10) NULL
                );
                CREATE TABLE dbo.aut_companias (
                    compania VARCHAR(4)  NOT NULL,
                    usuario  VARCHAR(10) NOT NULL
                );
                INSERT INTO dbo.companias VALUES ('C001','Test Company','RFC001','es-MX');
                INSERT INTO dbo.aut_companias VALUES ('C001','TestUser');
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();
                var result = service.obtenDatasetCompanias("es-MX");

                // The bCountry=true branch executes, parameters are added and prepared.
                // Result may be non-null with data or empty depending on SQL IN-clause behavior.
                Assert.IsNotNull(result);
            }
            finally
            {
                new SqlCommand(@"
                    DROP TABLE IF EXISTS dbo.aut_companias;
                    DROP TABLE IF EXISTS dbo.companias;
                ", setup).ExecuteNonQuery();
            }
        }

        #endregion

        #region LocalDB Tests - DeletePayslipsData (covers lines 190-205)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void DeletePayslipsData_LocalDb_ExecutesStoredProcedureAndReturns()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.sp_borrar_recibos_pago','P') IS NOT NULL
                    DROP PROCEDURE dbo.sp_borrar_recibos_pago;
            ", setup).ExecuteNonQuery();

            new SqlCommand(@"
                CREATE PROCEDURE dbo.sp_borrar_recibos_pago
                    @compania         CHAR(4),
                    @tipo_nomina      CHAR(2),
                    @clase_nomina     CHAR(2),
                    @anio             SMALLINT,
                    @periodo          SMALLINT,
                    @lstTrabajadores  VARCHAR(MAX)
                AS
                BEGIN
                    SELECT 1;
                END
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();
                var result = service.DeletePayslipsData("COMP", "TN", "CN", 2026, 1, "EMP001");

                // SP executes successfully, SqlCommandExecutor.Request returns true or false
                Assert.IsFalse(result);
            }
            finally
            {
                new SqlCommand("DROP PROCEDURE IF EXISTS dbo.sp_borrar_recibos_pago;", setup).ExecuteNonQuery();
            }
        }

        #endregion

        #region LocalDB Tests - obtenConfiguracionCompania existsConfTable=true (covers lines 221-242)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void ObtenConfiguracionCompania_LocalDb_ExistsConfTableTrue_ExecutesSecondQuery()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.tb_configuracion_adicional_compania','U') IS NOT NULL
                    DROP TABLE dbo.tb_configuracion_adicional_compania;
                IF OBJECT_ID('dbo.aut_companias','U') IS NOT NULL
                    DROP TABLE dbo.aut_companias;
                CREATE TABLE dbo.aut_companias (
                    compania VARCHAR(4)  NOT NULL,
                    usuario  VARCHAR(30) NOT NULL
                );
                CREATE TABLE dbo.tb_configuracion_adicional_compania (
                    compania       CHAR(4)       NOT NULL,
                    id_parametro   VARCHAR(50)   NOT NULL,
                    descripcion    VARCHAR(100)  NULL,
                    alfanumerico   VARCHAR(200)  NULL,
                    numero_real    DECIMAL(18,2) NULL,
                    numero_entero  INT           NULL,
                    fecha          DATETIME      NULL
                );
                INSERT INTO dbo.aut_companias VALUES ('COMP','TestUser');
                INSERT INTO dbo.tb_configuracion_adicional_compania
                    VALUES ('COMP','temp_path','Temp Path','C:\temp',0,0,NULL);
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();
                var result = service.obtenConfiguracionCompania("COMP");

                // existsConfTable=true branch executes, parameters added, query runs
                Assert.IsNotNull(result);
                Assert.IsTrue(result.Tables.Count > 0);
            }
            finally
            {
                new SqlCommand(@"
                    DROP TABLE IF EXISTS dbo.tb_configuracion_adicional_compania;
                    DROP TABLE IF EXISTS dbo.aut_companias;
                ", setup).ExecuteNonQuery();
            }
        }

        #endregion

        #region LocalDB Tests - GuardaConfiguracionCompania existsConfTable=true (covers lines 273-308)

        [TestMethod]
        [TestCategory("LocalDB")]
        public void GuardaConfiguracionCompania_LocalDb_ExistsConfTableTrue_InsertsNewRow()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.tb_configuracion_adicional_compania','U') IS NOT NULL
                    DROP TABLE dbo.tb_configuracion_adicional_compania;
                CREATE TABLE dbo.tb_configuracion_adicional_compania (
                    compania       CHAR(4)       NOT NULL,
                    id_parametro   VARCHAR(50)   NOT NULL,
                    descripcion    VARCHAR(100)  NULL,
                    alfanumerico   VARCHAR(300)  NULL,
                    numero_real    DECIMAL(18,2) NULL,
                    numero_entero  INT           NULL,
                    fecha          DATETIME      NULL
                );
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();

                // existsConfTable=true, row does not exist → INSERT branch
                service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "Temp Path", @"C:\temp", 1.5m, 10);

                var count = (int)new SqlCommand(
                    "SELECT COUNT(*) FROM dbo.tb_configuracion_adicional_compania WHERE compania = 'COMP'",
                    setup).ExecuteScalar();
                Assert.AreEqual(1, count, "Should have inserted one row");

                var alphanumeric = (string)new SqlCommand(
                    "SELECT alfanumerico FROM dbo.tb_configuracion_adicional_compania WHERE compania = 'COMP'",
                    setup).ExecuteScalar();
                Assert.AreEqual(@"C:\temp", alphanumeric);
            }
            finally
            {
                new SqlCommand("DROP TABLE IF EXISTS dbo.tb_configuracion_adicional_compania;", setup).ExecuteNonQuery();
            }
        }

        [TestMethod]
        [TestCategory("LocalDB")]
        public void GuardaConfiguracionCompania_LocalDb_ExistsConfTableTrue_UpdatesExistingRow()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.tb_configuracion_adicional_compania','U') IS NOT NULL
                    DROP TABLE dbo.tb_configuracion_adicional_compania;
                CREATE TABLE dbo.tb_configuracion_adicional_compania (
                    compania       CHAR(4)       NOT NULL,
                    id_parametro   VARCHAR(50)   NOT NULL,
                    descripcion    VARCHAR(100)  NULL,
                    alfanumerico   VARCHAR(300)  NULL,
                    numero_real    DECIMAL(18,2) NULL,
                    numero_entero  INT           NULL,
                    fecha          DATETIME      NULL
                );
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();

                // First call → INSERT
                service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "Old Desc", "OldValue", 0m, 0);

                // Second call → UPDATE (same company + parameterId)
                service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.temp_path, "New Desc", @"C:\new_temp", 2.5m, 20);

                // Only one row (upsert, not duplicate)
                var count = (int)new SqlCommand(
                    "SELECT COUNT(*) FROM dbo.tb_configuracion_adicional_compania WHERE compania = 'COMP'",
                    setup).ExecuteScalar();
                Assert.AreEqual(1, count, "Should have exactly one row after upsert");

                var alphanumeric = (string)new SqlCommand(
                    "SELECT alfanumerico FROM dbo.tb_configuracion_adicional_compania WHERE compania = 'COMP'",
                    setup).ExecuteScalar();
                Assert.AreEqual(@"C:\new_temp", alphanumeric, "Should have updated the alphanumeric value");
            }
            finally
            {
                new SqlCommand("DROP TABLE IF EXISTS dbo.tb_configuracion_adicional_compania;", setup).ExecuteNonQuery();
            }
        }

        [TestMethod]
        [TestCategory("LocalDB")]
        public void GuardaConfiguracionCompania_LocalDb_ExistsConfTableTrue_DefaultOptionalParams()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            using var setup = new SqlConnection(LocalDbConnectionString);
            setup.Open();

            new SqlCommand(@"
                IF OBJECT_ID('dbo.tb_configuracion_adicional_compania','U') IS NOT NULL
                    DROP TABLE dbo.tb_configuracion_adicional_compania;
                CREATE TABLE dbo.tb_configuracion_adicional_compania (
                    compania       CHAR(4)       NOT NULL,
                    id_parametro   VARCHAR(50)   NOT NULL,
                    descripcion    VARCHAR(100)  NULL,
                    alfanumerico   VARCHAR(300)  NULL,
                    numero_real    DECIMAL(18,2) NULL,
                    numero_entero  INT           NULL,
                    fecha          DATETIME      NULL
                );
            ", setup).ExecuteNonQuery();

            try
            {
                var service = CreateServiceWithLocalDb();

                // Call with default optional params (num_decimal=0, num_int=0)
                service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.api_url, "API URL", "https://api.example.com");

                var count = (int)new SqlCommand(
                    "SELECT COUNT(*) FROM dbo.tb_configuracion_adicional_compania WHERE compania = 'COMP'",
                    setup).ExecuteScalar();
                Assert.AreEqual(1, count, "Should have inserted one row with default params");
            }
            finally
            {
                new SqlCommand("DROP TABLE IF EXISTS dbo.tb_configuracion_adicional_compania;", setup).ExecuteNonQuery();
            }
        }

        [TestMethod]
        [TestCategory("LocalDB")]
        public void GuardaConfiguracionCompania_LocalDb_ExistsConfTableFalse_DoesNothing()
        {
            if (!IsLocalDbAvailable())
            {
                Assert.Inconclusive("LocalDB not available");
                return;
            }

            // No table created → existsConfTable=false → skips the inner block
            var service = CreateServiceWithLocalDb();

            // Should not throw; simply returns without writing anything
            service.GuardaConfiguracionCompania("COMP", ConfigurationTypes.api_url, "desc", "alpha");
        }

        #endregion
    }
}

﻿using System;
using System.IO;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ADAM.GeneracionRecibosElectronicos.Clases;
using ADAM.GeneracionRecibosElectronicos.Tests.Classes.Helpers;
using System.Reflection;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes
{
    [TestClass]
    public class UtileriasConfigTests
    {
        private TestConfigHelper _cfg;

        [TestInitialize]
        public void Init()
        {
            _cfg = new TestConfigHelper();
            _cfg.BackupAndDeleteIfExists();
        }

        [TestCleanup]
        public void Cleanup()
        {
            _cfg.CleanupRestore();
        }

        [DoNotParallelize]
        [TestMethod]
        public void LoadConfigDocument_WhenConfigFileDoesNotExist_ThrowsExceptionWithExpectedMessage()
        {
            Assert.IsFalse(File.Exists(_cfg.ConfigPath), "The config shouldn't exist for this test.");

            var ex = Assert.Throws<Exception>(() =>
                UtileriasConfig.loadConfigDocument());

            StringAssert.Contains(ex.Message, "No configuration file found");
        }

        [DoNotParallelize]
        [TestMethod]
        public void SaveEndpointAddress_WhenNodePathDoesNotExist_ThrowsInvalidOperationException()
        {
            _cfg.WriteConfigWithoutEndpointNode();

            var ex = Assert.Throws<InvalidOperationException>(() =>
                UtileriasConfig.SaveEndpointAddress("http://localhost:9999"));

            StringAssert.Contains(ex.Message, "Could not find endpoint node");
        }

        [DoNotParallelize]
        [TestMethod]
        public void SaveEndpointAddress_WhenNodeExists_UpdatesAddressAttributeAndSaves()
        {
            _cfg.WriteConfigWithEndpointNode(address: "http://old");

            UtileriasConfig.SaveEndpointAddress("http://new-endpoint");

            XmlDocument doc = _cfg.LoadXmlFromConfig();
            var node = doc.SelectSingleNode("//system.serviceModel//client//endpoint");
            Assert.IsNotNull(node, "There should be an endpoint node after saving.");

            var attr = node.Attributes?["address"];
            Assert.IsNotNull(attr, "The address attribute must exist.");

            Assert.AreEqual("http://new-endpoint", attr.Value);
        }

        [DoNotParallelize]
        [TestMethod]
        public void GetEndpointAddress_WhenAppsettingsNodeIsPresent_ReturnsExpectedValue()
        {
            _cfg.WriteConfigWithAppSetting(key: "NominaService", value: "http://nomina-service");
            System.Configuration.ConfigurationManager.RefreshSection("appSettings");

            var endpoint = UtileriasConfig.GetEndpointAddress();

            Assert.AreEqual("http://nomina-service", endpoint);
        }

        [TestMethod]
        public void AppSettings_Setter_MustAsiggneValue()
        {
            var expected = new ApplicationEnvironmentSettings();

            UtileriasConfig.AppSettings = expected;

            var value = UtileriasConfig.AppSettings;
            Assert.AreSame(expected, value);
        }

        [DoNotParallelize]
        [TestMethod]

        public void SaveEndpointAddress_WhenSaveFails_ShoudRethrowException()
        {
            _cfg.WriteConfigWithEndpointNode("http://old");

            var configPath = _cfg.ConfigPath;
            var original = File.GetAttributes(configPath);
            File.SetAttributes(configPath, original | FileAttributes.ReadOnly);

            var invalidEndpoint = "http://new-endpoint";

            var ex = Assert.Throws<Exception>(() =>
            {
                UtileriasConfig.SaveEndpointAddress(invalidEndpoint);
            });

            Assert.IsNotNull(ex);
        }

        [DoNotParallelize]
        [TestMethod]
        public void PrivateConstructor_ShouldBeInvocableViaReflection()
        {
            _cfg.WriteConfigWithEndpointNode("http://dummy");

            var type = typeof(UtileriasConfig);

            var ctor = type.GetConstructor(
                BindingFlags.Instance | BindingFlags.NonPublic,
                null,
                Type.EmptyTypes,
                null);

            Assert.IsNotNull(ctor, "Private constructor was not found");

            var instance = ctor.Invoke(null);
            Assert.IsNotNull(instance);
            Assert.IsInstanceOfType(instance, typeof(UtileriasConfig)); 
        }
    }
}
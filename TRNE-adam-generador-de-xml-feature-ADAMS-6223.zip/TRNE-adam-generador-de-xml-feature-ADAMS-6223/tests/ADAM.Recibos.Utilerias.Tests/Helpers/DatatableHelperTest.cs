﻿using System.Data;

namespace ADAM.Recibos.Utilerias.Tests.Helpers
{
    internal static class DatatableHelper
    {
        public static DataTable CreateSampleTable()
        {
            var table = new DataTable("SampleTable");
            table.Columns.Add("number", typeof(string));
            table.Columns.Add("name_value", typeof(string));
            table.Columns.Add("value", typeof(string));
            table.Rows.Add("row1", "Uno", "1");
            table.Rows.Add("row2", "Dos", "2");
            table.Rows.Add("row3", "Tres","3");
            return table;
        }

        public static DataTable CreateEmptyTable()
        {
            var table = new DataTable("EmptyTable");
            table.Columns.Add("number", typeof(string));
            table.Columns.Add("name_value", typeof(string));
            table.Columns.Add("value", typeof(string));
            return table;
        }
    }
}

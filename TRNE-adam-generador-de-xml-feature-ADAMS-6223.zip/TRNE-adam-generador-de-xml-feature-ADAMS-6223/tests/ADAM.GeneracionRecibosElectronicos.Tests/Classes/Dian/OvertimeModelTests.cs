using ADAM.GeneracionRecibosElectronicos.Clases.Dian;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ADAM.GeneracionRecibosElectronicos.Tests.Classes.Dian
{
    [TestClass]
    public class OvertimeModelTests
    {
        #region HeDs - Horas Extra Diurnas

        [TestMethod]
        public void HeDs_Properties_SetAndGet()
        {
            var he = new HeDs
            {
                HoraInicio = "06:00",
                HoraFin = "08:00",
                PagoCantidad = 2,
                PagoPorcentaje = 25.0m,
                Pago = 50000m
            };

            Assert.AreEqual("06:00", he.HoraInicio);
            Assert.AreEqual("08:00", he.HoraFin);
            Assert.AreEqual(2, he.PagoCantidad);
            Assert.AreEqual(25.0m, he.PagoPorcentaje);
            Assert.AreEqual(50000m, he.Pago);
        }

        [TestMethod]
        public void HeDs_JsonPropertyNames_AreCorrect()
        {
            var he = new HeDs { HoraInicio = "06:00", HoraFin = "08:00", PagoCantidad = 2, PagoPorcentaje = 25m, Pago = 50000m };
            var json = JsonConvert.SerializeObject(he);

            Assert.IsTrue(json.Contains("\"horaInicio\""));
            Assert.IsTrue(json.Contains("\"horaFin\""));
            Assert.IsTrue(json.Contains("\"cantidad\""));
            Assert.IsTrue(json.Contains("\"porcentaje\""));
            Assert.IsTrue(json.Contains("\"pago\""));
        }

        #endregion

        #region HeNs - Horas Extra Nocturnas

        [TestMethod]
        public void HeNs_Properties_SetAndGet()
        {
            var he = new HeNs
            {
                HoraInicio = "21:00",
                HoraFin = "23:00",
                PagoCantidad = 2,
                PagoPorcentaje = 75.0m,
                Pago = 90000m
            };

            Assert.AreEqual("21:00", he.HoraInicio);
            Assert.AreEqual(75.0m, he.PagoPorcentaje);
            Assert.AreEqual(90000m, he.Pago);
        }

        #endregion

        #region HrNs - Hora Recargo Nocturno

        [TestMethod]
        public void HrNs_Properties_SetAndGet()
        {
            var hr = new HrNs
            {
                HoraInicio = "22:00",
                HoraFin = "06:00",
                PagoCantidad = 8,
                PagoPorcentaje = 35.0m,
                Pago = 120000m
            };

            Assert.AreEqual("22:00", hr.HoraInicio);
            Assert.AreEqual(8, hr.PagoCantidad);
            Assert.AreEqual(120000m, hr.Pago);
        }

        #endregion

        #region HrddFs - Hora Recargo Dominical/Festivo Diurno

        [TestMethod]
        public void HrddFs_Properties_SetAndGet()
        {
            var hr = new HrddFs
            {
                HoraInicio = "08:00",
                HoraFin = "16:00",
                PagoCantidad = 8,
                PagoPorcentaje = 75.0m,
                Pago = 200000m
            };

            Assert.AreEqual("08:00", hr.HoraInicio);
            Assert.AreEqual(8, hr.PagoCantidad);
            Assert.AreEqual(200000m, hr.Pago);
        }

        #endregion

        #region HendFs - Hora Extra Nocturna Dominical/Festiva

        [TestMethod]
        public void HendFs_Properties_SetAndGet()
        {
            var he = new HendFs
            {
                HoraInicio = "21:00",
                HoraFin = "01:00",
                PagoCantidad = 4,
                PagoPorcentaje = 150.0m,
                Pago = 300000m
            };

            Assert.AreEqual("21:00", he.HoraInicio);
            Assert.AreEqual(150.0m, he.PagoPorcentaje);
            Assert.AreEqual(300000m, he.Pago);
        }

        #endregion

        #region HrndFs - Hora Recargo Nocturno Dominical/Festivo

        [TestMethod]
        public void HrndFs_Properties_SetAndGet()
        {
            var hr = new HrndFs
            {
                HoraInicio = "22:00",
                HoraFin = "06:00",
                PagoCantidad = 8,
                PagoPorcentaje = 110.0m,
                Pago = 280000m
            };

            Assert.AreEqual("22:00", hr.HoraInicio);
            Assert.AreEqual(110.0m, hr.PagoPorcentaje);
            Assert.AreEqual(280000m, hr.Pago);
        }

        #endregion

        #region HeddFs - Hora Extra Diurna Dominical/Festiva

        [TestMethod]
        public void HeddFs_Properties_SetAndGet()
        {
            var he = new HeddFs
            {
                HoraInicio = "06:00",
                HoraFin = "10:00",
                PagoCantidad = 4,
                PagoPorcentaje = 100.0m,
                Pago = 250000m
            };

            Assert.AreEqual("06:00", he.HoraInicio);
            Assert.AreEqual(100.0m, he.PagoPorcentaje);
            Assert.AreEqual(250000m, he.Pago);
        }

        #endregion
    }
}

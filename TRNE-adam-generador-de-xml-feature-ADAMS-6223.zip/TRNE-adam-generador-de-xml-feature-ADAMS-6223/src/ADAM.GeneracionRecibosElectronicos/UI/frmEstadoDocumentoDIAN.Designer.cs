
namespace ADAM.GeneracionRecibosElectronicos.UI
{
    partial class FrmEstadoDocumentoDIAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEstadoDocumentoDIAN));
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.dgDocumentos = new System.Windows.Forms.DataGridView();
            this.pnlDocumentos = new System.Windows.Forms.TableLayoutPanel();
            this.trvDocumento = new System.Windows.Forms.TreeView();
            this.pnlTrabajadores = new System.Windows.Forms.Panel();
            this.dgTrabajadores = new System.Windows.Forms.DataGridView();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDocumentos)).BeginInit();
            this.pnlDocumentos.SuspendLayout();
            this.pnlTrabajadores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTrabajadores)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.White;
            this.pnlLogo.Controls.Add(this.picLogo);
            this.pnlLogo.Controls.Add(this.lblTitulo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(842, 50);
            this.pnlLogo.TabIndex = 16;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ADAM.GeneracionRecibosElectronicos.Properties.Resources.LogoADAM_original;
            this.picLogo.Location = new System.Drawing.Point(0, 0);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(157, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(160, 10);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(428, 29);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Consulta Estado del Documento - DIAN";
            // 
            // dgDocumentos
            // 
            this.dgDocumentos.AllowUserToAddRows = false;
            this.dgDocumentos.AllowUserToDeleteRows = false;
            this.dgDocumentos.AllowUserToResizeColumns = false;
            this.dgDocumentos.AllowUserToResizeRows = false;
            this.dgDocumentos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgDocumentos.Location = new System.Drawing.Point(3, 3);
            this.dgDocumentos.Name = "dgDocumentos";
            this.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgDocumentos.Size = new System.Drawing.Size(537, 471);
            this.dgDocumentos.TabIndex = 0;
            this.dgDocumentos.SelectionChanged += new System.EventHandler(this.dgDocumentos_SelectionChanged);
            // 
            // pnlDocumentos
            // 
            this.pnlDocumentos.ColumnCount = 2;
            this.pnlDocumentos.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.60808F));
            this.pnlDocumentos.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.39193F));
            this.pnlDocumentos.Controls.Add(this.dgDocumentos, 0, 0);
            this.pnlDocumentos.Controls.Add(this.trvDocumento, 1, 0);
            this.pnlDocumentos.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDocumentos.Location = new System.Drawing.Point(0, 281);
            this.pnlDocumentos.MinimumSize = new System.Drawing.Size(0, 300);
            this.pnlDocumentos.Name = "pnlDocumentos";
            this.pnlDocumentos.RowCount = 1;
            this.pnlDocumentos.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlDocumentos.Size = new System.Drawing.Size(842, 477);
            this.pnlDocumentos.TabIndex = 18;
            // 
            // trvDocumento
            // 
            this.trvDocumento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trvDocumento.Location = new System.Drawing.Point(546, 3);
            this.trvDocumento.Name = "trvDocumento";
            this.trvDocumento.Size = new System.Drawing.Size(293, 471);
            this.trvDocumento.TabIndex = 1;
            // 
            // pnlTrabajadores
            // 
            this.pnlTrabajadores.Controls.Add(this.dgTrabajadores);
            this.pnlTrabajadores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTrabajadores.Location = new System.Drawing.Point(0, 50);
            this.pnlTrabajadores.MinimumSize = new System.Drawing.Size(0, 195);
            this.pnlTrabajadores.Name = "pnlTrabajadores";
            this.pnlTrabajadores.Size = new System.Drawing.Size(842, 231);
            this.pnlTrabajadores.TabIndex = 19;
            // 
            // dgTrabajadores
            // 
            this.dgTrabajadores.AllowUserToAddRows = false;
            this.dgTrabajadores.AllowUserToDeleteRows = false;
            this.dgTrabajadores.AllowUserToResizeColumns = false;
            this.dgTrabajadores.AllowUserToResizeRows = false;
            this.dgTrabajadores.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgTrabajadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTrabajadores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgTrabajadores.Location = new System.Drawing.Point(0, 0);
            this.dgTrabajadores.MultiSelect = false;
            this.dgTrabajadores.Name = "dgTrabajadores";
            this.dgTrabajadores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgTrabajadores.Size = new System.Drawing.Size(842, 231);
            this.dgTrabajadores.TabIndex = 0;
            this.dgTrabajadores.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgTrabajadores_CellPainting);
            this.dgTrabajadores.ColumnAdded += new System.Windows.Forms.DataGridViewColumnEventHandler(this.dgTrabajadores_ColumnAdded);
            this.dgTrabajadores.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgTrabajadores_ColumnHeaderMouseClick);
            this.dgTrabajadores.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgTrabajadores_RowPrePaint);
            this.dgTrabajadores.SelectionChanged += new System.EventHandler(this.dgTrabajadores_SelectionChanged);
            // 
            // FrmEstadoDocumentoDIAN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 758);
            this.Controls.Add(this.pnlTrabajadores);
            this.Controls.Add(this.pnlDocumentos);
            this.Controls.Add(this.pnlLogo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmEstadoDocumentoDIAN";
            this.Text = "Consultar Estado del Documento DIAN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmEstadoDocumentoDIAN_Load);
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDocumentos)).EndInit();
            this.pnlDocumentos.ResumeLayout(false);
            this.pnlTrabajadores.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTrabajadores)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.DataGridView dgDocumentos;
        private System.Windows.Forms.TableLayoutPanel pnlDocumentos;
        private System.Windows.Forms.Panel pnlTrabajadores;
        private System.Windows.Forms.DataGridView dgTrabajadores;
        private System.Windows.Forms.TreeView trvDocumento;
    }
}
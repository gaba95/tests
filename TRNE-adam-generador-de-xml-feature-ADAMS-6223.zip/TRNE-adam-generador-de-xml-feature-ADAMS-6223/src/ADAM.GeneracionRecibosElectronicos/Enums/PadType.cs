﻿namespace ADAM.GeneracionRecibosElectronicos.Enums
{
    public enum PadType
    {
        Left,
        Right
    };
}

using System.Configuration;
using ADAM.MIIA.Configuration;

namespace ADAM.MIIA.Configurador.UI;

public partial class frmModificaOrderProcess : Form
{
    private bool isNewRecord = false;

    public string OrderId { get; set; } = "";
    public string FileRegularExpr { get; set; } = "";
    public MIIAOrderProcessSection? MIIAOrderProcessSection { get; set; }
    public System.Configuration.Configuration? config { get; set; }
    public frmConfiguracion? frmPadre { get; set; }

    public frmModificaOrderProcess()
    {
        InitializeComponent();
    }

    private void frmModificaOrderProcess_Load(object? sender, EventArgs e)
    {
        if (OrderId.Trim() != "")
        {
            loadConfigValues();
            isNewRecord = false;
            nudOrder.Enabled = false;
        }
        else
        {
            isNewRecord = true;
            nudOrder.Enabled = true;
        }
    }

    private void cmdAceptar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        if (saveConfigValues(nudOrder.Text.Trim()))
        {
            DialogResult = DialogResult.OK;
            Close();
        }
        else
        {
            DialogResult = DialogResult.None;
        }
    }

    private void loadConfigValues()
    {
        nudOrder.Text = OrderId;
        txtRegEx.Text = FileRegularExpr;
    }

    private bool validateInputData()
    {
        string newOrderID = nudOrder.Text;

        if (isNewRecord)
        {
            foreach (OrderProcessMIIA orderProcess in MIIAOrderProcessSection!.OrderProcess)
            {
                if (orderProcess.OrderId == newOrderID)
                {
                    UIHelper.ShowMessage("La Clave que esta intentando ingresar ya existe", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    nudOrder.Focus();
                    return false;
                }
            }
        }

        foreach (Control control in Controls)
        {
            if (control.GetType().ToString() == "System.Windows.Forms.TextBox"
                && ((TextBox)control).Text.Trim() == string.Empty)
            {
                ((TextBox)control).Focus();
                UIHelper.ShowMessage("El campo no puede ser nulo", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        return true;
    }

    private bool saveConfigValues(string OrderId)
    {
        try
        {
            if (!validateInputData())
                return false;

            if (isNewRecord)
            {
                var newRecord = new OrderProcessMIIA();
                newRecord.OrderId = nudOrder.Text;
                newRecord.FileRegularExpr = txtRegEx.Text;
                MIIAOrderProcessSection!.OrderProcess.Add(newRecord);
            }
            else
            {
                var existingOrder = MIIAOrderProcessSection!.OrderProcess[OrderId];
                if (existingOrder != null)
                {
                    existingOrder.FileRegularExpr = txtRegEx.Text;
                }
            }

            var orderItem = MIIAOrderProcessSection!.OrderProcess[OrderId];
            if (orderItem != null)
            {
                orderItem.FileRegularExpr = txtRegEx.Text;
            }
            config!.Save();
            return true;
        }
        catch (Exception ex)
        {
            UIHelper.ShowMessage("Error al guardar la configuraci\u00F3n, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
    }
}

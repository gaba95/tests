using Moq;
using System.Data;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Datos.Clases.Common;

namespace ADAM.Recibos.DatosTests.Clases.CatalogoAdicional
{
    [TestClass]
    public class CatalogoAdicionalOracleOrchestrationTests
    {
        #region Test Subclass

        /// <summary>
        /// Subclass that overrides the internal virtual methods
        /// to return pre-built DataSets, enabling unit testing of
        /// dispatch and boolean conversion logic without Oracle.
        /// </summary>
        private class TestableCatalogoAdicionalOracle : CatalogoAdicionalOracle
        {
            public DataSet DeduccionesResult { get; set; }
            public DataSet IncapacidadResult { get; set; }
            public DataSet DefaultResult { get; set; }

            public int? LastDeduccionesTipoConcepto { get; private set; }
            public int? LastIncapacidadTipoConcepto { get; private set; }
            public int? LastDefaultTipoConcepto { get; private set; }

            public int AltaRelacionResult { get; set; }
            public int? LastAltaTipo { get; private set; }
            public string LastAltaClaveTipo { get; private set; }
            public int? LastAltaConcepto { get; private set; }

            public TestableCatalogoAdicionalOracle(IDbConnectionFactory connectionFactory)
                : base(connectionFactory) { }

            internal override DataSet FetchConceptosRelacionarDeducciones(int tipoConcepto)
            {
                LastDeduccionesTipoConcepto = tipoConcepto;
                return DeduccionesResult;
            }

            internal override DataSet FetchConceptosRelacionarIncapacidad(int tipoConcepto)
            {
                LastIncapacidadTipoConcepto = tipoConcepto;
                return IncapacidadResult;
            }

            internal override DataSet FetchConceptosRelacionarDefault(int tipoConcepto)
            {
                LastDefaultTipoConcepto = tipoConcepto;
                return DefaultResult;
            }

            internal override int ExecuteAltaRelacionConcepto(int tipo, string claveTipo, int concepto)
            {
                LastAltaTipo = tipo;
                LastAltaClaveTipo = claveTipo;
                LastAltaConcepto = concepto;
                return AltaRelacionResult;
            }
        }

        #endregion

        #region Helpers

        private static TestableCatalogoAdicionalOracle CreateTestableService()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CreateConnection()).Returns((IDbConnection)null!);
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);

            var service = new TestableCatalogoAdicionalOracle(mockFactory.Object);

            var emptyDs = new DataSet();
            emptyDs.Tables.Add(new DataTable("Result"));

            service.DeduccionesResult = emptyDs.Copy();
            service.IncapacidadResult = emptyDs.Copy();
            service.DefaultResult = emptyDs.Copy();
            service.AltaRelacionResult = 1;

            return service;
        }

        private static DataSet CreateDataSetWithTable(string tableName, params string[] columnNames)
        {
            var ds = new DataSet();
            var table = new DataTable(tableName);
            foreach (var col in columnNames)
            {
                table.Columns.Add(col, typeof(string));
            }
            table.Rows.Add(columnNames.Select(c => (object)$"val_{c}").ToArray());
            ds.Tables.Add(table);
            return ds;
        }

        #endregion

        #region obtenDatasetConceptosRelacionar Switch Dispatch Tests

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case2_ShouldCallDeducciones()
        {
            // Arrange
            var service = CreateTestableService();
            service.DeduccionesResult = CreateDataSetWithTable("Deducciones", "concepto", "descripcion");

            // Act
            var result = service.obtenDatasetConceptosRelacionar(2, "001");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2, service.LastDeduccionesTipoConcepto);
            Assert.IsNull(service.LastIncapacidadTipoConcepto);
            Assert.IsNull(service.LastDefaultTipoConcepto);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case4_ShouldCallIncapacidad()
        {
            // Arrange
            var service = CreateTestableService();
            service.IncapacidadResult = CreateDataSetWithTable("Incapacidad", "concepto", "descripcion");

            // Act
            var result = service.obtenDatasetConceptosRelacionar(4, "002");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(4, service.LastIncapacidadTipoConcepto);
            Assert.IsNull(service.LastDeduccionesTipoConcepto);
            Assert.IsNull(service.LastDefaultTipoConcepto);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case1_ShouldCallDefault()
        {
            // Arrange
            var service = CreateTestableService();
            service.DefaultResult = CreateDataSetWithTable("Default", "concepto", "descripcion");

            // Act
            var result = service.obtenDatasetConceptosRelacionar(1, "003");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, service.LastDefaultTipoConcepto);
            Assert.IsNull(service.LastDeduccionesTipoConcepto);
            Assert.IsNull(service.LastIncapacidadTipoConcepto);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case3_ShouldCallDefault()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            service.obtenDatasetConceptosRelacionar(3, "004");

            // Assert
            Assert.AreEqual(3, service.LastDefaultTipoConcepto);
            Assert.IsNull(service.LastDeduccionesTipoConcepto);
            Assert.IsNull(service.LastIncapacidadTipoConcepto);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case5_ShouldCallDefault()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            service.obtenDatasetConceptosRelacionar(5, "005");

            // Assert
            Assert.AreEqual(5, service.LastDefaultTipoConcepto);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case0_ShouldCallDefault()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            service.obtenDatasetConceptosRelacionar(0, "000");

            // Assert
            Assert.AreEqual(0, service.LastDefaultTipoConcepto);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case2_ShouldReturnDeduccionesResult()
        {
            // Arrange
            var service = CreateTestableService();
            var expected = CreateDataSetWithTable("Deducciones", "concepto", "descripcion");
            service.DeduccionesResult = expected;

            // Act
            var result = service.obtenDatasetConceptosRelacionar(2, "001");

            // Assert
            Assert.AreSame(expected, result);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Case4_ShouldReturnIncapacidadResult()
        {
            // Arrange
            var service = CreateTestableService();
            var expected = CreateDataSetWithTable("Incapacidad", "concepto", "descripcion");
            service.IncapacidadResult = expected;

            // Act
            var result = service.obtenDatasetConceptosRelacionar(4, "002");

            // Assert
            Assert.AreSame(expected, result);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_Default_ShouldReturnDefaultResult()
        {
            // Arrange
            var service = CreateTestableService();
            var expected = CreateDataSetWithTable("Percepciones", "concepto", "descripcion");
            service.DefaultResult = expected;

            // Act
            var result = service.obtenDatasetConceptosRelacionar(1, "003");

            // Assert
            Assert.AreSame(expected, result);
        }

        [TestMethod]
        public void ObtenDatasetConceptosRelacionar_ShouldPassTipoConceptoToHelper()
        {
            // Arrange
            var service = CreateTestableService();

            // Act
            service.obtenDatasetConceptosRelacionar(2, "unused");

            // Assert — the tipoConcepto value is correctly forwarded
            Assert.AreEqual(2, service.LastDeduccionesTipoConcepto);
        }

        #endregion

        #region AltaRelacionConcepto Boolean Conversion Tests

        [TestMethod]
        public void AltaRelacionConcepto_WhenExecuteReturnsNonZero_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateTestableService();
            service.AltaRelacionResult = 1;

            // Act
            var result = service.AltaRelacionConcepto(1, "001", 100);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void AltaRelacionConcepto_WhenExecuteReturnsZero_ShouldReturnFalse()
        {
            // Arrange
            var service = CreateTestableService();
            service.AltaRelacionResult = 0;

            // Act
            var result = service.AltaRelacionConcepto(1, "001", 100);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void AltaRelacionConcepto_WhenExecuteReturnsNegative_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateTestableService();
            service.AltaRelacionResult = -1;

            // Act
            var result = service.AltaRelacionConcepto(1, "001", 100);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void AltaRelacionConcepto_WhenExecuteReturnsLargePositive_ShouldReturnTrue()
        {
            // Arrange
            var service = CreateTestableService();
            service.AltaRelacionResult = 42;

            // Act
            var result = service.AltaRelacionConcepto(1, "001", 100);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void AltaRelacionConcepto_ShouldPassParametersToExecute()
        {
            // Arrange
            var service = CreateTestableService();
            service.AltaRelacionResult = 1;

            // Act
            service.AltaRelacionConcepto(5, "ABC", 999);

            // Assert
            Assert.AreEqual(5, service.LastAltaTipo);
            Assert.AreEqual("ABC", service.LastAltaClaveTipo);
            Assert.AreEqual(999, service.LastAltaConcepto);
        }

        [TestMethod]
        public void AltaRelacionConcepto_ShouldPassDifferentParameters()
        {
            // Arrange
            var service = CreateTestableService();
            service.AltaRelacionResult = 0;

            // Act
            var result = service.AltaRelacionConcepto(2, "XYZ", 1);

            // Assert
            Assert.IsFalse(result);
            Assert.AreEqual(2, service.LastAltaTipo);
            Assert.AreEqual("XYZ", service.LastAltaClaveTipo);
            Assert.AreEqual(1, service.LastAltaConcepto);
        }

        #endregion
    }
}

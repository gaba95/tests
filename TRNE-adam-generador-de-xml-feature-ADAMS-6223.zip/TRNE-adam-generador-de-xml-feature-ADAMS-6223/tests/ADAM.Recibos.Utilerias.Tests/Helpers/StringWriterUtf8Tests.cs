using ADAM.Recibos.Utilerias.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;

namespace ADAM.Recibos.Utilerias.Tests.Helpers
{
    [TestClass]
    public class StringWriterUtf8Tests
    {
        [TestMethod]
        public void Encoding_ReturnsUtf8()
        {
            var sb = new StringBuilder();
            using var writer = new StringWriterUtf8(sb);

            Assert.AreEqual(Encoding.UTF8, writer.Encoding);
        }

        [TestMethod]
        public void Write_AppendsToStringBuilder()
        {
            var sb = new StringBuilder();
            using var writer = new StringWriterUtf8(sb);

            writer.Write("Hello");
            writer.Write(" World");

            Assert.AreEqual("Hello World", sb.ToString());
        }

        [TestMethod]
        public void WriteLine_AppendsLineToStringBuilder()
        {
            var sb = new StringBuilder();
            using var writer = new StringWriterUtf8(sb);

            writer.WriteLine("Line1");

            StringAssert.StartsWith(sb.ToString(), "Line1");
        }

        [TestMethod]
        public void ToString_ReturnsSameAsStringBuilder()
        {
            var sb = new StringBuilder();
            using var writer = new StringWriterUtf8(sb);

            writer.Write("test content");

            Assert.AreEqual(sb.ToString(), writer.ToString());
        }
    }
}

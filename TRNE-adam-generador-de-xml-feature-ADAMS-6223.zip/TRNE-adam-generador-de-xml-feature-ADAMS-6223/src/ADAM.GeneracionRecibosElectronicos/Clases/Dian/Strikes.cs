﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADAM.GeneracionRecibosElectronicos.Clases.Dian
{
    [JsonObject("huelgas", ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Strikes
    {
        public string fechaInicio { get; set; }
        public string fechaFin { get; set; }
        public int cantidad { get; set; }
    }
}

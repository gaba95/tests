﻿using ADAM.BackOffice.Mexico.SAT;
using ADAM.GeneracionRecibosElectronicos.Clases;
using ADAM.GeneracionRecibosElectronicos.Enums;
using ADAM.GeneracionRecibosElectronicos.Properties;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases.CatalogoAdicional;
using ADAM.Recibos.Principal.Clases;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;
using ADAM.Recibos.Utilerias.Helpers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmConfiguracion : Form
    {
        #region Properties

        private const string ParamTimeout = "timeout";
        private const string ParamPassword = "password";

        private byte[] _keyBytes = null;
        private byte[] _certBytes = null;
        
        private bool hayCambiosParametros = false;
        private ICatalogoAdicional _catalogoAdicional;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Pais { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FrmGeneracionRecibo formaPadre { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ApplicationEnvironmentSettings AppSettings { get; set; } = new ApplicationEnvironmentSettings();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Server { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Database { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string User { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SecureString Pwd { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AdamExecution { get; set; }

        #endregion 

        #region Events

        private void FrmConfiguracion_Load(object sender, EventArgs e)
        {
            _certBytes = null;
            _keyBytes = null;

            LoadConfiguration();
            ToggleOptionsLegacyNewStampingMode();
        }

        public void ToggleOptionsLegacyNewStampingMode()
        {
            try
            {
                if (Enum.Parse<Countries>(this.Pais) == Countries.México)
                {
                    if (this.IsNewStampingMode())
                    {
                        this.lblServicio.Visible = false;
                        this.txtServicio.Visible = false;
                        this.lblSitio.Visible = false;
                        this.txtSitio.Visible = false;
                        if (!this.tabPrincipal.Controls.Contains(this.tabPage3))
                            this.tabPrincipal.Controls.Add(this.tabPage3);

                    }
                    else
                    {
                        this.lblServicio.Visible = true;
                        this.txtServicio.Visible = true;
                        this.lblSitio.Visible = true;
                        this.txtSitio.Visible = true;
                        this.tabPrincipal.Controls.Remove(this.tabPage3);
                    }
                }
            }
            catch
            {
                this.lblServicio.Visible = true;
                this.txtServicio.Visible = true;
                this.lblSitio.Visible = true;
                this.txtSitio.Visible = true;
                this.tabPrincipal.Controls.Remove(this.tabPage3);
            }
        }

        private void LoadConfiguration()
        {
            if (!string.IsNullOrEmpty(this.Pais))
            {
                // Set Country
                if (cboPaisDefault.Items.Count <= 0)
                {
                    cboPaisDefault.Items.Add(this.Pais);
                    cboPaisDefault.SelectedIndex = 0;
                }

                // Load Configuration
                LoadConfiguration(true, true, true);
            }
            else
            {
                // Load Configuration
                LoadConfiguration(true, true, false);
            }

            PoblarCboCompaniaCSD();
            PoblarGridCSD();
        }
        
        public void LoadConfiguration(bool loadConnectionConfig, bool loadAdditionalConfig, bool setAdditionalConfig)
        {
            // Fill Combos
            llenaComboDSN();
            ConfiguraCboMultiples();

            if (loadConnectionConfig)
            {
                // Get Local Config
                RecuperaConfiguracionActualConexion();
            }

            if (loadAdditionalConfig)
            {
                // Get Aditional Config
                ObtenXsltDisponibles();
                ObtenXSDDisponibles();
                RecuperaConfiguracionActualAdicional();
            }

            if (setAdditionalConfig)
            {
                // Enable Fields
                tabPrincipal.TabPages[1].Enabled = true;
                cboPaisDefault.Enabled = true;

                // Set Additional Config
                AsignaConfiguracionActualAdicional();
            }
            else
            {
                // Disable Fields
                tabPrincipal.TabPages[1].Enabled = false;
                cboPaisDefault.Enabled = false;
            }
        }
        
        private void cboPlataforma_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clean Errors
            epErroresConfiguracion.Clear();

            // Switch Environment Config
            switch (cboPlataforma.SelectedItem.ToString())
            {
                case "SQL":
                    pnlSqlOracle.Visible = true;
                    pnlODBC.Visible = false;
                    pnlDatosADAM.Visible = true;
                    pnlDatosADAM.Enabled = true;
                    pnlDatosADAM.Visible = true;

                    lblTipoServicio.Visible = false;
                    cboTipoServicio.Visible = false;
                    lblPuerto.Visible = false;
                    txtPuerto.Visible = false;
                    cmdBuscar.Visible = true;

                    lblBaseDatos.Location = new System.Drawing.Point(10, 100);
                    cboBaseDatos.Location = new System.Drawing.Point(180, 100);
                    pnlDatosADAM.Location = new System.Drawing.Point(3, 187);
                    pnlSqlOracle.Size = new System.Drawing.Size(670, 130);

                    lblBaseDatos.Text = "Base de Datos:";

                    break;

                case "ORACLE":
                    pnlSqlOracle.Visible = true;
                    pnlSqlOracle.Size = new System.Drawing.Size(670, 130);
                    pnlODBC.Visible = false;
                    pnlDatosADAM.Enabled = true;
                    pnlDatosADAM.Visible = true;

                    lblTipoServicio.Visible = true;
                    cboTipoServicio.Visible = true;
                    lblPuerto.Visible = true;
                    txtPuerto.Visible = true;
                    cmdBuscar.Visible = false;

                    lblBaseDatos.Location = new System.Drawing.Point(10, 133);
                    cboBaseDatos.Location = new System.Drawing.Point(180, 133);
                    pnlDatosADAM.Location = new System.Drawing.Point(3, 220);
                    pnlSqlOracle.Size = new System.Drawing.Size(670, 170);

                    lblBaseDatos.Text = "Servicio:";
                    pnlSqlOracle.PerformLayout();

                    break;

                case "ODBC":
                    pnlODBC.Visible = true;
                    pnlODBC.Dock = DockStyle.Fill;
                    pnlSqlOracle.Visible = false;
                    pnlDatosADAM.Visible = false;
                    pnlDatosADAM.Enabled = false;
                    break;
            }

            txtServidor.Text = string.Empty;
            txtUsuario.Text = string.Empty;
            txtContrasenia.Text = string.Empty;
            cboBaseDatos.Text = string.Empty;

            txtUsuarioODBC.Text = string.Empty;
            txtPasswordODBC.Text = string.Empty;
            txtPasswordODBC.Text = string.Empty;
            cboDSN.Text = string.Empty;
        }
        
        private void cmdAceptar_Click(object sender, EventArgs e)
        {
            switch (Enum.Parse<Countries>(this.Pais))
            {
                case Countries.México:
                case Countries.Colombia:
                    switch (tabPrincipal.SelectedIndex)
                    {
                        case 0:
                            if (ValidaCampos())
                            {
                                if (GuardaConfiguracionConexion())
                                {
                                    // Save to Settings
                                    MessageBox.Show("La configuración de conexión se guardó correctamente, la aplicación se cerrará para aplicar los cambios", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    Application.Exit();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Debe completar los campos para guardar la configuración", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            break;
                        case 1:
                            if (validaCamposAdicionales())
                            {
                                if (GuardaConfiguracionAdicional())
                                {
                                    MessageBox.Show("La configuración adicional se guardó correctamente", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Debe completar los campos para guardar la configuración", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            break;
                    }
                    break;
            }
        }

        private void cmdBuscar_Click(object sender, EventArgs e)
        {
            // Search Databases
            BuscarBases();
        }
        
        private void cmdValidarConexion_Click(object sender, EventArgs e)
        {
            // NLC

            // Set Values
            if (cboPlataforma.Text.Equals("ODBC"))
            {
                AppSettings.DSN = Properties.AppSettings.Default.dsn = cboDSN.Text;
                AppSettings.User = Properties.AppSettings.Default.user = txtUsuarioODBC.Text;
                Properties.AppSettings.Default.password = txtPasswordODBC.Text;
                AppSettings.Password = new NetworkCredential(string.Empty, txtPasswordODBC.Text).SecurePassword;
            }
            else
            {
                AppSettings.Server = Properties.AppSettings.Default.server = txtServidor.Text;
                AppSettings.Database = Properties.AppSettings.Default.database = cboBaseDatos.Text;
                AppSettings.User = Properties.AppSettings.Default.user = txtUsuario.Text;
                Properties.AppSettings.Default.password = txtContrasenia.Text;
                AppSettings.Password = new NetworkCredential(string.Empty, txtContrasenia.Text).SecurePassword;
                AppSettings.OracleType = Properties.AppSettings.Default.tipoOracle = cboTipoServicio.Text;
                AppSettings.OraclePort = Properties.AppSettings.Default.puertoOracle = txtPuerto.Text;
            }

            AppSettings.ApplicationUser = Properties.AppSettings.Default.applicationUser = txtUsuarioAplicacion.Text;
            AppSettings.Version = Properties.AppSettings.Default.version = cboVersion.Text;
            AppSettings.Platform = Properties.AppSettings.Default.plattaform = cboPlataforma.Text;

            // Validate Fields
            if (ValidaCampos())
                ValidaConexion();
            else
                MessageBox.Show("Los campos son requeridos", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        
        private void cmdValidarODBC_Click(object sender, EventArgs e)
        {
            // Validate ODBC Config
            ValidaConexionODBC();
        }
        
        private void txtUsuario_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Validate User
            if (txtUsuario.Text.Trim() == "")
                epErroresConfiguracion.SetError(txtUsuario, "El campo es requerido");
            else
                epErroresConfiguracion.SetError(txtUsuario, "");
        }
        
        private void txtServidor_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Validate Server
            if (txtServidor.Text.Trim() == "")
                epErroresConfiguracion.SetError(txtServidor, "El campo es requerido");
            else
                epErroresConfiguracion.SetError(txtServidor, "");
        }
        
        private void txtContrasenia_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Validate Password 
            if (txtContrasenia.Text.Trim() == "")
                epErroresConfiguracion.SetError(txtContrasenia, "El campo es requerido");
            else
                epErroresConfiguracion.SetError(txtContrasenia, "");
        }
        
        private void cboDSN_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Validate DSN
            if (cboDSN.Text.Trim() == "")
                epErroresConfiguracion.SetError(cboDSN, "El campo es requerido");
            else
                epErroresConfiguracion.SetError(cboDSN, "");

        }
        
        private void cboVersion_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Validate Platform
            if (cboPlataforma.Text != "ODBC")
            {
                if (cboVersion.Text.Trim() == "")
                    epErroresConfiguracion.SetError(cboVersion, "El campo es requerido");
                else
                    epErroresConfiguracion.SetError(cboVersion, "");
            }
        }
        
        private void txtUsuarioAplicacion_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Validate Platform
            if (cboPlataforma.Text != "ODBC")
            {
                if (txtUsuarioAplicacion.Text.Trim() == "")
                    epErroresConfiguracion.SetError(txtUsuarioAplicacion, "El campo es requerido");
                else
                    epErroresConfiguracion.SetError(txtUsuarioAplicacion, "");
            }
        }
        
        private void controles_valueChanged(object sender, EventArgs e)
        {
            // Validate Controls
            hayCambiosParametros = true;
            cmdAceptar.Enabled = true;
        }
        
        private void cboCompania_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Don't trigger if the dropdown is currently filled
            if (this.cboCompania.Tag != null) return;

            if (cboCompania.Items.Count > 0 &&
                cboCompania.SelectedValue != null &&
                !string.IsNullOrEmpty(cboCompania.SelectedValue.ToString()))
            {
                DataSet ConfiguracionActualAdicional = new DataSet();
                switch (Enum.Parse<Countries>(this.Pais))
                {
                    case Countries.México:
                        ConfiguracionActualAdicional = _catalogoAdicional.obtenConfiguracionCompania(cboCompania.SelectedValue.ToString());
                        if (ConfiguracionActualAdicional != null && ConfiguracionActualAdicional.Tables[0].Rows.Count > 0)
                        {
                            Func<string, string> getParameterStringValue = (string id_parametro) =>
                            {
                                var parametro = ConfiguracionActualAdicional.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                                if (parametro != null && parametro.Length > 0)
                                {
                                    return parametro[0]?.Field<string>("alfanumerico");
                                }
                                return string.Empty;
                            };

                            txtSitio.Text = getParameterStringValue(ConfigurationTypes.stamping_site.ToString());
                            cboXslt.SelectedItem = getParameterStringValue(ConfigurationTypes.xslt_file.ToString());
                            cboXSD.SelectedItem = getParameterStringValue(ConfigurationTypes.xsd_file.ToString());
                            cboMultiples.SelectedValue = getParameterStringValue(ConfigurationTypes.generation_type.ToString());
                            txtRuta.Text = getParameterStringValue(ConfigurationTypes.temp_path.ToString());
                            txtTimeout.Text = getParameterStringValue(ConfigurationTypes.timeout.ToString());
                            txtServicio.Text = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                            cboDatosAdicionales.SelectedValue = getParameterStringValue(ConfigurationTypes.additional_generation.ToString());
                            txtProcAdicionales.Text = getParameterStringValue(ConfigurationTypes.additional_proc.ToString());
                        }
                        else
                        {
                            txtSitio.Text = string.Empty;
                            cboXslt.SelectedIndex = -1;
                            cboXSD.SelectedIndex = -1;
                            cboMultiples.SelectedIndex = -1;
                            txtRuta.Text = string.Empty;
                            txtTimeout.Text = string.Empty;
                            txtServicio.Text = string.Empty;
                            cboDatosAdicionales.SelectedIndex = -1;
                            txtProcAdicionales.Text = string.Empty;
                        }
                        break;

                    case Countries.Colombia:
                        ConfiguracionActualAdicional = _catalogoAdicional.obtenConfiguracionCompania(cboCompania.SelectedValue.ToString());
                        if (ConfiguracionActualAdicional != null && ConfiguracionActualAdicional.Tables[0].Rows.Count > 0)
                        {
                            Func<string, string> getParameterStringValue = (string id_parametro) =>
                            {
                                var parametro = ConfiguracionActualAdicional.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                                if (parametro != null && parametro.Length > 0)
                                {
                                    return parametro[0]?.Field<string>("alfanumerico");
                                }
                                return string.Empty;
                            };

                            txtRuta.Text = getParameterStringValue(ConfigurationTypes.temp_path.ToString());
                            txtTimeout.Text = getParameterStringValue(ConfigurationTypes.timeout.ToString());
                            txtServicio.Text = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                            txtWSUsrID.Text = getParameterStringValue(ConfigurationTypes.ws_user.ToString());
                            txtWSUsrPwd.Text = getParameterStringValue(ConfigurationTypes.ws_password.ToString());
                        }
                        else
                        {
                            txtRuta.Text = string.Empty;
                            txtTimeout.Text = string.Empty;
                            txtServicio.Text = string.Empty;
                            txtWSUsrID.Text = string.Empty;
                            txtWSUsrPwd.Text = string.Empty;
                        }

                        // Add event to identify changes.
                        txtRuta.TextChanged += controles_valueChanged;
                        txtTimeout.TextChanged += controles_valueChanged;
                        txtServicio.TextChanged += controles_valueChanged;
                        txtWSUsrID.TextChanged += controles_valueChanged;
                        txtWSUsrPwd.TextChanged += controles_valueChanged;
                        break;
                }
            }
            else
            {
                // Mexico
                txtSitio.Text = string.Empty;
                cboXslt.SelectedIndex = -1;
                cboXSD.SelectedIndex = -1;
                cboMultiples.SelectedIndex = -1;
                txtRuta.Text = string.Empty;
                txtTimeout.Text = string.Empty;
                txtServicio.Text = string.Empty;
                cboDatosAdicionales.SelectedIndex = -1;
                txtProcAdicionales.Text = string.Empty;

                // Colombia
                txtRuta.Text = string.Empty;
                txtServicio.Text = string.Empty;
                txtWSUsrID.Text = string.Empty;
                txtWSUsrPwd.Text = string.Empty;
            }

            ToggleOptionsLegacyNewStampingMode();
        }
        
        private void cmdConsultasODBC_Click(object sender, EventArgs e)
        {
            // Validate Parameters
            hayCambiosParametros = true;
            ADAM.Recibos.Datos.Odbc.UI.FrmConfiguracionConsultas FrmConsultas = new Recibos.Datos.Odbc.UI.FrmConfiguracionConsultas();
            FrmConsultas.ShowDialog();
        }
        
        private void cboPaisDefault_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboPaisDefault.Items.Count > 0 &&
                cboPaisDefault.SelectedIndex >= 0)
            {
                this.Pais = cboPaisDefault.SelectedItem.ToString().Trim();

                // Get companies for actual selected country
                _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(TipoPlataforma.SQLServer, Properties.AppSettings.Default);
                var dsCompanies = _catalogoAdicional.obtenDatasetCompanias(this.Pais == "Mexico" ? LanguageCodes.Mexico : LanguageCodes.Colombia);
                if (dsCompanies != null && dsCompanies.Tables.Count > 0)
                { 
                    cboCompania.Tag = true;
                    cboCompania.DataSource = dsCompanies.Tables[0];
                    cboCompania.DisplayMember = "nombre_cia";
                    cboCompania.ValueMember = "compania";
                    cboCompania.Tag = null;
                }

                // Set actual configuration
                AsignaConfiguracionActualAdicional();
            }
        }
        
        private void tabPrincipal_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabPrincipal.SelectedIndex)
            {
                case 0:
                    pnlBotones.Visible = true;
                    cmdAceptar.Enabled = true;
                    break;
                default:
                case 1:
                    _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(TipoPlataforma.SQLServer, Properties.AppSettings.Default);
                    if (_catalogoAdicional.existeTablaConfiguracion())
                    {
                        pnlBotones.Visible = true;
                        cmdAceptar.Enabled = false;
                    }
                    else
                    {
                        pnlBotones.Visible = true;
                        cmdAceptar.Enabled = true;
                    }
                    break;
            }
        }

        private void btnLoadCert_Click(object sender, EventArgs e)
        {
            this._certBytes = null;
            this.fdCertFile.Title = "Seleccionar archivo";
            this.fdCertFile.Filter = "Archivos de certificado (*.cer)|*.cer";

            if (this.fdCertFile.ShowDialog() == DialogResult.OK)
            {
                this.txtCertPath.Text = this.fdCertFile.FileName;
                this._certBytes = File.ReadAllBytes(this.fdCertFile.FileName);
            }
        }

        private void btnLoadKey_Click(object sender, EventArgs e)
        {
            this._keyBytes = null;
            this.fdKeyFile.Title = "Seleccionar archivo";
            this.fdKeyFile.Filter = "Archivos de certificado (*.key)|*.key";

            if (this.fdKeyFile.ShowDialog() == DialogResult.OK) 
            { 
                this.txtKeyPath.Text = this.fdKeyFile.FileName; 
               this._keyBytes = File.ReadAllBytes(this.fdKeyFile.FileName);
            }
        }

        private void btnAddCertKey_Click(object sender, EventArgs e)
        {
            var certFile = this.txtCertPath.Text.Trim();
            var keyFile = this.txtKeyPath.Text.Trim();
            var selected_company = (this.cboCompaniaCertKey.SelectedItem as DataRowView).Row[0].ToString();
            var password = this.txtCertKeyPassword.Text;

            if (string.IsNullOrEmpty(certFile) || _certBytes.Length<=0)
                MessageBox.Show("No se ha especificado certificado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (string.IsNullOrEmpty(keyFile) || _keyBytes.Length<=0)
                MessageBox.Show("No se ha especificado llave", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (string.IsNullOrEmpty(selected_company))
                MessageBox.Show("No se ha especificado compañia", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (string.IsNullOrEmpty(password))
                MessageBox.Show("No se ha especificado contraseña", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (!string.IsNullOrEmpty(certFile) && _certBytes.Length>0 &&
                !string.IsNullOrEmpty(keyFile) && _keyBytes.Length>0 &&
                !string.IsNullOrEmpty(selected_company) && 
                !string.IsNullOrEmpty(password))
            {
                VerificarCSD(_certBytes, _keyBytes, password,
                             out bool keyPwdValid, out bool csdValid, 
                             out string subject, out DateTime not_after, 
                             out _
                            );

                if (keyPwdValid && csdValid)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine($"Verifica que los datos del csd corresponden con la compañia {selected_company}");
                    sb.AppendLine($"{subject}");
                    sb.AppendLine($"con fecha de vencimiento de {not_after:yyyy-MM-dd}?");

                    DialogResult result = MessageBox.Show(sb.ToString(), $"Verifica info de {selected_company}",
                                                          MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                    if (result == DialogResult.OK)
                    {
                        bool res = _catalogoAdicional.CreateReplaceCSD(_certBytes, _keyBytes, selected_company, password);
                        if (res)
                        {
                            PoblarGridCSD();
                            ResetCamposCSD();
                            MessageBox.Show("Se ha agregado el CSD de manera correcta", "CSD agregado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else { ResetCamposCSD(); }
                }

                if (!keyPwdValid)
                {
                    MessageBox.Show("Contraseña no corresponde con llave, favor de verificar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ResetCamposCSD();
                }

                if (!csdValid)
                {
                    MessageBox.Show($"Ha terminado la vigencia del CSD, el día {not_after:yyyy-MM-dd}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ResetCamposCSD();
                }
            }
        }

        public static void VerificarCSD(byte[] Cert, byte[] KeyByte, string password,
                                        out bool key_password_is_valid, out bool csd_is_still_valid, 
                                        out string subject, out DateTime not_after, out double available_cert_days)
        {
            OpenSslKeyV1.CertificateData(Cert, out X509Certificate cert, out string Certificate, out string CertificateNumber);
            var rsa = OpenSslKeyV1.OpenKeyFile(KeyByte, password);
            key_password_is_valid = rsa != null;
            subject = cert.Subject;
            not_after = PropertyHelper.GetPrivatePropertyValue<DateTime>(cert, "NotAfter");
            available_cert_days = Math.Floor((not_after - DateTime.Now).TotalDays);
            csd_is_still_valid = available_cert_days > 0;
        }

        public static byte[] StringToByteArray(string hex)
        {
            string[] arr = hex.Split('-');
            byte[] array = new byte[arr.Length];
            for (int i = 0; i < arr.Length; i++) array[i] = Convert.ToByte(arr[i], 16);
            return array;
        }

        public void PoblarCboCompaniaCSD()
        {
            if (_catalogoAdicional != null)
            {
                var language = (this.Pais == "Colombia") ? LanguageCodes.Colombia : LanguageCodes.Mexico;
                var dsCompanies = _catalogoAdicional.obtenDatasetCompanias(language);
                if (dsCompanies != null && dsCompanies.Tables.Count > 0)
                {
                    cboCompaniaCertKey.Tag = true;
                    cboCompaniaCertKey.DataSource = dsCompanies.Tables[0];
                    cboCompaniaCertKey.DisplayMember = "nombre_cia";
                    cboCompaniaCertKey.ValueMember = "compania";
                    cboCompaniaCertKey.Tag = null;
                }
            }
        }

        public void PoblarGridCSD()
        {
            this.lvCFDI.Items.Clear();
            if (_catalogoAdicional != null)
            {
                // Special Case  ADAM v5.4 & v5.3
                var ReadCSD = _catalogoAdicional.ReadCSD();

                if (ReadCSD != null)
                {
                    var items = ReadCSD.Tables[0].AsEnumerable();

                    foreach (var elemento in items)
                    {
                    ListViewItem item = new ListViewItem(elemento.Field<string>("client"));
                    item.SubItems.Add(elemento.Field<string>("certificado"));
                    item.SubItems.Add(elemento.Field<string>("llave"));
                    item.SubItems.Add(elemento.Field<string>(ParamPassword));
                    var cert = StringToByteArray(elemento.Field<string>("cert_data"));
                    var key = StringToByteArray(elemento.Field<string>("key_data"));
                    var password = elemento.Field<string>("password_data");

                    VerificarCSD(cert, key, password,
                        out bool key_password_is_valid, out bool csd_is_still_valid, out string subject, out DateTime not_after, out double available_cert_days);

                    item.SubItems.Add($"{not_after:yyyy-MM-dd}");
                    lvCFDI.Items.Add(item);
                    }
                }
            }

        }

        private void lvCFDI_ItemActivate(object sender, EventArgs e)
        {
            if (lvCFDI.SelectedItems.Count > 0)
            {
                string client = lvCFDI.SelectedItems[0].Text;
                DialogResult result = MessageBox.Show($"¿Quieres eliminar este CSD {client}?", "Borrado de CSD", MessageBoxButtons.OKCancel);

                if (result == DialogResult.OK)
                {
                    _catalogoAdicional.DeleteCSD(client);
                    PoblarGridCSD();
                }
            }
        }

        private void ResetCamposCSD()
        {
            this.txtCertPath.Text = "";
            this.txtKeyPath.Text = "";
            this.txtCertKeyPassword.Text = "";
            PoblarCboCompaniaCSD();
        }

        #endregion

        #region Methods

        public FrmConfiguracion()
        {
            InitializeComponent();
        }

        private String addDynamicEnvironmentSetting(String settingName)
        {
            String finalSettingName = AppSettings.ADAMEnvironment + "_" + settingName;

            ApplicationSettingsBase settings = Properties.AppSettings.Default;

            if (settings.Properties[finalSettingName] == null)
            {
                SettingsProvider sp = settings.Providers["LocalFileSettingsProvider"];
                SettingsProperty p = new SettingsProperty(finalSettingName)
                {
                    PropertyType = typeof(String)
                };
                p.Attributes.Add(typeof(UserScopedSettingAttribute), new UserScopedSettingAttribute());
                p.Provider = sp;
                p.SerializeAs = SettingsSerializeAs.Xml;
                SettingsPropertyValue v = new SettingsPropertyValue(p);
                settings.Properties.Add(p);
            }

            settings.Reload();

            if (string.IsNullOrEmpty((String)settings[finalSettingName]))
            {
                return "";
            }
            else
            {
                return (String)settings[finalSettingName];
            }
        }
        
        public void saveSetting(String settingName, String settingValue)
        {
            String finalSettingName = AppSettings.ADAMEnvironment + "_" + settingName;

            ApplicationSettingsBase settings = Properties.AppSettings.Default;
            settings[finalSettingName] = settingValue;

            settings.Save();
        }
        
        public bool RecuperaConfiguracionActualConexion()
        {
            if (!string.IsNullOrEmpty(AppSettings.ADAMEnvironment))
            {
                AppSettings.Platform = addDynamicEnvironmentSetting("platform");

                // For Odbc
                AppSettings.DSN = addDynamicEnvironmentSetting("dsn");

                // Sql and Oracle
                AppSettings.Server = addDynamicEnvironmentSetting("server");
                AppSettings.Database = addDynamicEnvironmentSetting("database");
                AppSettings.OracleType = addDynamicEnvironmentSetting("tipoOracle");
                AppSettings.OraclePort = addDynamicEnvironmentSetting("puertoOracle");

                // General
                AppSettings.User = addDynamicEnvironmentSetting("user");
                AppSettings.Password = new NetworkCredential(string.Empty, addDynamicEnvironmentSetting(ParamPassword)).SecurePassword;
                AppSettings.ApplicationUser = addDynamicEnvironmentSetting("applicationUser");
                AppSettings.Version = addDynamicEnvironmentSetting("version");
            }
            else
            {
                // Enable/Disable Controls
                if (AdamExecution == "1")
                {
                    AppSettings.Server = this.Server;
                    AppSettings.Database = this.Database;
                    AppSettings.User = this.User;
                    AppSettings.Password = this.Pwd;
                    AppSettings.ApplicationUser = this.User;
                    this.cboPlataforma.Enabled = false;
                    this.cboDSN.Enabled = false;
                    this.txtUsuarioODBC.Enabled = false;
                    this.txtPasswordODBC.Enabled = false;
                    this.textBox1.Enabled = false;
                    this.txtParametrosODBC.Enabled = false;
                    this.cboVersion.Enabled = false;
                    this.txtUsuarioAplicacion.Enabled = false;
                    this.cmdValidarODBC.Enabled = false;
                    this.cmdConsultasODBC.Enabled = false;
                    this.txtServidor.Enabled = false;
                    this.txtUsuario.Enabled = false;
                    this.txtContrasenia.Enabled = false;
                    this.cboTipoServicio.Enabled = false;
                    this.txtPuerto.Enabled = false;
                    this.cboBaseDatos.Enabled = false;
                    this.cmdValidarConexion.Enabled = false;
                    this.cmdBuscar.Enabled = false;
                    this.tabPrincipal.TabPages.Remove(this.tabPrincipal.TabPages[0]);
                    AppSettings.Platform = "SQL";
                    AppSettings.Version = "5";
                }
                else
                {
                    AppSettings.Server = Properties.AppSettings.Default.server;
                    AppSettings.Database = Properties.AppSettings.Default.database;
                    AppSettings.User = Properties.AppSettings.Default.user;
                    AppSettings.Password = new NetworkCredential(string.Empty, Properties.AppSettings.Default.password).SecurePassword;
                    AppSettings.ApplicationUser = Properties.AppSettings.Default.applicationUser;
                    AppSettings.Platform = Properties.AppSettings.Default.plattaform;
                    AppSettings.Version = Properties.AppSettings.Default.version;
                }

                AppSettings.DSN = Properties.AppSettings.Default.dsn;
                AppSettings.OracleType = Properties.AppSettings.Default.tipoOracle;
                AppSettings.OraclePort = Properties.AppSettings.Default.puertoOracle;
            }

            cboPlataforma.Text = AppSettings.Platform;

            // Set Settings
            if (AppSettings.Platform != null && AppSettings.Platform.Equals("ODBC"))
            {
                cboDSN.Text = AppSettings.DSN;
                txtUsuarioODBC.Text = AppSettings.User;
                txtPasswordODBC.Text = new NetworkCredential(string.Empty, AppSettings.Password).Password;
                pnlDatosADAM.Enabled = false;
            }
            else
            {
                txtServidor.Text = AppSettings.Server;
                cboBaseDatos.Text = AppSettings.Database;
                txtUsuario.Text = AppSettings.User;
                txtContrasenia.Text = new NetworkCredential(string.Empty, AppSettings.Password).Password;

                cboTipoServicio.Text = AppSettings.OracleType;
                txtPuerto.Text = AppSettings.OraclePort;

                pnlDatosADAM.Enabled = true;
            }

            txtUsuarioAplicacion.Text = AppSettings.ApplicationUser;
            cboVersion.Text = AppSettings.Version;

            // Set Global Platform Var
            if (formaPadre != null)
            {
                switch (AppSettings.Platform)
                {
                    case "SQL":
                        formaPadre.tipoPlataforma = TipoPlataforma.SQLServer;
                        break;
                    case "ORACLE":
                        formaPadre.tipoPlataforma = TipoPlataforma.ORACLE;
                        break;
                    default:
                        formaPadre.tipoPlataforma = TipoPlataforma.ODBC;
                        break;
                }
            }

            // Set Odbc Setting
            if (AppSettings.Platform != null && AppSettings.Platform.Equals("ODBC"))
            {
                return !string.IsNullOrEmpty(cboDSN.Text);
            }
            else
            {
                if (AdamExecution == "1")
                {
                    return true;
                }
                else
                {
                    return ((string.IsNullOrEmpty(txtServidor.Text) ||
                             string.IsNullOrEmpty(cboBaseDatos.Text) ||
                             string.IsNullOrEmpty(txtUsuario.Text) ||
                             string.IsNullOrEmpty(txtContrasenia.Text) ||
                             string.IsNullOrEmpty(cboVersion.Text) ||
                             string.IsNullOrEmpty(cboPlataforma.Text))
                             ? false
                             : true);
                }
            }
        }
        
        private void RecuperaConfiguracionActualAdicional()
        {
            // PTF-4928: Add environment settings and get their value, if environment is sent
            if (!string.IsNullOrEmpty(AppSettings.ADAMEnvironment))
            {
                AppSettings.Site = addDynamicEnvironmentSetting("sitio");
                AppSettings.Xslt = addDynamicEnvironmentSetting("archivoXSLT");
                AppSettings.Xsd = addDynamicEnvironmentSetting("archivoXSD");
                AppSettings.XmlFilePath = addDynamicEnvironmentSetting("rutaArchivos");
                AppSettings.MultipleFile = addDynamicEnvironmentSetting("multiplesArchivos");
                AppSettings.AdditionalData = addDynamicEnvironmentSetting("datosAdicionales");
                AppSettings.AdditionalProcedure = addDynamicEnvironmentSetting("procedimientoAdicionales");
                AppSettings.WSUsrID = addDynamicEnvironmentSetting("WSUsrID");
                AppSettings.WSUsrPwd = new NetworkCredential(string.Empty, addDynamicEnvironmentSetting("WSUsrPwd")).SecurePassword;
                AppSettings.SelectedCompany = addDynamicEnvironmentSetting("selectedCompany");
                AppSettings.DefaultCountry = addDynamicEnvironmentSetting("defaultCountry");

                // If some of these values is null, get the default value from Default configuration
                // as they have to be assigned later
                if (string.IsNullOrEmpty(AppSettings.MultipleFile))
                {
                    AppSettings.MultipleFile = Properties.AppSettings.Default.multiplesArchivos.ToString();
                }

                if (string.IsNullOrEmpty(AppSettings.AdditionalData))
                {
                    AppSettings.AdditionalData = Properties.AppSettings.Default.datosAdicionales.ToString();
                }

                if (string.IsNullOrEmpty(AppSettings.AdditionalProcedure))
                {
                    AppSettings.AdditionalProcedure = Properties.AppSettings.Default.procedimientoAdicionales;
                }

                if (string.IsNullOrEmpty(AppSettings.WSUsrID))
                {
                    AppSettings.WSUsrID = Properties.AppSettings.Default.WSUsrID;
                }

                if (AppSettings.WSUsrPwd is null || AppSettings.WSUsrPwd.Length<=0)
                {
                    AppSettings.WSUsrPwd = new NetworkCredential(string.Empty, Properties.AppSettings.Default.WSUsrPwd).SecurePassword;
                }

                if (string.IsNullOrEmpty(AppSettings.SelectedCompany))
                {
                    AppSettings.SelectedCompany = Properties.AppSettings.Default.selectedCompany;
                }

                if (string.IsNullOrEmpty(AppSettings.DefaultCountry))
                {
                    AppSettings.DefaultCountry = Properties.AppSettings.Default.defaultCountry;
                }

                if (string.IsNullOrEmpty(AppSettings.Timeout))
                {
                    AppSettings.Timeout = Properties.AppSettings.Default.timeout;
                }

                if (string.IsNullOrEmpty(AppSettings.ApplicationPath))
                {
                    AppSettings.ApplicationPath = Properties.AppSettings.Default.applicationPath;
                }
            }
            else
            {
                AppSettings.Site = Properties.AppSettings.Default.sitio;
                AppSettings.Xslt = Properties.AppSettings.Default.archivoXSLT;
                AppSettings.Xsd = Properties.AppSettings.Default.archivoXSD;
                AppSettings.Timeout = Properties.AppSettings.Default.timeout;
                AppSettings.XmlFilePath = Properties.AppSettings.Default.rutaArchivos;
                AppSettings.MultipleFile = Properties.AppSettings.Default.multiplesArchivos.ToString();
                AppSettings.AdditionalData = Properties.AppSettings.Default.datosAdicionales.ToString();
                AppSettings.AdditionalProcedure = Properties.AppSettings.Default.procedimientoAdicionales;
                AppSettings.WSUsrID = Properties.AppSettings.Default.WSUsrID;
                AppSettings.WSUsrPwd = new NetworkCredential(string.Empty, Properties.AppSettings.Default.WSUsrPwd).SecurePassword;
                AppSettings.SelectedCompany = Properties.AppSettings.Default.selectedCompany;
                AppSettings.DefaultCountry = Properties.AppSettings.Default.defaultCountry;
                AppSettings.ApplicationPath = Properties.AppSettings.Default.applicationPath;
            }
        }
        
        private void AsignaConfiguracionActualAdicional()
        {
            // Enable/Disable Controls By Country
            switch (Enum.Parse<Countries>(this.Pais))
            {
                case Countries.México:
                    lblSitio.Visible = true;
                    txtSitio.Visible = true;
                    lblXslt.Visible = true;
                    cboXslt.Visible = true;
                    lblXSD.Visible = true;
                    cboXSD.Visible = true;
                    lblRuta.Visible = true;
                    txtRuta.Visible = true;
                    lblTimeout.Visible = true;
                    txtTimeout.Visible = true;
                    lblMultiples.Visible = true;
                    cboMultiples.Visible = true;
                    lblServicio.Visible = true;
                    txtServicio.Visible = true;
                    lblDatosAdicionales.Visible = true;
                    cboDatosAdicionales.Visible = true;
                    lblProcAdicionales.Visible = true;
                    txtProcAdicionales.Visible = true;

                    lblCompania.Visible = true;
                    cboCompania.Visible = true;
                    lblWSUsrID.Visible = false;
                    txtWSUsrID.Visible = false;
                    lblWSUsrPwd.Visible = false;
                    txtWSUsrPwd.Visible = false;

                    txtSitio.Text = AppSettings.Site;
                    cboXslt.Text = AppSettings.Xslt;
                    cboXSD.Text = AppSettings.Xsd;
                    cboMultiples.SelectedValue = AppSettings.MultipleFile;
                    txtRuta.Text = AppSettings.XmlFilePath;
                    txtTimeout.Text = AppSettings.Timeout;
                    txtServicio.Text = UtileriasConfig.GetEndpointAddress();

                    cboDatosAdicionales.Text = AppSettings.AdditionalData;
                    txtProcAdicionales.Text = AppSettings.AdditionalProcedure;

                    // Add event to identify changes.
                    txtSitio.TextChanged += controles_valueChanged;
                    cboXslt.SelectedIndexChanged += controles_valueChanged;
                    cboXSD.SelectedIndexChanged += controles_valueChanged;
                    cboMultiples.SelectedIndexChanged += controles_valueChanged;
                    txtRuta.TextChanged += controles_valueChanged;
                    txtTimeout.TextChanged += controles_valueChanged;
                    txtServicio.TextChanged += controles_valueChanged;

                    cboDatosAdicionales.SelectedIndexChanged += controles_valueChanged;
                    txtProcAdicionales.TextChanged += controles_valueChanged;

                    UtileriasConfig.AppSettings = this.AppSettings;
                    if (this.AppSettings.Database.Length > 0)
                    {
                        // Create Object
                        _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(TipoPlataforma.SQLServer, Properties.AppSettings.Default);

                        if (_catalogoAdicional.existeTablaConfiguracion())
                        {
                            // Fill companies combobox
                            cboCompania.Tag = true;
                            cboCompania.DataSource = _catalogoAdicional.obtenDatasetCompanias(LanguageCodes.Mexico).Tables[0];
                            cboCompania.DisplayMember = "nombre_cia";
                            cboCompania.ValueMember = "compania";
                            cboCompania.Tag = null;

                            // Set Values
                            if (cboCompania.SelectedValue != null)
                            {
                                DataSet ConfiguracionActualAdicional = _catalogoAdicional.obtenConfiguracionCompania(cboCompania.SelectedValue.ToString());

                                if (ConfiguracionActualAdicional != null && ConfiguracionActualAdicional.Tables[0].Rows.Count > 0)
                                {
                                    Func<string, string> getParameterStringValue = (string id_parametro) =>
                                    {
                                        var parametro = ConfiguracionActualAdicional.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                                        if (parametro != null && parametro.Length > 0)
                                        {
                                            return parametro[0]?.Field<string>("alfanumerico");
                                        }
                                        return string.Empty;
                                    };

                                    txtSitio.Text = getParameterStringValue(ConfigurationTypes.stamping_site.ToString());
                                    cboXslt.SelectedItem = getParameterStringValue(ConfigurationTypes.xslt_file.ToString());
                                    cboXSD.SelectedItem = getParameterStringValue(ConfigurationTypes.xsd_file.ToString());
                                    cboMultiples.SelectedValue = getParameterStringValue(ConfigurationTypes.generation_type.ToString());
                                    txtRuta.Text = getParameterStringValue(ConfigurationTypes.temp_path.ToString());
                                    txtTimeout.Text = getParameterStringValue(ConfigurationTypes.timeout.ToString());
                                    txtServicio.Text = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                                    cboDatosAdicionales.SelectedItem = getParameterStringValue(ConfigurationTypes.additional_generation.ToString());
                                    txtProcAdicionales.Text = getParameterStringValue(ConfigurationTypes.additional_proc.ToString());
                                }
                            }
                        }
                        else
                        {
                            // ADAM v5.3 & v5.4
                            // The configuration table and UI section don't existe at the database and ADAM Architect
                            // The companies dropdown is hidden, and the config controls are enabled so the user can change it

                            lblCompania.Visible = false;
                            cboCompania.Visible = false;

                            txtSitio.Enabled = true;
                            txtSitio.ReadOnly = false;
                            cboXslt.Enabled = true;
                            cboXSD.Enabled = true;
                            cboMultiples.Enabled = true;
                            txtRuta.Enabled = true;
                            txtRuta.ReadOnly = false;
                            txtTimeout.Enabled = true;
                            txtTimeout.ReadOnly = false;
                            txtServicio.Enabled = true;
                            txtServicio.ReadOnly = false;
                            cboDatosAdicionales.Enabled = true;
                            txtProcAdicionales.Enabled = true;
                            txtProcAdicionales.ReadOnly = false;

                            txtSitio.BackColor = System.Drawing.Color.White;
                            cboXslt.BackColor = System.Drawing.Color.White;
                            cboXSD.BackColor = System.Drawing.Color.White;
                            cboMultiples.BackColor = System.Drawing.Color.White;
                            txtRuta.BackColor = System.Drawing.Color.White;
                            txtTimeout.BackColor = System.Drawing.Color.White;
                            txtServicio.BackColor = System.Drawing.Color.White;
                            cboDatosAdicionales.BackColor = System.Drawing.Color.White;
                            txtProcAdicionales.BackColor = System.Drawing.Color.White;
                        }

                        // Add event to identify changes.
                        txtRuta.TextChanged += controles_valueChanged;
                        txtServicio.TextChanged += controles_valueChanged;
                    }
                    break;

                case Countries.Colombia:
                    lblSitio.Visible = false;
                    txtSitio.Visible = false;
                    lblXslt.Visible = false;
                    cboXslt.Visible = false;
                    lblXSD.Visible = false;
                    cboXSD.Visible = false;
                    lblMultiples.Visible = false;
                    cboMultiples.Visible = false;
                    lblDatosAdicionales.Visible = false;
                    cboDatosAdicionales.Visible = false;
                    lblProcAdicionales.Visible = false;
                    txtProcAdicionales.Visible = false;

                    lblServicio.Visible = true;
                    lblCompania.Visible = true;
                    cboCompania.Visible = true;
                    lblRuta.Visible = true;
                    lblTimeout.Visible = true;
                    txtTimeout.Visible = true;
                    lblServicio.Visible = true;
                    txtServicio.Visible = true;
                    lblWSUsrID.Visible = true;
                    txtWSUsrID.Visible = true;
                    lblWSUsrPwd.Visible = true;
                    txtWSUsrPwd.Visible = true;

                    lblServicio.Text = "Servicio CENET/DIAN:";
                    lblRuta.Location = new System.Drawing.Point(14, 43);
                    txtRuta.Location = new System.Drawing.Point(190, 44);
                    lblServicio.Location = new System.Drawing.Point(17, 73);
                    txtServicio.Location = new System.Drawing.Point(190, 73);
                    lblTimeout.Location = new System.Drawing.Point(17, 103);
                    txtTimeout.Location = new System.Drawing.Point(190, 103);
                    lblWSUsrID.Location = new System.Drawing.Point(17, 133);
                    txtWSUsrID.Location = new System.Drawing.Point(190, 133);
                    lblWSUsrPwd.Location = new System.Drawing.Point(17, 163);
                    txtWSUsrPwd.Location = new System.Drawing.Point(190, 163);

                    UtileriasConfig.AppSettings = this.AppSettings;
                    if (this.AppSettings.Database.Length > 0)
                    {
                        _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(TipoPlataforma.SQLServer, Properties.AppSettings.Default);

                        // Fill companies combobox
                        var dsCompanies = _catalogoAdicional.obtenDatasetCompanias(LanguageCodes.Colombia);
                        if (dsCompanies != null && dsCompanies.Tables.Count > 0)
                        {
                            cboCompania.Tag = true;
                            cboCompania.DataSource = dsCompanies.Tables[0];
                            cboCompania.DisplayMember = "nombre_cia";
                            cboCompania.ValueMember = "compania";
                            cboCompania.Tag = null;
                        }

                        // Set Values
                        if (Properties.AppSettings.Default.selectedCompany != string.Empty) cboCompania.SelectedValue = Properties.AppSettings.Default.selectedCompany;
                        if (cboCompania.SelectedValue != null)
                        {
                            DataSet ConfiguracionActualAdicional = _catalogoAdicional.obtenConfiguracionCompania(cboCompania.SelectedValue.ToString());

                            if (ConfiguracionActualAdicional != null && ConfiguracionActualAdicional.Tables[0].Rows.Count > 0)
                            {
                                Func<string, string> getParameterStringValue = (string id_parametro) =>
                                {
                                    var parametro = ConfiguracionActualAdicional.Tables[0].AsEnumerable().Where(t => t.Field<string>("id_parametro") == id_parametro).ToArray();
                                    if (parametro != null && parametro.Length > 0)
                                    {
                                        return parametro[0]?.Field<string>("alfanumerico");
                                    }
                                    return string.Empty;
                                };

                                txtRuta.Text = getParameterStringValue(ConfigurationTypes.temp_path.ToString());
                                txtTimeout.Text = getParameterStringValue(ConfigurationTypes.timeout.ToString());
                                txtServicio.Text = getParameterStringValue(ConfigurationTypes.api_url.ToString());
                                txtWSUsrID.Text = getParameterStringValue(ConfigurationTypes.ws_user.ToString());
                                txtWSUsrPwd.Text = getParameterStringValue(ConfigurationTypes.ws_password.ToString());
                            }
                        }

                        // Add event to identify changes.
                        txtRuta.TextChanged += controles_valueChanged;
                        txtTimeout.TextChanged += controles_valueChanged;
                        txtServicio.TextChanged += controles_valueChanged;
                        txtWSUsrID.TextChanged += controles_valueChanged;
                        txtWSUsrPwd.TextChanged += controles_valueChanged;
                    }
                    break;
            }
        }
        
        bool GuardaConfiguracionConexion()
        {
            try
            {
                // PTF-4928: If environment is set, save the configuration in the separate group of settings
                if (!string.IsNullOrEmpty(AppSettings.ADAMEnvironment))
                {
                    saveSetting("platform", cboPlataforma.Text);
                    saveSetting("server", txtServidor.Text);
                    saveSetting("database", cboBaseDatos.Text);
                    saveSetting("applicationUser", txtUsuarioAplicacion.Text);
                    saveSetting("version", cboVersion.Text);
                    saveSetting("dsn", cboDSN.Text);

                    if (cboPlataforma.Text == "ODBC")
                    {
                        saveSetting("user", txtUsuarioODBC.Text);
                        saveSetting(ParamPassword, txtPasswordODBC.Text);
                    }
                    else
                    {
                        saveSetting("user", txtUsuario.Text);
                        saveSetting(ParamPassword, txtContrasenia.Text);
                    }
                }
                else
                {
                    Properties.AppSettings.Default.server = txtServidor.Text;
                    Properties.AppSettings.Default.database = cboBaseDatos.Text;
                    Properties.AppSettings.Default.applicationUser = txtUsuarioAplicacion.Text;
                    Properties.AppSettings.Default.version = cboVersion.Text;
                    Properties.AppSettings.Default.plattaform = cboPlataforma.Text;
                    Properties.AppSettings.Default.dsn = cboDSN.Text;

                    Properties.AppSettings.Default.tipoOracle = cboTipoServicio.Text;
                    Properties.AppSettings.Default.puertoOracle = txtPuerto.Text;

                    if (cboPlataforma.Text == "ODBC")
                    {
                        Properties.AppSettings.Default.user = txtUsuarioODBC.Text;
                        Properties.AppSettings.Default.password = txtPasswordODBC.Text;
                    }
                    else
                    {
                        Properties.AppSettings.Default.user = txtUsuario.Text;
                        Properties.AppSettings.Default.password = txtContrasenia.Text;
                    }

                    Properties.AppSettings.Default.Save();
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los parametros, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        
        bool GuardaConfiguracionAdicional()
        {
            // If not exists changes dont save.
            if (!hayCambiosParametros)
                return true;

            try
            {
                // PTF-4928: If environment is set, save the additional configuration in the separate group of settings
                if (!string.IsNullOrEmpty(AppSettings.ADAMEnvironment))
                {
                    // Save to settings
                    saveSetting("sitio", txtSitio.Text);
                    saveSetting("multiplesArchivos", cboMultiples.SelectedValue.ToString());
                    saveSetting("defaultCountry", cboPaisDefault.SelectedItem.ToString());

                    // Save to database
                    if (_catalogoAdicional.existeTablaConfiguracion())
                    {
                        _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.stamping_site, "sitio de timbrado", txtSitio.Text);
                        _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.generation_type, "tipo de generacion", cboMultiples.SelectedValue.ToString());
                    }

                    if (Countries.México.ToString().Equals(this.Pais))
                    {
                        // Save to settings
                        saveSetting("archivoXSLT", cboXslt.Text);
                        saveSetting("archivoXSD", cboXSD.Text);
                        saveSetting("rutaArchivos", txtRuta.Text);
                        saveSetting(ParamTimeout, txtTimeout.Text);
                        saveSetting("datosAdicionales", cboDatosAdicionales.Text);
                        saveSetting("procedimientoAdicionales", txtProcAdicionales.Text);

                        // Save to database
                        if (_catalogoAdicional.existeTablaConfiguracion())
                        {
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.xslt_file, "archivo XSLT", cboXslt.Text);
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.xsd_file, "archivo XSD", cboXSD.Text);
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.temp_path, "ruta temporal", txtRuta.Text);
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.additional_generation, "guarda datos adicionales", cboDatosAdicionales.Text);
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.additional_proc, "procedimiento adicional", txtProcAdicionales.Text);
                        }
                    }

                    if (Countries.Colombia.ToString().Equals(this.Pais))
                    {
                        // Save to settings
                        saveSetting("WSUsrID", txtWSUsrID.Text);
                        saveSetting("WSUsrPwd", txtWSUsrPwd.Text);
                        saveSetting(ParamTimeout, txtTimeout.Text);

                        // Save to database
                        if (_catalogoAdicional.existeTablaConfiguracion())
                        {
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.ws_user, "usuario servicios", txtWSUsrID.Text);
                            _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.ws_password, "password servicios", txtWSUsrPwd.Text);
                        }
                    }
                }
                else
                {
                    // Country Default
                    Properties.AppSettings.Default.defaultCountry = cboPaisDefault.SelectedItem.ToString();

                    // Properties per Country
                    switch (Enum.Parse<Countries>(this.Pais))
                    {
                        case Countries.México:
                            // Save to settings
                            Properties.AppSettings.Default.sitio = txtSitio.Text;
                            Properties.AppSettings.Default.multiplesArchivos = int.Parse(cboMultiples.SelectedValue.ToString());
                            Properties.AppSettings.Default.archivoXSLT = cboXslt.Text;
                            Properties.AppSettings.Default.archivoXSD = cboXSD.Text;
                            Properties.AppSettings.Default.rutaArchivos = txtRuta.Text;

                            Properties.AppSettings.Default.datosAdicionales = bool.Parse(cboDatosAdicionales.Text);
                            Properties.AppSettings.Default.procedimientoAdicionales = txtProcAdicionales.Text;

                            // Save to database
                            if (_catalogoAdicional.existeTablaConfiguracion())
                            {
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.stamping_site, "sitio de timbrado", txtSitio.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.generation_type, "tipo de generacion", cboMultiples.SelectedValue.ToString());
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.xslt_file, "archivo XSLT", cboXslt.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.xsd_file, "archivo XSD", cboXSD.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.temp_path, "ruta temporal", txtRuta.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.timeout, ParamTimeout, txtTimeout.Text);

                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.additional_generation, "guarda datos adicionales", cboDatosAdicionales.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.additional_proc, "procedimiento adicional", txtProcAdicionales.Text);
                            }

                            break;
                        case Countries.Colombia:
                            // Save to settings
                            Properties.AppSettings.Default.rutaArchivos = txtRuta.Text;
                            Properties.AppSettings.Default.timeout = txtTimeout.Text;
                            Properties.AppSettings.Default.WSUsrID = txtWSUsrID.Text;
                            Properties.AppSettings.Default.WSUsrPwd = txtWSUsrPwd.Text;

                            // Save to database
                            if (_catalogoAdicional.existeTablaConfiguracion())
                            {
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.temp_path, "ruta temporal", txtRuta.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.temp_path, ParamTimeout, txtTimeout.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.ws_user, "usuario servicios", txtWSUsrID.Text);
                                _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.ws_password, "password servicios", txtWSUsrPwd.Text);
                            }

                            break;
                    }

                    // Set Data
                    Properties.AppSettings.Default.Save();
                }

                // Save endpoint
                UtileriasConfig.SaveEndpointAddress(txtServicio.Text);

                // Save to database
                if (_catalogoAdicional.existeTablaConfiguracion())
                {
                    _catalogoAdicional.GuardaConfiguracionCompania(cboCompania.SelectedValue.ToString(), ConfigurationTypes.api_url, "servicio timbrado", txtServicio.Text);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar los parametros, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        
        private void BuscarBases()
        {

            cboBaseDatos.ValueMember = "name";
            cboBaseDatos.DisplayMember = "name";

            var dsAdditionalData = _catalogoAdicional.obtenBasesDisponibles();
            cboBaseDatos.DataSource = (dsAdditionalData != null && dsAdditionalData.Tables.Count > 0 
                                          ? _catalogoAdicional.obtenBasesDisponibles().Tables[0]
                                          : null
                                      );
        }
        
        private void llenaComboDSN()
        {
            ADAM.Recibos.Datos.Odbc.Clases.UtileriasODBC odbc = new Recibos.Datos.Odbc.Clases.UtileriasODBC();
            cboDSN.DataSource = odbc.EnumDsn();
        }
        
        private void ValidaConexion()
        {
            // Set Cursor
            this.Cursor = Cursors.WaitCursor;

            // Set Parameters By Platform
            if (cboPlataforma.Text == "SQL")
            {
                var br = BRReciboElectronicoHelper.CreateInstance(TipoPlataforma.SQLServer, Properties.AppSettings.Default);
                if (br.CheckDbConnection())
                {
                    MessageBox.Show("Los datos de la conexion son validos", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmdBuscar.Enabled = true;

                    // Get Languages Supported
                    _catalogoAdicional = CatalogoAdicionalHelper.CreateInstance(TipoPlataforma.SQLServer, Properties.AppSettings.Default);
                    var szLanguages = _catalogoAdicional.obtenCompaniasIdiomas();
                    if (string.IsNullOrEmpty(szLanguages))
                    {
                        this.cboPaisDefault.Items.Add("Colombia");
                        this.cboPaisDefault.Items.Add("México");
                    }
                    else
                    {
                        // Get Languages
                        var lstIdiomas = szLanguages.Split(',').ToList();
                        this.cboPaisDefault.Items.Clear();
                        foreach (var szItem in lstIdiomas)
                        {
                            this.cboPaisDefault.Items.Add((szItem.Equals(LanguageCodes.Mexico) ? "México" : "Colombia"));
                        }
                    }

                    // Set Item & Enable Country
                    this.Pais = this.cboPaisDefault.Items[0].ToString();
                    this.cboPaisDefault.SelectedIndex = 0;

                    // Add Additional Info
                    tabPrincipal.TabPages[1].Enabled = true;

                    // Enable Buttons
                    cmdAceptar.Enabled = true;
                    cboPaisDefault.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Los datos de la conexion NO son validos, favor de verificar", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmdBuscar.Enabled = false;
                    cmdAceptar.Enabled = false;
                    cboPaisDefault.Enabled = false;
                }
            }
            else
            {
                // Get Oracle Data
                var br = BRReciboElectronicoHelper.CreateInstance(TipoPlataforma.ORACLE, Properties.AppSettings.Default);

                // Set Parameters
                Hashtable parametros = new Hashtable();

                parametros["servidor"] = txtServidor.Text.Trim();
                parametros["nombreServicio"] = cboBaseDatos.Text.Trim();
                parametros["tipoOracle"] = cboTipoServicio.Text.Trim();
                parametros["puerto"] = txtPuerto.Text.Trim();
                parametros["usuario"] = txtUsuario.Text.Trim();
                parametros[ParamPassword] = txtContrasenia.Text.Trim();

                if (br.CheckDbConnection())
                {
                    MessageBox.Show("Los datos de la conexion son validos", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmdBuscar.Enabled = true;
                    cmdAceptar.Enabled = true;
                    cboPaisDefault.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Los datos de la conexion NO son validos, favor de verificar", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmdBuscar.Enabled = false;
                    cmdAceptar.Enabled = false;
                    cboPaisDefault.Enabled = false;
                }
            }

            this.Cursor = Cursors.Default;
        }
        
        private void ValidaConexionODBC()
        {
            this.Cursor = Cursors.WaitCursor;
            IBRReciboElectronico br;

            try
            {
                // Get Odbc Data
                br = BRReciboElectronicoHelper.CreateInstance(TipoPlataforma.ODBC, Properties.AppSettings.Default);

                // Set Parameters
                Hashtable parametros = new Hashtable();

                parametros["servidor"] = cboDSN.Text.Trim();
                parametros["usuario"] = txtUsuario.Text.Trim();
                parametros[ParamPassword] = txtContrasenia.Text.Trim();

                // Validate Conn
                if (br.CheckDbConnection())
                {
                    MessageBox.Show("Los datos de la conexion son validos", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmdBuscar.Enabled = true;
                    cmdAceptar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Los datos de la conexion NO son validos, favor de verificar", "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmdBuscar.Enabled = false;
                    cmdAceptar.Enabled = false;
                }

                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al validar la conexión, error: " + ex.Message + Environment.NewLine + ex.StackTrace, "ADAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private bool ValidaCampos()
        {
            // Validate Data by Platform 
            switch (cboPlataforma.SelectedItem.ToString())
            {
                case "SQL":
                    if (txtServidor.Text.Trim() == string.Empty)
                        return false;
                    if (txtUsuario.Text.Trim() == string.Empty)
                        return false;
                    if (txtContrasenia.Text.Trim() == string.Empty)
                        return false;
                    if (cboVersion.Text.Trim() == string.Empty)
                        return false;
                    if (txtUsuarioAplicacion.Text.Trim() == string.Empty)
                        return false;
                    break;
                case "ORACLE":
                    if (txtServidor.Text.Trim() == string.Empty)
                        return false;
                    if (txtUsuario.Text.Trim() == string.Empty)
                        return false;
                    if (txtContrasenia.Text.Trim() == string.Empty)
                        return false;
                    if (cboVersion.Text.Trim() == string.Empty)
                        return false;
                    if (txtUsuarioAplicacion.Text.Trim() == string.Empty)
                        return false;
                    break;
                case "ODBC":
                    if (cboDSN.Text.Trim() == string.Empty)
                        return false;
                    break;
            }
            return true;
        }
        
        private bool validaCamposAdicionales()
        {
            // Validate Data by Platform 
            switch (cboPlataforma.SelectedItem.ToString())
            {
                case "ORACLE":
                    if (txtServidor.Text.Trim() == string.Empty)
                        return false;
                    if (txtUsuario.Text.Trim() == string.Empty)
                        return false;
                    if (txtContrasenia.Text.Trim() == string.Empty)
                        return false;
                    if (cboVersion.Text.Trim() == string.Empty)
                        return false;
                    if (txtUsuarioAplicacion.Text.Trim() == string.Empty)
                        return false;
                    break;
                case "ODBC":
                    if (cboDSN.Text.Trim() == string.Empty)
                        return false;
                    break;
            }

            if (txtRuta.Text.Trim() == string.Empty)
                return false;
            if (txtServicio.Text.Trim() == string.Empty)
                return false;

            if (Countries.México.ToString().Equals(this.Pais))
            {
                if (string.IsNullOrEmpty(cboXslt.SelectedItem.ToString()))
                    return false;
                if (string.IsNullOrEmpty(cboXSD.SelectedItem.ToString()))
                    return false;
            }
            if (Countries.Colombia.ToString().Equals(this.Pais))
            {
                if (txtWSUsrID.Text.Trim() == string.Empty)
                    return false;
                if (txtWSUsrPwd.Text.Trim() == string.Empty)
                    return false;
            }
            return true;
        }
        
        private void ObtenXsltDisponibles()
        {
            if (this.AppSettings != null && this.AppSettings.ApplicationPath !=null )
            {
                DirectoryInfo dir = new DirectoryInfo(Path.Combine(this.AppSettings.ApplicationPath, "xml"));

                if (dir.Exists)
                {
                    FileInfo[] files = dir.GetFiles("*.xslt");

                    foreach (FileInfo archivo in files)
                    {
                        cboXslt.Items.Add(archivo.Name);
                    }
                }
            }
        }
        
        private void ObtenXSDDisponibles()
        {
            if (this.AppSettings != null && this.AppSettings.ApplicationPath != null)
            {
                DirectoryInfo dir = new DirectoryInfo(Path.Combine(this.AppSettings.ApplicationPath, "xml"));

                if (dir.Exists)
                {
                    FileInfo[] files = dir.GetFiles("*.xsd");

                    foreach (FileInfo archivo in files)
                    {
                        cboXSD.Items.Add(archivo.Name);
                    }
                }
            }
        }
        
        private void ConfiguraCboMultiples()
        {
            // AZ-1061: Three states can be selected
            List<Tuple<String, String>> itemList = new List<Tuple<string, string>>();
            itemList.Add(new Tuple<string, string>("0", "Un solo archivo, sin estados (Por Defecto)"));
            itemList.Add(new Tuple<string, string>("1", "Múltiples archivos, sin estados"));
            itemList.Add(new Tuple<string, string>("2", "Un archivo y restrigir por estado de recibo en servicio ADAM"));
            cboMultiples.DataSource = itemList;
            cboMultiples.DisplayMember = "item2";
            cboMultiples.ValueMember = "item1";
        }

        public bool IsNewStampingMode()
        {
            try
            {
                var compania = (this.cboCompania.SelectedItem as DataRowView).Row[0].ToString();
                DataSet dParametrosCompania = _catalogoAdicional.obtenParametrosCompania(compania);
                Func<string, string> getParametroCompania = GlobalHelper.CreateFuncGetParam(dParametrosCompania, "parametro", "valor");
                var stamping_mode = getParametroCompania("stamping_mode");
                bool result = _catalogoAdicional.existeTablaConfiguracion() && stamping_mode == "new_mode";
                return result;
            }
            catch
            {
                return false;
            }
        }

        #endregion
    }
}

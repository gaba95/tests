using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;
using ADAM.Recibos.Datos.Clases.CatalogoSAT;
using ADAM.Recibos.Principal.Clases.Helpers;
using ADAM.Recibos.Utilerias.Enums;

namespace ADAM.GeneracionRecibosElectronicos
{
    [ExcludeFromCodeCoverage]
    public partial class FrmCambiaMapeoSAT : Form
    {

        #region Properties

        private ICatalogoSat _catalogoSAT;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TipoPlataforma tipoPlataforma { get; set; } = TipoPlataforma.SQLServer;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FrmMapeoCatalogosSAT FrmMapeoCatalogosSAT { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string tipo { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string claveSat { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string compania { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string descripcion { get; set; }

        #endregion

        #region Events

        private void FrmCambiaMapeo_Load(object sender, EventArgs e)
        {
            inicializaClase();
        }

        private void cmdCambiar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            GuardaCambio();

            //Actualizar la lista de opciones disponibles
            LlenaComboValoresADAM();

            //actualiza los datos en el grid para mostrar el valor recien creado
            this.FrmMapeoCatalogosSAT.LlenaGridEquivalenciasADAM(tipo, claveSat);
            this.Cursor = Cursors.Default;

        }

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Methods

        public FrmCambiaMapeoSAT()
        {
            InitializeComponent();
        }

        private void inicializaClase()
        {
            lblDatoSAT.Text = "Dato SAT: " + claveSat;
            lblDescDatoSAT.Text = descripcion;
            _catalogoSAT = CatalogoSatHelper.CreateInstance(this.tipoPlataforma, Properties.AppSettings.Default);
            LlenaComboValoresADAM();
        }

        private void LlenaComboValoresADAM()
        {
            try
            {
                cboDatoADAM.ValueMember = "clave";
                cboDatoADAM.DisplayMember = "descripcion";
                cboDatoADAM.DataSource = _catalogoSAT.obtenCatalogoADAM(tipo, compania).Tables[0];

                if (claveSat != "")
                    cboDatoADAM.SelectedItem = claveSat;

            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al recuperar los datos, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }

        }

        private void GuardaCambio()
        {
            try
            {
                _catalogoSAT.AltaRelacionDatoCatalogoADAM(tipo, compania, claveSat, cboDatoADAM.SelectedValue.ToString().Trim());
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error al guardar el registro, error: " + ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }

        #endregion

    }
}

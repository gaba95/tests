using Moq;
using System;
using System.Data;
using System.Reflection;
using ADAM.Recibos.Datos;
using ADAM.Recibos.Datos.Clases;
using ADAM.Recibos.Datos.Clases.Common;
using ADAM.Recibos.Utilerias.Enums;
using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.DatosTests
{
    [TestClass]
    [TestCategory("LocalDb")]
    public class BRReciboElectronicoSqlLocalDbTests
    {
        private const string ConnectionString = "Server=(localdb)\\MSSQLLocalDB;Database=tempdb;Encrypt=false;";

        #region Class Setup / Teardown

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            string[] spDefinitions =
            [
                @"CREATE OR ALTER PROCEDURE dbo.sp_nomina_sat
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2), @clase_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT,
                    @concepto_factura VARCHAR(MAX) = NULL, @metodo_pago CHAR(1) = NULL,
                    @i_pago_separacion INT = NULL
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_horas_extra_sat
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2), @clase_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_incapacidades_sat
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_otros_pagos_sat
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2), @clase_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_acciones_titulos
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_jubilacion_pension_retiro
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_separacion_indemnizacion
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_subcontratacion
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0",

                @"CREATE OR ALTER PROCEDURE dbo.sp_acumulados_recibo
                    @compania CHAR(4), @trabajador CHAR(10), @tipo_nomina CHAR(2), @clase_nomina CHAR(2),
                    @anio INT, @periodo INT, @numero_liquidacion INT, @manejo_nomina INT
                  AS SELECT '' AS col1 WHERE 1=0"
            ];

            foreach (var sql in spDefinitions)
            {
                using var cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            try
            {
                using var conn = new SqlConnection(ConnectionString);
                conn.Open();

                string[] spNames =
                [
                    "sp_nomina_sat", "sp_horas_extra_sat", "sp_incapacidades_sat",
                    "sp_otros_pagos_sat", "sp_acciones_titulos", "sp_jubilacion_pension_retiro",
                    "sp_separacion_indemnizacion", "sp_subcontratacion", "sp_acumulados_recibo"
                ];

                foreach (var sp in spNames)
                {
                    using var cmd = new SqlCommand($"DROP PROCEDURE IF EXISTS dbo.{sp}", conn);
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* best-effort cleanup */ }
        }

        #endregion

        #region Helpers

        private static BRReciboElectronicoSql CreateServiceWithLocalDb()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(true);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection(ConnectionString));
            return new BRReciboElectronicoSql(mockFactory.Object);
        }

        private static Nomina CreateTestNomina(ManejoNomina manejoNomina = ManejoNomina.periodica)
        {
            return new Nomina("0001", "  90901010", "01", "01", 2026, 1, manejoNomina, 0, "1000", "1");
        }

        private static object InvokePrivateMethod(object instance, string methodName, params object[] parameters)
        {
            var method = instance.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.IsNotNull(method, $"Private method '{methodName}' should exist");
            return method.Invoke(instance, parameters);
        }

        #endregion

        #region ObtenDatasetReciboFull LocalDB Tests

        [TestMethod]
        public void ObtenDatasetReciboFull_Periodica_LocalDb_ShouldReturn8Tables()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.ObtenDatasetReciboFull("0001", "  90901010", "01", "01",
                                                        2026, 1, ManejoNomina.periodica, 0, "1000", "1");

            Assert.IsNotNull(result);
            Assert.AreEqual(8, result.Tables.Count);
            Assert.AreEqual("TablePrincipal", result.Tables[0].TableName);
            Assert.AreEqual("TableHorasExtra", result.Tables[1].TableName);
            Assert.AreEqual("TableIncapacidades", result.Tables[2].TableName);
            Assert.AreEqual("TableOtrosPagos", result.Tables[3].TableName);
            Assert.AreEqual("TableAccionesTitulos", result.Tables[4].TableName);
            Assert.AreEqual("TableJubilacionPensionRetiro", result.Tables[5].TableName);
            Assert.AreEqual("TableSeparacionIndemnizacion", result.Tables[6].TableName);
            Assert.AreEqual("TableSubcontratacion", result.Tables[7].TableName);
        }

        [TestMethod]
        public void ObtenDatasetReciboFull_Interactiva_LocalDb_ShouldReturn9TablesWithSwap()
        {
            var service = CreateServiceWithLocalDb();

            var result = service.ObtenDatasetReciboFull("0001", "  90901010", "01", "01",
                                                        2026, 1, ManejoNomina.interactiva, 0, "1000", "1");

            Assert.IsNotNull(result);
            Assert.AreEqual(9, result.Tables.Count);
            // Table swap should have occurred because TablePrincipal has 0 rows
            Assert.AreEqual("TableConceptosSeparacionZero", result.Tables[0].TableName);
            Assert.AreEqual("TablePrincipal", result.Tables[8].TableName);
        }

        #endregion

        #region ObtenDatasetRecibo LocalDB Tests

        [TestMethod]
        public void ObtenDatasetRecibo_Periodica_LocalDb_ShouldReturnDataSetWith8Tables()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina(ManejoNomina.periodica);

            var result = service.ObtenDatasetRecibo(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(8, result.Tables.Count);
            Assert.AreEqual("TablePrincipal", result.Tables[0].TableName);
            Assert.AreEqual("TableHorasExtra", result.Tables[1].TableName);
            Assert.AreEqual("TableIncapacidades", result.Tables[2].TableName);
            Assert.AreEqual("TableOtrosPagos", result.Tables[3].TableName);
            Assert.AreEqual("TableAccionesTitulos", result.Tables[4].TableName);
            Assert.AreEqual("TableJubilacionPensionRetiro", result.Tables[5].TableName);
            Assert.AreEqual("TableSeparacionIndemnizacion", result.Tables[6].TableName);
            Assert.AreEqual("TableSubcontratacion", result.Tables[7].TableName);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_Interactiva_LocalDb_ShouldReturnDataSetWith9Tables()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina(ManejoNomina.interactiva);

            var result = service.ObtenDatasetRecibo(nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(9, result.Tables.Count);
            // Table swap occurs because 0 rows in principal
            Assert.AreEqual("TableConceptosSeparacionZero", result.Tables[0].TableName);
            Assert.AreEqual("TablePrincipal", result.Tables[8].TableName);
        }

        [TestMethod]
        public void ObtenDatasetRecibo_CheckConnectionFalse_ShouldReturnNull()
        {
            var mockFactory = new Mock<IDbConnectionFactory>();
            mockFactory.Setup(f => f.ApplicationUser).Returns("TestUser");
            mockFactory.Setup(f => f.CheckConnection()).Returns(false);
            mockFactory.Setup(f => f.CreateConnection())
                       .Returns(() => new SqlConnection(ConnectionString));

            var service = new BRReciboElectronicoSql(mockFactory.Object);
            var nomina = CreateTestNomina();

            var result = service.ObtenDatasetRecibo(nomina);

            Assert.IsNull(result);
        }

        #endregion

        #region ObtenDatasetAdicionales LocalDB Tests

        [TestMethod]
        public void ObtenDatasetAdicionales_ValidProc_LocalDb_ShouldReturnDataSet()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = service.ObtenDatasetAdicionales(nomina, "sp_acumulados_recibo");

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Tables.Count > 0);
        }

        [TestMethod]
        public void ObtenDatasetAdicionales_InvalidProc_ShouldReturnNull()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = service.ObtenDatasetAdicionales(nomina, "nonexistent_proc");

            Assert.IsNull(result);
        }

        #endregion

        #region Private Method LocalDB Tests (via Reflection)

        [TestMethod]
        public void ObtenDatasetPrincipal_Periodica_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina(ManejoNomina.periodica);

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TablePrincipal", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetPrincipal_Interactiva_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina(ManejoNomina.interactiva);

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetPrincipal", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TablePrincipal", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDataseConceptosSeparacion_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina(ManejoNomina.interactiva);

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDataseConceptosSeparacion", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableConceptosSeparacion", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetHorasExtra_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetHorasExtra", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableHorasExtra", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetIncapacidades_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetIncapacidades", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableIncapacidades", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetOtrosPagos_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetOtrosPagos", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableOtrosPagos", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetAccionesTitulos_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetAccionesTitulos", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableAccionesTitulos", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetJubilacionPensionRetiro_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetJubilacionPensionRetiro", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableJubilacionPensionRetiro", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetSeparacionIndemnizacion_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetSeparacionIndemnizacion", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableSeparacionIndemnizacion", result.Tables[0].TableName);
        }

        [TestMethod]
        public void ObtenDatasetSubcontratacion_LocalDb_ShouldReturnDataSetWithTableName()
        {
            var service = CreateServiceWithLocalDb();
            var nomina = CreateTestNomina();

            var result = (DataSet)InvokePrivateMethod(service, "ObtenDatasetSubcontratacion", nomina);

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Tables.Count);
            Assert.AreEqual("TableSubcontratacion", result.Tables[0].TableName);
        }

        #endregion
    }
}

using ADAM.Recibos.Utilerias.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADAM.Recibos.Utilerias.Tests.Clases
{
    [TestClass]
    public class TipoPlataformaTests
    {
        [TestMethod]
        public void TipoPlataforma_SQLServer_HasValue1()
        {
            Assert.AreEqual(1, (int)TipoPlataforma.SQLServer);
        }

        [TestMethod]
        public void TipoPlataforma_ORACLE_HasValue2()
        {
            Assert.AreEqual(2, (int)TipoPlataforma.ORACLE);
        }

        [TestMethod]
        public void TipoPlataforma_ODBC_HasValue3()
        {
            Assert.AreEqual(3, (int)TipoPlataforma.ODBC);
        }

        [TestMethod]
        public void TipoPlataforma_ContainsThreeValues()
        {
            var values = Enum.GetValues(typeof(TipoPlataforma));
            Assert.AreEqual(3, values.Length);
        }

        [TestMethod]
        [DataRow(TipoPlataforma.SQLServer)]
        [DataRow(TipoPlataforma.ORACLE)]
        [DataRow(TipoPlataforma.ODBC)]
        public void TipoPlataforma_AllValues_AreDefined(TipoPlataforma tipo)
        {
            Assert.IsTrue(Enum.IsDefined(typeof(TipoPlataforma), tipo));
        }
    }
}

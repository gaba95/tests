using ADAM.Recibos.Principal;
using System.ComponentModel;

namespace ADAM.Recibos.Principal.Tests.Classes
{
    [TestClass]
    public class CallBackThreadTests
    {
        /// <summary>
        /// Lightweight fake that replaces System.Windows.Forms.Control for CI-safe testing.
        /// </summary>
        private sealed class FakeSynchronizeInvoke : ISynchronizeInvoke
        {
            public bool InvokeRequired => false;

            public IAsyncResult BeginInvoke(Delegate method, object[]? args)
            {
                method.DynamicInvoke(args);
                return null!;
            }

            public object? EndInvoke(IAsyncResult result) => null;

            public object? Invoke(Delegate method, object[]? args)
            {
                return method.DynamicInvoke(args);
            }
        }

        [TestMethod]
        public void Constructor_WithThreadFunctionDelegate_SetsProperties()
        {
            var invoker = new FakeSynchronizeInvoke();
            ThreadFunctionDelegate threadFunc = () => { };
            CallBackDelegate callback = (s, r) => { };

            var cbt = new CallBackThread(invoker, threadFunc, callback);

            Assert.AreEqual(invoker, cbt.BaseControl);
            Assert.IsFalse(cbt.Cancelar);
        }

        [TestMethod]
        public void Constructor_WithFuncTask_SetsProperties()
        {
            var invoker = new FakeSynchronizeInvoke();
            Func<Task> threadFunc = () => Task.CompletedTask;
            CallBackDelegate callback = (s, r) => { };

            var cbt = new CallBackThread(invoker, threadFunc, callback);

            Assert.AreEqual(invoker, cbt.BaseControl);
            Assert.IsFalse(cbt.Cancelar);
        }

        [TestMethod]
        public void Cancelar_SetAndGet_Works()
        {
            var cbt = new CallBackThread(null, () => Task.CompletedTask, (s, r) => { });
            cbt.Cancelar = true;
            Assert.IsTrue(cbt.Cancelar);
        }

        [TestMethod]
        public async Task Start_FirstTime_StartsThread()
        {
            bool executed = false;
            var cbt = new CallBackThread(null, () => { executed = true; return Task.CompletedTask; }, (s, r) => { });

            cbt.Start();

            await Task.Delay(500);
            Assert.IsTrue(executed);
        }

        [TestMethod]
        public void Start_CalledTwice_ThrowsException()
        {
            var cbt = new CallBackThread(null, () => Task.CompletedTask, (s, r) => { });

            cbt.Start();

            var ex = Assert.ThrowsExactly<InvalidOperationException>(() => cbt.Start());
            Assert.AreEqual("Thread ya iniciado", ex.Message);
        }

        [TestMethod]
        public void UpdateUI_WhenBaseControlIsNull_DoesNotThrow()
        {
            var cbt = new CallBackThread(null, () => Task.CompletedTask, (s, r) => { });

            Exception? caught = null;
            try
            {
                cbt.UpdateUI("test", false);
            }
            catch (Exception ex)
            {
                caught = ex;
            }

            Assert.IsNull(caught, "Expected no exception when baseControl is null.");
        }

        [TestMethod]
        public void UpdateUI_WhenBaseControlNotNull_NullCallback_DoesNotInvoke()
        {
            var cbt = new CallBackThread(new FakeSynchronizeInvoke(), () => Task.CompletedTask, null!);

            Exception? caught = null;
            try
            {
                cbt.UpdateUI("test", false);
            }
            catch (Exception ex)
            {
                caught = ex;
            }

            Assert.IsNull(caught, "Expected no exception when callback is null.");
        }

        [TestMethod]
        public void UpdateUI_WhenBothNotNull_InvokesCallback()
        {
            string receivedStatus = null!;
            bool receivedReset = true;
            CallBackDelegate callback = (s, r) => { receivedStatus = s; receivedReset = r; };
            var cbt = new CallBackThread(new FakeSynchronizeInvoke(), () => Task.CompletedTask, callback);

            cbt.UpdateUI("test", false);

            Assert.AreEqual("test", receivedStatus);
            Assert.IsFalse(receivedReset);
        }

        [TestMethod]
        public async Task Dispose_WhenThreadIsRunning_ThrowsPlatformNotSupported()
        {
            var cbt = new CallBackThread(null, () => { Task.Delay(5000).Wait(); return Task.CompletedTask; }, (s, r) => { });
            cbt.Start();
            await Task.Delay(100);

            // Thread.Abort() is not supported on .NET 5+
            Assert.ThrowsExactly<PlatformNotSupportedException>(() => ((IDisposable)cbt).Dispose());
        }

        [TestMethod]
        public async Task Dispose_WhenThreadIsStopped_DisposesCleanly()
        {
            var cbt = new CallBackThread(null, () => Task.CompletedTask, (s, r) => { });
            cbt.Start();
            await Task.Delay(500);

            ((IDisposable)cbt).Dispose();

            Assert.IsNull(cbt.BaseControl);
        }

        [TestMethod]
        public void Dispose_WhenNotStarted_ThrowsPlatformNotSupported()
        {
            var cbt = new CallBackThread(null, () => Task.CompletedTask, (s, r) => { });

            // Thread not started → ThreadState is Unstarted (not Stopped) → Abort throws
            Assert.ThrowsExactly<PlatformNotSupportedException>(() => ((IDisposable)cbt).Dispose());
        }

        [TestMethod]
        public async Task Dispose_CalledTwice_AfterThreadStopped_DoesNotThrow()
        {
            var cbt = new CallBackThread(null, () => Task.CompletedTask, (s, r) => { });
            cbt.Start();
            await Task.Delay(500);

            ((IDisposable)cbt).Dispose();

            // Second call is safely guarded by _disposedValue flag
            ((IDisposable)cbt).Dispose();
            Assert.IsNull(cbt.BaseControl);
        }
    }
}
